package locadora;

public class Filme {
	public static final int INFANTIL = 2;
	public static final int NORMAL = 0;
	public static final int LAN�AMENTO =1;

	private String _t�tulo;
	private int _c�digoPre�o;

	public Filme(String t�tulo, int codigoPre�o) {
		_t�tulo = t�tulo;
		_c�digoPre�o = codigoPre�o;
	}

	public int getC�digoPre�o() { return _c�digoPre�o; }

	public void setC�digoPre�o(int arg) {_c�digoPre�o = arg; }

	public String getT�tulo() {	return _t�tulo;	}

} //end Filme
