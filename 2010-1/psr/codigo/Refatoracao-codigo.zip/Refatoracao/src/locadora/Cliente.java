package locadora;

import java.util.LinkedList;
import java.util.List;

public class Cliente {
	private String _nome;
	private List<Loca��o> _loca��es = new LinkedList<Loca��o>();

	public Cliente(String nome) {
		_nome = nome;
	}
	
	public void adicionarLoca��o(Loca��o arg) {
		_loca��es.add(arg);
	}

	public String getNome() {
		return _nome;
	}

	public String Conta() {
		String resultado = "Registro de loca��o de " + getNome() + "\n";
		for (Loca��o cada : _loca��es){
			//mostrar valores para esta loca��o
			resultado += "\t" + cada.getFilme().getT�tulo() + "\t" +
					String.valueOf(cada.getPre�o()) + "\n";
		} // end for
		//adicionar linhas de rodap�;
		resultado += "O valor devido � " + String.valueOf(getPre�oTotal())+ "\n";
		resultado += "Voc� ganhou " + String.valueOf(getTotalPontosLocadorFreq�ente()) +
			" pontos de locador freq�ente";
		return resultado;
	} // end conta
	
	public double getPre�oTotal() {
		double resultado = 0;
		for (Loca��o cada : _loca��es){
			resultado += cada.getPre�o();
		}
		return resultado;
	}
	
	private int getTotalPontosLocadorFreq�ente() {
		int resultado = 0;
		for (Loca��o cada : _loca��es){
			resultado = cada.getPontosLocadorFrequente(resultado);
		}
		return resultado;
	}

	

}//end class 