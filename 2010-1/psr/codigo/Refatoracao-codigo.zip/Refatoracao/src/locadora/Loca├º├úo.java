package locadora;

public class Loca��o {
	private Filme _filme;
	private int _diasAlugados; 
	
	public Loca��o(Filme _filme, int diasAlugados) {
		this._filme = _filme;
		this._diasAlugados = diasAlugados;
	}

	public int getDiasAlugados() {
		return _diasAlugados;
	}

	public Filme getFilme() {
		return _filme;
	}

	double getPre�o() {
		double resultado = 0;
		//determinar quantias para cada linha
		switch (getFilme().getC�digoPre�o()) {
		case Filme.NORMAL:
			resultado +=2;
			if (getDiasAlugados() > 2)
				resultado += (getDiasAlugados() - 2) * 1.5;
			break;
		case Filme.LAN�AMENTO:
			resultado += getDiasAlugados() * 3;
			break;
		case Filme.INFANTIL:
			resultado += 1.5;
			if (getDiasAlugados() >3)
				resultado += (getDiasAlugados() -3) *1.5;
			break;
		}// end switch
		return resultado;
	}

	int getPontosLocadorFrequente(int pontosLocadorFreq�ente) {
		// adicionar os pontos do locador freq�ente
		pontosLocadorFreq�ente++;
		//adicionar b�nus para uma loca��o de lan�amentos por dois dias
		if ((getFilme().getC�digoPre�o() == Filme.LAN�AMENTO) &&
				getDiasAlugados() >1)
			pontosLocadorFreq�ente++;
		return pontosLocadorFreq�ente;
	}	
}
