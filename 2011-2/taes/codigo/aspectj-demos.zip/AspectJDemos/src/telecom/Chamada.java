package telecom;

import java.util.List;
import java.util.Vector;

/**
 * Uma chamada da apoio no processo de um cliente tentando conectar
 * a outros clientes.
 */
public class Chamada {

	private Cliente ligador, recebedor;
	private List<Conexao> conexoes = new Vector<Conexao>();

	public Chamada(Cliente ligador, Cliente recebedor) {
		this.ligador = ligador;
		this.recebedor = recebedor;
		Conexao c;
		if (recebedor.mesmoCodigoArea(ligador)) {
			c = new ConexaoLocal(ligador, recebedor);
		} else {
			c = new ConexaoLongaDistancia(ligador, recebedor);
		}
		conexoes.add(c);
	}

	public void atender() {
		getLastConnection().conectar();
	}

	public boolean estaConectado() {
		return getLastConnection().foiCompletada();
	}

	public void desligar(Cliente c) {
		for (Conexao con : conexoes) {
			con.desconectar();
		}
	}

	private Conexao getLastConnection() {
		return conexoes.get(conexoes.size() - 1);
	}
}