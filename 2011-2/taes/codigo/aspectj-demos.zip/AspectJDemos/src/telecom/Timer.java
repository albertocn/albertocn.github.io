package telecom;

/**
 * Timer simples usado para contar o tempo decorrido.
 */
public class Timer {
	public long startTime, stopTime;

	/**
	 * Inicia o timer guardando o tempo corrente
	 */
	public void start() {
		stopTime = startTime = System.currentTimeMillis();
	}

	/**
	 * Para o timer guardando o tempo corrente
	 */
	public void stop() {
		stopTime = System.currentTimeMillis();
	}

	/** 
	 * Tempo decorrido entre o start e stop 
	 */
	public long getTime() {
		return stopTime - startTime;
	}
}