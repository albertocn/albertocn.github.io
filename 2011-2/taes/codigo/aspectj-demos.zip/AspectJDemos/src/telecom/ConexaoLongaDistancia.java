package telecom;

/** Representa uma conexao entre clientes de codigos de area diferentes */
public class ConexaoLongaDistancia extends Conexao {
	ConexaoLongaDistancia(Cliente a, Cliente b) {
		super(a, b);
		System.out.println("[nova conexao de longa distancia de " + a + " to "
				+ b + "]");
	}
}
