package telecom.simulacao;

import telecom.Cliente;
import telecom.Cobranca;

/**
 * Simulacao que conta o tempo total de conexao e o gasto.
 */
public class SimulacaoCobranca extends SimulacaoAbstrata {

	public static void main(String[] args) {
		System.out.println("\n... Simulacao de Cobranca ...\n");
		new SimulacaoCobranca().run();
	}

	protected void reportar(Cliente c) {
		Cobranca b = Cobranca.aspectOf();
		System.out.println(c + " ficou conectado por "
				+ c.getTempoConectadoTotal() + " ms e tem uma conta de R$"
				+ b.calcularCobrancaTotal(c));
	}
}
