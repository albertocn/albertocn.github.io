package telecom.simulacao;

import telecom.Cliente;

/**
 * Subclasse que faz a simulacao apenas com os objetos basicos.
 */
public class SimulacaoBasica extends SimulacaoAbstrata {

	public static void main(String[] args) {
		new SimulacaoBasica().run();
	}

	protected void reportar(Cliente c) {
	}

}
