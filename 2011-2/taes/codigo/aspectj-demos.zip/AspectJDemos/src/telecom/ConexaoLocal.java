package telecom;

/** Representa uma conexao dentro de um mesmo codigo de area */
public class ConexaoLocal extends Conexao {
	ConexaoLocal(Cliente a, Cliente b) {
		super(a, b);
		System.out
				.println("[nova conexao local de " + a + " to " + b + "]");
	}
}
