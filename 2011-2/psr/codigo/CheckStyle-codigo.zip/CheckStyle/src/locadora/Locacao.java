package locadora;

public class Locacao {
	private Filme _filme;
	private int _diasAlugados; 
	
	public Locacao(Filme _filme, int diasAlugados) {
		this._filme = _filme;
		this._diasAlugados = diasAlugados;
	}

	public int getDiasAlugados() {
		return _diasAlugados;
	}

	public Filme getFilme() {
		return _filme;
	}	
}
