package locadora;

import java.util.List;
import java.util.LinkedList;

public class Cliente {
	
	private String _nome;
	private List<Locacao> _loca��es = new LinkedList<Locacao>();

	public Cliente(String nome) {
		_nome = nome;
	}
	
	public void adicionarLocacao(Locacao arg) {
		_loca��es.add(arg);
	}

	public String getNome() {
		return _nome;
	}
	
	public String Conta() {
		double quantiaTotal = 0;
		int pontosLocadorFreq�ente = 0;
		String resultado = "Registro de loca��o de " + getNome() + "\n";
		for (Locacao cada : _loca��es){
			double estaQuantia = 0;
			//determinar quantias para cada linha
			switch (cada.getFilme().getC�digoPre�o()) {
			case Filme.NORMAL:
				estaQuantia +=2;
				if (cada.getDiasAlugados() > 2)
					estaQuantia += (cada.getDiasAlugados() - 2) * 1.5;
				break;
			case Filme.LAN�AMENTO:
				estaQuantia += cada.getDiasAlugados() * 3;
				break;
			case Filme.INFANTIL:
				estaQuantia += 1.5;
				if (cada.getDiasAlugados() >3)
					estaQuantia += (cada.getDiasAlugados() -3) *1.5;
				break;
			}// end switch
			
			// adicionar os pontos do locador freq�ente
			pontosLocadorFreq�ente++;
			//adicionar b�nus para uma loca��o de lan�amentos por dois dias
			if ((cada.getFilme().getC�digoPre�o() == Filme.LAN�AMENTO) &&
					cada.getDiasAlugados() >1)
				pontosLocadorFreq�ente++;
			//mostrar valores para esta loca��o
			resultado += "\t" + cada.getFilme().getT�tulo() + "\t" +
					String.valueOf(estaQuantia) + "\n";
			quantiaTotal += estaQuantia;
		} // end for
		//adicionar linhas de rodap�;
		resultado += "O valor devido � " + String.valueOf(quantiaTotal)+ "\n";
		resultado += "Voc� ganhou " + String.valueOf(pontosLocadorFreq�ente) +
			" pontos de locador freq�ente";
		return resultado;
	} // end conta

}//end class 