package iterator;

/**
 * Interface que define as opera��es existentes em uma estrutura de dados 
 * com suporte a iteradores internos e externos
 *
 * @author Alberto Costa Neto
 */
public interface EstruturaDeDados {

    /**
     * Factory Method que retorna um objeto Iterador para varrer a
     * estrutura de dados
     */
    Iterador criarIterador();

    /**
     * Varre todos os elementos da estrutura de dados, chamando os
     * m�todos do objeto Processador passado
     *
     * @param p Processador que receber� chamadas para processar
     *          cada item da estrutura de dados
     */
    void processar(Processador p);
}