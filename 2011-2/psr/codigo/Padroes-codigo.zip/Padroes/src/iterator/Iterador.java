package iterator;

/**
 * Interface que define os m�todos dispon�veis em um iterador
 *
 * @author Alberto Costa Neto
 */
public interface Iterador {

    /**
     * Retorna true se h� mais elementos na estrutura de dados a serem
     * varridos
     */
    boolean temProximo();

    /**
     * Retorna o pr�ximo elemento contido na estrutura de dados. Caso
     * n�o hava, uma exce��o ser� levantada. Deve-se evitar chamar
     * esse m�todo sem antes chamar temProximo para ter certeza de que
     * realmente h� um pr�ximo
     */
    Object proximo();
}