package iterator;

import java.util.List;
import java.util.Vector;

/**
 * Classe que implementa uma estrutura de dados do tipo Pilho (Primeiro
 * a entrar, primeiro a sair)
 *
 * @author Alberto Costa Neto
 */
public class Pilha implements EstruturaDeDados {

    private List pilha = new Vector();

    /**
     * Insere o objeto passado no topo da pilha
     *
     * @param obj Objeto que ser� adicionado � pilha
     */
    public void empilhar(Object obj) {
        pilha.add(pilha.size(), obj);
    }

    /**
     * Retorna o objeto que est� no topo da pilha. Caso n�o haja
     * nenhum objeto na posi��o, retorna null
     */
    public Object topo() {
        if (pilha.isEmpty()) {
            return null;
        }
        return pilha.get(pilha.size() - 1);
    }


    /**
     * Remove e retorna o objeto que est� no topo da pilha. Caso n�o haja
     * nenhum objeto na posi��o, retorna null
     */
    public Object desempilhar() {
        if (pilha.isEmpty()) {
            return null;
        }
        return pilha.remove(pilha.size() - 1);
    }

    /**
     * Cria um Iterador que caminha do topo para a base da pilha
     */
    public Iterador criarIterador() {
        return new IteradorParaPilha();
    }

    /**
     * Processa os elementos da pilha no sentido topo -> base
     */
    public void processar(Processador p) {
        for (int i = pilha.size() - 1; i >= 0; i--) {
            if (!p.deveContinuar()) {
                break;
            }
            p.processarItem(pilha.get(i));
        }
    }

    /**
     * Inner Class que implementa um Iterador para Pilha. Tem acesso
     * aos dados da pilha, possibilitando o caminhamento na mesma
     */
    private class IteradorParaPilha implements Iterador {
        private int pos = pilha.size() - 1;

        public boolean temProximo() {
            return pos >= 0;
        }

        public Object proximo() {
            return pilha.get(pos--);
        }
    }
}