package iterator;

import java.util.List;
import java.util.Vector;

/**
 * Classe que implementa uma estrutura de dados do tipo Fila (Primeiro
 * a entrar, �ltimo a sair)
 *
 * @author Alberto Costa Neto
 */
public class Fila implements EstruturaDeDados {

    private List fila = new Vector();

    /**
     * Insere o objeto no fundo da fila.
     */
    public void inserir(Object obj) {
        fila.add(0, obj);
    }

    /**
     * Retorna o objeto que ocupa a primeira posi��o na fila.
     * Caso n�o haja nenhum objeto na posi��o, retorna null
     */
    public Object pegar() {
        return fila.get(fila.size() - 1);
    }

    /**
     * Remove e retorna o objeto que ocupa a �ltima posi��o na
     * fila. Caso n�o haja nenhum objeto na posi��o, retorna null
     */
    public Object retirar() {
        return fila.remove(fila.size() - 1);
    }

    /**
     * Cria um Iterador que caminha da frente para o fundo da fila
     */
    public Iterador criarIterador() {
        return new IteradorParaFila();
    }

    /**
     * Processa os elementos da fila no sentido frente -> fundo
     */
    public void processar(Processador p) {
        for (int i = fila.size() - 1; i >= 0; i--) {
            if (!p.deveContinuar()) {
                break;
            }
            p.processarItem(fila.get(i));
        }
    }

    /**
     * Inner Class que implementa um Iterador para Fila. Tem acesso
     * aos dados da fila, possibilitando o caminhamento na mesma
     */
    private class IteradorParaFila implements Iterador {

        private int pos = fila.size() - 1;

        public boolean temProximo() {
            return pos >= 0;
        }

        public Object proximo() {
            return fila.get(pos--);
        }
    }
}