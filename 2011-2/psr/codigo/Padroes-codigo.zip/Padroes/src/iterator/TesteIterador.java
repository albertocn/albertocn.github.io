package iterator;

public class TesteIterador {

    /**
     * Cria uma Fila que cont�m as strings passadas. Adiciona as strings
     * � fila na ordem crescente dos �ndices do array
     */
    public EstruturaDeDados criarFila(String[] strings) {
        Fila fila = new Fila();

        for (int i = 0; i < strings.length; i++) {
            fila.inserir(strings[i]);
        }

        return fila;
    }


    /**
     * Cria uma Pilha que cont�m as strings passadas. Adiciona as strings
     * � pilha na ordem crescente dos �ndices do array
     */
    public EstruturaDeDados criarPilha(String[] strings) {
        Pilha pilha = new Pilha();

        for (int i = 0; i < strings.length; i++) {
            pilha.empilhar(strings[i]);
        }

        return pilha;
    }


    /**
     * Imprime a mensagem passada seguida dos elementos acess�veis
     * atrav�s do iterador
     */
    public void imprimir(String msg, Iterador it) {
        System.out.print(msg + " [");

        while (it.temProximo()) {
            System.out.print(it.proximo());

            if (it.temProximo()) {
                System.out.print(",");
            }
        }

        System.out.println("]");
    }


    /**
     * Imprime a mensagem passada e aciona o iterador interno da
     * estrutura de dados passando um processador que imprime cada
     * elemento da estrutura
     */
    public void processar(String msg, EstruturaDeDados ed) {
        System.out.print(msg + " [ ");

        ed.processar(new ProcessadorQueImprime());

        System.out.println("]");
    }


    public static void main(String[] args) {
        TesteIterador ti = new TesteIterador();

        String[] vogaisMin = { "a", "e", "i", "o", "u" };
        String[] vogaisMai = { "A", "E", "I", "O", "U" };

        ti.imprimir("Fila", ti.criarFila(vogaisMin)
                              .criarIterador());

        ti.imprimir("Pilha", ti.criarPilha(vogaisMin)
                               .criarIterador());

        ti.processar("Fila",  ti.criarFila(vogaisMai));
        ti.processar("Pilha", ti.criarPilha(vogaisMai));
    }
}


class ProcessadorQueImprime implements Processador {

    public void processarItem(Object o) {
        System.out.print(o + " ");
    }

    public boolean deveContinuar() {
        return true;
    }
}