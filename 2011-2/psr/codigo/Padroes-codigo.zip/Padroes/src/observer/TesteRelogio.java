package observer;

public class TesteRelogio {

    public static void main(String args[]) {

        Relogio relogio = new Relogio(100);

        RelogioFrame rf = new RelogioFrame(relogio);
        rf.pack();
        rf.setDefaultCloseOperation(RelogioFrame.EXIT_ON_CLOSE);
        rf.setVisible(true);

        relogio.addRelogioListener(new RelogioSaidaPadrao());
        relogio.addRelogioListener(rf);
    }
}
