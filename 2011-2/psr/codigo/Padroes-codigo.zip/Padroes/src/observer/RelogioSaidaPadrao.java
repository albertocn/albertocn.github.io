package observer;

public class RelogioSaidaPadrao implements RelogioListener {

    private RelogioEvent ultimoRelogioEvent = null;

    public void atualizar(RelogioEvent re) {
        if (dataMudou(re))
            imprimir(re);

        ultimoRelogioEvent = re;
    }

    private boolean dataMudou(RelogioEvent re) {

        if (ultimoRelogioEvent != null)
            if (ultimoRelogioEvent.equals(re))
                return false;

        return true;
    }


    private void imprimir(RelogioEvent re) {
        System.out.println("Data/Hora atual: " +
                           re.getDia()    + "/" + re.getMes()  + "/" +
                           re.getAno()    + " " + re.getHora() + ":" +
			               re.getMinuto() + ":" + re.getSegundo());
    }
}