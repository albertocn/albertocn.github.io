package observer;

/**
 * Interface que deve ser implementada por qualquer classe interessada
 * em se tornar um Listener de eventos da classe Relogio
 *
 * @author Alberto Costa Neto
 */
public interface RelogioListener {

    /**
     * M�todo que � acionado por um Relogio quando houver alguma
     * mudan�a em seu estado
     *
     * @param re RelogioEvent que permite ter acesso ao Rel�gio e tamb�m
     *           traz informa��es sobre a data/hora atual
     */
    void atualizar(RelogioEvent re);
}