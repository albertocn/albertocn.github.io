package br.ufs.dcomp.testes.util;

import junit.framework.*;

/**
 * Aciona todos os TestCases do pacote
 *
 * @author Alberto Costa Neto
 */
public class TestAll extends TestCase {

    TestAll(String nome) {
        super(nome);
    }

    /**
     * Retorna a su�te de testes
     */
    public static Test suite() {
        TestSuite result = new TestSuite();
        result.addTest(QueueTest.suite());
        result.addTest(StackTest.suite());
        return result;
    }

    /**
     * Executa o JUnit para testar a classe
     */
    public static void main(String[] args) {
        junit.textui.TestRunner.run(suite());
    }
}

