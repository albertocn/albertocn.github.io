package br.ufs.dcomp.testes.util;

import br.ufs.dcomp.util.Stack;

import java.util.Arrays;
import java.util.Iterator;

import junit.framework.*;

/**
 * Utilizada para testes de unidade da classe
 * br.ufs.dcomp.util.Stack
 *
 * @author Alberto Costa Neto
 */
public class StackTest extends TestCase {

    // Atributos privados
    private Stack stack = null;

    /**
     * Construtor padr�o
     */
    public StackTest(String nome) {
        super(nome);
    }

    // Executado antes de cada m�todo de teste
    protected void setUp() {
        stack = new Stack();
    }

    // Executado antes de cada m�todo de teste
    protected void tearDown() {
        stack = null;
    }

    /**
     * Testa o m�todo top
     */
    public void testTop() {
        stack.insert("A");
        stack.insert("B");
        stack.insert("C");

        String s1 = (String) stack.top();
        String s2 = (String) stack.top();
        String s3 = (String) stack.top();

        assertEquals("Deveria retira a mesma string", s1, "C");
        assertEquals("Deveria retira a mesma string", s2, "B");
        assertEquals("Deveria retira a mesma string", s3, "A");
    }

    /**
     * Testa o m�todo insert, top
     */
    public void testGeral() {
        Object[] objects = new Object[50];

        for (int i = 0; i < objects.length; i++) {
            objects[i] = new Object();
            stack.insert(objects[i]);
        }

        assertEquals(objects.length, stack.size());
        assertTrue("N�o deve estar mais vazia", !stack.isEmpty());

        Object[] copia = new Object[objects.length];
        for (int i = copia.length; i > 0; i--) {
            copia[i - 1] = stack.top();
        }

        assertEquals(0, stack.size());
        assertTrue("Deve estar vazia", stack.isEmpty());

        assertTrue("Arrays devem ser iguais", Arrays.equals(objects, copia));
    }

    /**
     * Testa o iterator
     */
    public void testIterator() {

        Iterator it = stack.iterator();
        assertTrue("N�o deve ter pr�ximo", !it.hasNext());

        Object[] objects = new Object[3];
        for (int i = 0; i < objects.length; i++) {
            objects[i] = new Object();
            stack.insert(objects[i]);
        }

        Object[] retirados = new Object[objects.length];
        it = stack.iterator();

        int pos = objects.length - 1;
        while (it.hasNext()) {
            retirados[pos] = it.next();
            pos--;
            stack.top(); // Remo��o enquanto percorre a cole��o
        }

        assertTrue("Arrays devem ser iguais", Arrays.equals(objects, retirados));
        assertTrue("Deve estar vazia", stack.isEmpty());
    }

    /**
     * Testa os m�todos clear, isEmpty e size
     */
    public void testClearIsEmptySize() {
        assertTrue("Deve estar vazia", stack.isEmpty());
        assertEquals(stack.size(), 0);

        stack.insert(new Object());

        assertTrue("N�o deve estar vazia", !stack.isEmpty());
        assertEquals(stack.size(), 1);

        stack.top();

        assertTrue("Deve estar vazia", stack.isEmpty());
        assertEquals(stack.size(), 0);

        int num = 10;
        for (int i = 0; i < num; i++) {
            stack.insert(new Object());
        }

        assertTrue("N�o deve estar vazia", !stack.isEmpty());
        assertEquals(stack.size(), num);

        stack.clear();

        assertTrue("Deve estar vazia", stack.isEmpty());
        assertEquals(stack.size(), 0);
    }

    /**
     * Retorna a su�te de testes
     */
    public static Test suite() {
        TestSuite suite= new TestSuite();
        suite.addTest(new StackTest("testTop"));
        suite.addTest(new StackTest("testGeral"));
        suite.addTest(new StackTest("testIterator"));
        suite.addTest(new StackTest("testClearIsEmptySize"));
        return suite;
    }

    /**
     * Executa o JUnit para testar a classe
     */
    public static void main(String[] args) {
        junit.textui.TestRunner.run(suite());
    }
}
