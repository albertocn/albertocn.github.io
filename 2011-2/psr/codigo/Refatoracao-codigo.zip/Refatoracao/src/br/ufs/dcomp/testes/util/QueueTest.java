package br.ufs.dcomp.testes.util;

import br.ufs.dcomp.util.Queue;

import java.util.Arrays;
import java.util.Iterator;

import junit.framework.*;

/**
 * Utilizada para testes de unidade da classe
 * br.ufs.dcomp.util.Queue
 *
 * @author Alberto Costa Neto
 */
public class QueueTest extends TestCase {

    // Atributos privados
    private Queue queue = null;

    /**
     * Construtor padr�o
     */
    public QueueTest(String nome) {
        super(nome);
    }

    // Executado antes de cada m�todo de teste
    protected void setUp() {
        queue = new Queue();
    }

    // Executado depois de cada m�todo de teste
    protected void tearDown() {
        queue = null;
    }

    /**
     * Testa o m�todo front
     */
    public void testFront() {
        queue.insert("A");
        queue.insert("B");
        queue.insert("C");

        String s1 = (String) queue.front();
        String s2 = (String) queue.front();
        String s3 = (String) queue.front();

        assertEquals("Deveria retira a mesma string", "A", s1);
        assertEquals("Deveria retira a mesma string", "B", s2);
        assertEquals("Deveria retira a mesma string", "C", s3);
    }

    /**
     * Testa o m�todo insert, front
     */
    public void testGeral() {
        Object[] objects = new Object[50];

        for (int i = 0; i < objects.length; i++) {
            objects[i] = new Object();
            queue.insert(objects[i]);
        }

        assertEquals(objects.length, queue.size());
        assertTrue("N�o deve estar mais vazia", !queue.isEmpty());

        Object[] copia = new Object[objects.length];
        for (int i = 0; i < copia.length; i++) {
            copia[i] = queue.front();
        }

        assertEquals(0, queue.size());
        assertTrue("Deve estar vazia", queue.isEmpty());

        assertTrue("Arrays devem ser iguais", Arrays.equals(objects, copia));
    }

    /**
     * Testa o iterator
     */
    public void testIterator() {

        Iterator it = queue.iterator();
        assertTrue("N�o deve ter pr�ximo", !it.hasNext());

        Object[] objects = new Object[3];
        for (int i = 0; i < objects.length; i++) {
            objects[i] = new Object();
            queue.insert(objects[i]);
        }

        Object[] retirados = new Object[objects.length];
        it = queue.iterator();

        int pos = 0;
        while (it.hasNext()) {
            retirados[pos] = it.next();
            pos++;
            queue.front(); // Remo��o enquanto percorre a cole��o
        }

        assertTrue("Arrays devem ser iguais", Arrays.equals(objects, retirados));
        assertTrue("Deve estar vazia", queue.isEmpty());
    }

    /**
     * Testa os m�todos clear, isEmpty e size
     */
    public void testClearIsEmptySize() {
        assertTrue("Deve estar vazia", queue.isEmpty());
        assertEquals(queue.size(), 0);

        queue.insert(new Object());

        assertTrue("N�o deve estar vazia", !queue.isEmpty());
        assertEquals(queue.size(), 1);

        queue.front();

        assertTrue("Deve estar vazia", queue.isEmpty());
        assertEquals(queue.size(), 0);

        int num = 10;
        for (int i = 0; i < num; i++) {
            queue.insert(new Object());
        }

        assertTrue("N�o deve estar vazia", !queue.isEmpty());
        assertEquals(queue.size(), num);

        queue.clear();

        assertTrue("Deve estar vazia", queue.isEmpty());
        assertEquals(queue.size(), 0);
    }

    /**
     * Testa se ao inserir null lan�a uma IllegalArgumentException.
     */
    public void testInsertComNull() {
      try {
        queue.insert(null);
        fail("insert deveria lan�ar uma exce��o quando seu parametro for null");
      }
      catch (IllegalArgumentException ex) {
        // Deveria entrar aqui
        return;
      }
    }

    /**
     * Retorna a su�te de testes
     */
    public static Test suite() {
        return new TestSuite(QueueTest.class);
    }

    /**
     * Executa o JUnit para testar a classe
     */
    public static void main(String[] args) {
        junit.textui.TestRunner.run(suite());
    }
}
