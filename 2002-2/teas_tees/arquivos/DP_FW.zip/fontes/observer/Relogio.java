package observer;

import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

/**
 * Classe que implementa um rel�gio. Ele tem a responsabilidade de
 * notificar cada cliente no intevalo de tempo especificado
 * Utiliza o padr�o Observer
 *
 * @author Alberto Costa Neto
 * @date   02/03/2001
 */
public class Relogio implements Runnable {

    // Lista que mant�m os listeners
    private List listeners = new Vector();

    private int intervalo;


    // Construtor protegido contra tentativas inv�lidas de instancia��o
    private Relogio() {}

    /**
     * Cria e inicia um rel�gio que verifica a mudan�a de horas nos
     * intervalos de tempo especificados
     */
    public Relogio(int intervalo) {

        this.intervalo = intervalo;

        (new Thread(this)).start();
    }


    /**
	 * Adiciona o Listener ao conjunto de listeners
	 */
    public void addRelogioListener(RelogioListener rl) {
        synchronized (listeners) {
            listeners.add(rl);
        }
    }


    /**
	 * Remove o Listener do conjunto de listeners
	 */
    public void removeRelogioListener(RelogioListener rl) {
        synchronized (listeners) {
            listeners.remove(rl);
        }
    }


    /**
     * Notifica todos os listeners
     */
    public void notificar() {
        synchronized (listeners) {

            RelogioEvent re = new RelogioEvent(this, new Date());

            Iterator it = listeners.iterator();

            while (it.hasNext()) {
                ((RelogioListener) it.next()).atualizar(re);
            }
        }
    }


    /**
     * Acionado toda vez que o Thread acorda para executar
     */
    public void run() {
        while (true) {
            notificar();

            try { Thread.sleep(intervalo);
            } catch (InterruptedException e) {}
        }
    }
}