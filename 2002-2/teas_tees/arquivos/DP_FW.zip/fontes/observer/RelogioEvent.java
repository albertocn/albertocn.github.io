package observer;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Classe que representa um evento que mant�m informa��es sobre o rel�gio
 *
 * @author Alberto Costa Neto
 * @date   02/03/2001
 */
public class RelogioEvent {

    // Guarda uma refer�ncia para a fonte do evento
    private Object source;

    // Guardam as informa��es sobre a data passada
    private int ano;
    private int mes;
    private int dia;
    private int hora;
    private int minuto;
    private int segundo;


    // Construtor privado para evitar instancia��es inv�lidas
    private RelogioEvent() {}


    /**
     * Cria um objeto RelogioEvent
     */
    public RelogioEvent(Object source, Date data) {
        this.source = source;
        setData(data);
    }

    /**
     * Retorna uma refer�ncia para a fonte de eventos
     */
    public Object getSource() {
        return source;
    }

    /** Retorna o ano */
    public int getAno()     { return ano; }

    /** Retorna o m�s */
    public int getMes()     { return mes; }

    /** Retorna o dia */
    public int getDia()     { return dia; }

    /** Retorna a hora */
    public int getHora()    { return hora; }

    /** Retorna o minuto */
    public int getMinuto()  { return minuto; }

    /** Retorna o segundo */
    public int getSegundo() { return segundo; }


    // Ajusta os campos ano, mes, dia, hora, minuto e segundo de acordo
	// com a data passada
    private void setData(Date data) {
        Calendar c = new GregorianCalendar();
        c.setTime(data);

        this.ano     = c.get(c.YEAR);
        this.mes     = c.get(c.MONTH) + 1;
        this.dia     = c.get(c.DAY_OF_MONTH);
        this.hora    = c.get(c.HOUR_OF_DAY);
        this.minuto  = c.get(c.MINUTE);
        this.segundo = c.get(c.SECOND);
    }


    /** Retorna true se as datas s�o iguais */
    public boolean equals(Object o) {

        if ( !(o instanceof RelogioEvent) )
        {
            return false;
        }
		else
        {
            RelogioEvent outro = (RelogioEvent) o;
            return this.segundo == outro.getSegundo() &&
                   this.minuto  == outro.getMinuto()  &&
                   this.hora    == outro.getHora()    &&
                   this.dia     == outro.getDia()     &&
                   this.mes     == outro.getMes()     &&
                   this.ano     == outro.getAno();
        }
    }
}