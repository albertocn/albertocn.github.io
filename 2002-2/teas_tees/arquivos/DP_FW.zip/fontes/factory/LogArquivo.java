package factory;

import java.io.FileWriter;
import java.io.PrintWriter;

import java.io.IOException;

/**
 * Classe que permite gravar mensagens de log em arquivo
 *
 * @author Alberto Costa Neto
 * @date   26/02/2001
 */
public class LogArquivo extends LogTela {

    /**
	 * Cria um PrintWriter para gravar as mensagens em um arquivo 
	 * chamado "log.txt". Caso n�o seja poss�vel, dar� uma mensagem de 
	 * erro e retornar� um PrintWriter que escreve na sa�da padr�o
     */
    protected PrintWriter criarPrintWriter() {
        try {
            return new PrintWriter(new FileWriter("log.txt", true));
        } catch (IOException e) {
            e.printStackTrace();
            return new PrintWriter(System.out);
        }
    }
}