package factory;

import java.io.PrintWriter;

/**
 * Classe que permite gravar mensagens de log na tela
 *
 * @author Alberto Costa Neto
 * @date   26/02/2001
 */
public class LogTela extends LogAbstract {

    /**
	 * Cria um PrintWriter para gravar as mensagens na sa�da padr�o
     */
    protected PrintWriter criarPrintWriter() {
        return new PrintWriter(System.out);
    }
}