package factory;

/**
 * Classe que demonstra a utiliza��o da classe LogTela
 *
 * @author Alberto Costa Neto
 * @date   26/02/2001
 */
public class TesteLogTela {

    public TesteLogTela(int id) {

        Log l = new LogTela();

        for (int i = 1; i <= 10; i++) {
            l.gravar("id:" + id + " i:" + i);
        }
    }

    public static void main(String args[]) {
        new TesteLogTela(1);
        new TesteLogTela(2);
    }
}