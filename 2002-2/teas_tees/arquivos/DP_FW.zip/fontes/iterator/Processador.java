package iterator;

/**
 * Interface que define as opera��es existentes em processador que s�o
 * chamadas por um iterador interno
 *
 * @author Alberto Costa Neto
 * @date   28/02/2001
 */
public interface Processador {

    /**
     * M�todo que � chamado para cada item na estrutura de dados e
	 * serve para dar chance de processar cada um deles
     */
    void processarItem(Object o);

    /**
     * M�todo que retorna true se o processamento deve continuar e false
     * caso contr�rio
     */
    boolean deveContinuar();
}