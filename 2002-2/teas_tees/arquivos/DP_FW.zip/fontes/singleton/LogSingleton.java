package singleton;

import factory.*;

/**
 * Classe que permite gravar mensagens de log. Utiliza o padr�o de
 * projeto Singleton para oferecer acesso � inst�ncia �nica da classe
 *
 * @author Alberto Costa Neto
 * @date   26/02/2001
 */
public class LogSingleton implements Log {

    // Guarda a refer�ncia para a inst�ncia �nica
    private static LogSingleton logSingleton = null;


    // Log que ser� usado para delegar as grava��es
    private Log log = null;


    /**
	 * Construtor protegido para evitar que seja chamado inadvertidamente
	 */
    protected LogSingleton(Log log) {
        this.log = log;
	}


    /**
     * Retorna a inst�ncia �nica
     */
    public static synchronized Log instance() {
        if (logSingleton == null) {
            logSingleton = new LogSingleton(new LogTela());
//            logSingleton = new LogSingleton(new LogArquivo());
        }

        return logSingleton;
    }


    public synchronized void gravar(String msg) {
        log.gravar(msg);
    }
}