package singleton;

import factory.Log;
import factory.LogTela;

/**
 * Classe que demonstra a utiliza��o da classe LogTela
 *
 * @author Alberto Costa Neto
 * @date   26/02/2001
 */
public class TesteLogTela extends Thread {

    int id;

    public TesteLogTela(int id) {
        this.id = id;
    }

    public void run() {
        Log l = new LogTela();

        for (int i = 1; i <= 10; i++) {
            l.gravar("id:" + id + " i:" + i);
        }
    }

    public static void main(String args[]) {
        TesteLogTela t1 = new TesteLogTela(1);
        TesteLogTela t2 = new TesteLogTela(2);

        t1.start();
        t2.start();
    }
}