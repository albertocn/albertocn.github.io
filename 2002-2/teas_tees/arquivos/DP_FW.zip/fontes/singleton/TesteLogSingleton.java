package singleton;

/**
 * Classe que demonstra a utiliza��o da classe LogSingleton
 *
 * @author Alberto Costa Neto
 * @date   26/02/2001
 */
public class TesteLogSingleton extends Thread {

    int id;

    public TesteLogSingleton(int id) {
        this.id = id;
    }

    public void run() {

        for (int i = 1; i <= 10; i++) {
            LogSingleton.instance().gravar("id:" + id + " i:" + i);
        }
    }

    public static void main(String args[]) {
        TesteLogSingleton tl1 = new TesteLogSingleton(1);
        TesteLogSingleton tl2 = new TesteLogSingleton(2);

        tl1.start();
        tl2.start();
    }
}