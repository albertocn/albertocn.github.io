package decorator;

/**
 * Classe decoradora um objeto que implementa a interface Lista evitando
 * que ela seja modificada
 *
 * @author Alberto Costa Neto
 * @date   27/02/2001
 */
public class ListaNaoModificavel implements Lista {

    private Lista lista;

    public ListaNaoModificavel(Lista lista) {
        this.lista = lista;
    }

    /**
     * Lan�a uma RuntimeException caso seja chamado
     */
    public void inserir(int pos, Object obj) {
        throw new RuntimeException("inserir() n�o pode ser chamado");
	}

    public Object pegar(int pos) {
        return lista.pegar(pos);
    }

    /**
     * Lan�a uma RuntimeException caso seja chamado
     */
    public Object remover(int pos) {
        throw new RuntimeException("remover() n�o pode ser chamado");
	}
}