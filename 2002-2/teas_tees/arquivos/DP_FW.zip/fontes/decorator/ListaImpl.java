package decorator;

/**
 * Classe que implementa a interface Lista
 *
 * @author Alberto Costa Neto
 * @date   27/02/2001
 */
public class ListaImpl implements Lista {

    // Array de objetos para guardar os elementos da lista
    private Object[] objs = new Object[0];


    public void inserir(int pos, Object obj) {

        // Verifica se � necess�rio aumentar o array
        if (pos >= objs.length) {
            aumentarArray(pos + 1);
        }

        objs[pos] = obj;
    }

    public Object pegar(int pos) {
        return objs[pos];
    }

    public Object remover(int pos) {
		Object obj = objs[pos];
        objs[pos] = null;
        return obj;
    }

    // Aumenta o array para o tamanho especificado
    private void aumentarArray(int novoTamanho) {
        Object[] novoArray = new Object[novoTamanho];

        for (int i = 0; i < objs.length; i++) {
            novoArray[i] = objs[i];
        }

        objs = novoArray;
    }
}