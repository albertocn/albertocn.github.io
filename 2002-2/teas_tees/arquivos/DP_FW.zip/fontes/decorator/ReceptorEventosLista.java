package decorator;

/**
 * Interface que define m�todos que s�o chamados em resposta a eventos 
 * ocorridos em uma Lista
 *
 * @author Alberto Costa Neto
 * @date   27/02/2001
 */
public interface ReceptorEventosLista {

    /**
     * Chamado ap�s a inser��o de um elemento na lista
     *
     * @param pos Posi��o onde o objeto foi colocado
     * @param obj Objeto que foi adicionado � lista
     */
    void inseriu(int pos, Object obj);


    /**
     * Chamado ap�s pegar um objeto da lista
     *
     * @param pos Posi��o do objeto que foi retornado
     * @param obj Objeto que foi retornado
     */
    void pegou(int pos, Object obj);


    /**
     * Chamado ap�s remover um objeto da lista
     *
     * @param pos Posi��o do objeto que foi removido
     * @param obj Objeto que foi removido
     */
    void removeu(int pos, Object obj);
}