package command;

public class TornarMaiuscula extends Command
{
  //Cria�ao de vari�vel do tipo da classe Receptor
  private Receptor receptor;
  private String texto;

  //Construtor recebendo a instancia da classe Receptor como par�metro
  public TornarMaiuscula( Receptor receiver )
  {
    this.receptor = receiver;
    this.texto = receptor.getTexto();
  }

  //Implementa�ao do m�todo execute
  public void Execute()
  {
    texto = receptor.getTexto();
    receptor.AcaoTornarMaiuscula();
  }

  //Implementa�ao do m�todo unExecute
  //passa o estado do texto que estava armazenado
  public void UnExecute()
  {
    receptor.setTexto(texto);
  }
}

