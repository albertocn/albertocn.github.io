package command;

import java.util.*;


public class Receptor
{

  private String texto;

  //Contrutor recebendo uma String como parametro
  public Receptor( String texto )
  {
    this.texto = texto;
  }

  //M�todo que implementa a a�ao de Duplicar uma String
  public void AcaoDuplicar()
  {
    texto = texto + texto;

    System.out.println( "Acao Duplicar - TEXTO: "+texto );
  }

  //M�todo que implementa a a�ao de Tornar todas as letras da String em maiuscula
  public void AcaoTornarMaiuscula()
  {
    texto = texto.toUpperCase();

    System.out.println( "Acao Tornar Maiuscula - TEXTO: "+texto );
  }

  //M�todo que implementa a a�ao de Deletar o conte�do de uma String
  public void AcaoDeletar()
  {
    texto = "";

    System.out.println( "Acao Deletar - TEXTO: "+texto );
  }

  public String getTexto()
  {
    return texto;
  }

  public void setTexto(String texto)
  {
    this.texto = texto;
  }

}
