package command;

public class Deletar extends Command
{

  //Cria�ao de vari�vel do tipo da classe Receptor
  public Receptor receptor;
  public String texto;

  //Construtor recebendo a instancia da classe Receptor como par�metro
  public Deletar( Receptor receiver)
  {
    this.receptor = receiver;
    this.texto = receptor.getTexto();
  }

  //Implementa�ao do m�todo execute
  //aramazena o texto antes da a��o ser executada
  public void Execute()
  {
    texto = receptor.getTexto();
    receptor.AcaoDeletar();
  }

  //Implementa�ao do m�todo unExecute
  //passa o estado do texto que estava armazenado
  public void UnExecute()
  {
    receptor.setTexto(texto);
  }

}
