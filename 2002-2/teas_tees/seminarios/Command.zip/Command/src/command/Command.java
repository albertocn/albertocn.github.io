package command;

public abstract class Command
{

  //Assinatura do m�todo abstrato Execute que ser� implementado pelas classes
  //que herdarem de Command
  public abstract void Execute();

  //Assinatura do m�todo abstrato UnExecute que ser� implementado pelas classes
  //que herdarem de Command
  public abstract void UnExecute();

}