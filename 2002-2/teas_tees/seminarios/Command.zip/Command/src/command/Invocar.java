package command;

public class Invocar
{
  //Defini�ao da vari�vel do tipo da classe abstrata Command
  private Command command;


  //Construtor recebendo a instancia da classe Command como par�metro
  public Invocar( Command command )
  {
    this.command = command;
  }


  //M�todo que chamar� o met�do Execute da classe do tipo Command
  //que foi instanciada
  public void ChamarExecute()
  {
    if ( command != null )
      command.Execute();
  }
}
