package command;

public class Duplicar extends Command
{

  //Cria�ao de vari�vel do tipo da classe Receptor
  public Receptor receptor;
  public String texto;

  //Construtor recebendo a instancia da classe Receptor como par�metro
  public Duplicar( Receptor receiver )
  {
    this.receptor = receiver;
    this.texto = receptor.getTexto();
  }

  //Implementa�ao do m�todo execute
  public void Execute()
  {
    texto = receptor.getTexto();
    receptor.AcaoDuplicar();
  }

  //Implementa�ao do m�todo unExecute
  //passa o estado do texto que estava armazenado
  public void UnExecute()
  {
    receptor.setTexto(texto);
  }
}

