package command;

import java.util.Vector;

public class DesfazerMacroCommand extends Command
{

  //Cria�ao de vari�vel do tipo da classe Receptor
  //  public Receptor receptor;
  private Receptor receptor;
  private Vector vHistorico = new Vector();

  //Construtor recebendo a instancia da classe Receptor como par�metro
  public DesfazerMacroCommand( Vector vetHistorico, Receptor receptor )
  {
    this.vHistorico = vetHistorico;
    this.receptor = receptor;
  }

  //Implementa�ao do m�todo execute
  public void Execute()
  {
    for ( int i=0; i < vHistorico.size(); i++ )
    {
      Command classeConcreta = (Command)vHistorico.elementAt(vHistorico.size() - i - 1);
      classeConcreta.UnExecute();

      System.out.println("Texto do historico: "+receptor.getTexto());
    }
  }

  //Implementa�ao do m�todo unExecute
  public void UnExecute()
  {

  }
}

