package command;

import java.util.*;
import command.*;

public class AppClient
{

  public static void main(String[] args)
  {
    System.out.println("TEXTO QUE DESEJA MANIPULAR:     Patricia");

    //Cria uma instancia do Receiver passando parametro de entrada
    Receptor receptor = new Receptor("Patricia");

    //Vetor que ir� armazenar os commands que foram executados
    Vector vetCommand = new Vector();


    /*********** PARA A OP�AO DO MENU - DUPLICAR TEXTO ***********/
    //Cria uma inst�ncia do CommandConcret (Duplicar) passando como parametro
    //o Receiver
    Duplicar duplicarTexto = new Duplicar( receptor );

    //Cria uma instancia do Invoker (Invocar) passando como parametro
    //uma instancia do Duplicar que extend a classe Command
    Invocar invocarDuplicar = new Invocar( duplicarTexto );

    //Manda executar o m�todo Execute no CommandConcret especificado e
    //ser� feita a a�ao no Receiver especificado
    invocarDuplicar.ChamarExecute();
    vetCommand.add( duplicarTexto );


    /*********** PARA A OP�AO DO MENU - TORNAR MAIUSCULA TEXTO ***********/
    //Cria uma inst�ncia do CommandConcret (TornarMaiuscula) passando como parametro
    //o Receiver
    TornarMaiuscula tornarMaiuscula = new TornarMaiuscula( receptor );

    //Cria uma instancia do Invoker (Invocar) passando como parametro
    //uma instancia do TornarMaiuscula que extend a classe Command
    Invocar invocarMaiuscula = new Invocar( tornarMaiuscula );

    //Manda executar o m�todo Execute no CommandConcret especificado e
    //ser� feita a a�ao no Receiver especificado
    invocarMaiuscula.ChamarExecute();
    vetCommand.add( tornarMaiuscula );


    /*********** PARA A OP�AO DO MENU - DELETAR TEXTO ***********/
    //Cria uma inst�ncia do CommandConcret (Deletar) passando como parametro
    //o Receiver
    Deletar deletar = new Deletar( receptor );

    //Cria uma instancia do Invoker (Invocar) passando como parametro
    //uma instancia do TornarMaiuscula que extend a classe Command
    Invocar invocarDeletar = new Invocar( deletar );

    //Manda executar o m�todo Execute no CommandConcret especificado e
    //ser� feita a a�ao no Receiver especificado
    invocarDeletar.ChamarExecute();
    vetCommand.add( deletar );


    /*********** PARA A OP�AO DO MENU - DESFAZER ***********/
    //Cria uma inst�ncia do CommandConcret (DesfazerMacroCommand) passando
    //como parametro o Receiver
    DesfazerMacroCommand desfazerMacroCommand = new DesfazerMacroCommand( vetCommand, receptor );

    //Manda executar o m�todo Execute no CommandConcret especificado
    desfazerMacroCommand.Execute();


    System.out.println("FIM");
  }
}

