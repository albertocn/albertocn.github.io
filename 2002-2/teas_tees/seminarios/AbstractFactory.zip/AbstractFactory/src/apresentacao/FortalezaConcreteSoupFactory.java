package apresentacao;

class FortalezaConcreteSoupFactory extends AbstractSoupFactory
{
    public FortalezaConcreteSoupFactory() {factoryLocation = "Fortaleza";}
    public SopadeMarisco fazerSopadeMarisco()   {return new FortalezaSopadeMarisco();}
    public Peixada fazerPeixada()   {return new FortalezaPeixada();}
}

class FortalezaSopadeMarisco extends SopadeMarisco
{
    public FortalezaSopadeMarisco()
    {
        soupName = "Ensopado de Lagosta";
        soupIngredients.clear();
        soupIngredients.add("1/2 Quilo de Lagosta Fresca");
        soupIngredients.add("1 xicara de milho");
        soupIngredients.add("1/2 xicara de creme de leite");
        soupIngredients.add("1/4 xicara manteiga");
        soupIngredients.add("1/4 xicara de batata cozinha");
    }
}

class FortalezaPeixada extends Peixada
{
    public FortalezaPeixada()
    {
        soupName = "Robalo � Moda da Casa";
        soupIngredients.clear();
        soupIngredients.add("1/2 Quilo de Postas de Robalo Fresco");
        soupIngredients.add("1 xicara milho");
        soupIngredients.add("1/2 xicara de creme de leite");
        soupIngredients.add("1/4 xicara de manteiga");
        soupIngredients.add("1/4 xicara de batata cozida");
    }
}

