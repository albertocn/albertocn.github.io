package apresentacao;

class SalvadorConcreteSoupFactory extends AbstractSoupFactory
{
    public SalvadorConcreteSoupFactory() {factoryLocation = "Salvador";}
    public SopadeMarisco fazerSopadeMarisco()   {return new SalvadorSopadeMarisco();}
    public Peixada fazerPeixada()   {return new SalvadorPeixada();}
}

class SalvadorSopadeMarisco extends SopadeMarisco
{
    public SalvadorSopadeMarisco()
    {
        soupName = "Sopa de Marisco � Moda Baiana";
        soupIngredients.clear();
        soupIngredients.add("1/2 Quilo de Guaiamum ");
        soupIngredients.add("1 xicara de cubos de abacaxi");
        soupIngredients.add("1/2 xicara de leite de coco");
        soupIngredients.add("1/4 xicara de Dend�");
        soupIngredients.add("1/4 xicara de camar�o");
    }
}

class SalvadorPeixada extends Peixada
{
    public SalvadorPeixada()
    {
        soupName = "Ensopado de Linguado";
        soupIngredients.clear();
        soupIngredients.add("1/2 Quilo de Linguado Fresco");
        soupIngredients.add("1 xicara de cubos de abacaxi");
        soupIngredients.add("1/2 xicara de leite de coco");
        soupIngredients.add("1/4 xicara de Dend�");
        soupIngredients.add("1/4 xicara de camar�o");
    }
}

