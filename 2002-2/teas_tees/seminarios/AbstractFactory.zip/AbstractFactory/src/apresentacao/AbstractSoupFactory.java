package apresentacao;

abstract class AbstractSoupFactory
{
    String factoryLocation;
    public String getFactoryLocation() {return factoryLocation;}

    public SopadeGalinha fazerSopadeGalinha()   {return new SopadeGalinha();}
    public SopadeMarisco fazerSopadeMarisco()   {return new SopadeMarisco();}
    public Peixada fazerPeixada()               {return new Peixada();}
    public EspagueteaBolonhesa fazerEspagueteaBolonhesa()   {return new EspagueteaBolonhesa();}
    public Pastafazul fazerPastafazul() {return new Pastafazul();}
    public SopadeTofu fazerSopadeTofu()         {return new SopadeTofu();}
    public SopadeVegetais fazerSopadeVegetais()   {return new SopadeVegetais();}

}

