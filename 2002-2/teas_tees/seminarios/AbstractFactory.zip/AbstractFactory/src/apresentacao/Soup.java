package apresentacao;

import java.util.ArrayList;
import java.util.ListIterator;

abstract class Soup
{
   ArrayList soupIngredients = new ArrayList();
   String soupName;

   public String getSoupName()
   {
       return soupName;
   }

   public String toString()
   {
        StringBuffer stringOfIngredients = new StringBuffer(soupName);
        stringOfIngredients.append(" Ingredients: ");
        ListIterator soupIterator = soupIngredients.listIterator();
        while (soupIterator.hasNext())
        {
            stringOfIngredients.append((String)soupIterator.next());
        }
        return stringOfIngredients.toString();
   }
}

class SopadeGalinha extends Soup
{
    public SopadeGalinha()
    {
        soupName = "Sopa de Galinha";
        soupIngredients.add("1/2 Quilo de Galinha Fatiada");
        soupIngredients.add("1/2 xicara de arroz");
        soupIngredients.add("1 xicara cebola");
        soupIngredients.add("1/16 xicara de manteiga");
        soupIngredients.add("1/4 xicara de cenoura fatiada");
    }
}

class SopadeMarisco extends Soup
{
    public SopadeMarisco()
    {
        soupName = "Sopa de Marisco";
        soupIngredients.add("1/2 Quilo de Mariscos Frescos");
        soupIngredients.add("1 xicara de Frutas ou Vegetais");
        soupIngredients.add("1/2 xicara de Leite");
        soupIngredients.add("1/4 xicara de manteiga");
        soupIngredients.add("1/4 xicara de batata");
    }
}

class Peixada extends Soup
{
    public Peixada()
    {
        soupName = "Peixada";
        soupIngredients.add("1/2 Quilo de Peixe Fresco");
        soupIngredients.add("1 xicara de Frutas ou Vegetais");
        soupIngredients.add("1/2 xicara de Leite");
        soupIngredients.add("1/4 xicara de manteiga");
        soupIngredients.add("1/4 xicara de batata");
    }
}

class EspagueteaBolonhesa extends Soup
{
    public EspagueteaBolonhesa()
    {
        soupName = "Espaguete a bolonhesa";
        soupIngredients.add("1/2 quilo de tomate");
        soupIngredients.add("100gr de Espaguete");
        soupIngredients.add("1 x�cara de suco de tomate");
    }
}

class Pastafazul extends Soup
{
    public Pastafazul()
    {
        soupName = "Pasta fazul";
        soupIngredients.add("1/2 quilo de tomate");
        soupIngredients.add("100gr de Espaguete");
        soupIngredients.add("1/2 x�cara de cubos de cenoura");
        soupIngredients.add("1 x�cara de suco de tomate");
    }
}

class SopadeTofu extends Soup
{
    public SopadeTofu()
    {
        soupName = "Sopa de Tofu";
        soupIngredients.add("1/2 quilo de tofu");
        soupIngredients.add("1 x�cara de suco de cenoura");
        soupIngredients.add("1/4 x�cara de espinafre");
    }
}

class SopadeVegetais extends Soup
{
    public SopadeVegetais()
    {
        soupName = "Sopa de Vegetais";
        soupIngredients.add("1 Couve-Flor");
        soupIngredients.add("1/4 x�cara de cenoura");
        soupIngredients.add("1/4 x�cara de cubos de batatas");
    }
}

