package apresentacao;

/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2003
 * Company:
 * @author
 * @version 1.0
 */

import java.util.Calendar;

class TestAbstractSoupFactory {
   public static Soup MakeSoupOfTheDay(AbstractSoupFactory concreteSoupFactory)
   {
       Calendar todayCalendar = Calendar.getInstance();
       int dayOfWeek = todayCalendar.get(Calendar.DAY_OF_WEEK);

       if (dayOfWeek == Calendar.MONDAY)
       {return concreteSoupFactory.fazerSopadeGalinha();}
       else if (dayOfWeek == Calendar.TUESDAY)
       {return concreteSoupFactory.fazerSopadeMarisco();}
       else if (dayOfWeek == Calendar.WEDNESDAY)
       {return concreteSoupFactory.fazerPeixada();}
       else if (dayOfWeek == Calendar.THURSDAY)
       {return concreteSoupFactory.fazerEspagueteaBolonhesa();}
       else if (dayOfWeek == Calendar.FRIDAY)
       {return concreteSoupFactory.fazerPastafazul();}
       else if (dayOfWeek == Calendar.SATURDAY)
       {return concreteSoupFactory.fazerSopadeTofu();}
       else {return concreteSoupFactory.fazerSopadeVegetais();}
   }

   public static void main(String[] args)
   {
       AbstractSoupFactory concreteSoupFactory = new FortalezaConcreteSoupFactory();
       Soup soupOfTheDay = MakeSoupOfTheDay(concreteSoupFactory);
       System.out.println("A Sopa do Dia em " + concreteSoupFactory.getFactoryLocation() + " � " + soupOfTheDay.getSoupName());

       concreteSoupFactory = new SalvadorConcreteSoupFactory();
       soupOfTheDay = MakeSoupOfTheDay(concreteSoupFactory);
       System.out.println("A Sopa do Dia em " + concreteSoupFactory.getFactoryLocation() + " � " + soupOfTheDay.getSoupName());
   }
}

