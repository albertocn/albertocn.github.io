package builder_cod;

/**
 * Test code for the pattern.
 */
import java.io.*;
public class Test
{
	public static void main( String arg[] )
	{
		try
		{
      //concreteBuilder classe CBCarBuilder
			CBCarBuilder car_builder = new CBCarBuilder();

      //Directors
			DConcessionaria carro_clienteA = new DConcessionaria( car_builder );
      DConcessionaria carro_clienteB = new DConcessionaria( car_builder );

      carro_clienteA.construct(1,1,1,1);//montagem de um modelo de carro
      car_builder.getResult();          //solicita��o do resultado
 			carro_clienteB.construct(2,3,3,2);
      car_builder.getResult();
//===============
//====Outro tipo de ve�culo
      CBBizBuilder biz_builder = new CBBizBuilder();

			DConcessionaria biz_clienteA = new DConcessionaria( biz_builder );
      biz_clienteA.construct(2,0,0,0);
      biz_builder.getResult();



//=====
byte vetortexto[] = new byte[200];
int byteslidos = 0;
byteslidos = System.in.read(vetortexto);
//=====
    }
		catch( Exception e )
		{
			e.printStackTrace();
		}

	}
}
