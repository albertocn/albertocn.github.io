package builder_cod;
/**
 * Constroi um objeto usando a interface de um builder
 * public class Director
 */

public class DConcessionaria
{
	private Builder builder;

	public DConcessionaria( Builder builder )//construtor
	{
		this.builder = builder;
	}

	public void construct(int ml,int mt, int r, int p)
	{
		builder.buildModelo(ml);
		builder.buildMotor(mt);
		builder.buildRodas(r);
 		builder.buildPortas(p);
	}
}