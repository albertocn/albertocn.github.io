/*
 *Especifica uma interface abstrata para cria��o de partes de um objeto-produto
 */
package builder_cod;

public interface Builder
{
 void buildModelo(int c);
 void buildMotor(int m);
 void buildRodas(int r);
 void buildPortas(int p);

	//Product getResult();
  void getResult();
}
