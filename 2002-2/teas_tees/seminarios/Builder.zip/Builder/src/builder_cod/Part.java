package builder_cod;

/**
 * Represents a piece of the complex object under construction.
 */

public interface Part
{
//=====  iserido por vinicius
//System.out.println("Director.java - public interface Part");
//=====

}