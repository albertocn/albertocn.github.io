package builder_cod;
/*
 * Constr�i e monta partes do produto pela implementa��o da interface de Builder
 * Define e mant�m a representa��o que cria
 * Fornece uma interface para a recupera��o do produto
 */


public class CBCarBuilder implements Builder
{

	Product automovel;
  String[] op_modelos = {"modelo1","modelo2","modelo3"};
  String[] op_motores = {"100cv","200cv","300cv"};
  int[] op_num_portas = {2,4};
  String modelo, motor;
  int num_portas,num_rodas;
	public void buildModelo(int i)
	{
		if (i >= 0 && i <= 2) this.modelo = op_modelos[i];
    else this.modelo = "N�o fabricado";
	};

	public void buildMotor(int i)
	{
		if (i >= 0 && i <= 2) this.motor = op_motores[i];
    else this.motor = "N�o fabricado";
  };

	public void buildRodas(int i)
	{ this.num_rodas = 4;};
  public void buildPortas(int i)
	{
  	if (i >= 0 && i <= 1) this.num_portas = op_num_portas[i];
    else this.num_portas = 2;

	};

public void getResult()
{
System.out.println("Classe do ve�culo: Autom�vel");
System.out.println("Modelo do veiculo: "+modelo);
System.out.println("Pot�ncia do motor: "+motor);
System.out.println("N�mero de rodas  : "+num_rodas);
System.out.println("N�mero de portas : "+num_portas);
System.out.println("\n");
//=====
	};
}