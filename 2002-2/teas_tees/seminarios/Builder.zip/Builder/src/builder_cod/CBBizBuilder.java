package builder_cod;
/*
 * Constr�i e monta partes do produto pela implementa��o da interface de Builder
 * Define e mant�m a representa��o que cria
 * Fornece uma interface para a recupera��o do produto
 */
public class CBBizBuilder implements Builder
{

	Product Biz;
  String[] op_modelos = {"modelo1","modelo2","modelo3","modelo4"};
  String[] op_motores = {"30cv","60cv"};
//  int[] op_num_portas = {2,4};
  String modelo, motor;
  int num_rodas;
	public void buildModelo(int i)
	{
		if (i >= 0 && i <= 3) this.modelo = op_modelos[i];
    else this.modelo = "N�o fabricado";
	};

	public void buildMotor(int i)
	{
		if (i >= 0 && i <= 1) this.motor = op_motores[i];
    else this.motor = "N�o fabricado";
  };

	public void buildRodas(int i)
	{ this.num_rodas = 2;};
   public void buildPortas(int i){};

public void getResult()
{
System.out.println("Classe do ve�culo: Motocicleta Biz");
System.out.println("Modelo do veiculo: "+modelo);
System.out.println("Pot�ncia do motor: "+motor);
System.out.println("N�mero de rodas  : "+num_rodas);
System.out.println("\n");
	};
}