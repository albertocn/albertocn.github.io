package builder_cod;

/**
 * Representa o objeto complexo em constru��o.
 * Concrete builder constr�i a representa��o interna do produto e define o
 * processo pelo qual ele � montado.
 * Inclui classes que definem as partes constituintes, inclusive as interfaces
 * para montagem das partes no resultado final.
 */

public interface Product
{
}
