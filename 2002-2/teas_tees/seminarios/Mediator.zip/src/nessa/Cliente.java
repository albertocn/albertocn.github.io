/*
   - Classe main do projeto onde instanciara o ConcreteMediator em si que
esta representado pela classe Janela
*/

package nessa;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import com.borland.jbcl.layout.*;


public class Cliente
{
  public static void main ( String[] args )
  {
    JFrame frame = new JFrame ( "Fotos Equestres" );

    // Criando a tela inicial
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    frame.setLocation ( ( screenSize.width - 350 ) , 200 );
    frame.setVisible ( true );

    // Instanciacao do ConcreteMediator
    Janela listas = new Janela();
    frame.getContentPane().add ( listas.painel );
    frame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
    frame.pack();
    frame.setVisible ( true );
  }
}