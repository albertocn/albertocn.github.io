/*
   - Classe para a criacao de botoes que implementa a interface Componente
   - Corresponde ao ConcreteColleague na Estrutura do Padrao Mediator
*/

package nessa;

import javax.swing.JButton;

public class Botao extends JButton implements Componente
{
  Diretor diretor;
  public JButton botao;
  public String mostrar = new String ( "Mostrar" );

  public Botao ( Diretor diretor )
  {
    super();
    botao = new JButton ( mostrar );
    botao.setEnabled ( false );
    this.diretor = diretor;
  }

  // Metodo da classe Componente implementado
  public void mudar()
  {
    diretor.notificarMudan�a ( this );
  }

}




