/*
   - Classe para a criacao do ListBox que implementa a interface Componente
   - Corresponde ao ConcreteColleague na Estrutura do Padrao Mediator
*/

package nessa;

import javax.swing.JList;
import java.util.*;

public class ListBox extends JList implements Componente
{
  Diretor diretor;
  public JList lista = new JList();

  public ListBox ( Diretor diretor )
  {
    super();
    this.diretor = diretor;
  }

  // Metodo da classe Componente implementado
  public void mudar()
  {
    diretor.notificarMudan�a ( this );
  }

  public JList inserirLista( Vector elemento )
  {
    lista = new JList( elemento );
    return lista;
  }

}