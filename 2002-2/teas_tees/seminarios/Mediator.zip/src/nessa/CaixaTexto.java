/*
   - Classe para a criacao da caixa de texto que implementa a interface Componente
   - Corresponde ao ConcreteColleague na Estrutura do Padrao Mediator
*/

package nessa;

import javax.swing.JTextField;

public class CaixaTexto extends JTextField implements Componente
{
  Diretor diretor;
  public JTextField caixa;

  public CaixaTexto ( Diretor diretor )
  {
    super();
    this.diretor = diretor;
  }

  // Metodo da classe Componente implementado
  public void mudar()
  {
    diretor.notificarMudan�a ( this );
  }

  // Outra forma de se instanciar um objeto dessa classe seria compondo outro
  // construtor
  public void InserirCaixaDeTexto ( String texto )
  {
    this.caixa = new JTextField ();
    this.caixa.setText ( texto );
  }


}