/*
   - Interface que declara o metodo notificarMudanca() que sera implementado pelo
ConcreteMediator na Estrutura do Padrao
   - Corresponde ao Mediator
*/

package nessa;

public interface Diretor
{
  void notificarMudan�a ( Componente componente );
}