/*
   - Esta classe esta representada pelo ConcreteMediator, pois ela implementa a
interface Mediator ( Diretor )
*/

package nessa;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import com.borland.jbcl.layout.*;
import java.util.*;
import java.io.*;

public class Janela extends JDialog implements Diretor, ListSelectionListener
{
  public Vector imagemNomes = new Vector();
  private JLabel figura;
  public JPanel painel = new JPanel();
  private XYLayout xYLayout1 = new XYLayout();
  public CaixaTexto caixaTexto;
  public Border border1;
  public ListBox listBox;
  public Botao botaoMostrar;



  public Janela ( Frame frame, String title, boolean modal )
  {
    super ( frame, title, modal );
    try
    {
      criarComponentes();
      pack();
    }
    catch( Exception ex )
    {
      ex.printStackTrace();
    }
  }

  public Janela()
  {
    this( null, "", false );
  }


  void criarComponentes() throws Exception
  {
    botaoMostrar = new Botao ( this );
    // Comando para adicionar Listner ao botao
    botaoMostrar.botao.setActionCommand ( botaoMostrar.mostrar );
    botaoMostrar.botao.addActionListener (new BotaoAcionado () );

    caixaTexto = new CaixaTexto ( this );
    caixaTexto.InserirCaixaDeTexto ( "" );
    border1 = new EtchedBorder ( EtchedBorder.RAISED,Color.white,new Color(178, 178, 178 ) );
    painel.setLayout ( xYLayout1 );
    caixaTexto.caixa.setBorder ( BorderFactory.createLineBorder ( Color.black ) );

    listarImagens();

    // adicionando elementos ao listBox
    listBox = new ListBox ( this );
    listBox.inserirLista ( imagemNomes );
    listBox.lista.setSelectionMode ( ListSelectionModel.SINGLE_SELECTION );
    listBox.lista.setBorder ( BorderFactory.createLineBorder ( Color.black ) );
    // Adicinando um Listner ao ListBox
    listBox.lista.addListSelectionListener ( this );

    // adicionando componentes no JPanel
    painel.add ( caixaTexto.caixa, new XYConstraints ( 0, 30, 160, 25 ) );
    painel.add ( botaoMostrar.botao, new XYConstraints ( 180, 30, 100, -1 ) );
    painel.add ( listBox.lista, new XYConstraints ( 0, 67,280 , 200 ) );
    this.getContentPane().add ( painel, BorderLayout.CENTER );
  }

  // Esta classe foi criada a fim de implementar o metodo actionPerformed da Interface
  // ActionListner
  class BotaoAcionado implements ActionListener
  {
    public void actionPerformed ( ActionEvent e )
    {
      if (!(caixaTexto.caixa.getText().equals("")))
      {
        botaoMostrar.mudar();
        return;
      }
    }
  }

  // Este metodo eh declarado na Interface ListSelectionListener, que eh utilizado
  // quando ah alguma altera��o no ListBox
  public void valueChanged ( ListSelectionEvent e )
  {
    listBox.mudar();
  }

  // Este metodo tem o objetivo de colher os arquivos imagens e inseri-los em
  // um vetor
  void listarImagens()
  {
    try
    {
      File file = new File( "imagens\\" );
      String[] arquivos = file.list();
      for ( int i = 0; i < arquivos.length; i++ )
      {
        if ( arquivos[i].endsWith( ".jpg" )
             || arquivos[i].endsWith( ".bmp" )
             || arquivos[i].endsWith( ".gif" ) )
      {
        imagemNomes.addElement( "imagens\\" + arquivos[i] );
      }
      else
      {
        System.out.println( "dispensando " + arquivos[i] );
      }
      }
    }
  catch ( Exception ex )
  {
    ex.printStackTrace();
  }
}


// Este metodo esta declarado na Interface Diretor ( Mediator )
// Ele concentra resolve todas as medidas que os objetos devem tomar quando um deles
// for alterado. Ou seja, quando algum objeto eh alterado ele envia uma informa��o
// para a sua SuperClasse e esta chama o metodo notificarMudanca passando a si
// propria como referencia para que o mesmo possa tomar as decis�es
 public void notificarMudan�a( Componente componente )
 {
   if ( componente instanceof ListBox )
   {
     if (!( listBox.lista.getSelectedIndex( ) == -1 ))
     {
       //Selecao, atualiza a Caixa de Texto
       botaoMostrar.botao.setEnabled ( true );
       String name = listBox.lista.getSelectedValue().toString();
       caixaTexto.caixa.setText ( name );
     }
   }
   else if ( componente instanceof Botao )
   {
     JFrame frame = new JFrame(listBox.lista.getSelectedValue().toString());

     // Selecao da Imagem para sua posterior amostra
     String nomeSelecionado = listBox.lista.getSelectedValue().toString();
     ImageIcon firstImage = new ImageIcon( nomeSelecionado );
     figura = new JLabel( firstImage );
     frame.getContentPane().add( figura );
     frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
     frame.pack();
     frame.setVisible(true);
   }
 }
}






