package nessa;

import java.awt.*;
import javax.swing.*;
import com.borland.jbcl.layout.*;

public class Exmplo1 extends JDialog
{
  private JPanel panel1 = new JPanel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private XYLayout xYLayout1 = new XYLayout();
  private JButton jButton1 = new JButton();
  private JButton jButton2 = new JButton();
  private JButton jButton3 = new JButton();

  public Exmplo1(Frame frame, String title, boolean modal)
  {
    super(frame, title, modal);
    try
    {
      jbInit();
      pack();
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
  }

  public Exmplo1()
  {
    this(null, "", false);
  }
  private void jbInit() throws Exception
  {
    StringBuffer ex = new StringBuffer("Nessa");
    panel1.setLayout(borderLayout1);
    this.getContentPane().setLayout(xYLayout1);
    xYLayout1.setWidth(316);
    xYLayout1.setHeight(300);
    jButton1.setText(ex.toString());
    jButton2.setText("Botao 2");
    jButton3.setText("jButton3");
    getContentPane().add(panel1,  new XYConstraints(0, 0, -1, -1));
    this.getContentPane().add(jButton2,   new XYConstraints(172, 172, 97, 29));
    this.getContentPane().add(jButton3,   new XYConstraints(27, 174, 94, -1));
    this.getContentPane().add(jButton1, new XYConstraints(107, 98, -1, 31));
  }
}