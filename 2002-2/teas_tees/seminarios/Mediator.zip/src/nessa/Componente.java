/*
   - Interface que declara o metodo mudar() o qual sera implementado pelas subclasses
   -  Corresponde ao Colleague na Estrutura do Padrao Mediator
*/
package nessa;

public interface Componente
{
  void mudar();
}