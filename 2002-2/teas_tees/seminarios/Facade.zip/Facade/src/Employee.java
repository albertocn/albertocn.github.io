public interface Employee
{
    public String getName();
    public float getSalary();
}