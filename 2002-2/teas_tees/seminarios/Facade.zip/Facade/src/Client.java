public class Client
{
    public static void main(String args[])
    {
        CompanyFacade company = new CompanyFacade();
        System.out.println(company.getEmployeeInfo("Vanessa"));
        System.out.println(company.getAssetInfo("Cadeira"));
        System.out.println(company.companyReport());
    }
}