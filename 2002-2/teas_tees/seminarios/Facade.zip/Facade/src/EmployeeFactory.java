import java.util.*;

public class EmployeeFactory
{
    static Map employees = null;

    private EmployeeFactory() {}

    static Map getEmployees()
    {
        if ( employees == null )
        {
            employees = new HashMap();
            employees.put("Emanuel",new StaffEmployee("Emanuel",2000.0f));
            employees.put("Vanessa",new StaffEmployee("Vanessa",2500.0f));
            employees.put("Alberto",new StaffEmployee("Alberto",30000.0f));
        }
        return employees;
    }
}