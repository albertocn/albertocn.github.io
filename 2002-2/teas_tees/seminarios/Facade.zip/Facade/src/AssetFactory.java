import java.util.*;

public class AssetFactory
{
    static HashMap assets = null;
    
    private AssetFactory() {}
    
    static Map getAssets()
    {
        if ( assets == null )
        {
            assets = new HashMap();
            assets.put("Escrivaninha",new CompanyAsset("Escrivaninha",1));
            assets.put("Cadeira",new CompanyAsset("Cadeira",2));
            assets.put("Caneta",new CompanyAsset("Caneta",3));
        }
        return assets;
    }
}