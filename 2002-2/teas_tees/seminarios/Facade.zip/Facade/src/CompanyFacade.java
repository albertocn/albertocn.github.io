import java.util.*;

public class CompanyFacade
{
    Map assets;
    Map employees;
    
    public CompanyFacade()
    {
        assets = AssetFactory.getAssets();
        employees = EmployeeFactory.getEmployees();
    }
    
    public String companyReport()
    {
        StringBuffer sb = new StringBuffer();
        
        sb.append("Bens\n");
        Iterator iterator = assets.values().iterator();
        while (iterator.hasNext())
        {
            Asset asset = (Asset)iterator.next();
            sb.append(asset.toString()+"\n");
        }
        sb.append("Empregados\n");
        iterator = employees.values().iterator();
        while (iterator.hasNext())
        {
            Employee emp = (Employee)iterator.next();
            sb.append(emp.toString()+"\n");
        }
        return sb.toString();
    }
            
    public String getEmployeeInfo(String name)
    {
        Employee emp = (Employee) employees.get(name);
        return emp.toString();
    }
    public String getAssetInfo(String name)
    {
        Asset asset = (Asset) assets.get(name);
        return asset.toString();
    }
}