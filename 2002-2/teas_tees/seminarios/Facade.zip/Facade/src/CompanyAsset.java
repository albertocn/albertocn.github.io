public class CompanyAsset implements Asset
{
    String description;
    int number;
    
    public CompanyAsset(String desc,int num)
    {
        this.description = desc;
        this.number = num;
    }
    
    public String getAssetDescription()
    {
        return description;
    }
    
    public int getAssetNumber()
    {
        return number;
    }
    
    public String toString()
    {
        return ("Descricao: "+getAssetDescription()+
                "    Numero: "+getAssetNumber());
    }
    
}