public class StaffEmployee implements Employee
{
    private String name;
    private float salary;
    
    StaffEmployee(String name, float salary)
    {
        this.name = name;
        this.salary = salary;
    }
    
    public String getName()
    {
        return name;
    }
    
    public float getSalary()
    {
        return salary;
    }
    
    public String toString()
    {
        return ("Nome: "+getName()+
                "    Salario: "+getSalary());
    }
}