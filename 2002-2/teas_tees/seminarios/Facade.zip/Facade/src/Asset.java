public interface Asset
{
    public String getAssetDescription();
    public int getAssetNumber();
}