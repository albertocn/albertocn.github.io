package proxy_ex;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

import java.util.Hashtable;
import java.util.Enumeration;
import java.util.ArrayList;

public class Client extends JFrame {
  private ProxyClient pc = new ProxyClient(); // Parte Cliente do Proxy

  private JPanel contentPane;
  private BorderLayout borderLayout1 = new BorderLayout();
  private TitledBorder titledBorder1;
  private JPanel jPanel1 = new JPanel();
  private TitledBorder titledBorder2;
  private JPanel jPanel2 = new JPanel();
  private TitledBorder titledBorder3;
  private BorderLayout borderLayout2 = new BorderLayout();
  private JButton jButton1 = new JButton();
  private FlowLayout flowLayout1 = new FlowLayout();
  private ButtonGroup buttonGroup1 = new ButtonGroup();
  private JTextField jTextField1 = new JTextField(10);
  private JLabel jLabel1 = new JLabel();
  private TitledBorder titledBorder4;
  private TitledBorder titledBorder5;
  private JButton jButton2 = new JButton();
  private TitledBorder titledBorder6;
  private JButton jButton3 = new JButton();
  private TitledBorder titledBorder7;
  private TitledBorder titledBorder8;
  private JScrollPane jcp = new JScrollPane();
  private JTextArea memo = new JTextArea();
  private TitledBorder titledBorder9;

  /**Construct the frame*/
  public Client() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  /**Component initialization*/
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(Client.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    titledBorder3 = new TitledBorder("");
    titledBorder4 = new TitledBorder("");
    titledBorder5 = new TitledBorder("");
    titledBorder6 = new TitledBorder("");
    titledBorder7 = new TitledBorder("");
    titledBorder8 = new TitledBorder("");
    titledBorder9 = new TitledBorder("");
    contentPane.setLayout(borderLayout1);
    this.setSize(new Dimension(600, 400));
    this.setState(Frame.ICONIFIED);
    this.setTitle("Aplica��o Cliente - Proxy");
    jPanel1.setBorder(titledBorder2);
    jPanel1.setPreferredSize(new Dimension(22, 50));
    jPanel1.setLayout(flowLayout1);
    jPanel2.setBorder(titledBorder3);
    jPanel2.setLayout(borderLayout2);
    jButton1.setBorder(titledBorder5);
    jButton1.setText("Enviar");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    jLabel1.setText("Matr�cula: ");
    jTextField1.setBorder(titledBorder4);
    jTextField1.setMinimumSize(new Dimension(30, 21));
    jTextField1.setPreferredSize(new Dimension(30, 21));
    jTextField1.setToolTipText("");
    jButton2.setBorder(titledBorder6);
    jButton2.setText("Limpar");
    jButton2.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton2_actionPerformed(e);
      }
    });
    jButton3.setBorder(titledBorder7);
    jButton3.setText("Sair");
    jButton3.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton3_actionPerformed(e);
      }
    });
    memo.setBorder(BorderFactory.createEtchedBorder());
    memo.setEditable(false);
    contentPane.add(jPanel2, BorderLayout.CENTER);
    jPanel2.add(jcp, BorderLayout.CENTER);
    contentPane.add(jPanel1, BorderLayout.NORTH);
    jPanel1.add(jLabel1, null);
    jPanel1.add(jTextField1, null);
    jPanel1.add(jButton1, null);
    jPanel1.add(jButton2, null);
    jPanel1.add(jButton3, null);
    jcp.getViewport().add(memo, null);
  }
  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      System.exit(0);
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    if (jTextField1.getText().equals(""))
      exibirTurma();
    else
      exibirAluno(jTextField1.getText());
  }

  private void exibirTurma() {
    try {
      Hashtable ht = pc.getNotas();

      Enumeration e = ht.keys();
      while (e.hasMoreElements()) {
        String mat = (String) e.nextElement();
        ArrayList al = (ArrayList) ht.get(mat);
        String nome = (String) al.get(0);

        memo.append(mat + " - " + nome + " -> " );

        for (int i = 1 ; i < al.size() ; i++)
          memo.append((String) al.get(i) + " ");

        memo.append("\n");
      }
      memo.append("\n");
   } catch (Exception e) {
     memo.append(e.getMessage() + "\n");
   }
 }

  private void exibirAluno(String matricula) {
    try {
      Hashtable ht = pc.getNotas(matricula);

      Enumeration e = ht.keys();
      if (e.hasMoreElements()) {
        String mat = (String) e.nextElement();
        ArrayList al = (ArrayList) ht.get(mat);
        String nome = (String) al.get(0);

        memo.append(mat + " - " + nome + " -> " );

        for (int i = 1 ; i < al.size() ; i++)
          memo.append((String) al.get(i) + " ");

        memo.append("\n");
      }
      memo.append("\n");
    } catch (Exception e) {
      memo.append(e.getMessage() + "\n");
    }
  }

  void jButton2_actionPerformed(ActionEvent e) {
    jTextField1.setText("");
  }

  void jButton3_actionPerformed(ActionEvent e) {
    System.exit(0);
  }

  public static void main(String args[]) {
    Client cliente = new Client();
    cliente.setVisible(true);
  }
}