package proxy_ex;

import java.io.IOException;
import java.lang.ClassNotFoundException;
import java.util.Hashtable;

/**
 * <p>Title: App_Proxy</p>
 * <p>Description: Exemplo do Padr�o de Projeto Proxy</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Mijasoftware</p>
 * @author Andre Luis e Jose Coutinho
 * @version 1.0
 */

public interface ProxyInterface {

  public Hashtable getNotas() throws Exception;
  public void alterarNotas(String matricula, int unidade, float nota) throws Exception;
  public Hashtable getNotas(String matricula) throws Exception;


}