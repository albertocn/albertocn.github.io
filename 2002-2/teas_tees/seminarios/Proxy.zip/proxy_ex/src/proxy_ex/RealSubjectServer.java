package proxy_ex;

import java.util.Hashtable;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.Enumeration;

import java.io.*;
import java.lang.*;

/**
 * <p>Title: App_Proxy</p>
 * <p>Description: Exemplo do Padr�o de Projeto Proxy</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Mijasoftware</p>
 * @author Andre Luis e Jose Coutinho
 * @version 1.0
 */

public class RealSubjectServer implements ProxyInterface {

  File f = null;
  RandomAccessFile arquivo = null;

  private String TratarEntrada (String s) {
    int l = s.length();
    String s2 = "";
    for (int i=1;i<=l-2;i+=2) {
      s2 = s2 + s.charAt(i);
    }
    return s2;
  }

  public RealSubjectServer() {
    f = new File ("Notas.txt");
    if (!f.exists()){
      try {
        System.out.println("[" + this.getClass().getName() + "] Criando Arquivo...");
        f.createNewFile();
      }
      catch (IOException ioe){
        System.out.println("[" + this.getClass().getName() + "] " + ioe.getMessage());
      }
    }
    try {
      arquivo = new RandomAccessFile(f,"rw");
    }
    catch (FileNotFoundException fnfe) {
      System.out.println("[" + this.getClass().getName() + "] " + fnfe.getMessage());
    }
  }

  public Hashtable getNotas() throws Exception {
    Hashtable p = new Hashtable ();
    arquivo.seek(0);
    String linha = arquivo.readLine();
    String notas,linhaTratada,chave = null;
    StringTokenizer st = null;
    ArrayList al = null;
    int i = 0;
    while (linha != null) {
      linhaTratada = TratarEntrada ( linha );
      st = new StringTokenizer(linhaTratada,"@");
      chave = st.nextToken();
      al = new ArrayList ();
      al.add(i++,st.nextToken());
      do {
        notas = st.nextToken();
        if (notas != "")
          al.add(i++,notas);
      }
      while (st.hasMoreTokens());
      p.put(chave,al);
      linha = arquivo.readLine();
      i = 0;
    }
    return p;
  }

  public Hashtable getNotas(String matricula) throws Exception {
    Hashtable p = new Hashtable();
    StringTokenizer st = null;
    arquivo.seek(0);
    String linha = arquivo.readLine();
    String linhaTratada, mat = null;
    while (linha != null) {
      linhaTratada = TratarEntrada ( linha );
      st = new StringTokenizer(linhaTratada,"@");
      mat = st.nextToken();
      if (mat.equals(matricula)) {
        ArrayList al = new ArrayList();
        int i = 0;
        al.add(i++,st.nextToken());
        String nota = null;
        while (st.hasMoreTokens()) {
          nota = st.nextToken();
          if (nota != "")
            al.add(i++,nota);
        }
        p.put(mat,al);
        return p;
      }
      linha = arquivo.readLine();
    }
    throw new Exception("Matricula " + matricula + " inexistente!");
  }

  public void alterarNotas(String matricula, int unidade, float nota) throws Exception {
    Hashtable p = this.getNotas();
    if (p.containsKey(matricula)) {
      ArrayList al = (ArrayList) p.remove(matricula);
      al.set(unidade, new Float(nota));
      p.put(matricula,al);
      arquivo.setLength(0);
      String linha, mat,nome = null;
      int tam, i = 0;
      Enumeration e = p.keys();
      while (e.hasMoreElements()) {
        linha = "";
        mat = (String) e.nextElement();
        al = (ArrayList) p.get(mat);
        nome = (String) al.get(0);
        tam = al.size();
        linha = mat + "@" + nome + "@";
        for (i=1;i<=tam-1;i++)
          linha = linha + (String) al.get(i) + "@";
        linha = linha + "\n";
        arquivo.writeChars(linha);
      }
     }
  }

}