package proxy_ex;

import java.io.PrintStream;
import javax.swing.JTextArea;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.awt.Component;


/**
 * Title:        App_Proxy
 * Description:  Exemplo do Padr�o de Projeto Proxy
 * Copyright:    Copyright (c) 2003
 * Company:      Mijasoftware
 * @author Andre Luis e Jose Coutinho
 * @version 1.0
 */

public class LogPrintStream extends PrintStream {
  private JTextArea memo;
  private SimpleDateFormat sdf;

  public LogPrintStream(JTextArea memo) {
    super(System.out, true);
    this.memo = memo;
    sdf = new SimpleDateFormat("E dd/MM/yyyy - hh:mm:ss");
  }

  public LogPrintStream() {
    this(new JTextArea());
  }

  public Component getDisplay() {
    return this.memo;
  }

  public void print(String msg) {
    super.print("[" + sdf.format(new Date()) + "] " + msg);
  }

  public void println(String msg) {
    super.println(msg);
    this.memo.append("[" + sdf.format(new Date()) + "] " + msg + "\n");
  }

  public void print(Object obj) {
    super.print("[" + sdf.format(new Date()) + "] " + obj.toString());
  }

  public void println(Object obj) {
    super.println(obj.toString());
    this.memo.append("[" + sdf.format(new Date()) + "] " + obj.toString() + "\n");
  }
}