package proxy_ex;

/**
 * <p>Title: App_Proxy</p>
 * <p>Description: Exemplo do Padr�o de Projeto Proxy</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Mijasoftware</p>
 * @author Andre Luis e Jose Coutinho
 * @version 1.0
 */

public interface Talkable {
  public static final byte OK = 0;
  public static final byte ERROR = 1;
  public static final byte EXIBIR_NOTAS = 2;
  public static final byte EXIBIR_ALUNO = 3;
  public static final byte ALTERAR_NOTAS = 4;
  public static final byte FINNISH = 5;
}