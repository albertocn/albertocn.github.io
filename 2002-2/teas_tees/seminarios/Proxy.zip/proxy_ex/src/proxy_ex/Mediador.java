package proxy_ex;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.net.BindException;

public class Mediador extends JFrame {

  private ServerThread st = null;

  private JPanel contentPane;
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel jPanel1 = new JPanel();
  private TitledBorder titledBorder1;
  private JPanel jPanel2 = new JPanel();
  private TitledBorder titledBorder2;
  private TitledBorder titledBorder3;
  private JButton jButton1 = new JButton();
  private TitledBorder titledBorder4;
  private BorderLayout borderLayout2 = new BorderLayout();
  private TitledBorder titledBorder5;
  private TitledBorder titledBorder6;
  private JScrollPane jScrollPane1 = new JScrollPane();
  private JTextArea memo = new JTextArea();

  /**Construct the frame*/
  public Mediador() {
    enableEvents(AWTEvent.WINDOW_EVENT_MASK);
    try {
      jbInit();
      System.setOut(new LogPrintStream(memo));

      st = new ServerThread();
      st.start();

      this.st = st;

    } catch(BindException be) {
      be.printStackTrace();
    } catch(Exception e) {
      e.printStackTrace();
    }

  }
  /**Component initialization*/
  private void jbInit() throws Exception  {
    //setIconImage(Toolkit.getDefaultToolkit().createImage(Mediador.class.getResource("[Your Icon]")));
    contentPane = (JPanel) this.getContentPane();
    titledBorder1 = new TitledBorder("");
    titledBorder2 = new TitledBorder("");
    titledBorder3 = new TitledBorder("");
    titledBorder4 = new TitledBorder("");
    titledBorder5 = new TitledBorder("");
    titledBorder6 = new TitledBorder("");
    contentPane.setLayout(borderLayout1);
    this.setSize(new Dimension(600, 400));
    this.setState(Frame.ICONIFIED);
    this.setTitle("Servidor Proxy");
    jPanel1.setAlignmentX((float) 0.0);
    jPanel1.setAlignmentY((float) 0.0);
    jPanel1.setBorder(titledBorder1);
    jPanel1.setPreferredSize(new Dimension(60, 60));
    jPanel1.setLayout(borderLayout2);
    jPanel2.setBorder(titledBorder2);
    jPanel2.setPreferredSize(new Dimension(50, 50));
    contentPane.setBorder(titledBorder3);
    contentPane.setMinimumSize(new Dimension(600, 400));
    contentPane.setPreferredSize(new Dimension(600, 400));
    jButton1.setText("Desligar");
    jButton1.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(ActionEvent e) {
        jButton1_actionPerformed(e);
      }
    });
    memo.setBorder(BorderFactory.createEtchedBorder());
    memo.setEditable(false);
    contentPane.add(jPanel1,  BorderLayout.CENTER);
    jPanel1.add(jScrollPane1, BorderLayout.CENTER);
    jScrollPane1.getViewport().add(memo, null);
    contentPane.add(jPanel2, BorderLayout.SOUTH);
    jPanel2.add(jButton1, null);
  }
  /**Overridden so we can exit when window is closed*/
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING)  {
      jButton1_actionPerformed(null);
    }
  }

  void jButton1_actionPerformed(ActionEvent e) {
    if (st.isAlive())
      st.desligar();
    else System.exit(0);
  }

  public static void main(String[] args) {
    Mediador tela = new Mediador();
    tela.setVisible(true);
  }

}