package proxy_ex;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.IOException;

import java.net.Socket;
import java.net.UnknownHostException;
import java.net.URL;
import java.net.URLConnection;

import java.util.Hashtable;
import java.util.Properties;


/**
 * <p>Title: App_Proxy</p>
 * <p>Description: Exemplo do Padr�o de Projeto Proxy</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Mijasoftware</p>
 * @author Andre Luis e Jose Coutinho
 * @version 1.0
 */

public class ProxyClient implements ProxyInterface, Talkable {

  private static String SERVER_NAME = "localhost";
  private static int PORT = 444;

  /**
  static {
    try {
      URLConnection con = new URL("jar:file:/server.jar!/server.properties").openConnection();
      Properties p = new Properties();
      p.load(con.getInputStream());
      System.out.println("teste");
      SERVER_NAME = p.getProperty("host");
      PORT = Integer.parseInt(p.getProperty("port"));
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  */

  private Socket socketClient = null;
  private ObjectInputStream in  = null;
  private ObjectOutputStream out = null;
  private Hashtable resultado = null;


  public Hashtable getNotas()  throws Exception {
    try {
      conectar();
      byte result = 0;

      try{
        out.write(EXIBIR_NOTAS);
        out.flush();

        resultado = null;
        result = in.readByte();
        if (result == OK) {
          resultado = (Hashtable) in.readObject();
        }
      } catch (IOException ioe) {
        System.out.println("[" + this.getClass().getName() + "] " + ioe.getMessage());
      } catch (ClassNotFoundException cnfe) {
        System.out.println("[" + this.getClass().getName() + "] " + cnfe.getMessage());
      }

      if (result == ERROR) {
        Exception ex = (Exception) in.readObject();
        throw ex;
      }
    } finally {
      out.writeByte(FINNISH);
      out.flush();
      desconectar();
    }

    return resultado;
  }

  public Hashtable getNotas(String matricula) throws Exception {
    try {
      conectar();
      byte result = 0;

      try{
        out.write(EXIBIR_ALUNO);
        out.flush();

        resultado = null;
        result = in.readByte();
        if (result == OK) {
          out.writeUTF(matricula);
          out.flush();
          resultado = (Hashtable) in.readObject();
        }
      } catch (IOException ioe) {
        System.out.println("[" + this.getClass().getName() + "] " + ioe.getMessage());
      } catch (ClassNotFoundException cnfe) {
        System.out.println("[" + this.getClass().getName() + "] " + cnfe.getMessage());
      }

      if (result == ERROR) {
        Exception ex = (Exception) in.readObject();
        throw ex;
      }
    } finally {
      out.writeByte(FINNISH);
      out.flush();
      desconectar();
    }

    return resultado;
  }

  public void alterarNotas(String matricula, int unidade, float nota) throws Exception {
    try {
      conectar();
      byte result = 0;

      try{
        out.write(ALTERAR_NOTAS);
        out.flush();

        result = in.readByte();
        if (result == OK) {
          String args[] = {matricula, Integer.toString(unidade), Float.toString(nota)};
          out.writeObject(args);
          out.flush();

          result = in.readByte();
        }
      } catch (IOException ioe) {
        System.out.println("[" + this.getClass().getName() + "] " + ioe.getMessage());
      }

      if (result == ERROR) {
        Exception ex = (Exception) in.readObject();
        throw ex;
      }
    } finally {
      out.writeByte(FINNISH);
      out.flush();
      desconectar();
    }
  }

  private void conectar() {
    if (socketClient == null)
      try{
        System.out.println("[" + this.getClass().getName() + "] " + "Conectando com o servidor...");

        socketClient = new Socket(SERVER_NAME,PORT);
        out = new ObjectOutputStream(socketClient.getOutputStream());
        in = new ObjectInputStream(socketClient.getInputStream());

        System.out.println("[" + this.getClass().getName() + "] " + "Conex�o efetuada com sucesso...");
      } catch(UnknownHostException uhe){
        System.out.println("[" + this.getClass().getName() + "] " + uhe.getMessage());
      } catch(IOException ioe){
        System.out.println("[" + this.getClass().getName() + "] " + ioe.getMessage());
      }
  }

  private void desconectar() {
    try {
      System.out.println("[" + this.getClass().getName() + "] " + "Desconex�o com o servidor sendo realizada...");
      out.close();
      in.close();
      socketClient.close();
      socketClient = null;
    } catch(IOException ioe) {
      ioe.printStackTrace();
    }
  }
}