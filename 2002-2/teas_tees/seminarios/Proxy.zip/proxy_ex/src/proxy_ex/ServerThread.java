package proxy_ex;

import java.net.BindException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.io.IOException;

/**
 * <p>Title: App_Proxy</p>
 * <p>Description: Exemplo do Padr�o de Projeto Proxy</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Mijasoftware</p>
 * @author Andre Luis e Jose Coutinho
 * @version 1.0
 */

public class ServerThread extends Thread {
  private static final int TIME_OUT = 10000;
  private static final int PORT = 444;

  public static final byte ON = 1;
  public static final byte OFF = 0;

  private byte status;
  private ServerSocket server = null;

  public ServerThread() {
    this(PORT);
  }

  public ServerThread(int port) {
    super("ServerThread");
    super.setDaemon(false);

    try {
      server = new ServerSocket(port);
      server.setSoTimeout(TIME_OUT);

      status = ON;
    } catch(BindException be) {
      System.out.println("[" + this.getClass().getName() + "] " + be.getMessage());
    } catch(IOException ioe) {
      System.out.println("[" + this.getClass().getName() + "] " + ioe.getMessage());
    }
}

  public void run() {

    try {
      while (status != OFF) {
        try {

          System.out.println("[" + this.getClass().getName() + "] " + "Servidor principal aguardando requisi��es...");

          Socket clientSocket = server.accept();

          InetAddress inet = clientSocket.getInetAddress();

          System.out.println("[" + this.getClass().getName() + "] " + "Requisi��o aceita... " + inet.getHostAddress());

          new ProxyServer(clientSocket).start();

        }
        catch(Exception e) {}
      }
    } finally {
      try { server.close(); } catch(IOException e) {}
      System.out.println("[" + this.getClass().getName() + "] " + "Servidor Finalizado com sucesso...");
      System.exit(0);
    }
  }

  public void desligar() {
    this.status = OFF;
    System.out.println("[" + this.getClass().getName() + "] " + "Desligando o Servidor... " );
  }

  public boolean estaLigado() {
    return (status == ON);
  }
}