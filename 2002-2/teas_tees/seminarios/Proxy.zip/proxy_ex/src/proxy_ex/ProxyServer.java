package proxy_ex;

import java.util.Hashtable;
import java.util.Map;
import java.io.*;
import java.net.*;
import java.rmi.RemoteException;

/**
 * <p>Title: App_Proxy</p>
 * <p>Description: Exemplo do Padr�o de Projeto Proxy</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: Mijasoftware</p>
 * @author Andre Luis e Jose Coutinho
 * @version 1.0
 */

public class ProxyServer extends Thread implements ProxyInterface, Talkable {
  public static final byte ON = 1;
  public static final byte OFF = 0;

  private byte status = ON;

  private Socket sck = null;
  private InetAddress inet = null;
  private ObjectInputStream in  = null;
  private ObjectOutputStream out = null;

  private RealSubjectServer rs = null;

  public ProxyServer(Socket socket) {
    this.sck = socket;
    this.inet = sck.getInetAddress();
    rs = new RealSubjectServer();

    System.out.println("[" + this.getClass().getName() + "] " + "ProxyServer iniciado...");

    try{
      if ((in == null) || (out == null)){
        in = new ObjectInputStream(sck.getInputStream());
        out = new ObjectOutputStream(sck.getOutputStream());
      }
    } catch(IOException ioe) {
      System.out.println("[" + this.getClass().getName() + "] " + ioe.getMessage());
    }
  }

  public void run() {
    byte msg;

    while (status == ON) {
      try {
        msg = in.readByte();
        System.out.println("[" + this.getClass().getName() + "] Mensagem recebida: " + msg);

        switch (msg) {
          case EXIBIR_NOTAS:
            out.writeByte(OK);
            out.writeObject(this.getNotas());
            out.flush();
            break;

          case EXIBIR_ALUNO:
            out.writeByte(OK);
            out.flush();
            String mat = in.readUTF();
            out.writeObject(this.getNotas(mat));
            out.flush();
            break;

          case ALTERAR_NOTAS:
            out.writeByte(OK);
            out.flush();
            String[] args = (String[]) in.readObject();
            this.alterarNotas(args[0], Integer.parseInt(args[1]), Float.parseFloat(args[2]));
            out.writeByte(OK);
            out.flush();
            break;

          case FINNISH:
            status = OFF;
            break;

          default:
            sendError("Op��o Inv�lida: " + msg);
        }
      } catch(IOException ioe) {
        System.out.println("[" + this.getClass().getName() + "] " + ioe.getMessage());
      } catch(Exception e) {
        sendError(e.getMessage());
      } finally {
        status = OFF;
      }
    }

    System.out.println("[" + this.getClass().getName() + "] " + "ProxyServer(" + inet.getHostAddress() + ") finalizando...");
  }

  public Hashtable getNotas() throws Exception {
    return rs.getNotas();
  }

  public Hashtable getNotas(String matricula) throws Exception {
    return rs.getNotas(matricula);
  }

  public void alterarNotas(String matricula, int unidade, float nota) throws Exception {
    rs.alterarNotas(matricula, unidade, nota);
  }

  private void sendError(String msg) {
    try {
      System.out.println("[" + this.getClass().getName() + "] " + msg);
      out.writeByte(ERROR);
      out.writeObject(new RemoteException("[" + this.getClass().getName() + "] " + msg));
      out.flush();
    } catch(IOException ioe) {
      System.out.println("[" + this.getClass().getName() + "] " + ioe.getMessage());
    }
  }

  public void finalize() {
    try {
      this.sck.close();
    } catch(IOException ioe) {}
  }
}