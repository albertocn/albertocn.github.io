package bridge;

import java.util.List;

/**
 * Classe que define uma interface para cria��o de objetos
 * do tipo List.
 *
 * Utiliza o padr�o de projeto Abstract Factory implementado
 * como um Singleton.
 */

public abstract class AbstractFactoryImp {

  private static AbstractFactoryImp fabrica = null;

  public static AbstractFactoryImp instance () {

    if (fabrica == null)
      fabrica = new ConcreteFactoryImp();

    return fabrica;
  }

  protected abstract List criarList (int tamanho, List list);
  protected abstract List criarLinkedList (List list);
}