package bridge;

import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;

/**
 * Classe que implementa a interface definida por
 * AbstractFactoryImp para criar objetos de subclasses
 * concretas de List (LinkedList e ArrayList).
 *
 * @author Jos� Carlos dos Santos J�nior e Manoel Messias da S. M. J�nior
 * @date 11/02/2003
 */

public class ConcreteFactoryImp extends AbstractFactoryImp {

  public ConcreteFactoryImp() {
  }

  /**
   * Cria um ArrayList com tamanho inicial igual ao parametro
   * tamanho caso o parametro list seja null, caso contr�rio
   * cria um ArrayList com o conte�do do paramnetro list passado.
   *
   * @param tamanho int que especifica o tamanho para o ArrayList
   * @param list List que cont�m o conte�do para o ArrayList
   */
  public List criarList(int tamanho, List list) {
    if (list == null)
      return new ArrayList(tamanho);
    else
      return new ArrayList(list);
  }

  /**
   * Cria um LinkedList com o conte�do do par�metro list
   *
   * @param list List que cont�m o conte�do para o LinkedList
   */
  public List criarLinkedList(List list) {
    return new LinkedList(list);
  }

}