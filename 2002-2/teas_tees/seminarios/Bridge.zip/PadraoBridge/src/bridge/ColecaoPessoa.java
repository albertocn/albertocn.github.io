package bridge;

import java.util.List;
import java.util.LinkedList;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Classe abstrata que define a abstra��o ColecaoPessoa que pode ser
 * redefinida para criar classes concretas como ColecaoAluno e
 * ColecaoProfessor.
 * Repassa as solicita��es do cliente para o objeto Implementor (List).
 * Utiliza o padr�o de projeto Bridge para desacoplar a abstra��o de sua
 * implementa��o.
 *
 * @author Jos� Carlos dos Santos J�nior e Manoel Messias da S. M. J�nior
 * @date 11/02/2003
 */

public abstract class ColecaoPessoa {

  // tamanho limite que indicar� quando mudar de implementa��o (imp)
  private static final int TAM_LIMITE = 3;

  // Guarda a refer�ncia para a implementa��o que vai utilizar
  protected List imp;

  public ColecaoPessoa() {
    // Utiliza o Padr�o Abstract Factory para criar a implementa��o
    imp = AbstractFactoryImp.instance().criarList(TAM_LIMITE, null);
  }

  /**
   * Insere uma Pessoa na cole��o utilizando a implementa��o referenciada por
   * imp
   */
  public void inserir (Pessoa pessoa) {
    // Verifica se � necess�rio mudar de implementa��o (imp)
    if (imp.size() == TAM_LIMITE)
      mudarImpToLinkedList();

    imp.add(pessoa);
    System.out.println("Inseriu: " + pessoa + " Imp: " + imp.getClass() + " Tamanho: " + imp.size());
  }

  /**
   * Remove uma Pessoa da cole��o utilizando a implementa��o referenciada por
   * imp
   */
  public void remover (Pessoa pessoa) {
    if (pessoa.getNome() == null)
      pessoa = pegar(pessoa);

    imp.remove(pessoa);
    System.out.println("Removeu: " + pessoa + " Imp: " + imp.getClass() + " Tamanho: " + imp.size());

    // Verifica se � necess�rio mudar de implementa��o (imp)
    if (imp.size() == TAM_LIMITE)
      mudarImpToArrayList();
  }

  /**
   * Retorna uma pessoa espec�fica, caso essa pessoa n�o exista retorna null
   */
  public Pessoa pegar (Pessoa pessoa) {
    Iterator it = imp.iterator();
    while (it.hasNext()) {
      Pessoa temp = (Pessoa) it.next();
      if (temp.equals(pessoa))
        return temp;
    }
    return null;
  }

  /**
   * Muda a implementa��o referenciada por imp para LinkedList
   */
  protected void mudarImpToLinkedList () {
    imp = AbstractFactoryImp.instance().criarLinkedList(imp);
  }

  /**
   * Muda a implementa��o referenciada por imp para ArrayList
   */
  protected void mudarImpToArrayList () {
    imp = AbstractFactoryImp.instance().criarList(TAM_LIMITE, imp);
  }

  public int tamanho () {
    return imp.size();
  }

  public String getImpClass() {
    return imp.getClass().toString();
  }
}