package bridge;

/**
 * Subclasse concreta de Pessoa que adiciona caracter�sticas
 * espec�ficas de um professor.
 *
 * @author Jos� Carlos dos Santos J�nior e Manoel Messias da S. M. J�nior
 * @date 11/02/2003
 */

public class Professor extends Pessoa {

  protected String nivel;

  public Professor(String nome, String matricula, String nivel) {
    this.nome = nome;
    this.matricula = matricula;
    this.nivel = nivel;
  }

  public Professor (String matricula) {
    this.matricula = matricula;
  }

  public String getNivel() {
    return nivel;
  }

  public String toString() {
    return (matricula + " " + nome + " nivel: " + nivel);
  }
}