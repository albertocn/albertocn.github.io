package bridge;

import java.awt.event.*;
import java.awt.Container;
import java.awt.GridLayout;

import javax.swing.*;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Cadastro extends JFrame implements ActionListener, WindowListener {

  private ColecaoPessoa cl_aluno;
  private ColecaoPessoa cl_professor;

  private JLabel jl_tam_cl_aluno;
  private JLabel jl_tam_cl_professor;
  private JLabel jl_imp_cl_aluno;
  private JLabel jl_imp_cl_professor;

  private JMenuItem mi_inserir_aluno = new JMenuItem("Inserir");
  private JMenuItem mi_remover_aluno = new JMenuItem("Remover");
  private JMenuItem mi_consultar_aluno =  new JMenuItem("Consultar");

  private JMenuItem mi_inserir_professor = new JMenuItem("Inserir");
  private JMenuItem mi_remover_professor = new JMenuItem("Remover");
  private JMenuItem mi_consultar_professor =  new JMenuItem("Consultar");

  public Cadastro (ColecaoPessoa cl_aluno, ColecaoPessoa cl_professor) {
    super("Cadastro de Professores e Alunos");

    setSize(320, 215);
    setResizable(false);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    getContentPane().setLayout(null);

    this.cl_aluno = cl_aluno;
    this.cl_professor = cl_professor;

    JPanel p1 = new JPanel();
    JPanel p2 = new JPanel();

    p1.add(new JLabel("Cole��o de Alunos"));
    p1.add(new JLabel("Tamanho: "));
    jl_tam_cl_aluno = new JLabel(cl_aluno.tamanho()+"");
    p1.add(jl_tam_cl_aluno);
    p1.add(new JLabel("Implementa��o: "));
    jl_imp_cl_aluno = new JLabel(cl_aluno.getImpClass());
    p1.add(jl_imp_cl_aluno);

    p2.add(new JLabel("Cole��o de Professores"));
    p2.add(new JLabel("Tamanho: "));
    jl_tam_cl_professor = new JLabel(cl_professor.tamanho()+"");
    p2.add(jl_tam_cl_professor);
    p2.add(new JLabel("Implementa��o: "));
    jl_imp_cl_professor = new JLabel(cl_professor.getImpClass());
    p2.add(jl_imp_cl_professor);

    p1.setBorder(BorderFactory.createEtchedBorder());
    p2.setBorder(BorderFactory.createEtchedBorder());

    p1.setBounds(0, 0, 160, 160);
    p2.setBounds(160, 0, 160, 160);

    Container cp = getContentPane();
    cp.add(p1);
    cp.add(p2);

    JMenuBar mb = new JMenuBar();

    JMenu menu_cadastrar_aluno = new JMenu("Cadastrar Aluno");
    JMenu menu_cadastrar_professor = new JMenu("Cadastrar Professor");

    mi_inserir_aluno.setMnemonic('I');
    mi_remover_aluno.setMnemonic('R');
    mi_consultar_aluno.setMnemonic('C');

    mi_inserir_professor.setMnemonic('I');
    mi_remover_professor.setMnemonic('R');
    mi_consultar_professor.setMnemonic('C');

    menu_cadastrar_aluno.setMnemonic('A');
    menu_cadastrar_professor.setMnemonic('P');

    menu_cadastrar_aluno.add(mi_inserir_aluno);
    menu_cadastrar_aluno.add(mi_remover_aluno);
    menu_cadastrar_aluno.add(mi_consultar_aluno);

    menu_cadastrar_professor.add(mi_inserir_professor);
    menu_cadastrar_professor.add(mi_remover_professor);
    menu_cadastrar_professor.add(mi_consultar_professor);

    mi_inserir_aluno.addActionListener(this);
    mi_remover_aluno.addActionListener(this);
    mi_consultar_aluno.addActionListener(this);

    mi_inserir_professor.addActionListener(this);
    mi_remover_professor.addActionListener(this);
    mi_consultar_professor.addActionListener(this);

    mb.add(menu_cadastrar_aluno);
    mb.add(menu_cadastrar_professor);

    setJMenuBar(mb);

    this.addWindowListener(this);
  }

  public void actionPerformed(ActionEvent e) {
    JMenuItem jmi = (JMenuItem) e.getSource();

    if (jmi == mi_inserir_aluno)
      new InserirAluno(cl_aluno).show();

    if (jmi == mi_inserir_professor)
      new InserirProfessor(cl_professor).show();

    if (jmi == mi_remover_aluno)
      new RemoverAluno(cl_aluno).show();

    if (jmi == mi_remover_professor)
      new RemoverProfessor(cl_professor).show();

    if (jmi == mi_consultar_aluno)
      new ConsultarAluno(cl_aluno).show();

    if (jmi == mi_consultar_professor)
      new ConsultarProfessor(cl_professor).show();
  }

  public void windowActivated(WindowEvent e) {
    jl_tam_cl_aluno.setText(cl_aluno.tamanho()+"");
    jl_imp_cl_aluno.setText(cl_aluno.getImpClass());
    jl_tam_cl_professor.setText(cl_professor.tamanho()+"");
    jl_imp_cl_professor.setText(cl_professor.getImpClass());
  }

  public void windowDeactivated(WindowEvent e) {}

  public void windowIconified(WindowEvent e) {}

  public void windowDeiconified(WindowEvent e) {}

  public void windowOpened(WindowEvent e) {}

  public void windowClosed(WindowEvent e) {}

  public void windowClosing(WindowEvent e) {}

  public static void main (String args[]) {
    new Cadastro(new ColecaoAluno(), new ColecaoProfessor()).show();
  }
}

class InserirAluno extends JFrame implements ActionListener {

  private ColecaoPessoa cl_aluno;
  private JTextField jtf_nome;
  private JTextField jtf_matricula;
  private JTextField jtf_creditos;

  public InserirAluno(ColecaoPessoa cl_aluno) {
    super("Inserir Aluno");

    this.cl_aluno = cl_aluno;

    setSize(320, 160);
    setResizable(false);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    Container cp = getContentPane();
    cp.setLayout(new GridLayout(4, 2));
    JLabel jl_nome = new JLabel(" Nome");
    JLabel jl_matricula = new JLabel(" Matr�cula");
    JLabel jl_creditos = new JLabel(" Cr�ditos");
    JButton jb_inserir = new JButton(" Inserir");
    jtf_nome = new JTextField();
    jtf_matricula = new JTextField();
    jtf_creditos = new JTextField();

    cp.add(jl_nome);
    cp.add(jtf_nome);
    cp.add(jl_matricula);
    cp.add(jtf_matricula);
    cp.add(jl_creditos);
    cp.add(jtf_creditos);
    cp.add(jb_inserir);

    jb_inserir.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e) {
    cl_aluno.inserir(new Aluno(jtf_nome.getText(), jtf_matricula.getText(),
                               jtf_creditos.getText()));
    jtf_nome.setText("");
    jtf_matricula.setText("");
    jtf_creditos.setText("");
  }
}

class RemoverAluno extends JFrame implements ActionListener {
  private ColecaoPessoa cl_aluno;
  private JTextField jtf_matricula;

  public RemoverAluno (ColecaoPessoa cl_aluno) {
    super("Remover Aluno");

    this.cl_aluno = cl_aluno;

    setSize(320, 100);
    setResizable(false);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    Container cp = getContentPane();
    cp.setLayout(new GridLayout(2, 2));
    JLabel jl_matricula = new JLabel(" Matr�cula");
    JButton jb_remover = new JButton("Remover");
    jtf_matricula = new JTextField();

    cp.add(jl_matricula);
    cp.add(jtf_matricula);
    cp.add(jb_remover);

    jb_remover.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e) {
    cl_aluno.remover(new Aluno(jtf_matricula.getText()));
    jtf_matricula.setText("");
  }
}

class ConsultarAluno extends JFrame implements ActionListener {
  private ColecaoPessoa cl_aluno;
  private JTextField jtf_matricula;
  private JLabel jl_matricula;
  private JLabel jl_nome = new JLabel(" Nome");
  private JLabel jl_creditos = new JLabel(" Cr�ditos");
  private JTextField jtf_nome = new JTextField();
  private JTextField jtf_creditos = new JTextField();
  private JLabel jl_res = new JLabel();

  private Container cp;
  private JButton jb_consultar;

  public ConsultarAluno(ColecaoPessoa cl_aluno) {
    super("Consultar Aluno");

    this.cl_aluno = cl_aluno;
    setSize(320, 160);
    setResizable(false);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    jb_consultar = new JButton("Consultar");

    cp = getContentPane();
    cp.setLayout(new GridLayout(2, 2));
    jl_matricula = new JLabel(" Matr�cula");
    jtf_matricula = new JTextField();

    cp.add(jl_matricula);
    cp.add(jtf_matricula);
    cp.add(jb_consultar);

    jb_consultar.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e) {
    Pessoa p = cl_aluno.pegar(new Aluno(jtf_matricula.getText()));

    cp.removeAll();
    setResizable(true);
    if (p != null) {
      setSize(320, 160);
      setResizable(false);
      cp.setLayout(new GridLayout(4, 2));


      cp.add(jl_matricula);
      cp.add(jtf_matricula);
      cp.add(jl_nome);
      jtf_nome.setText(p.getNome());
      cp.add(jtf_nome);
      cp.add(jl_creditos);
      jtf_creditos.setText(((Aluno)p).getCreditos());
      cp.add(jtf_creditos);
      cp.add(jb_consultar);

    }
    else {
      setSize(340, 160);
      setResizable(false);
      cp.setLayout(new GridLayout(3, 2));

      cp.add(jl_matricula);
      cp.add(jtf_matricula);
      jl_res.setText("Aluno " + jtf_matricula.getText() + " inexistente.");
      cp.add(jl_res);
      cp.add(jb_consultar);
    }
  }

}

class InserirProfessor extends JFrame implements ActionListener {
  private ColecaoPessoa cl_professor;
  private JTextField jtf_nome;
  private JTextField jtf_matricula;
  private JTextField jtf_nivel;

  public InserirProfessor(ColecaoPessoa cl_professor) {
    super("Inserir Professor");

    this.cl_professor = cl_professor;

    setSize(320, 160);
    setResizable(false);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    Container cp = getContentPane();
    cp.setLayout(new GridLayout(4, 2));
    JLabel jl_nome = new JLabel(" Nome");
    JLabel jl_matricula = new JLabel(" Matr�cula");
    JLabel jl_nivel = new JLabel(" N�vel");
    JButton jb_inserir = new JButton(" Inserir");
    jtf_nome = new JTextField();
    jtf_matricula = new JTextField();
    jtf_nivel = new JTextField();

    cp.add(jl_nome);
    cp.add(jtf_nome);
    cp.add(jl_matricula);
    cp.add(jtf_matricula);
    cp.add(jl_nivel);
    cp.add(jtf_nivel);
    cp.add(jb_inserir);

    jb_inserir.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e) {
    cl_professor.inserir(new Professor(jtf_nome.getText(), jtf_matricula.getText(),
                                       jtf_nivel.getText()));
    jtf_nome.setText("");
    jtf_matricula.setText("");
    jtf_nivel.setText("");
  }
}

class RemoverProfessor extends JFrame implements ActionListener {
  private ColecaoPessoa cl_professor;
  private JTextField jtf_matricula;

  public RemoverProfessor (ColecaoPessoa cl_professor) {
    super("Remover Professor");

    this.cl_professor = cl_professor;

    setSize(320, 100);
    setResizable(false);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    Container cp = getContentPane();
    cp.setLayout(new GridLayout(2, 2));
    JLabel jl_matricula = new JLabel(" Matr�cula");
    JButton jb_remover = new JButton("Remover");
    jtf_matricula = new JTextField();

    cp.add(jl_matricula);
    cp.add(jtf_matricula);
    cp.add(jb_remover);

    jb_remover.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e) {
    cl_professor.remover(new Aluno(jtf_matricula.getText()));
    jtf_matricula.setText("");
  }
}

class ConsultarProfessor extends JFrame implements ActionListener {

  private ColecaoPessoa cl_professor;
  private JTextField jtf_matricula;
  private JLabel jl_matricula;
  private JLabel jl_nome = new JLabel(" Nome");
  private JLabel jl_nivel = new JLabel(" N�vel");
  private JTextField jtf_nome = new JTextField();
  private JTextField jtf_nivel = new JTextField();
  private JLabel jl_res = new JLabel();

  private Container cp;
  private JButton jb_consultar;

  public ConsultarProfessor(ColecaoPessoa cl_professor) {
    super("Consultar Professor");

    this.cl_professor = cl_professor;
    setSize(320, 160);
    setResizable(false);
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

    jb_consultar = new JButton("Consultar");

    cp = getContentPane();
    cp.setLayout(new GridLayout(2, 2));
    jl_matricula = new JLabel(" Matr�cula");
    jtf_matricula = new JTextField();

    cp.add(jl_matricula);
    cp.add(jtf_matricula);
    cp.add(jb_consultar);

    jb_consultar.addActionListener(this);
  }

  public void actionPerformed(ActionEvent e) {
    Pessoa p = cl_professor.pegar(new Professor(jtf_matricula.getText()));

    cp.removeAll();
    setResizable(true);
    if (p != null) {
      setSize(320, 160);
      setResizable(false);
      cp.setLayout(new GridLayout(4, 2));


      cp.add(jl_matricula);
      cp.add(jtf_matricula);
      cp.add(jl_nome);
      jtf_nome.setText(p.getNome());
      cp.add(jtf_nome);
      cp.add(jl_nivel);
      jtf_nivel.setText(((Professor)p).getNivel());
      cp.add(jtf_nivel);
      cp.add(jb_consultar);

    }
    else {
      setSize(380, 100);
      setResizable(false);
      cp.setLayout(new GridLayout(3, 2));

      cp.add(jl_matricula);
      cp.add(jtf_matricula);
      jl_res.setText("Professor " + jtf_matricula.getText() + " inexistente.");
      cp.add(jl_res);
      cp.add(jb_consultar);
    }
  }
}