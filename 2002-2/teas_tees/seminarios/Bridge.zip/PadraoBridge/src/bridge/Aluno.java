package bridge;

/**
 * Subclasse concreta de Pessoa que adiciona caracter�sticas
 * espec�ficas de um aluno
 *
 * @author Jos� Carlos dos Santos J�nior e Manoel Messias da S. M. J�nior
 * @date 11/02/2003
 */

public class Aluno extends Pessoa {

  protected String creditos;

  public Aluno() {
  }

  public Aluno(String nome, String matricula, String creditos) {
    this.nome = nome;
    this.matricula = matricula;
    this.creditos = creditos;
  }

  public Aluno(String matricula) {
    this.matricula = matricula;
  }

  public String getCreditos() {
    return creditos;
  }

  public String toString() {
    return (matricula + " " + nome + " creditos: " + creditos);
  }
}