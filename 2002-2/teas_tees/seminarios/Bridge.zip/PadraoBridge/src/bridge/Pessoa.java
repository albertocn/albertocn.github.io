package bridge;

/**
 * Classe abstrata que define uma Pessoa gen�rica
 *
 * @author Jos� Carlos dos Santos J�nior e Manoel Messias da S. M. J�nior
 * @date 11/02/2003
 */

public abstract class Pessoa {

  protected String nome;
  protected String matricula;

  public Pessoa() {
  }

  public  String getNome() {
    return nome;
  }

  public String getMatricula() {
    return matricula;
  }

  public boolean equals (Object obj) {
    return this.matricula.equals(((Pessoa) obj).getMatricula());
  }

  public String toString() {
    return (matricula + " " + nome);
  }
}