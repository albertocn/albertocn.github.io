package bridge;

import java.util.LinkedList;
import java.util.ArrayList;

/**
 * Abstra��o redefinida, subclasse da classe abstrata ColecaoPessoa
 *
 * @author Jos� Carlos dos Santos J�nior e Manoel Messias da S. M. J�nior
 * @date 11/02/2003
 */

public class ColecaoAluno extends ColecaoPessoa {

  public ColecaoAluno() {
  }

  public void inserir (Pessoa pessoa) {
      super.inserir(pessoa);
  }

  public void remover (Pessoa pessoa) {
    super.remover(pessoa);
  }

  public Pessoa pegar (Pessoa pessoa) {
    return super.pegar(pessoa);
  }
}