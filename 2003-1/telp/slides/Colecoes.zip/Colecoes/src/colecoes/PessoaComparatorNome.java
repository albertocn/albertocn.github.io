package colecoes;

import java.util.Comparator;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class PessoaComparatorNome implements Comparator {

  public int compare(Object o1, Object o2) {
    Pessoa p1 = (Pessoa) o1;
    Pessoa p2 = (Pessoa) o2;

    return p1.getNome().compareTo( p2.getNome() );
  }

  public static void main(String[] args) {
    List pessoas = new ArrayList();
    pessoas.add( new Pessoa(3, "B") );
    pessoas.add( new Pessoa(4, "Z") );
    pessoas.add( new Pessoa(1, "A") );
    pessoas.add( new Pessoa(2, "X") );
    System.out.println( "Inicial.: " + pessoas );

    Set pessoasPorId = new TreeSet( pessoas );
    System.out.println( "Por ID..: " + pessoasPorId );

    Set pessoasPorNome = new TreeSet( new PessoaComparatorNome() );
    pessoasPorNome.addAll( pessoas );
    System.out.println( "Por nome: " + pessoasPorNome );
  }
}