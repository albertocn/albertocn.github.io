package colecoes;

import java.util.Collection;
import java.util.Map;
import java.util.TreeMap;
import java.util.Iterator;
import java.util.Set;

public class TesteMapEntry {

  public static void main(String[] args) {
    Map map = new TreeMap();
    map.put( new Integer(1), "A" );
    map.put( new Integer(2), "B" );
    map.put( new Integer(3), "C" );

    imprimirEntries( map );
    imprimirChaves( map );
    imprimirValores( map );
  }

  private static void imprimirEntries( Map map ) {
    Set entrySet = map.entrySet();
    Iterator it = entrySet.iterator();
    System.out.print('[');
    while (it.hasNext()) {
      Map.Entry entry = (Map.Entry) it.next();
      System.out.print('(');
      System.out.print(entry.getKey());
      System.out.print(',');
      System.out.print(entry.getValue());
      System.out.print(')');
    }
    System.out.println(']');
  }
  private static void imprimirChaves( Map map ) {
    Set keySet = map.keySet();
    imprimir( "Chaves: ", keySet.iterator() );
  }
  private static void imprimirValores( Map map ) {
    Collection valores = map.values();
    imprimir( "Valores: ", valores.iterator() );
  }

  private static void imprimir( String msg, Iterator it ) {
    System.out.print(msg);
    while (it.hasNext()) {
      System.out.print( it.next() );
      if (it.hasNext())
        System.out.print( ',' );
    }
    System.out.println();
  }
}