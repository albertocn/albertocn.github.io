package colecoes;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;
import java.util.HashSet;

public class TesteSet {

  public static void main(String args[]) {
    Set set = new HashSet();
    set.add("C");
    set.add("B");
    set.add("C");
    set.add("A");
    set.add("D");
    println( set.iterator() );

    Set sortedSet = new TreeSet(set);
    println(sortedSet.iterator());
  }

  private static void println(Iterator it) {
    System.out.print('[');
    while (it.hasNext()) {
      String s = (String) it.next();
      System.out.print(s);
      if (it.hasNext())
        System.out.print(", ");
    }
    System.out.println(']');
  }
}