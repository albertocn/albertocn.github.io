package swing;

import java.awt.CardLayout;
import java.awt.BorderLayout;
import java.awt.Choice;
import java.awt.Container;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CardLayoutDemo extends JFrame {

  private final static String BUTTONPANEL = "JPanel com JButtons";
  private final static String TEXTPANEL   = "JPanel com JTextField";

  private JPanel cards;

  public CardLayoutDemo() {

    Container contentPane = getContentPane();

    // Coloca o JComboBox em um JPanel
    JPanel pc = new JPanel();
    JComboBox c = new JComboBox();
    c.addItem(BUTTONPANEL);
    c.addItem(TEXTPANEL);
    pc.add(c);
    contentPane.add(BorderLayout.NORTH, pc);

    cards = new JPanel();
    cards.setLayout(new CardLayout());

    // Cria o JPanel com os bot�es
    JPanel p1 = new JPanel();
    p1.add(new JButton("Button 1"));
    p1.add(new JButton("Button 2"));
    p1.add(new JButton("Button 3"));

    // Cria o JPanel com o campo de texto
    JPanel p2 = new JPanel();
    p2.add(new JTextField("TextField", 20));

    cards.add(BUTTONPANEL, p1);
    cards.add(TEXTPANEL,   p2);
    contentPane.add(BorderLayout.CENTER, cards);

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });

    c.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        CardLayout cl = (CardLayout) cards.getLayout();
        cl.show(cards, (String) e.getItem());
      }
    });
  }

  public static void main(String args[]) {
    JFrame f = new CardLayoutDemo();
    f.setTitle("CardLayoutDemo");
    f.pack();
    f.show();
  }
}
