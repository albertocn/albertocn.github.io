package swing;

import java.awt.BorderLayout;
import java.awt.Container;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.File;
import java.io.IOException;

import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class JListDemo extends JFrame {

  private JList arquivos = new JList();
  private JLabel tamanho = new JLabel();

  public JListDemo() {
    super( "JList Demo" );

    Container contentPane = getContentPane();
    contentPane.setLayout( new BorderLayout() );

    arquivos.setListData( obterArquivos() );
    arquivos.addListSelectionListener( new ArquivosListener() );

    JScrollPane scrollPane = new JScrollPane(arquivos,
                                             JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    contentPane.add( BorderLayout.CENTER, scrollPane );
    contentPane.add( BorderLayout.SOUTH, tamanho );

    setSize( 500, 200 );
    show();
  }

  private class ArquivosListener implements ListSelectionListener {
    public void valueChanged (ListSelectionEvent e) {
      atualizarLabel();
    }
  }

  private void atualizarLabel() {
    this.tamanho.setText( getTextTamanho() );
  }

  private String getTextTamanho() {
    return "Tamanho (em bytes): " + getTamanhoSelecionados();
  }

  public long getTamanhoSelecionados() {
    Object[] files = arquivos.getSelectedValues();

    long soma = 0;
    for (int i = 0; i < files.length; i++) {
      soma += ( (File) files[i]).length();
    }
    return soma;
  }

  private Vector obterArquivos() {
    Vector arqs = new Vector();
    try {
      File dir = new File(".").getCanonicalFile();
      File[] conteudoDir = dir.listFiles();
      for (int i = 0; i < conteudoDir.length; i++) {
        if (conteudoDir[i].isFile()) {
          arqs.add( conteudoDir[i]);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return arqs;
  }

  public static void main( String args[] ) {
    JListDemo application = new JListDemo();
    application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }
}