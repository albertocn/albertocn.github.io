package errosexcecoes;

import java.util.Date;

public class DateException extends Exception {

  protected Date data = new Date();

  public DateException(String msg) {
    super(msg);
  }

  public DateException() {
    super();
  }

  public Date getData() { return data; }

  public static void main(String[] args) {
    try {
      metodo1();
    } catch (DateException e) {
      System.err.println("Data: " + e.getData());
      e.printStackTrace();

    }
  }

  private static void metodo1() throws DateException {
    metodo2();
  }

  private static void metodo2() throws DateException {
    metodo3();
  }

  private static void metodo3() throws DateException {
//    DateException de = new DateException();
    DateException de = new DateException("MENSAGEM DE ERRO");
    throw de;
  }

}