package errosexcecoes;

public class ExemploThrow {

  private String param;

  public ExemploThrow( String param ) {
    setParam( param );
    System.out.println("Param OK");
  }

  public String getParam() { return param; }

  public void setParam( String novoParam ) {
    if (novoParam == null) {
      throw new IllegalArgumentException ( "param n�o pode ser null" );
    } else if ( novoParam.equals("") ) {
      throw new IllegalArgumentException ( "param deve conter algo" );
    }
  }

  public static void main(String[] args) {
//    new ExemploThrow( null );
//    new ExemploThrow( "" );
    new ExemploThrow( "A" );
  }
}