public class Tarefa {
    public static final int PRIORIDADE_MINIMA =  0;
    public static final int PRIORIDADE_NORMAL =  5;
    public static final int PRIORIDADE_MAXIMA = 10;
}