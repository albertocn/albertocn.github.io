public class Unicode {
  public static void main(String[] args) {
    System.out.println("Linha 1\nLinha 2");
    System.out.println("\"");
//    System.out.println("\u0022");
    System.out.println("\u005c\u0022");
//    System.out.println("\\u0022");
    System.out.println('\u0041');
  }
}