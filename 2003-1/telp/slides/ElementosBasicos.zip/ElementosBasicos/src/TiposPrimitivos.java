public class TiposPrimitivos {

  public static void main(String[] args) {

    // Caracteres
    char A = 'A';
    char novaLinha = '\n';
    char apostrofo = '\'';

    // Booleanos
    boolean b1 = true;
    boolean b2 = A == '\u0041';

    // Inteiros
    byte  b = 127;
    short s = 32767;
    int   i = 2147483647;
    long  l = 9223372036854775807L;

    // Reais
    float  f1 = 0.0f;
    float  f2 = 3.00e+8F;
    double d1 = 0.0;
    double d2 = 3.00E+8;
  }
}