public class Circulo {
    public double x, y;  // Coordenadas do centro
    public double r;     // Raio

    // M�todo que retorna a circunfer�ncia
    public double circunferencia() {
        return 2 * 3.14159 * r;
    }

    // M�todo que retorna a �rea
    public double area() {
        return 3.14159 * r * r;
    }

    // Imprime os atributos do objeto
    public void print() {
      System.out.println("(x, y) = (" + x + ", " + y + ") r = " + r);
    }

    // Mostra como acessar atributos de um objeto
    private static void acessarAtributos() {
      // Instancia a classe Circulo
      Circulo c = new Circulo();

      // Inicializa o c�rculo para ter
      // centro (1,4) e raio 10.0
      c.x = 1.0;
      c.y = 4.0;
      c.r = 10.0;

      c.print();
    }

    // Mostra como chamar m�todos de um objeto
    private static void chamarMetodos() {
      Circulo c = new Circulo();
      c.x = 1.0; c.y = 1.0; c.r = 10.0;

      // Atribui o valor da �rea � vari�vel a
      double a = c.area();

      // Atribui o valor da circunfer�ncia � vari�vel b
      double b = c.circunferencia();

      c.print();
      System.out.println("Area = " + a);
      System.out.println("Circunfer�ncia = " + b);
    }

    public static void main(String[] args) {
      acessarAtributos();
      chamarMetodos();
    }
}