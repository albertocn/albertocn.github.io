public class Referencia {

  public static void main(String[] args) {
    StringBuffer sb1, sb2;
    sb1 = new StringBuffer("O"); // sb1 se refere a um objeto StringBuffer
    sb2 = sb1;                   // sb2 se refere ao mesmo StringBuffer
    sb1.append("k");             // Uma mudan�a no objeto atrav�s de sb1
    String s = sb2.toString();   // tamb�m � vis�vel atrav�s de sb2
    System.out.println(s);       // s cont�m OK

    int i = 3;  // i cont�m o valor 3
    int j = i;  // j cont�m uma c�pia do valor de i
    i = 2;      // Trocar o valor de i n�o afeta j
    System.out.println("i = " + i); // i = 2
    System.out.println("j = " + j); // j = 3
  }
}