package br.com.y;

public class Produto {
  // Defini��o da classe
}