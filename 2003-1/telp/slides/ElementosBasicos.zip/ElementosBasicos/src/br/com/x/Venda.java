package br.com.x;

import br.com.y.Produto;
import java.util.*;

public class Venda {
    protected Vector itens;
    protected Date data;
    protected Produto produto;
    // Defini��o da classe
}
