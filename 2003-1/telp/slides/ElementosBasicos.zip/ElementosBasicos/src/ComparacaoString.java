public class ComparacaoString {

  public static void main(String args[])
  {
    // O compilador usa o mesmo objeto, imprimindo a mensagem
    String teste1 = "teste1";
    if (teste1 == "teste1") {
      System.out.println("== 1");
    }

    // Ao usar o operador new, foi criado uma nova inst�ncia,
    // independente do pool do compilador
    String teste2 = new String("teste2");
    if (teste2 == "teste2") {
      System.out.println("== 2");
    }

    // O valor de teste3 s� pode ser determinado em tempo de execu��o
    // Por isso, usa uma nova inst�ncia
    String teste3 = "";
    teste3 = teste3 + "teste3";
//    teste3 += "teste3";
    if (teste3 == "teste3") {
      System.out.println("== 3");
    }

    if (teste1.equals("teste1")) {
      System.out.println("equals 1");
    }
    if (teste2.equals("teste2")) {
      System.out.println("equals 2");
    }
    if (teste3.equals("teste3")) {
      System.out.println("equals 3");
    }
  }
}