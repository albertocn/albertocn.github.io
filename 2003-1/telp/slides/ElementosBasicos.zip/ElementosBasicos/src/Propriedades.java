public class Propriedades {
  public static void main(String[] args) {
    // Imprime o nome do sistema operacional
    System.out.println( System.getProperty("os.name") );
    // Imprime a propriedade passada na linha de comando
    System.out.println( System.getProperty("prop1") );
    // Lista todas as propriedades
    System.getProperties().list(System.out);
  }
}