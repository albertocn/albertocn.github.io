/** Imprime todos os argumentos passados na linha de comando */
public class Echo {
  public static void main(String[] args) {
    for (int i = 0; i < args.length; i++) {
      System.out.print("args[" + i + "] = ");
      System.out.println(args[i]);
    }
    System.exit(0);
  }
}