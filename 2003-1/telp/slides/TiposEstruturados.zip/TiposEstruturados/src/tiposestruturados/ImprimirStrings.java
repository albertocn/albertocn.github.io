package tiposestruturados;

/**
 * Demonstra a utiliza��o de Strings
 */
public class ImprimirStrings {

    public static void main(String args[]) {
        String s = "ABC";
        for (int i = 0; i < s.length(); i++) {
            System.out.println(s.charAt(i));
        }
        for (int j = 1; j <= 3; j++) {
          s += String.valueOf(j);
        }
        System.out.println(s);
        System.out.println("Index Of B:" + s.indexOf('B'));
        s += 'A';
        System.out.println("Substring: " + s.substring(3, 6));
        System.out.println("Last Index Of A: " + s.lastIndexOf('A'));
        System.out.println("Equals: " + s.equals( "ABC123A") );
    }
}

