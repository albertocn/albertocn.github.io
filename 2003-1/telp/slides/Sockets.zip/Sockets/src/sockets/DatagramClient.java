package sockets;

import java.io.*;
import java.net.*;

public class DatagramClient {

  private DatagramSocket dSocket;

  public DatagramClient(String servidorDeNomes,
                        String nomeAPesquisar)
      throws UnknownHostException, SocketException, IOException {

    // Cria um DatatagramSocket que escuta na porta 5001
    dSocket = new DatagramSocket(5001);

    // Ajusta o time out do socket para 1 segundo. Isso
    // que significa o tempo m�ximo de resposta � de 1 segundo.
    // Se ocorrer algum problema (servidor congestionado,
    // servidor fora do ar, rede caiu, etc) que impossibilite o
    // recebimento de uma resposta, � lan�ada uma exce��o
    dSocket.setSoTimeout(1000);

    // Obt�m o endere�o associado ao nome, usando o
    // servidor de nomes especificado
    String end = consultarServidor(servidorDeNomes, nomeAPesquisar);

    System.out.println("Endereco: " + end);
  }

  // Consulta o servidor de nomes especificado pelo nome
  private String consultarServidor(String servidorDeNomes,
                                   String nomeAPesquisar)
      throws UnknownHostException, IOException {

    // Cria o pacotes a ser enviado ao servidor
    DatagramPacket pacoteAEnviar = criarPacoteAEnviar(servidorDeNomes,
                                                      5000,
                                                      nomeAPesquisar);

    // Envia o pacote com o nome a ser consultado ao servidor
    dSocket.send(pacoteAEnviar);

    // Espera o datagrama que cont�m a resposta do servidor
    DatagramPacket pacoteRecebido = esperarResposta();

    // Retorna o endere�o contido no datagrama
    return new String(pacoteRecebido.getData(), 0,
                      pacoteRecebido.getLength());
  }

  // Cria um datagrama a ser enviado para o host especificado,
  // usando a porta passada e contendo a String s
  private DatagramPacket criarPacoteAEnviar(String host,
                                            int    porta,
                                            String s)
      throws UnknownHostException {

    byte[] buf = s.getBytes();
    InetAddress address = InetAddress.getByName(host);
    return new DatagramPacket(buf, buf.length, address, porta);
  }

  // Retorna um datagrama recebido do socket
  private DatagramPacket esperarResposta() throws IOException {
    byte[] buf = new byte[256];
    DatagramPacket p = new DatagramPacket(buf, buf.length);

    // Bloqueia at� que receba um datagrama ou que ocorra um
    // time out (especificado atrav�s do m�todo setSoTimeout())
    dSocket.receive(p);

    return p;
  }

  public static void main(String[] args) {
    if (args.length != 2) {
      System.out.println("Use: java sockets.DatagramClient " +
                         "<servidorDeNomes> <nome>");
      System.out.println("Ex.: java sockets.DatagramClient " +
                         "localhost a");
      System.exit(1);
    }

    try {
      new DatagramClient(args[0], args[1]);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}