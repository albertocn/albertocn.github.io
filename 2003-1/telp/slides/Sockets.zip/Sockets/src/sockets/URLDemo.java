package sockets;

import java.net.MalformedURLException;
import java.net.URL;

public class URLDemo {

    public URLDemo() throws MalformedURLException {
        imprimir(criarURLSimples());
        imprimir(criarURLRelativa());
        imprimir(criarURLPartes());
    }

    // Cria uma URL usado o construtor que recebe uma
    // String que representa a URL
    private URL criarURLSimples()
            throws MalformedURLException {

        return new URL("http://java.sun.com");
    }

    // Cria um objeto URL relativo a outro objeto URL
    private URL criarURLRelativa()
            throws MalformedURLException {

        URL urlBase = new URL("http://java.sun.com");
        return new URL(urlBase, "index.htm");
    }

    // Cria um objeto URL informando algumas das partes
    // de uma URL
    private URL criarURLPartes()
            throws MalformedURLException {

        return new URL("http", "java.sun.com", 80, "/index.htm");
    }

    // Imprime as partes do objeto URL especificado
    private void imprimir(URL url) {
      System.out.println();
      System.out.println("URL: " + url);

      System.out.print("protocolo: " + url.getProtocol() + ", ");
      System.out.print("host: "      + url.getHost()     + ", ");
      System.out.println("porta: "     + url.getPort()     + ", ");

      System.out.println("caminho: "   + url.getFile());
    }

    public static void main(String[] args) {
        try {
            new URLDemo();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
}