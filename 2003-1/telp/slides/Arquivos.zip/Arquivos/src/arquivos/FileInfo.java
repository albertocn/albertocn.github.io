package arquivos;

import java.io.File;
import java.io.IOException;

import java.util.Date;

public class FileInfo {

  public FileInfo( String path ) {
    try {
      File f = new File( path );
      System.out.println("exists: " + f.exists());
      System.out.println("canRead: " + f.canRead());
      System.out.println("canWrite: " + f.canWrite());
      System.out.println("getName: " + f.getName());
      System.out.println("isDirectory: " + f.isDirectory());
      System.out.println("isFile: " + f.isFile());
      System.out.println("isHidden: " + f.isHidden());
      System.out.println("lastModified: " + new Date(f.lastModified()));
      System.out.println("length: " + f.length());
      System.out.println("getAbsolutePath: " + f.getAbsolutePath());
      System.out.println("getCanonicalPath: " + f.getCanonicalPath());

      exibir("Arquivos", f.getCanonicalFile().getParentFile().listFiles() );
      exibir("Roots", f.listRoots() );
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  private void exibir (String msg, File[] files) {
    System.out.println("[" + msg + "]");
    for (int i = 0; i < files.length; i++) {
      System.out.println(files[i]);
    }
  }

  public static void main(String[] args) {
    new FileInfo("Arquivos.jpx");

//    String sep = System.getProperty("file.separator");
//    new FileInfo(".." + sep + "arquivos" + sep + "Arquivos.jpx");
  }
}