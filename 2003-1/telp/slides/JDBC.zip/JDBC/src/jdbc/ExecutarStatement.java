package jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Demonstra como executar uma consulta e navegar pelo resultado usando
 * um Statement.
 */
public class ExecutarStatement extends ExecutarBase {

  public ExecutarStatement( String nome ) {
    super(nome);
  }

  public void consultar( String sql ) {
    Connection con = criarConexao();
    if (con == null) {
      System.err.println("Erro ao obter conex�o");
      return;
    }

    try {
      Statement stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery( sql );
      exibirResultSet( rs );
    } catch (SQLException e) {
      System.err.println( "SQLState: " + e.getSQLState() );
      System.err.println( "ErrorCode: " + e.getErrorCode() );
      e.printStackTrace();
    } finally {
      if (con != null) {
        try { con.close();
        } catch (Exception e) { e.printStackTrace(); }
      }
    }
  }

  public static void main(String[] args) {
//    ExecutarStatement es = new ExecutarStatement( "JDataStore.Employee" );
//    ExecutarStatement es = new ExecutarStatement( "Interbase.Employee" );
    ExecutarStatement es = new ExecutarStatement( "Interbase.FB.Employee" );
    es.consultar( "SELECT * FROM employee" );
//    ExecutarStatement es = new ExecutarStatement( "MySQL.JDBC" );
//    es.consultar( "SELECT * FROM tb_aluno" );
  }
}