package jdbc;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

import java.util.Properties;

/**
 * Permite criar conex�es a partir de arquivos de configura��o
 */
public class FabricaConexoes {

  protected Properties prop = new Properties();

  private FabricaConexoes( String nome )
      throws FileNotFoundException, IOException {
    prop.load( new FileInputStream( new File( nome + ".config") ) );
  }

  protected String getURL() {
    return prop.getProperty( "jdbc.url" );
  }

  protected String getDriver() {
    return prop.getProperty( "jdbc.driver" );
  }

  protected String getUsuario() {
    return prop.getProperty( "jdbc.usuario" );
  }

  protected String getSenha() {
    return prop.getProperty( "jdbc.senha" );
  }

  protected Connection criarConexao()
      throws ClassNotFoundException, IOException, FileNotFoundException, SQLException {
    Class.forName( getDriver() );
    return DriverManager.getConnection( getURL(), getUsuario(), getSenha() );
  }

  public static Connection instance( String nome )
      throws ClassNotFoundException, IOException, FileNotFoundException, SQLException {
    return new FabricaConexoes( nome ).criarConexao();
  }

  public static void main(String[] args) {
    Connection con = null;
    try {
//      con = FabricaConexoes.instance( "MySQL.JDBC" );
//      con = FabricaConexoes.instance( "JDataStore.Employee" );
//      con = FabricaConexoes.instance( "Interbase.Employee" );
      con = FabricaConexoes.instance( "Interbase.FB.Employee" );
      System.out.println("Conex�o efetuada");
      con.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}