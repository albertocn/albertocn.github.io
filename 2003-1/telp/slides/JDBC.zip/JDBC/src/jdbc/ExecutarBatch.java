package jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Demonstra como executar comandos SQL em Batch
 */

public class ExecutarBatch extends ExecutarBase {

  public ExecutarBatch( String nome ) {
    super(nome);
  }

  public void executar( String[] comandos ) {
    Connection con = criarConexao();
    if (con == null) {
      System.err.println("Erro ao obter conex�o");
      return;
    }

    try {
      Statement stmt = con.createStatement();
      for (int i = 0; i < comandos.length; i++) {
        stmt.addBatch( comandos[i] );
      }
      int[] linhas = stmt.executeBatch();
      for (int i = 0; i < comandos.length; i++) {
        System.out.print("Comando: [" + comandos[i] + "] afetou (");
        System.out.println( linhas[i] + ") linha(s)");
      }
    } catch (SQLException e) {
      System.err.println( "SQLState: " + e.getSQLState() );
      System.err.println( "ErrorCode: " + e.getErrorCode() );
      e.printStackTrace();
    } finally {
      if (con != null) {
        try { con.close();
        } catch (Exception e) { e.printStackTrace(); }
      }
    }
  }

  public static void main(String[] args) {
    ExecutarBatch eb = new ExecutarBatch( "MySQL.JDBC" );
    String[] comandos = { "DELETE FROM tb_Aluno WHERE matricula = 1",
                          "INSERT INTO tb_Aluno VALUES (1,'BETO')",
                          "UPDATE tb_Aluno SET NOME = 'ALBERTO' WHERE NOME = 'BETO'" };
    eb.executar(comandos);
  }
}