package jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.Types;

import java.math.BigDecimal;

import java.util.Map;
import java.util.TreeMap;

/**
 * Demonstra como executar uma consulta e navegar pelo resultado usando
 * uma PreparedStatement.
 */

public class ExecutarPreparedStatement extends ExecutarBase {

  public ExecutarPreparedStatement( String nome ) {
    super (nome);
  }

  public void consultar( String sql, Map params ) {
    Connection con = criarConexao();
    if (con == null) {
      System.err.println("Erro ao obter conex�o");
      return;
    }

    try {
      PreparedStatement pstmt = con.prepareStatement( sql );
      preencherParams( pstmt, params );
      ResultSet rs = pstmt.executeQuery();
      exibirResultSet( rs );
    } catch (SQLException e) {
      System.err.println( "SQLState: " + e.getSQLState() );
      System.err.println( "ErrorCode: " + e.getErrorCode() );
      e.printStackTrace();
    } finally {
      if (con != null) {
        try { con.close();
        } catch (Exception e) { e.printStackTrace(); }
      }
    }
  }

  public static void main(String[] args) {
//    ExecutarPreparedStatement eps = new ExecutarPreparedStatement( "JDataStore.Employee" );
//    ExecutarPreparedStatement eps = new ExecutarPreparedStatement( "Interbase.Employee" );
    ExecutarPreparedStatement eps = new ExecutarPreparedStatement( "Interbase.FB.Employee" );
    Map params = new TreeMap();
    Parametro param = new Parametro( new BigDecimal("500000.00" ), Types.NUMERIC);
    params.put( "1", param );
    eps.consultar( "SELECT * FROM employee WHERE salary > ?", params);

//    ExecutarPreparedStatement eps = new ExecutarPreparedStatement( "MySQL.JDBC" );
//    Map params = new TreeMap();
//    Parametro param = new Parametro( "%JOSE%", Types.VARCHAR);
//    params.put( "1", param );
//    eps.consultar( "SELECT * FROM tb_aluno WHERE nome LIKE ?", params );
  }
}