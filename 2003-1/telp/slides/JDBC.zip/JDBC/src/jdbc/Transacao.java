package jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Demonstra a utiliza��o de transa��es
 */
public class Transacao extends ExecutarBase {

  public Transacao( String nome, int id ) {
    super (nome);
  }

  public void executar() {

    Connection con = null;
    try {
      con = criarConexao();
      con.setAutoCommit( false );
      Statement stmt = con.createStatement();
      int n = stmt.executeUpdate("INSERT INTO tb_Aluno (matricula, nome) " +
                                 "VALUES (2, 'TESTE')");
      System.out.println("N�mero de linhas atualizadas:" + n);

      System.out.println("Consultando a tabela antes do rollback");
      exibirResultSet( stmt.executeQuery( "SELECT * FROM tb_Aluno WHERE matricula = 2") );
      con.rollback();

      System.out.println("Consultando a tabela depois do rollback");
      exibirResultSet( stmt.executeQuery( "SELECT * FROM tb_Aluno WHERE matricula = 2") );

    } catch (SQLException e) {
      System.err.println( "SQLState: " + e.getSQLState() );
      System.err.println( "ErrorCode: " + e.getErrorCode() );
      e.printStackTrace();
    } finally {
      if (con != null) {
        try { con.close();
        } catch (Exception e) { e.printStackTrace(); }
      }
    }
  }

  public static void main(String[] args) {
    Transacao t = new Transacao( "MySQL.JDBC", 2 );
    t.executar();
  }
}