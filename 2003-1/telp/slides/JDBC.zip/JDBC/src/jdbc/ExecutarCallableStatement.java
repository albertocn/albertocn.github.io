package jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import java.util.Map;
import java.util.TreeMap;

/**
 * Demonstra como executar uma consulta e navegar pelo resultado usando
 * uma PreparedStatement.
 */

public class ExecutarCallableStatement extends ExecutarBase {

  public ExecutarCallableStatement( String nome ) {
    super(nome);
  }

  public void executar( String sp, Map params ) {
    Connection con = criarConexao();
    if (con == null) {
      System.err.println("Erro ao obter conex�o");
      return;
    }

    try {
      CallableStatement cstmt = con.prepareCall( sp );
      preencherParams( cstmt, params );
      cstmt.execute();
      exibirResultSet (cstmt.getResultSet());
    } catch (SQLException e) {
      System.err.println( "SQLState: " + e.getSQLState() );
      System.err.println( "ErrorCode: " + e.getErrorCode() );
      e.printStackTrace();
    } finally {
      if (con != null) {
        try { con.close();
        } catch (Exception e) { e.printStackTrace(); }
      }
    }
  }

  public static void main(String[] args) {
//    ExecutarCallableStatement ecs = new ExecutarCallableStatement( "Interbase.Employee" );
    ExecutarCallableStatement ecs = new ExecutarCallableStatement( "Interbase.FB.Employee" );
    Map params = new TreeMap();

//    Parametro param = new Parametro( new Integer(4), Types.SMALLINT);
//    params.put( "1", param );
//    tc.executar( "{call GET_EMP_PROJ(?)}", params );

    Parametro param = new Parametro ( "100", Types.CHAR );
    params.put( "1", param );
    ecs.executar( "{call DEPT_BUDGET(?)}", params );
  }
}