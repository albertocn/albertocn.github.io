package jdbc;

/**
 * Encapsula um par�metro para um PreparedStatement com seu valor e tipo alvo
 */
public class Parametro {

  private final Object o;
  private final int tipoSQL;

  public Parametro(Object o, int tipoSQL) {
    this.o = o;
    this.tipoSQL = tipoSQL;
  }

  public Object getObject() { return o; }
  public int getTipoSQL() { return tipoSQL; }
}