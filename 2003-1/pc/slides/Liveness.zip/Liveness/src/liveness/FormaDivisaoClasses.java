package liveness;

/** Altera��o na classe Forma usando divis�o de classes */

public class FormaDivisaoClasses {

  protected Localizacao loc = new Localizacao();
  protected Dimensoes dim = new Dimensoes();

  public double x() { return loc.x(); }
  public double y() { return loc.y(); }
  public void ajustarLocalizacao() { loc.ajustar(); }

  public double largura() { return dim.largura(); }
  public double altura()  { return dim.altura(); }
  public void ajustarDimensoes() { dim.ajustar(); }
}