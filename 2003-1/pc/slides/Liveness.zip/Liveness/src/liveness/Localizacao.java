package liveness;

public class Localizacao {
  // Acessados pelos m�todos: x, y e ajustarLocalizacao
  protected double x = 0.0;
  protected double y = 0.0;

  public synchronized double x() { return x; }
  public synchronized double y() { return y; }
  public synchronized void ajustar() {
    x = calculoDemorado1();
    y = calculoDemorado2();
  }

  // M�todos n�o implementados
  protected double calculoDemorado1() { return Math.random(); }
  protected double calculoDemorado2() { return Math.random(); }
}