package progdist;

/** Indica um erro ocorrido durante a passagem de mensagem */
public final class PassagemMensagemException extends RuntimeException {
   public PassagemMensagemException()         { super(); }
   public PassagemMensagemException(String s) { super(s); }
}
