package progdist;

import java.io.*;
import java.net.*;

/**
 * Implementa a passagem de objetos intra-JVM e inter-JVM usando serializa��o.
 */
public final class PassagemMensagemPipeObjeto implements PassagemMensagem {

   private PipedOutputStream outPipe = null;
   private PipedInputStream inPipe = null;
   private ObjectOutputStream outObj = null;
   private ObjectInputStream inObj = null;
   private final Object enviando = new Object();
   private final Object recebendo = new Object();
   private Socket socket = null;

   /**
    * Cria um pipe atrav�s do qual ser�o serializados e transferidos objetos
    * dentro da mesma JVM
    */
   public PassagemMensagemPipeObjeto() {
      outPipe = new PipedOutputStream();
      try {
         inPipe = new PipedInputStream(outPipe);
      } catch (IOException e) {
         System.err.println("PassagemMensagemPipeObjeto:" + e);
         e.printStackTrace();
         throw new PassagemMensagemException();
      }
      try {
         outObj = new ObjectOutputStream(outPipe);
         inObj = new ObjectInputStream(inPipe);
      } catch (IOException e) {
         System.err.println("PassagemMensagemPipeObjeto:" + e);
         e.printStackTrace();
         throw new PassagemMensagemException();
      }
   }

   /**
    * Cria um pipe usando o socket passado atrav�s do qual ser�o transferidos
    * objetos entre JVM diferentes.
    */
   public PassagemMensagemPipeObjeto(Socket socket) {
      if (socket == null) {
         throw new NullPointerException("N�o � permitido um socket null");
      }
      this.socket = socket;
      try {
         outObj = new ObjectOutputStream(socket.getOutputStream());
         inObj = new ObjectInputStream(socket.getInputStream());
      } catch (IOException e) {
         System.err.println("PassagemMensagemPipeObjeto:" + e);
         e.printStackTrace();
         throw new PassagemMensagemException();
      }
   }

   public final void enviar(Object m) {
      synchronized (enviando) {
         try {
            outObj.writeObject(m);
            outObj.flush();
            if (outPipe != null)
               outPipe.flush();
         } catch (IOException e) {
            System.err.println("Erro ao enviar:" + e);
            e.printStackTrace();
            throw new PassagemMensagemException();
         }
      }
   }

   public final Object receber() {
      Object o = null;
      synchronized (recebendo) {
         try {
            o = inObj.readObject();
         } catch (Exception e) {
            System.err.println("Erro ao receber:" + e);
            e.printStackTrace();
            throw new PassagemMensagemException();
         }
      }
      return o;
   }

   public void close() {
      try {
         if (inObj != null) inObj.close();
         if (outObj != null) outObj.close();
         if (inPipe != null) inPipe.close();
         if (outPipe != null) outPipe.close();
         if (socket != null) socket.close();
      } catch (IOException e) {
         System.err.println("Erro em close: " + e);
      }
   }
}
