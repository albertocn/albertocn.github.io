package progdist.tarefa;

import progdist.PassagemMensagem;
import progdist.PassagemMensagemException;
import progdist.PassagemMensagemPipeObjeto;

import java.io.IOException;
import java.net.Socket;

public class ClienteTarefasSocket implements Runnable {

  private String servidor;
  private long cont = 0;

  public ClienteTarefasSocket( String servidor ) {
    this.servidor = servidor;
  }

  public void run() {

    log( "INICIADO" );
    while (deveContinuar()) {
      try {
        PassagemMensagem pm = criarPassagemMensagem();
        log ("Criando a tarefa");
        Tarefa tarefa = new Multiplicacao( new Long (10), new Long(20) );
        log ("Tarefa enviada");
        pm.enviar( tarefa );
        log ("Esperando resultado");
        Multiplicacao m = (Multiplicacao) pm.receber();
        log ("Tarefa recebida");
        log ("Resultado: " + m.getResultado());
      } catch (IOException e) {
        e.printStackTrace();
        break;
      }
    }
    log( "PARADO" );
  }

  protected PassagemMensagem criarPassagemMensagem() throws IOException {
    Socket socket = new Socket( servidor, ServidorTarefasSocket.PORTA );
    return new PassagemMensagemPipeObjeto( socket );
  }

  private void log(String msg) {
    System.out.println("CLIENTE: " + msg);
  }

  private boolean deveContinuar() {
     return cont++ < 1;
  }

  public static void main(String[] args) {
    String SERVIDOR = "localhost";
    Thread t = new Thread (new ClienteTarefasSocket( SERVIDOR ));
    t.start();
  }
}