package progdist.tarefa;

import progdist.EstabelecerRendezvous;
import progdist.Rendezvous;

public class ClienteTaferasRendezvous implements Runnable {

  private long cont = 0;
  private Rendezvous rendezvous;

  public ClienteTaferasRendezvous( String servidor ) {
    EstabelecerRendezvous er = new EstabelecerRendezvous( servidor,
                                                          EstabelecerRendezvous.PORTA_PADRAO );
    this.rendezvous =  er.clienteParaServidor();
  }

  public void run() {
    log( "INICIADO" );
    while (deveContinuar()) {
      log ("Criando a tarefa");
      Tarefa tarefa = new Multiplicacao( new Long (10), new Long(20) );

      log ("Fazendo requisi��o e esperando resposta");
      Object resp = rendezvous.clienteFazRequisicaoEsperaResposta( tarefa );
      log ("Resposta recebida");

      Multiplicacao m = (Multiplicacao) resp;
      log ("Resultado: " + m.getResultado());
    }
    log( "PARADO" );
  }

  private void log(String msg) {
    System.out.println("CLIENTE: " + msg);
  }

  private boolean deveContinuar() {
     return cont++ < 1;
  }

  public static void main(String[] args) {
    String SERVIDOR = "localhost";
    Thread t = new Thread (new ClienteTaferasRendezvous( SERVIDOR ));
    t.start();
  }
}
