package progdist.tarefa;

import progdist.PassagemMensagem;

public class ClienteTarefas implements Runnable {

  private PassagemMensagem pmTarefasNaoExecutadas;
  private PassagemMensagem pmTarefasExecutadas;
  private long inicio;

  public ClienteTarefas( PassagemMensagem pmTarefasNaoExecutadas,
                         PassagemMensagem pmTarefasExecutadas) {
    this.pmTarefasNaoExecutadas = pmTarefasNaoExecutadas;
    this.pmTarefasExecutadas = pmTarefasExecutadas;
    this.inicio = System.currentTimeMillis();

    Thread t = new Thread (this, "CLIENTE");
    t.start();
  }

  public void run() {
    log( "INICIADO" );
    while (deveContinuar()) {
      log ("Criando a tarefa");
      Tarefa tarefa = new Multiplicacao( new Long (10), new Long(20) );
      log ("Tarefa enviada");
      pmTarefasNaoExecutadas.enviar( tarefa );
      log ("Esperando resultado");
      Multiplicacao m = (Multiplicacao) pmTarefasExecutadas.receber();
      log ("Tarefa recebida");
      log ("Resultado: " + m.getResultado());
    }
    log( "PARADO" );
  }

  private void log(String msg) {
    System.out.println("CLIENTE: " + msg);
  }

  private boolean deveContinuar() {
     return inicio + 50 > System.currentTimeMillis();
  }
}
