package progdist.tarefa;

import progdist.EstabelecerRendezvous;
import progdist.Rendezvous;

public class ServidorTarefasRendezvous implements Runnable {

  private EstabelecerRendezvous er;

  public ServidorTarefasRendezvous() {
    this.er = new EstabelecerRendezvous( EstabelecerRendezvous.PORTA_PADRAO );
  }

  public void run() {

    log( "INICIADO" );
    while (true) {

      log ("Esperando conex�o");
      Rendezvous rendezvous = er.servidorParaCliente();

      log ("Esperando tarefa");
      Tarefa tarefa = (Tarefa) rendezvous.servidorRecebeRequisicao();
      log ("Tarefa recebida");

      log ("Tarefa sendo executada");
      tarefa.executar();
      log ("Tarefa executada");

      rendezvous.servidorEnviaResposta(tarefa);
      log ("Tarefa enviada de volta ao CLIENTE");
    }
  }

  private void log(String msg) {
    System.out.println("SERVIDOR: " + msg);
  }

  public static void main(String[] args) {
    Thread t = new Thread( new ServidorTarefasRendezvous() );
    t.start();
  }
}