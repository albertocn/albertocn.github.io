package progdist.tarefa;

import progdist.PassagemMensagem;
import progdist.PassagemMensagemPipeObjeto;

public class Exemplo2 {

  private PassagemMensagem pmTarefasNaoExecutadas = new PassagemMensagemPipeObjeto();
  private PassagemMensagem pmTarefasExecutadas = new PassagemMensagemPipeObjeto();

  public void executar() {
    new ServidorTarefas( pmTarefasNaoExecutadas, pmTarefasExecutadas );
    new ClienteTarefas( pmTarefasNaoExecutadas, pmTarefasExecutadas );
  }

  public static void main(String[] args) {
    new Exemplo2().executar();
    try { Thread.currentThread().sleep(500);
    } catch (InterruptedException ie) {}
    System.exit(0);
  }
}