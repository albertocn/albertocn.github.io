package progdist.tarefa;

import progdist.PassagemMensagem;
import progdist.PassagemMensagemException;
import progdist.PassagemMensagemPipeObjeto;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorTarefasSocket implements Runnable {

  public static int PORTA = 5555;

  protected ServerSocket ss;

  public ServidorTarefasSocket() {
    try {
      ss = new ServerSocket( PORTA );
    } catch (IOException e) {
      e.printStackTrace();
      throw new PassagemMensagemException();
    }

  }

  public void run() {
    log( "INICIADO" );

    while (true) {
      PassagemMensagem pm;
      try {
        pm = createPassagemMensagem();
      } catch (IOException e) {
        e.printStackTrace();
        break;
      }

      log ("Esperando tarefa");
      Tarefa tarefa = (Tarefa) pm.receber();
      log ("Tarefa recebida");

      log ("Tarefa sendo executada");
      tarefa.executar();
      log ("Tarefa executada");

      pm.enviar(tarefa);
      log ("Tarefa enviada de volta ao CLIENTE");
    }
  }

  protected PassagemMensagem createPassagemMensagem() throws IOException {
    log( "ESPERANDO" );
    Socket socket = ss.accept();
    log( "SOCKET CRIADO" );

    return new PassagemMensagemPipeObjeto( socket );
  }

  private void log(String msg) {
    System.out.println("SERVIDOR: " + msg);
  }

  public static void main(String[] args) {
    Thread t = new Thread( new ServidorTarefasSocket() );
    t.start();
  }
}