package progdist.tarefa;

public class Multiplicacao implements Tarefa {

  private Long x;
  private Long y;
  private Long resultado;

  public Multiplicacao(Long x, Long y) {
    this.x = x;
    this.y = y;
  }

  public void executar() {

    try { Thread.currentThread().sleep(100); }
    catch (InterruptedException ie) {}

    resultado = new Long(x.longValue() * y.longValue());
  }

  public Long getResultado() {
    return resultado;
  }
}
