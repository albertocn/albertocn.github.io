package progdist;

public interface Rendezvous {

   /** Cliente faz requisi��o e espera at� que o servidor responda */
   Object clienteFazRequisicaoEsperaResposta(Object m);

   /** Servidor recebe requisi��o do cliente */
   Object servidorRecebeRequisicao();

   /** Servidor envia resposta para o cliente */
   void servidorEnviaResposta(Object m);

   /** Encerra o rendezvous */
   void close();
}