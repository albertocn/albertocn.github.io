package progdist;

import java.net.ServerSocket;
import java.net.Socket;

import java.io.IOException;

public class EstabelecerRendezvous {

  public static int PORTA_PADRAO = 4000;

  private PassagemMensagem in = null;
  private String nomeServidor = null;
  private int porta = -1;           // stays -1 in local case as a flag
  private ServerSocket serverSocket = null;

  /**
   * Usado tanto pelo Cliente como pelo Servidor para estabelecer um
   * Rendezvous Intra-JVM
   */
  public EstabelecerRendezvous() {
    in = new PassagemMensagemSincrona();
  }

  /**
   * Usado pelo Servidor para estabelecer um Rendezvous Inter-JVM
   *
   * @param porta N�mero da porta que o servidor deve ficar escutando
   *
   * @throws PassagemMensagemException Lan�ada caso ocorra algum erro ao tentar
   *                                   instanciar o ServerSocket
   */
  public EstabelecerRendezvous(int porta) throws PassagemMensagemException {
    this.porta = porta;
    try {
      serverSocket = new ServerSocket(porta);
    } catch (IOException e) {
      e.printStackTrace();
      throw new PassagemMensagemException();
    }
  }

  /**
   * Usado pelo Cliente para estabelecer um Rendezvous Inter-JVM
   *
   * @param nomeServidor Nome do servidor esperando conex�o
   * @param porta N�mero da porta em que o servidor est� escutando
   */
  public EstabelecerRendezvous(String nomeServidor, int porta) {
    this.nomeServidor = nomeServidor;
    this.porta = porta;
  }

  /**
   * Chamado pelo servidor para estabelecer um Rendezvous com um cliente
   *
   * @return Rendezvous criado que permite que o servidor espere requisi��es
   *         do cliente
   *
   * @throws PassagemMensagemException quando ocorrer algum erro ao criar
   *                                  um socket
   */
  public Rendezvous servidorParaCliente() throws PassagemMensagemException {

    // local
    if (porta < 0)
      return (Rendezvous) in.receber();

    // remoto
    Socket socket = null;
    try {
      socket = serverSocket.accept();
    } catch (IOException e) {
      throw new PassagemMensagemException();
    }
    return new ExtendedRendezvous(socket);
  }

  /**
   * Chamado pelo cliente para estabelecer um Rendezvous com um servidor
   *
   * @return Rendezvous criado que permite que o cliente envie requisi��es
   *         para o servidor
   *
   * @throws PassagemMensagemException quando ocorrer algum erro ao criar
   *                                  um socket
   */
  public Rendezvous clienteParaServidor() throws PassagemMensagemException {

    if (porta < 0)   // Local
    {
      Rendezvous r = new ExtendedRendezvous();
      in.enviar(r);
      return r;
    }
    else   // Remoto
    {
      Socket socket = null;
      try {
        socket = new Socket(nomeServidor, porta);
      } catch (IOException e) {
        throw new PassagemMensagemException();
      }
      return new ExtendedRendezvous(socket);
    }
  }

  public void close() {
    try {
      if (serverSocket != null)
        serverSocket.close();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
