package progdist;

import semaforo.SemaforoBinario;

/**
 * <p>Implementa a passagem de mensagens s�ncronas intra-JVM
 * <p>Tanto o envio como a recep��o s�o s�ncronos (Rendezvous).
 */
public final class PassagemMensagemSincrona implements PassagemMensagem {

   private Object msg = null;
   private final Object enviando = new Object();
   private final Object recebendo = new Object();
   private final SemaforoBinario semEnviando = new SemaforoBinario(0);
   private final SemaforoBinario semRecebendo = new SemaforoBinario(0);

   public final void enviar(Object m) {
     if (m == null) {
       throw new NullPointerException("N�o � permitida uma mensagem null");
     }
     synchronized (enviando) {
       msg = m;
       semEnviando.V();
       semRecebendo.P();
     }
   }

  public final Object receber() {
    Object mensagemRecebida = null;
    synchronized (recebendo) {
      semEnviando.P();
      mensagemRecebida = msg;
      semRecebendo.V();
    }
    return mensagemRecebida;
  }

  public void close() {}
}