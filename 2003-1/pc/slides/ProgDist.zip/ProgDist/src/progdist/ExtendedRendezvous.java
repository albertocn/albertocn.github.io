package progdist;

import java.net.Socket;

public class ExtendedRendezvous implements Rendezvous {

   private PassagemMensagem in = null;
   private PassagemMensagem out = null;

   /** Intra-JVM */
   public ExtendedRendezvous() {
      this.in = new PassagemMensagemSincrona();
      this.out = new PassagemMensagemSincrona();
   }

   /** Inter-JVM */
   public ExtendedRendezvous(Socket socket) {
      this.in = new PassagemMensagemPipeObjeto(socket);
      this.out = this.in;
   }

   /**
    * Chamado pelo cliente, retornando apenas quando o servidor tiver
    * processado a requisi��o.
    * @param m Mensagem usada durante o processamento pelo servidor
    * @return Mensagem de resposta do servidor
    */
   public Object clienteFazRequisicaoEsperaResposta(Object m) {
      in.enviar( m );
      return out.receber();
   }

   /**
    * Chamado pelo Servidor para bloque�-lo at� que o cliente envie
    * uma requisi��o
    *
    * @return Retorna o objeto passado pelo cliente ao fazer a requisi��o
    */
   public Object servidorRecebeRequisicao() {
      return in.receber();
   }

   /**
    * Chamado pelo servidor ap�s processar a requisi��o
    *
    * @param m Mensagem de resposta para o cliente
    */
   public void servidorEnviaResposta(Object m) {
      out.enviar( m );
   }

   public void close() {
     in.close();
     out.close();
   }
}