package progdist.pcbl;

import progdist.PassagemMensagem;

public class Produtor implements Runnable {

  protected PassagemMensagem pm;
  private String nome;
  private long cont;

  public Produtor( PassagemMensagem pm, char c) {
    this.pm = pm;
    this.nome = "P" + c;

    Thread t = new Thread (this, this.nome);
    t.start();
  }

  public void run() {
    while (deveContinuar()) {
      produzir();
    }
  }

  protected void produzir() {
    String obj = Thread.currentThread().getName() + ++cont;
    pm.enviar( obj );
    System.out.println("Produzido (" + obj + ")");
  }

  protected boolean deveContinuar() {
    return cont < 10;
  }
}