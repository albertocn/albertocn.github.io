package progdist.pcbl;

import progdist.PassagemMensagem;
import progdist.PassagemMensagemAssincrona;

public class Exemplo {

  protected PassagemMensagem pm = new PassagemMensagemAssincrona();

  public void executar() {
    criarProdutor('A');
    criarProdutor('B');

    for (int i = 1; i <= 3; i++) {
      criarConsumidor(i);
    }
  }

  protected Produtor criarProdutor(char a) {
    return new Produtor( this.pm, a );
  }

  protected Consumidor criarConsumidor(int i) {
    return new Consumidor( this.pm, i );
  }

  public static void main(String[] args) {
    new Exemplo().executar();
    try { Thread.currentThread().sleep(5000);
    } catch (InterruptedException ie) {}
    System.exit(0);
  }
}