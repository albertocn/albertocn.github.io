package progdist.pcbl;

import progdist.PassagemMensagem;

public class Consumidor implements Runnable {

  protected PassagemMensagem pm;
  private String nome;
  private long inicio;

  public Consumidor(  PassagemMensagem pmProdCons,
                      long             id ) {
    this.pm = pmProdCons;
    this.inicio = System.currentTimeMillis();
    this.nome = "C" + id;

    Thread t = new Thread (this, this.nome);
    t.start();
  }

  public void run() {
    while (deveContinuar()) {
      consumir();
    }
    System.out.println("CONSUMIDOR " + this.nome + " ENCERRADO");
  }

  protected void consumir() {
    Object obj = pm.receber();
    System.out.println( this.nome + " RECEBEU " + obj );

    try { Thread.sleep( (long) Math.round(Math.random() * 250) );
    } catch (InterruptedException ie) {}

    System.out.println( this.nome + " CONSUMIU " + obj );
  }

  protected boolean deveContinuar() {
    return System.currentTimeMillis() < inicio + 1000;
  }
}