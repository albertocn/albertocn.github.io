package exclusaomutua;

public class Tentativa4
       extends TentativaBase
       implements Arbitro {

  public void entrarSC(int i) {
    desejaSC[i].valor = true;
    while (desejaSC[outro(i)].valor) { // Espera ocupada
      desejaSC[i].valor = false; // Desiste
//      System.out.println("Desist�ncia de " + i);
      Thread.currentThread().yield();
      desejaSC[i].valor = true;
    }
  }

  public void sairSC(int i) {
    desejaSC[i].setValor(false);
  }

  public static void main(String args[]) {
    Tentativa4 arb = new Tentativa4();
    No no1 = new No("No", 0, 10, 10, arb);
    No no2 = new No("No", 1, 10, 10, arb);
  }
}