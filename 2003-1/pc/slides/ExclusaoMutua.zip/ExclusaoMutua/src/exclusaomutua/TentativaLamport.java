package exclusaomutua;

public class TentativaLamport
       extends TentativaBase
       implements Arbitro {

  private int numNos = 0;
  private Bilhete[] bilhetes = null;

  public TentativaLamport(int numNos) {
    this.numNos = numNos;
    this.bilhetes = new Bilhete[numNos];
    for (int i = 0; i < numNos; i++)
      bilhetes[i] = new Bilhete();
  }

  public void entrarSC(int i) {
    bilhetes[i].valor = 1;
    bilhetes[i].valor = 1 + max( bilhetes );   // calcula o pr�ximo bilhete
    for (int j = 0; j < numNos; j++) {
      if (j != i) {
        while (! ( semBilhete(j) || // Quando pegar ser� maior que o bilhete de i
                   bilheteMenor(i, j) || // i deve entrar antes de j devido ao bilhete
                   (bilheteIgual(i, j) && i < j))) // Quando os bilhetes s�o iguais,
        {                                          // entra a thread com o valor
          Thread.currentThread()                   // menor entre i e j
                .yield(); // espera ocupada
        }
      }
    }
  }

  public void sairSC(int i) {
    bilhetes[i].valor = 0;
  }

  private int max(Bilhete[] bilhetes) {
    int m = bilhetes[0].valor;
    for (int i = 1; i < bilhetes.length; i++)
      if ( bilhetes[i].valor > m )
        m = bilhetes[i].valor;
    return m;
  }

  private boolean semBilhete(int n) {
    return bilhetes[n].valor == 0;
  }

  private boolean bilheteMenor(int i, int j) {
    return bilhetes[i].valor < bilhetes[j].valor;
  }

  private boolean bilheteIgual(int i, int j) {
    return bilhetes[i].valor == bilhetes[j].valor;
  }

  public static void main(String args[]) {
    No[] nos = new No[10];
    TentativaLamport arb = new TentativaLamport( nos.length );
    for (int i = 0; i < nos.length; i++) {
      nos[i] = new No("No", i, 10, 10, arb);
    }
  }
}