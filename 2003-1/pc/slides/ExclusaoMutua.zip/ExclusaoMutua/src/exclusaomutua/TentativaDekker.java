package exclusaomutua;

public class TentativaDekker
       extends TentativaBase
       implements Arbitro {

  public void entrarSC(int i) {
    desejaSC[i].valor = true;
    while (desejaSC[outro(i)].valor) { // Espera ocupada
      if (vez != i) {
        desejaSC[i].valor = false; // Desiste
        while (vez != i) // Espera ocupada pela sua vez
          Thread.currentThread().yield();
        desejaSC[i].valor = true;
      }
    }
  }

  public void sairSC(int i) {
    desejaSC[i].setValor(false);
    vez = outro(i);
  }

  public static void main(String args[]) {
    TentativaDekker arb = new TentativaDekker();
    No no1 = new No("No", 0, 100, 100, arb);
    No no2 = new No("No", 1, 100, 100, arb);
  }
}