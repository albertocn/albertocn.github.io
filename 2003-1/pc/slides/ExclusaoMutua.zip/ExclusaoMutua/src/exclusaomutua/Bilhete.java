package exclusaomutua;

public class Bilhete {
  public volatile int valor = 0;
}