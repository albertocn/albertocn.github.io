package exclusaomutua;

public class Flag {

  public volatile boolean valor = false;

  private final int id;

  public Flag(int id) {
    this.id = id;
  }

  public boolean getValor() {
    System.out.println("Retornando o valor do Flag " + id);
    return valor;
  }

  public void setValor(boolean valor) {

    // Inclu�do apenas para facilitar o aparecimento do problema
    if (valor) {
      try {
        Thread.sleep(100);
      } catch (InterruptedException ie) { ie.printStackTrace(); }
    }

    // Altera��o efetiva do valor
    this.valor = valor;

    System.out.println("Alterado o valor do Flag " + id + " para " + valor);
  }
}