package safety;

/** Representa uma conex�o com um BD */
public class Conexao {

  private static long cont = 0;

  public void abrir() {
    synchronized ( getClass() ) {
      cont++;
    }
  }

  public void fechar() {
    synchronized ( getClass() ) {
      cont--;
    }
  }

  public static synchronized long getCont() {
    return cont;
  }
}