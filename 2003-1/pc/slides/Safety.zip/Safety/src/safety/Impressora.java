package safety;

/** Representa um recurso compartilhado */
public class Impressora {

  public void imprimir( String str ) {
    System.out.println( str );
  }
}