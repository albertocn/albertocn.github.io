package safety;

/** Lista no estilo LISP modificada */
public class LinkedCell2 extends LinkedCell {

  public LinkedCell2 (long v, LinkedCell p) {
    super( v, p );
  }

  /**
   * Mant�m o primeiro objeto travado at� chegar ao �ltimo,
   * n�o sendo uma boa alternativa
   */
  public synchronized long soma() {
    long v = valor();
    return v + somaProx(); // Permanece sincronizado
  }

  public long somaProx() {
    return prox() == null ? 0 : prox().soma();
  }
}