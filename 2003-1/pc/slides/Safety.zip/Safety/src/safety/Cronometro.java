package safety;

import java.util.Date;

/** Representa um Cron�metro */
public class Cronometro {

  private final Date inicio;
  private final Date fim;

  public Cronometro() {
    this.inicio = new Date(0);
    this.fim = new Date(0);
  }

  public synchronized void iniciar() {
    inicio.setTime( System.currentTimeMillis() );
  }

  public synchronized void terminar() {
    fim.setTime( System.currentTimeMillis() );
  }

  public synchronized long tempo() {
    return fim.getTime() - inicio.getTime();
  }

  public static void main(String[] args) {
    Cronometro cron = new Cronometro();
    cron.iniciar();
    System.out.println("Iniciado");
    try {
      System.out.println("Dormindo");
      Thread.currentThread().sleep(1000);
      System.out.println("Acordando");
    } catch (InterruptedException ie) { ie.printStackTrace(); }
    cron.terminar();
    System.out.println("Terminado");
    System.out.println("Tempo: " + cron.tempo());
  }
}