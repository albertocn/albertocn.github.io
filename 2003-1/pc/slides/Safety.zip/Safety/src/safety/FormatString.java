package safety;

/** Mostra uma classe sem estado */
public class FormatString {

   public static final int ESQUERDO = 0;
   public static final int DIREITO  = 1;

   /**
    * Preenche uma String colocando o caractere passado no lado informado
    * at� atingir o tamanho requerido.
    *
    * @param s    String a ser preenchida
    * @param lado Lado onde ser� feito preenchimento
    * @param c    Caractere usado para preencher
    * @param tam  Tamanho final da String
    * @return Retorna a String preenchida
    */
   public static String preencher(String s, int lado, char c, int tam) {
     StringBuffer strCompletar = new StringBuffer();
     for (int i = 0; i < (tam - s.length()); i++)
        strCompletar.append(c);

     if (lado == ESQUERDO) {
        return strCompletar.append(s).toString();
     } else if (lado == DIREITO) {
        return strCompletar.insert(0, s).toString();
     } else {
       throw new IllegalArgumentException("valor do lado inv�lido: " + lado);
     }
   }

   public static void main(String[] args) {
     String s = "ABC";
     char c = '.';
     System.out.println( FormatString.preencher(s, ESQUERDO, c, 5) );
     System.out.println( FormatString.preencher(s, DIREITO, c, 10) );
     System.out.println( FormatString.preencher(s, ESQUERDO, c, 3) );
     System.out.println( FormatString.preencher(s, ESQUERDO, c, 1) );
   }
}