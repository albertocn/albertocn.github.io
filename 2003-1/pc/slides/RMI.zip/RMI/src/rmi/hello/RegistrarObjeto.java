package rmi.hello;

import java.rmi.Naming;

public class RegistrarObjeto  {

  public RegistrarObjeto( String servidor, String nome ) throws Exception {
    HelloServer hs = new HelloServer();
    System.out.println("Objeto remoto instanciado");

    String url = "rmi://" + servidor + "/" + nome;
    System.out.println("URL: " + url);

    Naming.rebind( url, hs );
    System.out.println("Objeto remoto " + nome +
                       " registrado no servidor " + servidor);

    exibirBindings( servidor );
  }

  private void exibirBindings( String servidor ) throws Exception {
    System.out.println( "Objetos registrados no servidor:" );
    String[] bindings = Naming.list( servidor );
    for (int i = 0; i < bindings.length; i++) {
      System.out.println( bindings[i] );
    }
  }

  public static void main(String[] args) {
    String servidor = args[0];
    String nome = args[1];

    try {
      RegistrarObjeto ro = new RegistrarObjeto( servidor, nome );
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}