package semaforo.pcbi;

import semaforo.Semaforo;
import semaforo.SemaforoContador;
import semaforo.SemaforoDebug;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Exemplo {

  protected List buffer;
  protected Semaforo elementos;

  public Exemplo() {
    this.buffer = criarBuffer();
    this.elementos = criarSemaforo();
  }

  public void executar() {
    Produtor prod = criarProdutor();
    Consumidor cons = criarConsumidor();

    Thread tp = new Thread (prod, "P");
    Thread tc = new Thread (cons, "C");

    tp.start();
    tc.start();

    try {
      tp.join();
      tc.join();
    } catch (InterruptedException ie) {
      ie.printStackTrace();
    }

    System.out.println("Situa��o do Buffer: " + buffer);
  }

  protected List criarBuffer() {
    return Collections.synchronizedList( new LinkedList() );
  }

  protected Semaforo criarSemaforo() {
    return new SemaforoDebug( new SemaforoContador(0), "Elementos" );
  }

  protected Produtor criarProdutor() {
    return new Produtor( this.buffer, this.elementos );
  }

  protected Consumidor criarConsumidor() {
    return new Consumidor( this.buffer, this.elementos );
  }

  public static void main(String[] args) {
    new Exemplo().executar();
  }
}