package semaforo.pcbi;

import semaforo.Semaforo;
import java.util.List;

public class Produtor implements Runnable {

  protected List buffer;
  protected Semaforo elementos;
  protected long cont;

  public Produtor( List buffer, Semaforo elementos ) {
    this.buffer = buffer;
    this.elementos = elementos;
    this.cont = 0;
  }

  public void run() {
    while (deveContinuar()) {
      produzir();
      elementos.V();
    }
  }

  protected void produzir() {
    if (cont % 3 == 0) {
      try {
        long tempo = Math.round(Math.random() * 200);
        System.out.println("Produtor dormindo por " + tempo + " ms");
        Thread.currentThread().sleep( tempo );
      } catch (InterruptedException ie) { ie.printStackTrace(); }
    }
    String obj = "" + ++cont + "� OBJ";
    buffer.add( obj );
    System.out.println("Produzido (" + obj + ")");
  }

  protected boolean deveContinuar() {
    return cont < 10;
  }
}