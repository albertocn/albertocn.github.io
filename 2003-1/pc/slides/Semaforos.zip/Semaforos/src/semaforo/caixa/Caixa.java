package semaforo.caixa;

import semaforo.*;

public class Caixa implements Runnable {

  private final Semaforo sem;

  public Caixa( Semaforo sem ) {
    this.sem = sem;
  }

  public void run() {
    while (true) {
      log("Descansando");
      try { Thread.sleep(1000); }
      catch (InterruptedException ie) { ie.printStackTrace(); }
      log("Vai atender");
      sem.V();
    }
  }

  private void log ( String msg ) {
    System.out.println("[Caixa] " + msg);
  }
}


