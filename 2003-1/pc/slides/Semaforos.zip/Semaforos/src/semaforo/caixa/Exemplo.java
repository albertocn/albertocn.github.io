package semaforo.caixa;

import semaforo.Semaforo;
import semaforo.SemaforoBinario;

public class Exemplo {

  protected Semaforo sem;

  public Exemplo() {
    this.sem = criarSemaforo();
  }

  public void executar() {
    Caixa caixa = criarCaixa();
    Thread threadCaixa = new Thread (caixa, "Caixa");
    threadCaixa.start();

    Pessoa[] pessoas = new Pessoa[25];
    for (int i = 0; i < pessoas.length; i++) {
       pessoas[i] = criarPessoa( i );
       Thread t = new Thread (pessoas[i], "Pessoa" + i);
       t.start();
       try { Thread.sleep(20); }
       catch (InterruptedException ie) { ie.printStackTrace(); }

    }
  }

  protected Semaforo criarSemaforo() {
    return new SemaforoBinario(0);
  }

  protected Pessoa criarPessoa( int n ) {
    return new Pessoa( n, sem );
  }

  protected Caixa criarCaixa() {
    return new Caixa( sem );
  }

  public static void main(String[] args) {
    new Exemplo().executar();
  }
}
