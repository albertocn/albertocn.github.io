package semaforo.caixa;

import semaforo.Semaforo;

public class Pessoa implements Runnable {

  private final int n;
  private final Semaforo sem;

  public Pessoa( int n, Semaforo sem ) {
    this.n = n;
    this.sem = sem;
  }

  public int getN() { return n; }

  public void run() {
    log("Chamando P");
    sem.P();
    log("Sendo atendido");
  }

  private void log ( String msg ) {
    System.out.println("[P" + n + "] " + msg);
  }
}
