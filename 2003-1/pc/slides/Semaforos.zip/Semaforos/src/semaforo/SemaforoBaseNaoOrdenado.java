package semaforo;

public class SemaforoBaseNaoOrdenado extends SemaforoBase {

  protected SemaforoBaseNaoOrdenado() {
    super();
  }

  protected SemaforoBaseNaoOrdenado(int inicial) {
    super( inicial );
  }

  public synchronized void P() {
     valor--;
     if (valor < 0) {
        while (true) {
           try {
              wait();
              break;
           } catch (InterruptedException e) {
              System.err.println
                 ("SemaforoBase.P(): InterruptedException, esperar novamente");
              if (valor >= 0) break;
              else continue;
           }
        }
     }
  }

  public synchronized void V() {
     valor++;
     if (valor <= 0) notify();
  }
}