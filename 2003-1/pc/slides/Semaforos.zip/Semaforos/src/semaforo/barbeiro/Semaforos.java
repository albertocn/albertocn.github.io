package semaforo.barbeiro;

import semaforo.Semaforo;
import semaforo.SemaforoBinario;
import semaforo.SemaforoContador;
import semaforo.SemaforoDebug;

public class Semaforos {

  public final Semaforo mutex;
  public final Semaforo clientes;
  public final Semaforo barbeiro;
  public final Semaforo cortando;

  public Semaforos() {
    this.mutex    = criarSemMutex();
    this.clientes = criarSemClientes();
    this.barbeiro = criarSemBarbeiro();
    this.cortando = criarSemCortando();
  }

  protected Semaforo criarSemMutex() {
//    return new SemaforoDebug( new SemaforoBinario( 1 ), "MUTEX" );
    return new SemaforoBinario( 1 );
  }
  protected Semaforo criarSemClientes() {
//    return new SemaforoDebug( new SemaforoContador( 0 ), "CLIENTES" );
    return new SemaforoContador( 0 );
  }
  protected Semaforo criarSemBarbeiro() {
//    return new SemaforoDebug( new SemaforoBinario( 0 ), "BARBEIRO" );
   return new SemaforoBinario( 0 );
  }
  protected Semaforo criarSemCortando() {
//    return new SemaforoDebug( new SemaforoBinario( 0 ), "CORTANDO" );
    return new SemaforoBinario( 0 );
  }
}