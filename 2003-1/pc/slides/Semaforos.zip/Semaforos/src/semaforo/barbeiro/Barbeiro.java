package semaforo.barbeiro;

public class Barbeiro implements Runnable {

  public static final double TEMPO_ATENDIMENTO = 5000.0;

  protected final Salao salao;
  protected final Semaforos semaforos;

  public Barbeiro( Salao salao, Semaforos semaforos  ) {
    this.salao = salao;
    this.semaforos = semaforos;
  }

  public void run() {
    while (true) {
      log ("Buscando cliente (se n�o houver, dorme)");
      semaforos.clientes.P(); // Espera algum cliente chegar
      log ("H� algum cliente");
      semaforos.mutex.P();
      salao.decClientesEsperando();
      log ("Chamando cliente");
      semaforos.barbeiro.V();
      semaforos.mutex.V();
      cortar();
      semaforos.cortando.V();
    }
  }

  protected void cortar() {
    log ("Come�ando a cortar");
    long tempo = Math.round( Math.random() * TEMPO_ATENDIMENTO );
    try { Thread.currentThread().sleep( tempo );
    } catch (InterruptedException ie) { ie.printStackTrace(); }
    log ("Terminando de cortar");
  }

  private void log (String msg) {
    System.out.println("[Barbeiro]: " + msg + " em " + salao.getTempoTotal() + " ms");
  }
}