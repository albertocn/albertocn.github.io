package semaforo.barbeiro;

public class Salao {

  public static final int N_CADEIRAS = 2;
  public static final long inicio = System.currentTimeMillis();

  private int clientesEsperando = 0;

  public int getClientesEsperando() { return clientesEsperando; }
  public void decClientesEsperando() { clientesEsperando--; }
  public void incClientesEsperando() { clientesEsperando++; }

  public long getTempoTotal() {
    return System.currentTimeMillis() - inicio;
  }
}