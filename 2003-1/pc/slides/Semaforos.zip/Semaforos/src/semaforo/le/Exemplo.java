package semaforo.le;

public class Exemplo {

  public static final int N_LEITORES = 3;
  public static final int N_ESCRITORES = 2;

  public Exemplo() {
    BD bd = new BD();
    criarLeitores( bd );
    criarEscritores( bd );
  }

  private void criarLeitores( BD bd ) {
    for (int i = 1; i <= N_LEITORES; i++) {
      new Leitor( i, bd );
    }
  }

  private void criarEscritores( BD bd ) {
    for (int i = 1; i <= N_ESCRITORES; i++) {
      new Escritor( i, bd );
    }
  }

  public static void main(String[] args) {
    new Exemplo();
  }
}