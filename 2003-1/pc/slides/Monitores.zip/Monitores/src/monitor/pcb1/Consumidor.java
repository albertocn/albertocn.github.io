package monitor.pcb1;

public class Consumidor implements Runnable {

  protected MonitorPC monitor;
  private String nome;
  private long inicio;

  public Consumidor( MonitorPC monitor, long id ) {
    this.monitor = monitor;
    this.inicio = System.currentTimeMillis();
    this.nome = "C" + id;

    Thread t = new Thread (this, this.nome);
    t.start();
  }

  public void run() {
    while (deveContinuar()) {
      consumir();
    }
    System.out.println("CONSUMIDOR " + this.nome + " ENCERRADO");
  }

  protected void consumir() {
    Object obj = monitor.retirar();
    System.out.println( this.nome + " CONSUMIU " + obj );
  }

  protected boolean deveContinuar() {
    return System.currentTimeMillis() < inicio + 100;
  }
}