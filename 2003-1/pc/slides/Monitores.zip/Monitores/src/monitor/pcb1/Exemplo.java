package monitor.pcb1;

public class Exemplo {

  protected MonitorPC monitor;

  public Exemplo (MonitorPC monitor) {
    this.monitor = monitor;
  }

  public void executar() {
    criarProdutor('A');
    criarProdutor('B');

    for (int i = 1; i <= 3; i++) {
      criarConsumidor(i);
    }
  }

  protected Produtor criarProdutor(char a) {
    return new Produtor( this.monitor, a );
  }

  protected Consumidor criarConsumidor(int i) {
    return new Consumidor( this.monitor, i );
  }

  public static void main(String[] args) {
    MonitorPC mon = null;
    try {
      mon = (MonitorPC) Class.forName("monitor.pcb1.MonitorPCB1" + args[0])
                             .newInstance();
    } catch (Exception e) {
      e.printStackTrace();
      System.exit(1);
    }
    new Exemplo(mon).executar();
    try { Thread.currentThread().sleep(500);
    } catch (InterruptedException ie) {}
    System.exit(0);
  }
}