package monitor.pcb1;

public class MonitorPCB1V1 implements MonitorPC {

  private Object obj;
  private boolean vazio = true;

  public synchronized Object retirar() {
    System.out.println( Thread.currentThread().getName() + " tentando RETIRAR");
    while (vazio) {
      System.out.println("WAIT sobre " + Thread.currentThread().getName());
      try { wait(); }
      catch (InterruptedException ie) {}
    }
    System.out.println(Thread.currentThread().getName() + " vai RETIRAR");
    Object res = obj;
    obj = null;
    vazio = true;
    //  Substituir notifyAll por notify causaria um erro porque a thread
    //  acordada poderia ser um outro consumidor. Como nao ha o que consumir,
    //  e notificou o objeto errado, ficara esperando indefinidamente
    notifyAll();
//    notify();
    return res;
  }

  public synchronized void colocar( Object obj ) {
    System.out.println( Thread.currentThread().getName() + " tentando COLOCAR");
    while (!vazio) {
      System.out.println("WAIT sobre " + Thread.currentThread().getName());
      try { wait(); }
      catch (InterruptedException ie) {}
    }
    System.out.println(Thread.currentThread().getName() + " vai PRODUZIR");
    this.obj = obj;
    vazio = false;
    //  Substituir notifyAll por notify causaria um erro porque a thread
    //  acordada poderia ser um outro produtor. Como nao espaco para colocar
    //  e notificou o objeto errado, ficara esperando indefinidamente
    notifyAll();
//    notify();
  }
}