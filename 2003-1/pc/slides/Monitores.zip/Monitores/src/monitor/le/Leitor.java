package monitor.le;

public class Leitor implements Runnable {

  private int id;
  private MonitorBD bd;

  public Leitor( int id, MonitorBD bd ) {
    this.id = id;
    this.bd = bd;
    new Thread(this).start();
  }

  public void run() {
    while (true) {
      dormir ( 1000 );
      bd.iniciarLeitura( this );
      dormir ( 2000 );
      bd.encerrarLeitura( this );
    }
  }

  public void log ( String msg ) {
    System.out.println("[Leitor" + id + "]: " + msg );
  }

  private void dormir (long max) {
    long tempo = Math.round( Math.random() * max );
    log( "dormindo por " + tempo + " ms" );
    try {
      Thread.currentThread().sleep( tempo );
    } catch (InterruptedException ie) {
      ie.printStackTrace();
    }
  }
}