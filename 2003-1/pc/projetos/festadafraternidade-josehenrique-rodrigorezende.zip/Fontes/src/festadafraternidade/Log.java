package festadafraternidade;

/**
 * <p>Title: Log </p>
 * <p>Description: Classe Responsavel por Log </p>
 * @author Henrique e Rodrigo
 * @version 1.0
 *
 * <p> A classe log � respons�vel por receber chamadas vindas de objetos querendo
 * registrar texto no campo de log. Ela fornece os servi�os pra imprimir na sa�da
 * padr�o e tamb�m na Janela principal da aplica��o (a janela o notifica quando est�
 * pronta para receber logs). </p>
 *
 * @see festadafraternidade.apresentacao.Janelao
 *
 */

import java.util.Date;
import festadafraternidade.apresentacao.Janelao;

public class Log {

  /**
   * M�todo que permite emitir log na sa�da padr�o do sistema
   *
   * @param origem - Usado para imprimir de onde veio o Log (quem est� postando)
   * @param msg    - Mensagem que deve ser impressa no Log
   */
  public static void log(String origem, String msg) {
    //pega Data do sistema para impress�o no Log
    Date d = new Date();
    String saida = d.toLocaleString();
    System.out.println(saida+" ["+origem+"]: "+msg);
  }


  /**
   * Atributo que armazena a refer�ncia � Janela principal da aplica��o.
   * Necess�rio para imprimir log na janela.
   *
   * @see festadafraternidade.apresentacao.Janelao
   */
  private static Janelao janela;

  /**
   *
   * M�todo que a janela da aplica��o chama para notificar a classe Log
   * passando uma referencia para receber chamadas a Janelao.Print(String)
   *
   * @param janelaA Janela principal da Aplica��o, que cont�m a �rea de log
   *
   * @see festadafraternidade.apresentacao.Janelao
   */
  public static void setLog(Janelao janelaA) {
    janela = janelaA;
  }

  /**
   * M�todo que permite a impress�o de log na �rea de texto da Janela da
   * Aplica��o. Se a janela ainda n�o passou sua referencia a classe Log, esta
   * ultima nao tentar� imprimir o log.
   *
   * @param origem - Usado para imprimir de onde veio o Log (quem est� postando)
   * @param msg    - Mensagem que deve ser impressa no Log
   */
  public static void logJanela(String origem, String msg) {
    //pega Data do sistema para impress�o no Log
    Date d = new Date();
    String saida = d.toLocaleString();
    if (janela != null)
      janela.print(saida+" ["+origem+"]: "+msg);
  }


}