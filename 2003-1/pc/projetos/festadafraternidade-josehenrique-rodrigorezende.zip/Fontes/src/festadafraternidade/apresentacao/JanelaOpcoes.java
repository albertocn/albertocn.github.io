package festadafraternidade.apresentacao;

/**
 * <p>Title: JanelaOpcoes</p>
 * <p>Description: Janela de Opcoes de Configura��o </p>
 * @author Henrique, Rodrigo
 *
 * <p>Permite a inicializa��o dos par�metros da Simula��o</p>
 *
 */

import festadafraternidade.configuracao.Configuracao;
import festadafraternidade.sincronizacao.Sincronizador;

import festadafraternidade.*;
import javax.swing.*;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.awt.GridLayout;


public class JanelaOpcoes extends JFrame{

  /**
   * Container dos bot�es da janela
   */
  private Container botoes;

  /**
   * Cont�m os campos e labels da janela
   */
  private Container campos;

  /**
   * Bo�es da janela
   */
  private JButton ok, cancelar, padrao;

  /**
   * Campos edit�veis
   */
  private JTextField nDosesField, mDosesField, nConvidadosField,
                     dConvidadosField, dGarconField, dCentralField;

  /**
   *  Refer�ncia para a Janela Principal da Aplica��o.
   */
  private Janelao janela;

  /**
   * Construtor que recebe como argumento:
   *
   * @param janela Janela principal da Aplica��o
   */
  public JanelaOpcoes(Janelao janela) {
    super(  "Iniciar Simula��o" );

    this.janela = janela;

    //organizando o layout
    Container contentPane = getContentPane();
    botoes = new Container();
    botoes.setLayout(new GridLayout(1,3,15,5));

    contentPane.setLayout(new BorderLayout());

    campos = new Container();
    campos.setLayout(new GridLayout(6,2,10,3));

    //criando os labels
    JLabel nDosesLabel = new JLabel("N�mero inicial de doses no barril");
    JLabel mDosesLabel = new JLabel("M�ximo de doses no barril");
    JLabel nConvidadosLabel = new JLabel("N�mero de Convidados");
    JLabel dConvidadosLabel = new JLabel("Tempo de Convidado Beber");
    JLabel dGarconLabel = new JLabel("Tempo de Garcon Encher");
    JLabel dCentralLabel = new JLabel("1/Velocidade");


    //criando os campos
    nDosesField      = new JTextField();
    mDosesField      = new JTextField();
    nConvidadosField = new JTextField();
    dConvidadosField = new JTextField();
    dGarconField     = new JTextField();
    dCentralField    = new JTextField();

    //adicionando os componentes
    campos.add(nDosesLabel);
    campos.add(mDosesLabel);

    campos.add(nDosesField);
    campos.add(mDosesField);

    campos.add(nConvidadosLabel);
    campos.add(dConvidadosLabel);


    campos.add(nConvidadosField);
    campos.add(dConvidadosField);

    campos.add(dGarconLabel);
    campos.add(dCentralLabel);

    campos.add(dGarconField);
    campos.add(dCentralField);

    //adicionando bot�o de Ok
    ok = new JButton();
    ok.setText("Ok");
    botoes.add( ok );
    ok.addActionListener( new okListener() );

    //adicionando bot�o de Cancelar
    cancelar = new JButton();
    cancelar.setText("Cancelar");
    botoes.add( cancelar );
    cancelar.addActionListener( new cancelarListener() );

    //adicionando bot�o de Iniciar com configura��es padr�o
    padrao = new JButton();
    padrao.setText("Iniciar com Configura��o Padr�o");
    botoes.add( padrao );
    padrao.addActionListener( new padraoListener() );

    contentPane.add(campos, BorderLayout.NORTH);
    contentPane.add(botoes, BorderLayout.SOUTH);


    pack();
    show();

  }

  /**
   *
   * <p>Title: OkListener </p>
   * <p>Description: Implementa a a��o do bot�o OK </p>
   * @author Henrique, Rodrigo
   * @version 1.0
   */
  private class okListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      //configurando a simula��o
      Configuracao.setNumDoses(Integer.parseInt(nDosesField.getText()));
      Configuracao.setMaxDoses(Integer.parseInt(mDosesField.getText()));
      Configuracao.setNumConvidados(Integer.parseInt(nConvidadosField.getText()));
      Configuracao.setDormirConvidados(Long.parseLong(dConvidadosField.getText()));
      Configuracao.setDormirGarcon(Long.parseLong(dGarconField.getText()));
      Configuracao.setDormirCentral(Long.parseLong(dCentralField.getText()));

      //criando o objeto sincronizador
      Sincronizador sinc = new Sincronizador();
      //limpando a refer�ncia � janela de op��es (para permitir cri�-la de novo)
      janela.limparOpcoes();
      dispose();
    }
  }

  /**
   *
   * <p>Title: cancelarListener </p>
   * <p>Description: Implementa a a��o do bot�o Cancelar </p>
   * @author Henrique, Rodrigo
   * @version 1.0
   */
  private class cancelarListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      //cancela o in�cio da simula��o
      janela.cancelar();
      //limpando a refer�ncia � janela de op��es (para permitir cri�-la de novo)
      janela.limparOpcoes();
      dispose();
    }
  }

  /**
   *
   * <p>Title: padraoListener </p>
   * <p>Description: Implementa a a��o do bot�o Padr�o </p>
   * @author Henrique, Rodrigo
   * @version 1.0
   */
  private class padraoListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      //Configura a simula��o com os par�metros padr�o
      Configuracao.padrao();
      //limpando a refer�ncia � janela de op��es (para permitir cri�-la de novo)
      janela.limparOpcoes();
      Sincronizador sinc = new Sincronizador();
      dispose();
    }
  }




}