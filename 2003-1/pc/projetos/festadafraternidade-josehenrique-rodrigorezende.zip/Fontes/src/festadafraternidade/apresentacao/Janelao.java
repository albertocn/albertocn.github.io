package festadafraternidade.apresentacao;


/**
 * <p>Title: Janelao </p>
 * <p>Description: Janela Principal da Aplica��o </p>
 * @author Henrique e Rodrigo
 * @version 1.0
 *
 * <p> A classe Janelao representa a Janela principal da Aplicacao,
 * e � instanciada uma �nica vez em seu m�todo main.
 * Possui �rea de log e bot�es para iniciar a finalizar a simula��o. </p>
 *
 */


import festadafraternidade.sincronizacao.Encerrar;

import festadafraternidade.*;
import javax.swing.*;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.*;
import java.awt.GridLayout;

public class Janelao extends JFrame {

  /**
   * Referencia � Janela de Opcoes aberta
   * @see festadafraternidade.apresentacao.JanelaOpcoes
   */
  private JanelaOpcoes opcoes;

  /**
   * M�todo que imprime na �rea de Log, que � um JTextArea.
   * Recebe apenas o String a ser impresso.
   *
   * @param msg - String a ser impresso
   */
 public void print(String msg) {
   synchronized (campo) {
     campo.append(msg + "\n");
   }
 }

 /**
  * Referencia a si mesma, usada para que as classes membro possam
  * referenciar o objeto que as cont�m.
  */
 private Janelao me = this;

 /**
  * Container dos bot�es da janela
  */
 private Container botoes;

 /**
  * Bot�es da janela
  */
 private JButton Iniciar, Finalizar;

 /**
  * �rea de Log
  */
 private JTextArea campo;

 /**
  * Inicializa e mostra a janela Principal.
  */
 public Janelao() {

   super(  "Festa da Fraternidade" );

   //arrumando layout do contentPane
   Container contentPane = getContentPane();
   contentPane.setLayout( new BorderLayout() );

   //arrumando layout do Container
   botoes = new Container();
   botoes.setLayout(new GridLayout(1,2,10,5));


   //inicializando �rea de Log
   campo = new JTextArea(30,80);
   campo.setEditable( false );

   //coloca��o da �rea de Log na Interface
   JScrollPane scroll = new JScrollPane(campo, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                                        JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
   contentPane.setLayout(new BorderLayout());
   contentPane.add( BorderLayout.NORTH, scroll );

      campo.append("-----------------Festa da Fraternidade-------------------\n");
      campo.append("\n\nClique em Iniciar Simula��o para configurar os par�metros");
      campo.append("\ne executar a Simula��o\n");

   //Inicializa��o e coloca��o do bot�o de Iniciar Simula��o
   Iniciar = new JButton();
   Iniciar.setText("Iniciar Simulacao");
   botoes.add( Iniciar );
   Iniciar.addActionListener( new IniciarListener() );

   //Inicializa��o e coloca��o do bot�o de Finalizar Simula��o
   Finalizar = new JButton();
   Finalizar.setText(  "Finalizar Simula��o" );
   botoes.add( Finalizar );
   Finalizar.setEnabled( false );
   Finalizar.addActionListener( new FinalizarListener() );

   contentPane.add( BorderLayout.AFTER_LAST_LINE, botoes);
   pack();
   show();

}

 /**
  *
  * <p>Title: IniciarListener</p>
  * <p>Description: Inicia a Simula��o</p>
  * @author Henrique, Rodrigo
  * @version 1.0
  */
 private class IniciarListener implements ActionListener {
   public void actionPerformed( ActionEvent e ) {

     //encerra as Threads (personagens da simula��o)
     Encerrar.iniciar();

     //mant�m consist�ncia dos bot�es
     Iniciar.setEnabled( false );
     Finalizar.setEnabled( true );

     //mant�m apenas uma janela de op��es aberta por vez
     if (opcoes == null)
       opcoes = new JanelaOpcoes(me);
       opcoes.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );

   }
 }

 /**
  *
  * <p>Title: FinalizarListener</p>
  * <p>Description: Finaliza a Simula��o</p>
  * @author Henrique, Rodrigo
  * @version 1.0
  */

 private class FinalizarListener implements ActionListener {
   public void actionPerformed( ActionEvent e ) {

     if (opcoes != null)
       return;

     //encerra as Threads (personagems da simula��o)
     Encerrar.encerrar();

     //mant�m consist�ncia dos bot�es
     Finalizar.setEnabled( false );
     Iniciar.setEnabled( true );

     //exibe as estat�sticas da simula��o que acaba de ser finalizada
     Estatistica.exibir();
   }
 }

 /**
  * M�todo onde se inicia a aplica��o.
  * @param args
  */
 public static void main( String args[] ) {
    Janelao Festa;
    Festa = new Janelao();

    //prepara a classe Log para fazer chamadas a seu m�todo print
    Log.setLog(Festa);
    Festa.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
 }

 /**
  * M�todo usado para que a janela de op��es possa cancelar a a��o
  * de iniciar a simula��o.
  *
  * @see festadafraternidade.apresentacao.JanelaOpcoes
  */

 public void cancelar() {
   Iniciar.setEnabled(true);
   Finalizar.setEnabled(false);
 }

 /**
  *Limpa a refer�ncia janela de Op��es. Ap�ia o mecanismo de n�o permitir
  * duplicatas da Janela de Op��es
  *
  * @see festadafraternidade.apresentacao.JanelaOpcoes
  */
 public void limparOpcoes(){
   opcoes = null;
 }

}
