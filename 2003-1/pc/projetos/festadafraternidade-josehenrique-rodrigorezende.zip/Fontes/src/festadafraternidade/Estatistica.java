package festadafraternidade;

/**
 * <p>Title: Estat�stica </p>
 * <p>Description: Classe que faz C�lculos Estat�sticos </p>
 * @author Henrique, Rodrigo
 * @version 1.0
 *
 * A classe Estat�stica, ao final de cada Simula��o, exibe dados sobre aquela
 * simula��o, nas sa�das de Log do sistema.
 *
 */

import festadafraternidade.sincronizacao.personagens.*;
import festadafraternidade.configuracao.Configuracao;

public class Estatistica {

  /**
   *
   * O m�todo estatico exibir � chamado quando a simulacao de fato � finalizada
   * Ent�o a classe Estat�stica pode mostrar os dados.
   *
   * @see festadafraternidade.apresentacao.Janelao
   */

  public static void exibir() {

    //obtendo informa��es
    float numConvidados = Configuracao.getNumConvidados();
    if (numConvidados == 0)
      numConvidados = 1;
    float jaBeberam = Convidado.getJaBeberam();
    float percentual = (jaBeberam / numConvidados)*100;

    //montado string a ser exibida
    String estatisticas = "\nTotal de Convidados = "+numConvidados+
        "\nCapacidade Maxima de Doses no Barril = "+Configuracao.getMaxDoses()+
        "\nCapacidade Inicial de Doses no Barril = "+Configuracao.getNumDoses()+
        "\nTotal de Doses Servidas = "+Convidado.getDosesTomadas()+"\n"
        +"Total de enchimentos do barril = "+Barril.getEnchimentos()+"\n"
        +"Total de Convidados que beberam = "+jaBeberam+"\n"
        +"Percentual de Convidados que beberam = "+percentual+"%\n";

    //exibe as estat�sticas na sa�da padr�o e na �rea da Interface
    Log.logJanela("*********************************************"+
                  "ESTATISTICAS *********************************************",
                  estatisticas);
    Log.log("*********************************************"+
                  "ESTATISTICAS *********************************************",
                  estatisticas);

  }

}
