package festadafraternidade.configuracao;

/**
 * <p>Title: Configura��o </p>
 * <p>Description: Respons�vel pela Configura��o dos Par�metros </p>
 * @author Henrique, Rodrigo
 * @version 1.0
 *
 * Essa classe mant�m um pequeno "banco de dados" dos parametros de
 * simula��o.
 *
 */

import festadafraternidade.Constantes;


public class Configuracao {

  /**
   * Configura as op��es a seu padr�o
   */
  public synchronized static void padrao() {
    numConvidados = Constantes.NUMCONVIDADOS;
    numDoses      = Constantes.NUMDOSES;
    maxDoses      = Constantes.MAXDOSES;
    dormirConvidados = Constantes.DORMIRCONVIDADOS;
    dormirGarcon     = Constantes.DORMIRGARCON;
    dormirCentral    = Constantes.DORMIRCENTRAL;
  }

  //os atributos abaixo s�o os dados e objetos usados na sincroniza��o de
  //acesso a eles

  private static int  numConvidados = Constantes.NUMCONVIDADOS;
  private static Object      lockNumConvidados = new Object();
  private static int  numDoses      = Constantes.NUMDOSES;
  private static Object      lockNumDoses = new Object();
  private static int  maxDoses      = Constantes.MAXDOSES;
  private static Object      lockMaxDoses = new Object();

  private static long dormirConvidados = Constantes.DORMIRCONVIDADOS;
  private static Object      lockDormirConvidados = new Object();
  private static long dormirGarcon     = Constantes.DORMIRGARCON;
  private static Object      lockDormirGarcon = new Object();
  private static long dormirCentral    = Constantes.DORMIRCENTRAL;
  private static Object      lockDormirCentral = new Object();


  //Abaixo encontram-se m�todos de obten��o e atualiza��o dos dados,
  //com algumas restri��es de consist�ncia.

  public static int getNumConvidados() {
    synchronized (lockNumConvidados) {
         return numConvidados;
    }
  }

  public static void setNumConvidados(int valor) {
    if (valor < 0)
      valor = Constantes.NUMCONVIDADOS;
    synchronized (lockNumConvidados) {
      numConvidados = valor;
    }
  }

  public static int getNumDoses() {
    synchronized (lockNumDoses) {
         return numDoses;
    }
  }

  public static void setNumDoses(int valor) {
    if ((valor < 0)||(valor > getMaxDoses()))  //n�o pode exceder a capacidade
      valor = Constantes.NUMDOSES;             //do barril
    synchronized (lockNumDoses) {
      numDoses = valor;
    }
  }

  public static int getMaxDoses() {
    synchronized (lockMaxDoses) {
         return maxDoses;
    }
  }

  public static void setMaxDoses(int valor) {
    if ((valor < 0)||(valor < getNumDoses()))
      valor = Constantes.MAXDOSES;
    synchronized (lockMaxDoses) {
      maxDoses = valor;
    }
  }

  public static long getDormirConvidados() {
    synchronized (lockDormirConvidados) {
         return dormirConvidados;
    }
  }

  public static void setDormirConvidados(long valor) {
    if ((valor < 1))
      valor = Constantes.DORMIRCONVIDADOS;
    synchronized (lockDormirConvidados) {
      dormirConvidados = valor;
    }
  }

  public static long getDormirCentral() {
    synchronized (lockDormirCentral) {
         return dormirCentral;
    }
  }

  public static void setDormirCentral(long valor) {
    if ((valor < 1))
      valor = Constantes.DORMIRCENTRAL;
    synchronized (lockDormirCentral) {
      dormirCentral = valor;
    }
  }

  public static long getDormirGarcom() {
    synchronized (lockDormirGarcon) {
         return dormirGarcon;
    }
  }

  public static void setDormirGarcon(long valor) {
    if ((valor < 1))
      valor = Constantes.DORMIRGARCON;
    synchronized (lockDormirGarcon) {
      dormirGarcon = valor;
    }
  }






}