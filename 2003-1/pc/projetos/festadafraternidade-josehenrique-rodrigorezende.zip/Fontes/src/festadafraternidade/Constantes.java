package festadafraternidade;

/**
 * <p>Title: </p>
 * <p>Description: Constantes dee inicializa��o dos atributos
 * com n�mero inicial de doses, numero de convidados e maximo de doses que o
 * barril podede conter, e tempo de lat�ncia de cada personagem.
 * </p>
 * @author Henrique e Rodrigo
 * @version 1.0
 */



public class Constantes {

  //As constantes abaixo referem-se aos parametros gerais do problema

  /**Numero de convidados Padrao: int=10*/
  public final static int NUMCONVIDADOS = 10;
  /**Numero de Doses Inicial Padrao: int=30*/
  public final static int NUMDOSES = 30;
  /**Numero Maximo de doses do Barril padrao: int=35*/
  public final static int MAXDOSES = 35;

  //As constantes abaixo controlam principalmente a velocidade de cada elemento

  //A velocidade da simulacao pode ser controlada atraves da central, afinal ela
  //Eh a respons�vel pelo fluxo da sincroniza��o


  /**Tempo de Convidados Dormirem: long=3000*/
  public final static long DORMIRCONVIDADOS = 3000;
  /**Tempo do Gar�on dormindo: long=5000*/
  public final static long DORMIRGARCON = 5000;
  /**Velocidade da Simulacao: long=1000*/
  public final static long DORMIRCENTRAL = 1000;


}
