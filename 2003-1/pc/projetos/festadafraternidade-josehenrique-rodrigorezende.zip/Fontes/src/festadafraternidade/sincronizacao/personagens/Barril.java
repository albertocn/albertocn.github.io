package festadafraternidade.sincronizacao.personagens;

/**
 * <p>Title: Barril.java</p>
 * <p>Description: Classe que inicializa a thread do barril e seu construtor
 * Passamos o numero maximo de doses que o barril pode conter (MAXDOSES) e o numero de
 * doses que ele contem.
 * A Thread do barril fica respons�vel por passar as doses aos convidados por meio de mensagens
 * Pode passar uma mensagem em que d� uma dose, avisa que est� vazio e precisa ser enchido.
 * A mensagem � passada como um Rendeezvous onde mbox � a resposta a condi�ao, passa uma dose
 * caso ainda haja e manda chamar o gar�on caso nao haja doses.
 * </p>
 * @author Henrique e Rodrigo
 * @version 1.0
 */


import festadafraternidade.sincronizacao.Ajustavel;

import festadafraternidade.sincronizacao.comunicacao.IRendezvousExtendidoCondicional;

import festadafraternidade.Log;

public class Barril extends Ajustavel implements Runnable {

  /**
   * Dado estat�stico
   */
  private static long enchimentos = 0;

  /**
   * M�ximo de doses possivel no Barril
   */
  private final int MAXDOSES;

  /**
   * Armazena n�mero atual de Doses
   */
  private int numDoses;

  /**
   * Permite acesso exclusivo a numDoses
   */
  private final Object lockNumDoses = new Object();

  /**
   * Central de Mensagems, usada para sincroniza��o
   */
  private final IRendezvousExtendidoCondicional mbox;

  /**
   * Indica se h� algum Convidado chamando o Gar�on
   */
  private boolean chamando = false;

  public boolean getChamando() { return chamando;}


  public int getNumDoses() {
    synchronized (lockNumDoses) {
      return numDoses;
    }
  }

  /**Construtor do Barril.
   * maxdoses � quantidade maxima de doses do Barril
   * numDoses � a quantidade de Doses com que o Barril � iniciado
   * mbx � o Rendezvous Condicional passado como central de mensagem para o Barril.
   */

  public Barril(int maxdoses, int numDoses,
                IRendezvousExtendidoCondicional mbox) {
    super(300);
    MAXDOSES = maxdoses;
    this.numDoses = numDoses;
    this.mbox = mbox;             /**Central de mensagens para o redezvous*/
    Thread eu = new Thread(this, "Garcon");
    eu.start();
  }

  /**Inicia a Thread do Barril para gerenciamento do nivel de doses atraves da central*/
  public void run() {
    Thread.currentThread().setPriority(6);
    while (true) {
      Object msg = mbox.receive(new ConditionBarril(this));
      if (msg == "querendoDose") { /**recebe a mensagem do convidado*/
        if (decNumDoses())
          mbox.answer("umaDose");  /**caso ainda haja doses, dah uma dose como mensagem
                                    do redezvous para o convidado*/
        else {
          chamando = true;
          mbox.answer("barrilVazio");   /**caso contrario manda msg dee barril vazio*/
                                       //para que o usu�rio v� acordar o Gar�on
        }
      } else if (msg == "encher") {    /**recebe msg do gar�on avisando que est� enchendo*/
        incEnchimentos();
        log("O garcon est� me enchendo..");
        mbox.answer("ok");
        /**garante o lock e garante o acesso unico quando enchendo*/
        synchronized (lockNumDoses) {
          numDoses = MAXDOSES;
        }
        chamando = false;
      }
      if (verificarEncerramento()) //verifica se a simula��o foi encerrada
        return;
    }
  }

  /**Verifica se ainda h� doses.
   * Se houver, decrementa
   **/
  private boolean decNumDoses() {
    synchronized (lockNumDoses) {
      if (numDoses == 0)
        return false;
      else {
        numDoses--;
        log("Pegaram uma dose, doses dispon�veis: "+numDoses);
        return true;
      }
    }
  }

  /**
   * Envia mensagem ao log
   * @param msg - Mensagem
   */
  private void log(String msg) {
    Log.log("< B A R R I L >",msg);
    Log.logJanela("< B A R R I L >",msg);
  }

  /**
   * C�lculo Estat�stico
   */
  private synchronized static void incEnchimentos() {
    enchimentos++;
  }

  /**
   * Obt�m estat�stica
   * @return Numero de vezes que o Gar�om encheu o Barril
   */
  public synchronized static long getEnchimentos() {
    return enchimentos;
  }

  /**
   * Inicializa Estat�stica
   */
  public synchronized static void limparEnchimentos() {
    enchimentos = 0;
  }



}
