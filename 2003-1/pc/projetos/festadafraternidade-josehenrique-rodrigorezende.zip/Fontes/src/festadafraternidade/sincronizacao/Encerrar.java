package festadafraternidade.sincronizacao;

/**
 * <p>Title: Encerrar </p>
 * <p>Description: Respons�vel pelo mecanismo de encerramento da Simula��o</p>
 * @author Henrique, Rodrigo
 * @version 1.0
 *
 * Permite aos participantes da simula��o saberem quando uma simula��o foi
 * encerrada.
 *
 */

public class Encerrar {


  private static boolean encerrar = false;

  public static void encerrar() {encerrar = true;}

  public static boolean verificarEncerramento() {
    return encerrar;
  }

  /**
   * Inicializa uma nova simula��o
   */
  public static void iniciar() {encerrar = false;}

}