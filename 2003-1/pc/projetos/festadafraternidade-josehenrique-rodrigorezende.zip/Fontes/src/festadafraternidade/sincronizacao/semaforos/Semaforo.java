package festadafraternidade.sincronizacao.semaforos;

/**
 * <p>Title: </p>
 * <p>Description: Semaforos Auxiliares</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Henrique e Rodrigo
 * @version 1.0
 */

public interface Semaforo {
  /**Passar*/
  void P();
  /**Continuar*/
  void V();
}
