package festadafraternidade.sincronizacao.comunicacao;

/**
 * <p>Title: Rendezvous </p>
 * <p>Description: Implementa a interface IRendezvous </p>
 * @author Henrique, Rodrigo
 * @version 1.0
 */

import festadafraternidade.sincronizacao.semaforos.SemaforoBinario;

public class Rendezvous implements IRendezvous {

  /**
   * Mensagem a ser transmitida de maneira s�ncrona
   */
  private Object msg = null;

  /**
   * Lock para garantir que nunca haja dois remetentes
   */
  private final Object lockEnviando = new Object();

  /**
   * Lock para garantir que nunca haja dois destinat�rios
   */
  private final Object lockRecebendo = new Object();
  /**
   * Semaforo que bloqueia a Thread que receber� a mensagem
   */
  private SemaforoBinario enviando = new SemaforoBinario(0);

  /**
   * Semaforo que bloqueia a Thread que enviar� a mensagem
   */
  private SemaforoBinario recebendo = new SemaforoBinario(0);

  /**
   * Envia a mensagem
   * @param m - Mensagem
   */
  public void send(Object m) {
    if (m == null)
      throw new IllegalArgumentException("Mensagem nao pode ser nula");
    synchronized (lockEnviando) {
      msg = m;
      enviando.V();
      recebendo.P();
    }
  }

  /**
   * Recebe a mensagem
   * @return - Mensagem
   */
  public Object receive() {
    Object result;
    synchronized (lockRecebendo) {
      enviando.P();
      result = msg;
      recebendo.V();
    }
    return result;
  }


}
