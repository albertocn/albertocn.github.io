package festadafraternidade.sincronizacao.comunicacao;

/**
 * <p>Title: IRendezvousExtendidoCondicional</p>
 * <p>Description: Interface de Rendezvous Extendido Condicional</p>
 * @author Henrique e Rodrigo
 * @version 1.0
 */

public interface IRendezvousExtendidoCondicional {


  /**
   * Metodo para enviar a mensagem
   * @param msg - mensagem a ser enviada
   * @return Mensagem de Resposta (Rendezvous Extendido)
   */
  Object send(Object msg);

  /**
   * Metodo para receber a mensagem condional
   * @param c - Condi��o a que a mensagem dever� atender
   * @return - mensagem que atende � condi��o
   * @see festadafraternidade.sincronizacao.comunicacao.Condition
   */
  Object receive(Condition c);

  /**
   * M�todo para responder (Rendezvous Extendido)
   * @param msg - Mensagem de Resposta
   */
  void answer(Object msg);

}
