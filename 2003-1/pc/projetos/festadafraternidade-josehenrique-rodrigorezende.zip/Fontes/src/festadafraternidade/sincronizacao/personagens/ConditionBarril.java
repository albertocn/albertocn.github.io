package festadafraternidade.sincronizacao.personagens;

/**
 * <p>Title: ConditionBarril </p>
 * <p>Description: Implementa Condition</p>
 * @author Henrique e Rodrigo
 * @version 1.0
 *
 * Classe constru�da para testar condi��es sobre mensagens.
 */

import festadafraternidade.sincronizacao.comunicacao.Condition;


public class ConditionBarril implements Condition {

  private final Barril barril;

  public ConditionBarril (Barril barril) {
    this.barril = barril;
  }

  /** Testa a mensagem recebida pedindo a quantidade de Doses ainda no Barril
   * E retorna se aceita ou n�o a mensagem.*/
  public boolean testar(Object msg) {
    if (msg == "querendoDose") { //convidado
      return ( (barril.getNumDoses() != 0) || (!barril.getChamando()));
    }
    else if (msg == "encher") //garcon
      return true;
    else //mensagem desconhecida
      return false;
  }

}
