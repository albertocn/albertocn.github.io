package festadafraternidade.sincronizacao.comunicacao;

/**
 * <p>Title: Condition </p>
 * <p>Description: Responsavel pelo mecanismo de Rendezvous Condicional</p>
 * @author Henrique e Rodrigo
 * @version 1.0
 */

public interface Condition {

  /**Testa a mensagem para verificar se atende � condi��o
   * @param msg - Mensagem que se est� verificando
   * @see festadafraternidade.sincronizacao.comunicacao.IRendezvousExtendidoCondicional
   * @see festadafraternidade.sincronizacao.comunicacao.RendezvousExtendidoCondicional
  */
  boolean testar(Object msg);

}

