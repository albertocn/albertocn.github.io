package festadafraternidade.sincronizacao.comunicacao;

/**
 * <p>Title: RendezvousExtendidoCondicional </p>
 * <p>Description: Classe que implementa o servi�o de
 * Central de mensagens enviadas e recebidas por Rendezvous
 * extendido condicional para m�ltiplos destinat�rios
 * e remetentes</p>
 *
 * @author Henrique, Rodrigo
 * @version 1.0
 */


import festadafraternidade.configuracao.Configuracao;

import java.util.List;
import java.util.LinkedList;
import java.util.Collections;

import festadafraternidade.Constantes;
import festadafraternidade.Log;
import festadafraternidade.sincronizacao.semaforos.SemaforoBinario;
import festadafraternidade.sincronizacao.Ajustavel;

public class RendezvousExtendidoCondicional extends Ajustavel //chamado abaixo REC
    implements IRendezvousExtendidoCondicional, Runnable {

  /**
   *Armazena as mensagens esperando para serem aceitas
   */
  private final List mensagens   = Collections.synchronizedList(new LinkedList());

  /**
   * Armazena as requisi��es (por mensagens) de destinat�rios
   */
  private final List requisicoes = Collections.synchronizedList(new LinkedList());

  /**
   * Sem�foro que controla acesso exclusivo ao atributo canalDeResposta
   */
  private final SemaforoBinario respondendo = new SemaforoBinario(1);

  /**
   * Canal que � utilizado na Resposta do Rendezvous
   */
  private Rendezvous canalDeResposta;

  /**
   * Construtor que inicializa a Thread de Servi�o
   */
  public RendezvousExtendidoCondicional() {
    super(Configuracao.getDormirCentral());
    Thread me = new Thread(this,"Canal de Mensagens");
    me.setPriority(10);
    me.setDaemon(true);
    me.start();
  }

  /**
   * Envia a Mensagem a central, bloqueando ate receber uma resposta
   * @param msg - Mensagem
   * @return - Mensagem de Resposta
   */
  public Object send(Object msg) {
    //cria canal de resposta
    Rendezvous canal = new Rendezvous();
    //adiciona mensagem na lista
    Mensagem novaMsg = new Mensagem(canal, msg);
    mensagens.add(novaMsg);
    //bloqueia esperando resposta
    return canal.receive();
  }

  /**
   * M�todo para receber Mensagens
   *Bloqueia esperando uma mensagem que atenda a condi��o.
   * @param c - Condi��o necess�ria
   * @return - Mensagem que atende a condi��o
   */
  public Object receive(Condition c) {
    //cria canal de recep��o
    Rendezvous canal = new Rendezvous();
    //cria Requisi��o a ser inserida na lista
    Requisicao novaReq = new Requisicao(canal, c);
    requisicoes.add(novaReq);
    //Nesse ponto, bloqueia at� receber a mensagem
    Mensagem m = (Mensagem) canal.receive();
    //Ao receber, espera at� poder utilizar o canal de resposta
    respondendo.P();
    //Pega o canal onde o remetente espera por resposta
    canalDeResposta = m.getCanal();
    return m.getMsg();
  }

  public void answer(Object msg) {
    //responde ao remetente, completando o REC
    canalDeResposta.send(msg);
    //libera o canal de resposta
    respondendo.V();
  }


  public void run() {
    while (true) {
      //enquanto encontra mensagens que tem destino certo, continua
      while (encontrarMensagens()) ;
      //sen�o, dorme e espera
      dormir();
      //verifica se foi notificada para terminar
      if (verificarEncerramento())
        return;
    }
  }

  private void dormir() {
    try {
      Thread.currentThread().sleep(getTempoDormir());
    } catch (InterruptedException ie) {}
  }

  /**
   * M�todo que implementa o casamento entre mensagens e condi��es
   * @return
   */
  private boolean encontrarMensagens() {
    for (int i=0; i < requisicoes.size(); i++) {
      try {
        Requisicao reqAtual = (Requisicao) requisicoes.get(i);
        for (int j = 0; j < mensagens.size(); j++) {
          try { //busca as listas at� encontrar uma mensagem que satisfa�a
            Mensagem msgAtual = (Mensagem) mensagens.get(j);
            if (reqAtual.getCondicao().testar(msgAtual.getMsg())) {
              //caso satisfa�a, pega o canal de recebimento do destinatario e
              //envia a mensagem
              reqAtual.getCanal().send(msgAtual);
              //remove a rquisicao e a mensagem das listas
              requisicoes.remove(i);
              mensagens.remove(j);
              return true;
            }
          }
          catch (IndexOutOfBoundsException e) {e.printStackTrace(); break;}
          catch (NullPointerException e) {e.printStackTrace(); break;}
        }
      } catch (IndexOutOfBoundsException e) {e.printStackTrace(); break;}
        catch (NullPointerException e) {e.printStackTrace(); break;}
    }
    return false;
  }

  /**
   *
   * <p>Title: Mensagem</p>
   * @author Henrique, Rodrigo
   * @version 1.0
   *
   * Encapsula uma Mensagem enviada, e tamb�m o canal onde o remetente
   * espera por resposta.
   *
   */
  private class Mensagem {

    private final Rendezvous canal;
    private final Object msg;

    public Mensagem(Rendezvous canal, Object msg) {
      this.canal = canal;
      this.msg = msg;
    }

    public Rendezvous getCanal() {
      return canal;
    }

    public Object getMsg() {
      return msg;
    }
  }

  /**
   *
   * <p>Title: Requisicao </p>
   * @author Henrique, Rodrigo
   * @version 1.0
   *
   * Encapsula o canal de recebimento de um destinatario
   * e a condi��o de recebimento de mensagem
   *
   */
  private class Requisicao {

    private final Rendezvous canal;
    private final Condition condicao;

    public Requisicao(Rendezvous canal, Condition condicao) {
      this.canal = canal;
      this.condicao = condicao;
    }

    public Rendezvous getCanal() {
      return canal;
    }

    public Condition getCondicao() {
      return condicao;
    }
  }



}
