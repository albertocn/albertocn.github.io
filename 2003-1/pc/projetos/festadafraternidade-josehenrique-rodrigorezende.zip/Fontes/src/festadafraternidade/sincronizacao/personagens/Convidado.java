package festadafraternidade.sincronizacao.personagens;

/**
 * <p>Title: Convidado </p>
 * @author Henrique e Rodrigo
 * @version 1.0
 *
 * Classe personagem que representa os convidados da festa
 *
 */


import festadafraternidade.configuracao.Configuracao;
import festadafraternidade.sincronizacao.Ajustavel;
import festadafraternidade.sincronizacao.comunicacao.IRendezvousExtendidoCondicional;
import festadafraternidade.Log;
import festadafraternidade.sincronizacao.comunicacao.IRendezvous;



public class Convidado extends Ajustavel implements Runnable {

  /**
   * Dado estat�stico
   */
  private static long dosesTomadas = 0;
  private static Object lockDosesTomadas = new Object();
  private static long jaBeberam = 0;
  private static Object lockJaBeberam = new Object();

  /**
   * Dado de controle para c�lculo estat�stico
   */
  private boolean jaBebeu;

  private final IRendezvousExtendidoCondicional mbox;
  private final IRendezvous garcon;
  /**
   * Identificador �nico
   */
  private final int id;

  public Convidado(int id, IRendezvousExtendidoCondicional mbox,
                   IRendezvous garcon) {
    super(Configuracao.getDormirConvidados());
    jaBebeu = false;
    this.mbox = mbox;
    this.id = id;
    this.garcon = garcon;
    Thread me = new Thread(this, "Convidado "+id);
    me.start();
  }


  public void pausar() {

  }

  public void run() {
    while (true) {
      log("Quero tomar uma!");
      avisarGarconCasoEstejaVazio();
      log("Indo pegar minha dose..");
      pegarDose();
      log("Ahhh! Geladinha");
      beber();
      if (verificarEncerramento()) //verifica se a Simula��o foi encerrada
        return;
    }
  }

  private void avisarGarconCasoEstejaVazio() {
    Object resposta = mbox.send("querendoDose"); //envia mensagem solicitando dose
    while (resposta == "barrilVazio") {  //caso receba como resposta essa mensagem
      log("Garcon, encha aqui o barril..");
      garcon.send("encherBarril");  //acorda o garcon para que ele encha
      resposta = mbox.send("querendoDose");
    }
  }

  private void pegarDose() {
    log("pegando mais uma dose.. (vou at� cair no ch�o)");
    incDosesTomadas();
  }

  private void beber() {
    jaBebeu();
    try {
      Thread.currentThread().sleep(getTempoDormir());
    } catch (InterruptedException ie) {}
  }

  private void log(String msg) {
    Log.log("-Convidado-"+id+"-: ",msg);
    Log.logJanela("-Convidado-"+id+"-: ",msg);
  }


  /**
   * M�todos estat�sticos
   */
  private static void incDosesTomadas(){
    synchronized (lockDosesTomadas) {
      dosesTomadas++;
    }
  }

  public static void limparDoses(){
    synchronized (lockDosesTomadas) {
      dosesTomadas = 0;
    }

  }

  public static long getDosesTomadas() {
    synchronized (lockDosesTomadas) {
      return dosesTomadas;
    }

  }

  private static void incJaBeberam(){
    synchronized (lockJaBeberam) {
      jaBeberam++;
    }

  }

  public static void limparJaBeberam(){
    synchronized (lockJaBeberam) {
      jaBeberam=0;
    }
  }

  public static long getJaBeberam() {
    synchronized (lockJaBeberam) {
      return jaBeberam;
    }
  }


  private void jaBebeu() {
    if (!jaBebeu) {
      incJaBeberam();
      jaBebeu = true;
    }
  }


}
