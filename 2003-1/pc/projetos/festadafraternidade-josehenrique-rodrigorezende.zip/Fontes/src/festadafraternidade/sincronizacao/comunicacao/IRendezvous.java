package festadafraternidade.sincronizacao.comunicacao;

/**
 * <p>Title: IRendedzvous </p>
 * <p>Description: Interface de Rendezvous </p>
 * @author Henrique e Rodrigo
 * @version 1.0
 */

public interface IRendezvous {

  /**Metodo de envio da mensagem de rendezvous
   * @param m - mensagem a ser enviada
   */
  void send(Object m);

  /**
   * M�todo de recebimento de mensagem pelo Rendezvous
   * @return - Mensagem
   */
  Object receive();

}
