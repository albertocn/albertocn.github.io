package festadafraternidade.sincronizacao;

/**
 * <p>Title: Sincronizador</p>
 * <p>Description: Gerencia a simula��o </p>
 * @author Henrique, Rodrigo
 * @version 1.0
 *
 * Mant�m as referencias aos personagens da simula��o
 * e os gerencia
 *
 */


import festadafraternidade.Log;

import festadafraternidade.configuracao.Configuracao;

import festadafraternidade.sincronizacao.comunicacao.*;
import festadafraternidade.sincronizacao.personagens.*;

import festadafraternidade.Constantes;


import java.util.LinkedList;
import java.util.List;


public class Sincronizador {

  /**
   * Dado estat�stico
   */
  private static int numSimulacao = 0;

  /**
   * Lista de convidados
   */
  private List   convidados;
  private Garcon garcon;
  private Barril barril;

  private IRendezvousExtendidoCondicional central;
  private IRendezvous canalGarcon;



  public Sincronizador() {
    new Sincronizador(Configuracao.getNumConvidados(), Configuracao.getNumDoses(),
                             Configuracao.getMaxDoses());
  }

  public Sincronizador(int numConvidados, int numDoses, int maxDoses) {

    Log.log("-----------------------------------------","Iniciando Simulacao Numero "+ (numSimulacao++)+" :[-----------------------------------------]");
    Log.logJanela("-----------------------------------------","Iniciando Simulacao Numero "+ (numSimulacao++)+" :[-----------------------------------------]");

    //inicializa as estat�sticas
    Convidado.limparDoses();
    Convidado.limparJaBeberam();
    Barril.limparEnchimentos();

    //cria os personagens
    central = new RendezvousExtendidoCondicional();
    canalGarcon = new Rendezvous();
    garcon = new Garcon(central, canalGarcon);
    barril = new Barril(maxDoses, numDoses, central);
    convidados = new LinkedList();

    for (int i=1; i<= numConvidados; i++) {
      Convidado novo = new Convidado(i, central, canalGarcon);
      convidados.add(novo);
    }

  }

  /**
   * Encerra a simula��o
   */
  public synchronized void encerrar() {
    Encerrar.encerrar();
  }

}
