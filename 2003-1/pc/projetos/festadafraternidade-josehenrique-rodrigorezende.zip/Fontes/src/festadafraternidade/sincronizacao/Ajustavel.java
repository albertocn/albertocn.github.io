package festadafraternidade.sincronizacao;

/**
 * <p>Title: Ajustavel</p>
 * <p>Description: Permite a abstra��o de classes ajust�veis em velocidade </p>
 * @author Henrique, Rodrigo
 * @version 1.0
 */



public abstract class Ajustavel {

  private long tempoDormir;

  protected Ajustavel(long tempoDormir) {
    this.tempoDormir = tempoDormir;
  }


  protected long getTempoDormir() {
    return tempoDormir;
  }

  protected boolean verificarEncerramento(){
    return Encerrar.verificarEncerramento();
  }

}
