package festadafraternidade.sincronizacao.personagens;

/**
 * <p>Title: Garcon</p>
 * <p>Description: Personagem da simula��o </p>
 * @author Henrique, Rodrigo
 * @version 1.0
 */

import festadafraternidade.sincronizacao.Encerrar;

import festadafraternidade.configuracao.Configuracao;
import festadafraternidade.Constantes;
import festadafraternidade.sincronizacao.Ajustavel;
import festadafraternidade.sincronizacao.comunicacao.IRendezvousExtendidoCondicional;
import festadafraternidade.sincronizacao.comunicacao.IRendezvous;
import festadafraternidade.Log;


public class Garcon extends Ajustavel implements Runnable {


  private final IRendezvousExtendidoCondicional mbox;
  private final IRendezvous me;

  public Garcon(IRendezvousExtendidoCondicional mbox ,
                IRendezvous me) {
    super(Configuracao.getDormirGarcom());
    this.mbox = mbox;
    this.me = me;
    Thread eu = new Thread(this, "Garcon");
    eu.start();
  }

  public void run() {
    Thread.currentThread().setPriority(7);
    while (true) {
      log("Esperando barril esvaziar..");
      esperarBarrilEsvaziar();
      log("Indo encher o barril");
      encherBarril();
      log("Enchi o barril");
      if (Encerrar.verificarEncerramento())
        return;
    }
  }

  private void esperarBarrilEsvaziar() {
    Object resposta = me.receive(); //dorme esperando alguem responder (acordar)
    log((String) resposta);
  }

  private void encherBarril() { //se acordou � porque o Barril necessita ser preenchido
    dormir();
    Object resposta = mbox.send("encher");
    log((String) resposta);
  }

  private void dormir() {
    try {
      Thread.currentThread().sleep(getTempoDormir());
    } catch (InterruptedException ie) {}
  }


  private void log(String msg) {
    Log.log("GARCON ",msg);
    Log.logJanela("GARCON ",msg);
  }

}
