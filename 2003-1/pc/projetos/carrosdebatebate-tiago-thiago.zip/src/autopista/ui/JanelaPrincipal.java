package autopista.ui;

import javax.swing.*;
import java.awt.*;

/**
 * <p>Title: Janela Principal</p>
 * <p>Description: A Janela Principal da aplica��o � a sua �nica
 * interface gr�fica; consiste de duas �reas dispostas horizontalmente
 * onde a �rea superior � o log geral da aplica��o e a inferior pode ser
 * tanto o log dos carros do autopista quanto o log dos pilotos, para
 * mudar de um para outro, pasta clicar em uma das "abas" correspondentes. </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: T&T</p>
 * @author Thiago Caetano e Tiago Santos
 * @version 1.0
 */

public class JanelaPrincipal extends JFrame {
  JSplitPane JSPLogs = new JSplitPane();
  JTabbedPane jTabbedPaneLogsIndividuais = new JTabbedPane();
  JScrollPane jScrollPaneLogPilotos = new JScrollPane();
  JScrollPane jScrollPaneLogCarros = new JScrollPane();
  JTextArea jTextAreaLogPilotos = new JTextArea();
  JTextArea jTextAreaLogCarros = new JTextArea();
  JSplitPane jSplitPaneLOGS = new JSplitPane();
  JLabel jLabelLogGeral = new JLabel();
  JScrollPane jScrollPaneLogGeral = new JScrollPane();
  JTextArea jTextAreaLogGeral = new JTextArea();

  /**
   * Construtor �nico. Inicia a interface de uma janela, "empacota"
   * para um tamanho m�nimo e exibe na sa�da de v�deo.
   * @throws Exception;
   */
  public JanelaPrincipal() {
    try {
      jbInit();
      pack();
      show();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception {
    this.setLocation(100,100);
    JSPLogs.setOrientation(JSplitPane.VERTICAL_SPLIT);
    JSPLogs.setBackground(UIManager.getColor("windowText"));
    JSPLogs.setPreferredSize(new Dimension(640, 480));
    JSPLogs.setDividerSize(8);
    jTextAreaLogPilotos.setAutoscrolls(true);
    jTextAreaLogPilotos.setEditable(false);
    jTextAreaLogPilotos.setText("");
    jTabbedPaneLogsIndividuais.setTabPlacement(JTabbedPane.BOTTOM);
    jTabbedPaneLogsIndividuais.setPreferredSize(new Dimension(108, 85));
    jScrollPaneLogPilotos.setAutoscrolls(true);
    jScrollPaneLogCarros.setAutoscrolls(true);
    jSplitPaneLOGS.setOrientation(JSplitPane.VERTICAL_SPLIT);
    jSplitPaneLOGS.setBorder(null);
    jSplitPaneLOGS.setDebugGraphicsOptions(0);
    jSplitPaneLOGS.setToolTipText("LOG GERAL");
    jSplitPaneLOGS.setDividerSize(2);
    jSplitPaneLOGS.setOneTouchExpandable(false);
    jSplitPaneLOGS.setResizeWeight(0.0);
    jLabelLogGeral.setForeground(Color.cyan);
    jLabelLogGeral.setBorder(BorderFactory.createEtchedBorder());
    jLabelLogGeral.setHorizontalAlignment(SwingConstants.CENTER);
    jLabelLogGeral.setText("LOG GERAL");
    jTextAreaLogGeral.setEditable(false);
    jTextAreaLogGeral.setText("");
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.setTitle("Projeto de Programa��o Concorrente - ");
    jTextAreaLogCarros.setEditable(false);
    jTextAreaLogCarros.setText("");
    this.getContentPane().add(JSPLogs, BorderLayout.CENTER);
    JSPLogs.add(jTabbedPaneLogsIndividuais, JSplitPane.BOTTOM);
    jTabbedPaneLogsIndividuais.add(jScrollPaneLogPilotos,  "Pilotos");
    jScrollPaneLogPilotos.getViewport().add(jTextAreaLogPilotos, null);
    jTabbedPaneLogsIndividuais.add(jScrollPaneLogCarros,  "Carros");
    JSPLogs.add(jSplitPaneLOGS, JSplitPane.TOP);
    jSplitPaneLOGS.add(jLabelLogGeral, JSplitPane.TOP);
    jSplitPaneLOGS.add(jScrollPaneLogGeral, JSplitPane.BOTTOM);
    jScrollPaneLogGeral.getViewport().add(jTextAreaLogGeral, null);
    jScrollPaneLogCarros.getViewport().add(jTextAreaLogCarros, null);
    JSPLogs.setDividerLocation(180);
    jSplitPaneLOGS.setDividerLocation(23);
  }

  /**
   * Retorna o a �rea de texto no qual o log Geral da aplica��o sera impresso.
   * @return �rea de texto;
   */
  public JTextArea getLogGeral(){
    return this.jTextAreaLogGeral;
  }

  /**
   * Retorna o a �rea de texto no qual o log dos Pilotos sera impresso.
   * @return �rea de texto;
   */
  public JTextArea getLogPilotos(){
    return this.jTextAreaLogPilotos;
  }

  /**
   * Retorna o a �rea de texto no qual o log dos Carros do autopista
   * sera impresso.
   * @return �rea de texto;
   */
  public JTextArea getLogCarros(){
    return this.jTextAreaLogCarros;
  }


}