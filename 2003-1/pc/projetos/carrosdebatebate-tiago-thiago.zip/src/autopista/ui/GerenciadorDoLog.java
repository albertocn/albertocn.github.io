package autopista.ui;

import autopista.ui.JanelaPrincipal;
import autopista.*;

import java.io.PrintStream;
import javax.swing.JTextArea;

/**
 * <p>Title: Gerenciadordos Logs da Aplica��o</p>
 * <p>Description: Esta classe � a respons�vel pelo desvio do fluxo
 * de impress�o da sa�da convenciona de v�deo para uma janela que
 * contenha as �reas de texto referntes a cada log da aplica��o "autopista".</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: T&T </p>
 * @author Thiago Caetano e Tiago Santos
 * @version 1.0
 */

public class GerenciadorDoLog extends PrintStream {

  private JTextArea logGeral = null;  // ver construtor
  private JTextArea logPiloto = null; // ver construtor
  private JTextArea logCarro = null;  // ver construtor

  private PrintStream out = null; // sa�da de impress�o


  /**
   * Construtor �nico. Obtem as sa�das dos logs.
   * @param logG �rea de texto no qual o log Geral da aplica��o sera impresso
   * @param logPi �rea de texto no qual o log dos Pilotos sera impresso;
   * @param logCar �rea de texto no qual o log dos Carros do autopista
   * sera impresso;
   */
  public GerenciadorDoLog(JTextArea logG,
                          JTextArea logPi,
                          JTextArea logCar) {
    super(System.out); // cria um novo fluxo de impress�o (print stream)
    // os valores e objetos ser�o impressos em 'System.out'

    this.out = System.out; // setando a sa�da da aplica��o para 'System.out'

    this.logGeral = logG;   // referencia as sa�das dos logs
    this.logPiloto = logPi;
    this.logCarro = logCar;

  }


  /**
   * Imprime uma String na s�da padr�o e na �rea de texto referente
   * ao objeto que requisitar a impress�o.
   * @param x String a ser impressa;
   */
  public void print(String x) {

    // out.print(x); // est� comentado pois � uma op��o: com esse comando
    // podemos imprimir tamb�m na sa�da convencional - tela de batch

    logGeral.append(x); // coloca mensagem na �rea de texto do log Geral
    logGeral.setCaretPosition(logGeral.getCaretPosition() + x.length());
    // altera a posi��o do curssor para uma pr�xima impress�o


    Object o = Thread.currentThread();
    // obtem o objeto que requisita a impress�ao

    if (o instanceof Piloto){
      logPiloto.append(x);// coloca mensagem na �rea de texto do log Geral
      logPiloto.setCaretPosition(logPiloto.getCaretPosition() + x.length());
      // altera a posi��o do curssor para uma pr�xima impress�o
    }

    if (o instanceof Carro){
      logCarro.append(x);// coloca mensagem na �rea de texto do log Geral
      logCarro.setCaretPosition(logCarro.getCaretPosition() + x.length());
      // altera a posi��o do curssor para uma pr�xima impress�o
    }
  }

  /**
   * 'Println' imprime o mesmo que 'print' e depois "quebra a linha".
   * @param x String a ser impressa;
   */
  public void println(String x) {
    print(x + "\n");
  }

  /**
   * � o m�todo de impress�o respons�vel pela impress�o de objetos.
   * @param x Objeto com o m�todo toString a ser impresso;
   */
  public void println(Object x) {
    try { println(x.toString());} // se o objeto n�o tiver um 'toString'
    catch (Exception e) {e.printStackTrace();} // uma exce��o � lan�ada
  }
}