package autopista;

/**
 * <p>Title: Carro do Autopista.</p>
 * <p>Description:  � o Carro gerenciado pelo Coordenador do autopista;</p>

 * <p>Sua rotina consiste em solicitar ao coordenador um piloto, notificar o
 * coordenador que ele est� sendo guiado pelo piloto fornecido e ent�o
 * terminar a  volta depois que se passar um tempo aleat�rio com dura��o
 * m�xima informada pelo coordenador no construtor do Carro.</p>

 * <p>O carro possui um identificador, "sabe" o tempo m�ximo de dura��o de
 * uma volta, tem uma refer�ncia para o coordenador do autopista e possui o
 * identificador do seu piloto, quando est� dando uma volta no autopista.</p>

 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: T&T</p>
 * @author Thiago Caetano e Tiago Santos
 * @version 1.0
 */
public class Carro extends Thread {

// campos do CARRO

  private int idc;     // identificador do carro

  private int Tvolta;  // tempo m�ximo de uma volta

  private Coordenador coord = null; // coordenador do autopista

  private int piloto; // o carro possui o identificador do seu piloto

  /**
   * Construtor �nico, sem valores default. Garante a integridade
   * da aplica��o, j� que o coordenador do autopista possui uma
   * identifica��o �nica de cada Carro.
   * @param id Informa o identificador do carro;
   * @param tv Informa o tempo m�ximo de uma volta;
   * @param c  Informa ao Carro quem � o coordenador do autopista;
   * @see <a href="Coordenador.html">Coordenador</a>
   */
  public Carro(int id, int tv, Coordenador c) {
    idc = id;
    Tvolta = tv;
    coord = c;
    this.start();
  }

  /**
   * Retorna o Piloto deste Carro.
   * @return Identificador do Piloto deste Carro;
   */
  public int obterPiloto() {
    return this.piloto;
  }

  /**
   * Altera o Piloto deste Carro.
   * @param idp Identificador do novo Piloto;
   */
  public void setarPiloto(int idp){
    this.piloto = idp;
  }

  /**
   * Gera um n�mero rand�mico entre 0 (zero) e 'n'. � usado para
   * gerar o tempo de dura��o da volta do carro.
   * @param n Limite superior do n�mero rand�mico;
   * @return N�mero rand�mico;
   */
  private long random(long n) {
     return Math.round( Math.random() * n);
   }

  /**
   * Faz a Thread Carro "dormir", simulando uma volta no autopista.
   * @param tempo Tempo m�ximo em segundos da dura��o da volta;
   */
  private void correr(int tempo){
    log("Correndo com o Piloto" + this.obterPiloto());
    try { this.sleep( random( tempo ) * 1000 ); }
    catch (InterruptedException e) { e.printStackTrace();}

  }

  public void run () {

    log("Funcionando!");

    while (true) {      // rotina de opera��es do Carro

      coord.ocupar(idc); // pede ao coord. para ocup�-lo com um piloto

      correr(Tvolta);   // simula uma volta no autopista por 'Tvolta' segundos

      coord.desocupar(idc); // corrida acabada, este carro dispensa seu piloto
    }

  }

  /**
   * Gera log do Carro.
   * @param msg Mensagem de log;
   */
  private void log (String msg) {
    System.out.println("[Carro   0" + idc + " ]: -> " + msg);
  }

}