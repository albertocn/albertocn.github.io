package autopista;

import java.util.LinkedList;
import semaforo.SemaforoBinario;
import semaforo.SemaforoContador;

/**
 * <p>Title: Coordenador do Autopista</p>
 * <p>Description: � respons�vel por todo o controle do autopista,
 * ou seja, todas as requisi�oes por parte dos Carros e dos Pilotos
 * s�o feitas ao Coordenador e ele � posto a process�-las de forma
 * que todos os requerentes possam eventualmente realizar suas a��es
 * de forma coerente e organizada;</p>
 * <h4>Se��es Criticas:</h4>A fila de espera � o objeto mais requisitado
 * da aplica��o - os Pilotos pedem ao coordenador que os coloquem na fila,
 * j� os carros pedem para ocup�-los com um piloto da fila e novamente
 * deve-se acess�-la, logo, o coordenador mant�m um sem�foro bin�rio para
 * sincroniz�-la;
 * <h4>Condi��es de Sincroniza��o:</h4>Al�m de uma se��o cr�tica h�
 * condi��es a serem respeitadas, tais que impedem as entidades de realizarem
 * certas a��es a menos que um determinado evento ocorra, s�o condi��es:
 * <li>Os Pilotos s� come�am a corrida quando um carro estiver dispon�vel
 * para ele;
 * <li>Ainda os Pilotos s� terminar�o a volta no autopista quando o tempo
 * da volta (determinado pelo carro) acabar;
 * <li>Um carro s� pode requisitar pilotos na fila se houver pilotos;</li>
 * <p>As duas primeira condi��es s�o fiscalizadas por dois vetores de sem�foros
 * bin�rios independentes, onde a posi��o i corresponde ao sem�foro do
 * piloto i;  a �ltima condi��o � gerenciada por um sem�foro Contador de
 * pilotos;</p>
 * <p>Al�m disso tudo, o coordenador mant�m uma refer�ncia (por meio de um
 * vetor) para cada Carro do autopista, simulando seu controle sobre o
 * mesmo.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: T&T</p>
 * @author Thiago Caetano e Tiago Santos
 * @version 1.0
 */

public class Coordenador {

// CAMPOS

// sem�foros de sincroniza��o por condi��o
  private SemaforoBinario[] comecoDaCorrida = null; //
  private SemaforoBinario[] finalDaCorrida  = null; //
  private SemaforoContador  pilotosContador = null; // indica quantos pilotos
                                                    // est�o na fila de espera

// controle da se��o cr�tica
  private LinkedList filaDeEspera = null;  // fila de espera por carros
  public  SemaforoBinario semFila; // sem�foro para o acesso exclusivo aa fila

  private Carro[] carros   = null; // coordenador "sabe" os carros do autopista

// M�TODOS

  /**
   * Construtor �nico.
   * @param Npilotos N�mero de Pilotos no parque;
   * @param cs Vetor dos Carros do autopista;
   */
  public Coordenador(int Npilotos, Carro[] cs) {

    this.filaDeEspera  = new LinkedList(); // cria fila inicialmente vazia
    this.semFila = new SemaforoBinario(1);

    this.pilotosContador = new SemaforoContador(0);
    // zero pois n�o h� pilotos na fila

    this.inicializarSemaforos(Npilotos);
    // inicializa sem�foros de controle para cada piloto

    this.carros = cs;

    log("Estou Operando!\n");
  }

/**
 * M�todo invoc�vel por um piloto, que passa seu identificador e o
 * coordenador o coloca na �ltima posi��o da fila de espera por um
 * carro, assim que poss�vel(liberada).
 * @param idp Identificador do Piloto que deseja entrar na fila de espera;
 */
  public void entrarNaFila (Integer idp) {
    log("Piloto | " + idp.toString() + " | quer entrar na fila.");

    semFila.P();

    filaDeEspera.add(idp); // o piloto � adicionado na �ltima posi��o
    pilotosContador.V();   // notifica que h� um piloto pelo menos

    semFila.V();

    log("Piloto | " + idp.toString() + " | entrou na fila.");
  }

  /**
   * M�todo invoc�vel por um piloto, que tamb�m passa seu identificador
   * e o coordenador deve agora aloc�-lo no sem�foro de in�cio da corrida,
   * que ocorrer� quando um carro estiver dispon�vel para ele.
   * @param idp Identificador do Piloto que quer o carro;
   */
  public void pegarUmCarro (int idp) {

    log("Piloto | " + idp + " | quer um carro...");

    comecoDaCorrida[idp].P(); // piloto bloqueado at� que um carro o requeira,
  }                           // executando um V() nesta mesma posi��o


  /**
   * M�todo invoc�vel por um piloto. J� num carro, o piloto solicita
   * ao coordenador que o libere do carro quando a corrida acabar.
   * @param idp Identificador do Piloto que est� dando uma volta no autopista;
   */
  public void darUmaVolta(int idp) {

    log("Piloto | " + idp + " | est� correndo e espera terminar a sua volta...");

    finalDaCorrida[idp].P(); // piloto 'idp' bloqueado at� que um carro
  }                          // execute um V(), depois que a volta acabar;


  /**
   * M�todo invoc�vel pelos carros de Bate-Bate. Coordenador ocupa o
   * carro invocador do m�todo com o primeiro piloto da fila de espera.
   * @param idc Identificador do Carro que ir� ser ocupado;
   */
  public void ocupar (int idc) {

    pilotosContador.P(); // notifica a retirada de um piloto da fila

    semFila.P();
    Integer i = (Integer) filaDeEspera.removeFirst();  // pega o primeiro piloto
    semFila.V();

    int idp = i.intValue(); // obtem o id do primeiro piloto
                            // da fila no formato int

    carros[idc].setarPiloto(idp); // o piloto ocupa o carro

    comecoDaCorrida[idp].V(); // o mesmo piloto � liberado para correr

    log("Carro  | " + idc + " | � ocupado pelo piloto | " + i.toString()
        + " |.");
  }

  /**
   * M�todo invoc�vel pelo Carro. Carro libera seu piloto.
   * @param idc Identificador do carro que ser� desocupado;
   */
  public void desocupar (int idc) {
    int idp = carros[idc].obterPiloto();
    finalDaCorrida[idp].V();  // carro libera seu piloto (idp)
    log("Tempo da minha volta | acabou! ");
  }

  /**
   * Gera log do Coordenador.
   * @param msg Mensagem de log;
   */
  private void log (String msg) {
    System.out.println("[COORDENADOR]: -> " + msg);
  }

  /**
   * Inicializa os Sem�foros de Controle da Corrida: o de come�o e o de t�rmino.
   * @param n Indica quantos sem�foros ser�o criados; Para o Coordenador, n
   * � igual ao n�mero de Pilotos;
   */
  private void inicializarSemaforos(int n){
    comecoDaCorrida = new SemaforoBinario[n];
    finalDaCorrida =  new SemaforoBinario[n];

    for (int i = 0; i < n; i++){
      comecoDaCorrida[i] = new SemaforoBinario(0);
      finalDaCorrida[i]  = new SemaforoBinario(0);
    }
  }
}

