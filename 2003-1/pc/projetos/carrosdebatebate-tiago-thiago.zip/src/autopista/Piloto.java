package autopista;

import java.lang.Integer;
import java.lang.InterruptedException;
import java.lang.Math;

/**
 * <p>Title: Piloto de Carros de Autopista.</p>
 * <p>Description: O piloto possui um identificador �nico, conhece (tem
 * uma refer�ncia para) o coordenador do autopista, e, inicialmente ele
 * fica passeando pelo parque de divers�es por um tempo aleat�rio.</p>
 *
 * <p>Depois deste tempo, o piloto requisita ao coordenador que coloque
 * seu identificador numa fila de espera por um carro do autopista; no
 * momento em que o coordenador  do autopista libera um carro para este
 * piloto, ele sai da fila de espera e entra no carro para dar uma volta
 * no autopista, ent�o, ele aguarda que a volta acabe.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: T&T</p>
 * @author Thiago Caetano e Tiago Santos
 * @version 1.0
 */
public class Piloto extends Thread {

// campos do PILOTO

  private int idp; // identificador do piloto

  private int Tpasseio; // tempo m�ximo que o piloto passseia pelo parque

  private Coordenador coord = null; // coordenador do Autopista

  /**
   * Construtor �nico. Garante a integridade da aplica��o,
   * j� que o coordenador do autopista possui uma identifica��o
   * �nica de cada Piloto.
   * @param id Identificador do Piloto;
   * @param tp Dura��o m�xima do passeio do piloto pelo parque (em seg);
   * @param c Coordenador do Autopista;
   * @see <a href="Coordenador.html">Coordenador</a>
   */
  public Piloto(int id, int tp, Coordenador c) {
    this.idp = id;
    this.Tpasseio = tp;
    this.coord = c;
    this.start();
  }

  /**
   * Gera um n�mero rand�mico entre 0 (zero) e 'n'. � usado para
   * gerar o tempo de dura��o do passeio do piloto pelo parque.
   * @param n Limite superior do n�mero rand�mico;
   * @return N�mero rand�mico;
   */
  private long random(long n) {
     return Math.round( Math.random() * n);
   }

  /**
   * Faz a Thread Piloto 'dormir', simulando um passeio no parque.
   * @param tempo Tempo m�ximo em segundos da dura��o do passeio;
    */
  private void passearPeloParque(int tempo) {
   log("Passeando pelo parque...");

   try { this.sleep( random( tempo ) * 1000 ); }
   catch (InterruptedException e) { e.printStackTrace(); }

    log("Terminei de passear!");

  }

  public void run () {
    while ( true ) {                // rotina de opera��es do piloto

      passearPeloParque(Tpasseio); // o Piloto est� passeando pelo Parque

      coord.entrarNaFila(new Integer(idp)); // coord. do autopista
                                            // insere piloto[idp] na fila

      coord.pegarUmCarro(idp); // piloto solicita um carro ao coordenador

      coord.darUmaVolta(idp);  // piloto, j� com o carro d� um volta nele
    }
  }

  /**
   * Gera log do Piloto.
   * @param msg Mensagem de log;
   */
  private void log (String msg) {
    System.out.println("[Piloto  0" + idp + " ]: -> " + msg);
  }

}