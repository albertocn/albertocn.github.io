package autopista;

import javax.swing.JDialog;
import javax.swing.JLabel;

import autopista.ui.*;

/**
 * <p>Title: Classe inicializadora do Autopista </p>
 * <p>Description: Captura os par�metros de inicializa��o do autopista
 * passados pelo usu�rio, instancia, a partir do n� de carros passado como
 * par�metro, os carros do autopista, inicializa o coordenador do mesmo,
 * instancia os pilotos; "dorme" pelo tempo parametrizado
 * (tempo total da corrida) e ent�o finaliza o autopista.  </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: T&T</p>
 * @author Thiago Caetano e Tiago Santos
 * @version 1.0
 */

public class IniciarAutopista {

  Coordenador coord = null;

  private static int Npilotos = 10; // n�mero de pilotos
  private static int Ncarros  =  5; // n�mero de carros
  private static int Tvolta   =  5; // dura��o m�xima de uma volta no autopista
  private static int Tpasseio = 10; // dura��o m�xima de um passeio pelo parque
  private static int TCorrida = 60; // tempo total de execu��o do autopista

  public IniciarAutopista() {

    // interface

    JanelaPrincipal jPrinc = new JanelaPrincipal();
    GerenciadorDoLog gdl = new GerenciadorDoLog( jPrinc.getLogGeral(),
                                                 jPrinc.getLogPilotos(),
                                                 jPrinc.getLogCarros() );
    System.setOut(gdl);

    // inicializa��es

    Carro[] cs = new Carro[Ncarros]; // crando os carros do autopista

    coord = new Coordenador(Npilotos, cs);
   // cria o coordenador e lhe passa o n� de pilotos e os carros que ele
   // coordenar�; o vetor de carros ainda n�o foi criado. <consulte a
   // documenta��o desta classe >, pois os carros
   // precisam de um coordenador para serem riados, logo o coordenador deve
   // ser criado antes dos carros


    for (int i = 0; i < Npilotos; i++){ // inicializando pilotos
      new Piloto(i, Tpasseio, coord);
    }

    for (int j = 0; j < Ncarros; j++){ // inicializando carros
      cs[j] = new Carro(j, Tvolta, coord);
    }

  }

  /**
   * O m�todo pricipal captura os par�metros de inicializa��o do autopista,
   * inicializa o autopista, "dorme" por 'TCorrida' segundos e ent�o
   * finaliza o autopista;
   * @param args Par�metros de inicializa��o;
   */
  public static void main(String[] args){

    for (int i = 0 ; i < args.length ; i += 2) { // captura par�metros

      if (args[i].equals("-R")) { // n�mero de pilotos (RIDERS)
        Npilotos = Integer.parseInt(args[i +1]);
        continue; // pula para a pr�xima execu��o do la�o,
                  // evitando testes desnecess�rios
      }

      if (args[i].equals("-C")) { // n�mero de carros (CARS)
        Ncarros = Integer.parseInt(args[i +1]);
        continue;
      }

      if (args[i].equals("-B")) { // dura��o de uma volta no autopista (TBUMP)
        Tvolta = Integer.parseInt(args[i +1]);
        continue;
      }

      if (args[i].equals("-W")) { // dura��o de um passeio pelo parque (TWALK)
        Tpasseio = Integer.parseInt(args[i +1]);
        continue;
      }

      if (args[i].equals("-T")) { // tempo total de execu��o do autopista (TTOTAL)
        TCorrida = Integer.parseInt(args[i +1]);
        continue;
      }

      if (args[i].equals("-?")) { // um pequeno HELP
        System.out.println("Uso: java -jar [-opc�es] autopista [-parametros]\n"+
                           "\n\nonde op��es s�o as op��es de execu��o"         +
                           "do 'java' e os parametros s�o:\n"                  +

                           "\t-R #valor \t n�mero de pessoas que brincar�o no" +
                           " autopista (pilotos)\n"                            +

                           "\t-C #valor \t n�mero de Carros que o autopista"   +
                           "possui \n"                                         +

                           "\t-B #valor \t dura��o m�xima de uma volta no "    +
                           "autopista\n"                                       +

                           "\t-W #valor \t dura��o m�xima de um passeio pelo " +
                           "parque realizado por um piloto\n"                  +

                           "\t-T #valor\t dura��o total da simula��o do "      +
                           "autopista \n"                                      +

                           "OBS: ap�s cada par�metro digite um valor positivo" +
                           "; os par�metros s�o opcionais. Aqueles que n�o"    +
                           "forem defenidos acarretar� no uso de seus valores" +
                           "default correspondentes."                         );
        System.exit(1);

      }
    }

    log ("Iniciando o Autopista...");
    new IniciarAutopista();           // finalmente iniciando o autopista

    autopistaEmExecucaoPor(TCorrida); // autopista executando at� que se
                                      // passe o tempo estimado
    log("Tempo de execu��o do Autopista acabado...");
    finalizarAutopista();             // tempo de execu��o do autopista acabado


  } // main()

  /**
   * Faz com que o objeto inicializador do autopista "durma" durante
   * por um tempo pre-definido pelo usu�rio ou um valor default.
   * Depois deste tempo, o autopista ser� finalizado pelo mesmo objeto.
   * @param tc dura��o total da execu��o do autopista;
   */
  private static void autopistaEmExecucaoPor(int tc){
    try { Thread.sleep( tc * 1000 ); }
    catch (InterruptedException e) { e.printStackTrace();}
  }

  /**
   * Finaliza o autopista;
   */
  private static void finalizarAutopista(){
    System.exit(1);
  }

  /**
   * Gera log do objeto principal, o inicializador do autopista.
   * @param msg Mensagem de log;
   */
  private static void log (String msg) {
    System.out.println("\n");
    System.out.println("[PRINCIPAL]: ->  " + msg);
  }

} // class