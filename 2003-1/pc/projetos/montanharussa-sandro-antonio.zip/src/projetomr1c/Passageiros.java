package projetomr1c;

/**
 * Classe que cria as Threads passageiros.
 */
public class Passageiros implements Runnable{

  /**
   * Representa o id do passageiro
   */
  protected final int id;

  /**
   * Representa o carro
   */
  protected Carro carro;

  /**
   * Representa os sem�foros da simula��o
   */
  protected final Semaforos semaforos;

  /**
   * Representa a montanha-russa
   */
  private MontanhaRussa montanha;

  /**
   * Representa o tempo em que o passageiro entrou no carro
   */
  private long inicio;

  /**
   * Representa o tempo gasto que o passageiro esperou para dar uma volta
   */
  private long tempo_total;

  /**
   * M�todo construtor da classe.
   */
  public Passageiros(int id, Carro carro, Semaforos semaforos, MontanhaRussa montanha) {
    this.id = id;
    this.carro = carro;
    this.semaforos = semaforos;
    this.montanha = montanha;
  }

  /**
   * M�todo respons�vel por executar cada thread passageiros.
   */
  public void run() {
    while (true) {
      // Testa se h� vaga no carro.
      if (carro.getLugaresOcupados() < montanha.NUM_LUGARES) {
        // Pedido de acesso exclusivo � vari�vel compartilhada.
        semaforos.mutex.P();
        // Incrementa a quantidade de lugares ocupados.
        carro.incLugaresOcupados();
        // Come�a a cronometrar
        inicio = System.currentTimeMillis();
        // Testa se � �ltimo passageiro do carro.
        if (carro.getLugaresOcupados() == montanha.NUM_LUGARES) {
          // Indica que o carro est� cheio.
          semaforos.passageiros.V();
        }
        // Libera o acesso exclusivo � vari�vel compartilhada.
        semaforos.mutex.V();
        System.out.println(Thread.currentThread().getName() + " pede para rodar");
        // Termina de Cronometrar
        tempo_total = System.currentTimeMillis() - inicio;
        // Seta o tempo de espera da thread corrente at� o momento em que
        // o carro come�ou a rodar.
        montanha.setTempoTotal(tempo_total);
        // Pedido para come�ar a rodar.
        semaforos.rodando.P();
        // Tempo rand�mico de passeio no parque ap�s ter dado uma volta.
        long tempo = Math.round( Math.random() * 5000 );
        System.out.println(Thread.currentThread().getName() + " passeando no parque " + tempo + " milisegundos");
        try { Thread.currentThread().sleep( tempo );}
        catch (InterruptedException ie) { ie.printStackTrace(); }
      }
      System.out.println(Thread.currentThread().getName() + " esperando o carro voltar");
      // Espera o carro voltar.
      semaforos.carro.P();
    }
  }
}