package projetomr1c;

/**
 * Classe respons�vel por realizar a simula��o do experimento
 */
public class Simulacao {

  /**
   * Representa os sem�foros da simula��o.
   */
  private Semaforos semaforos;

  /**
   * M�todo construtor da classe.
   */
  public Simulacao() {
    this.semaforos = new Semaforos();
  }

  /**
   * M�todo respons�vel por executar a simula��o, utilizando-se de
   * par�metros passados.
   */
  public void executar(long tempoaberto, int numpassageiros, int numlugares, long tempovolta) {
    System.out.println("INICIANDO SIMULA��O");
    // Cria a thread que controla o funcionamento da montanha-russa.
    new Thread(new MontanhaRussa(this.semaforos, tempoaberto, numpassageiros, numlugares, tempovolta),
               "Montanha").start();
  }

  /**
   * M�todo respons�vel por executar a simula��o sem a utiliza��o de
   * par�metros.
   */
   public void executar() {
     System.out.println("INICIANDO SIMULA��O");
     // Cria a thread que controla o funcionamento da montanha-russa.
     new Thread(new MontanhaRussa(this.semaforos),"Montanha").start();
   }

   /**
    * M�todo default main.
    */
   public static void main(String[] args) {
     if (args.length > 0){
       // Executa a simula��o com parametros.
       new Simulacao().executar(new Long(args[0]).longValue(), new Integer(args[1]).intValue(),
                               new Integer(args[2]).intValue(), new Long(args[3]).longValue());
     }
     else{
       // Executa a simula��o sem parametros.
       new Simulacao().executar();
     }

   }
}