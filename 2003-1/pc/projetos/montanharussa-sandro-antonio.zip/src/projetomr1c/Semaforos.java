package projetomr1c;

import semaforo.Semaforo;
import semaforo.SemaforoBinario;
import semaforo.SemaforoContador;

/**
 * M�todo respons�vel por gerar os sem�foros utilizados na simula��o.
 */
public class Semaforos {

  /**
   * Sem�foro que controla a exclus�o m�tua no acesso a vari�vel compartilhada.
   */
  public final Semaforo mutex;

  /**
   * Sem�foro que controla os passageiros dentro do carro.
   */
  public final Semaforo passageiros;

  /**
   * Sem�foro que controla os passageiros fora do carro.
   */
  public final Semaforo carro;

  /**
   * Sem�foro que controla se o carro est� rodando.
   */
  public final Semaforo rodando;

  /**
   * M�todo construtor da classe.
   */
  public Semaforos() {
    this.mutex       = criarSemMutex();
    this.passageiros = criarSemPassageiros();
    this.carro       = criarSemCarro();
    this.rodando     = criarSemRodando();
  }

  /** M�todo que cria o sem�foro bin�rio respons�vel pela exclus�o m�tua
   * no acesso a vari�vel que controla o numero de passageiros.
   */
  protected Semaforo criarSemMutex() {
    return new SemaforoBinario( 1 );
  }

  /** M�todo que cria o sem�foro bin�rio respons�vel por controlar a entrada
   * de passageiros no carro.
   */
  protected Semaforo criarSemPassageiros() {
    return new SemaforoBinario( 0 );
  }

  /** M�todo que cria o sem�foro contador respons�vel por controlar os
   * passageiros que esparam o carro voltar.
   */
  protected Semaforo criarSemCarro() {
   return new SemaforoContador( 0 );
  }

  /** M�todo que cria o sem�foro contador respons�vel por controlar os
   * passageiros que est�o rodando com o carro.
   */
  protected Semaforo criarSemRodando() {
    return new SemaforoContador( 0 );
  }
}