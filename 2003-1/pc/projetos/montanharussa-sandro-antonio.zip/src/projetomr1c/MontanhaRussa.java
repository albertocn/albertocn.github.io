package projetomr1c;

/**
 * Classe que cria a Thread montanha-russa.
 */
public class MontanhaRussa implements Runnable{

  /**
   * Representa o tempo de funcionamento da montanha-russa.
   */
  private static long TEMPO_ABERTO;

  /**
   * Representa o n�mero de passageiros que disputam para dar uma volta na montanha-russa.
   */
  private static int NUM_PASSAGEIROS;

  /**
   * Representa a quantidade de lugares no carro.
   */
  public static int NUM_LUGARES;

  /**
   * Representa o tempo que o carro despende numa volta.
   */
  public static long TEMPO_VOLTA;

  /**
   * Representa os sem�foros da simula��o.
   */
  protected final Semaforos semaforos;

  /**
   * Representa o tempo de in�cio da simula��o.
   */
  private static long inicio;

  /**
   * Representa o tempo que os passageiros esperaram para dar uma volta na montanha-russa.
   */
  private static long tempo;

  /**
   * Representa a quantidade de passageiros que deram uma volta na montanha-russa.
   */
  private static int cont;

  /**
   * M�todo construtor da classe com par�metros default.
   */
  public MontanhaRussa(Semaforos semaforos) {
   this.semaforos = semaforos;
   this.inicio = System.currentTimeMillis();
   this.TEMPO_ABERTO = 90000;
   this.NUM_PASSAGEIROS = 10;
   this.NUM_LUGARES = 4;
   this.TEMPO_VOLTA = 6000;
  }

  /**
   * M�todo construtor da classe com alguns par�metros passados.
   */
  public MontanhaRussa(Semaforos semaforos, long tempoaberto, int numpassageiros, int numlugares, long tempovolta) {
    this.semaforos = semaforos;
    this.inicio = System.currentTimeMillis();
    this.TEMPO_ABERTO = tempoaberto;
    this.NUM_PASSAGEIROS = numpassageiros;
    this.NUM_LUGARES = numlugares;
    this.TEMPO_VOLTA = tempovolta;
  }

  /**
   * M�todo que retorna o tempo atual de funcionamento da montanha-russa.
   */
  public long getTempoTotal(){
     return System.currentTimeMillis() - inicio;
  }

  /**
   * M�todo sincronizado que seta o tempo de espera das threads at� o
   * momento em que o carro come�ou a rodar.
   */
  public synchronized void setTempoTotal(long tempo_total){
    tempo = tempo + tempo_total;
    // Contabiliza a quantidade de threads que rodaram na montanha-russa.
    cont++;
  }

  /**
   * M�todo respons�vel por executar a thread montanha-russa.
   */
  public void run() {
    // Instancia o carro.
    Carro carro = new Carro(semaforos, this);
    // Cria a thread que representa o carro.
    new Thread(carro, "Carro").start();
    System.out.println("Criando o Carro");
    // Cria as threads que representam os passageiros da montanha-russa.
    for (int i = 1; i <= NUM_PASSAGEIROS; i++) {
      Thread passageiro = new Thread(new Passageiros(i, carro, this.semaforos, this), "Passageiro " + i);
      System.out.println("Criando " + passageiro.getName());
      passageiro.start();
    }
    // Loop respons�vel por controlar o tempo de funcionamento da montanha.
    while (getTempoTotal() <= TEMPO_ABERTO) {
      // Dorme 10 ms para melhorar o desempenho da aplica��o.
      try{
          Thread.currentThread().sleep(10);
      } catch(InterruptedException ie) {}
    }
    // Exibe dados da simula��o.
    System.out.println("Tempo total: " + getTempoTotal() + " milisegundos");
    System.out.println("Tempo m�dio por passageiro: " + (tempo/cont) + " milisegundos");
    System.out.println("FINALIZANDO SIMULA��O");
    // Aborta a execu��o.
    System.exit(0);
  }


}