package projetomr1c;

/**
 * Classe que cria a Thread carro.
 */
public class Carro implements Runnable{

  /**
   * Representa o n�mero de lugares ocupados no carro.
   */
  private int lugaresOcupados = 0;

  /**
   * Representa os sem�foros da simula��o.
   */
  protected final Semaforos semaforos;

  /**
   * Representa a montanha-russa.
   */
  private MontanhaRussa montanha;

  /**
   * M�todo construtor da classe.
   */
  public Carro(Semaforos semaforos, MontanhaRussa montanha) {
    this.semaforos = semaforos;
    this.montanha = montanha;
  }

  /**
   * M�todo que retorna a quantidade de lugares ocupados no carro.
   */
  public int getLugaresOcupados() {
    return lugaresOcupados;
  }

  /**
   * M�todo que incrementa a quantidade de lugares ocupados no carro.
   */
  public void incLugaresOcupados() {
    lugaresOcupados++;
  }

  /**
   * M�todo que decrementa a quantidade de lugares ocupados no carro.
   */
  private void decLugaresOcupados() {
    lugaresOcupados--;
  }

  /**
   * M�todo respons�vel por executar a thread carro.
   */
  public void run() {
    while (true) {
      // Pergunta se o carro est� cheio.
      semaforos.passageiros.P();
      System.out.println("Lugares ocupados: " + getLugaresOcupados());
      // Come�a a rodar.
      rodar();
      // Pedido de acesso exclusivo � vari�vel compartilhada.
      semaforos.mutex.P();
      while (getLugaresOcupados() > 0) {
        // Decrementa a quantidade de lugares ocupados.
        decLugaresOcupados();
        // Libera cada passageiro que estava rodando com o carro.
        semaforos.rodando.V();
      }
      for (int i = 1; i <= montanha.NUM_LUGARES; i++) {
        // Libera para que novos passageiros entrem no carro.
        semaforos.carro.V();
      }
      // Libera o acesso exclusivo � vari�vel compartilhada.
      semaforos.mutex.V();
    }
  }

  /**
   * M�todo respon�vel por simular uma volta do carro.
   */
  public void rodar() {
    System.out.println ("Come�ando a rodar");
    // Dorme o tempo estipulado para a volta.
    try { Thread.currentThread().sleep( montanha.TEMPO_VOLTA );
    } catch (InterruptedException ie) { ie.printStackTrace(); }
    System.out.println ("Terminando de rodar");
  }
}