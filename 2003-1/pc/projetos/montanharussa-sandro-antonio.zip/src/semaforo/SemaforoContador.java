package semaforo;

public final class SemaforoContador extends SemaforoBase {

   public SemaforoContador() {
     super();
   }

   public SemaforoContador(int initial) {
      super(initial);
   }
}
