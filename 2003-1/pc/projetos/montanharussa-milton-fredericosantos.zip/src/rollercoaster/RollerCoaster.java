package rollercoaster;

/**
 * <p>Title: Programa��o concorrente: Montanha Russa com um carro</p>
 * <p>Description: Programa que trata o acesso concorrente a um carro de
 * montanha russa por varios passageiros</p>
 * @author Frederico Santos do Vale
 * @author Milton C�sar de Souza Leite
 */

public class RollerCoaster {

  private Semaphores semaphores;
  private Mount mount;
  private static long simulacao;
  private static int n_passengers;
  private static long tempo_volta;
  private static int n_assentos;
  private static long passeando;

 /**
  * Construtor para a instancia��o do aplicativo
  */
  public RollerCoaster() {
    this.semaphores = new Semaphores();
  }

 /*
  * M�todo que dispara a execu��o
  */
  public void executar() {
      mount = new Mount(n_assentos);
      new Thread( new Car( mount, this.semaphores, 1000*tempo_volta,
                           1000*simulacao ), "Carro" ).start();
      new Thread( new CreatePassenger( mount, this.semaphores, n_passengers,
                                       1000*passeando,1000*simulacao ),
                                       "Gerar passageiros" ).start();
  }

 /**
  *M�todo principal
  *
  * @param args
  */
  public static void main(String args[]) {

      char[] a;

      for (int i = 0, l = args.length; i <= (l-2); i+=2) {
         a = args[i].toCharArray();
         switch (a[1]){
           case 'C':
           case 'c': n_assentos = Integer.parseInt(args[i+1]);
                     break;
           case 'T':
           case 't': tempo_volta = Long.parseLong(args[i+1]);
                     break;
           case 'M':
           case 'm': n_passengers = Integer.parseInt(args[i+1]);
                     if (n_assentos >= n_passengers) {
                        n_passengers  = 10;
                        n_assentos = 4;
                        System.out.println("N�mero de passageiros menor que o de assentos!!!");
                        System.out.println("Ser� adotado o default !!");
                     }
                     break;
           case 'W':
           case 'w': passeando = Long.parseLong(args[i+1]);
                     break;
           case 'R':
           case 'r': simulacao = Long.parseLong(args[i+1]);
                      break;
           case '?': System.out.println("Para a correta execu��o do programa, entre com os par�metros:");
                     System.out.println("-C: n�mero de assentos no carro.");
                     System.out.println("-T: tempo para efetuar uma volta.");
                     System.out.println("-M: n�mero de passageiros que desejam mandar no carro.");
                     System.out.println("-W: tempo que os passageiros circulando no parque.");
                     System.out.println("-R: tempo total da simula��o.");
                     System.out.println( "\\?: Ajuda.");
                     System.out.println("OBS: o n�mero passageiros tem que ser maior que o n�mero de assentos!!");
         }
      }
     new RollerCoaster ().executar();
  }
}