package rollercoaster;

/**
 * <p>Title: Programa��o concorrente: Montanha Russa com um carro</p>
 * <p>Description: Programa que trata o acesso concorrente a um carro de
 * montanha russa por varios passageiros</p>
 * @author Frederico Santos do Vale
 * @author Milton C�sar de Souza Leite
 */

/**
 * Classe que instacia os passageiros
 */
public class CreatePassenger implements Runnable {

  protected final Mount mount;
  protected final Semaphores semaphores;
  protected int n_passengers = 10;
  protected long walking;
  protected long simule;
  Thread t[];

 /*
  * Construtor que inicia montanha, Semaforos, passageiros, passeio e simula��o
  *
  * @param mount
  * @param semaphores
  * @param n_passengers
  * @param walking
  * @param simule
  */
  public CreatePassenger( Mount mount, Semaphores semaphores, int n_passengers, long walking,
                          long simule) {
    this.mount = mount;
    this.semaphores = semaphores;
    if (n_passengers > 0)
      this.n_passengers = n_passengers;
    if (walking > 0)
      this.walking = walking;
    if (simule > 0)
      this.simule = simule;
  }

 /**
  * Construtor que recebe n�mero de identifica��o do passageiro e que retorna passageiro
  *
  * @param id
  * @return Passenger
  */
  public Passenger CreatePassenger(int id) {
    return new Passenger( id, mount, semaphores, walking, simule );
  }

 /**
  * M�todo que inst�ncia as threads e coloca-as em estado de pronto
  */
  public void run() {
    t = new Thread[n_passengers];
    for (int cont = 1; cont <= n_passengers; cont++) {
      t[cont-1] = new Thread(CreatePassenger(cont), "Passageiro " + cont);
      t[cont-1].start();
    }
  }
}