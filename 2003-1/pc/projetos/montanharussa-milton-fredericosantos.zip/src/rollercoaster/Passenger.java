package rollercoaster;

/**
 * <p>Title: Programa��o concorrente: Montanha Russa com um carro</p>
 * <p>Description: Programa que trata o acesso concorrente a um carro de
 * montanha russa por varios passageiros</p>
 * @author Frederico Santos do Vale
 * @author Milton C�sar de Souza Leite
 */

public class Passenger implements Runnable {

  protected final int id;
  protected final Mount mount;
  protected final Semaphores semaphores;
  protected long passeando = 5000;
  protected long simulacao = 90000;
  protected boolean ja = true;
  protected boolean dormir = false;

 /**
  * Construtor inicia identifica��o, montanha, Semaforos, passageiros, passeio e simula��o
  *
  * @param id
  * @param mount
  * @param semaphores
  * @param passeando
  * @param Simulacao
  */
  public Passenger( int id, Mount mount, Semaphores semaphores, long passeando,
                    long simulacao ) {
    this.id = id;
    this.mount = mount;
    this.semaphores = semaphores;
    if (passeando > 0)
      this.passeando = passeando;
    if (simulacao > 0)
      this.simulacao = simulacao;
  }

 /**
  * M�todo que coloca as threads em execu��o
  */
  public void run() {
    while (mount.getTempoTotal() < (simulacao/1000)) {
       semaphores.mutex.P();
       if (!Car.rodando){
         if ((mount.getPassengersEsperando() < Mount.n_assentos)&&ja){
            mount.incPassengersEsperando();
            log ("ENTRANDO NO CARRO");
            ja = false;
            semaphores.mutex.V();
            if (mount.getPassengersEsperando() == Mount.n_assentos){
              semaphores.passengers.V();
              semaphores.car.P();
              semaphores.rodando.P();
              Passear();
            }
        }
       }
       semaphores.mutex.V();

     }
  }

  /*
   * M�todo exibe a a��o corrente
   *
   * @param msg
   */
  private void log (String msg) {
    System.out.println("[Passageiro" + id + "]: " + msg + " em " + mount.getTempoTotal() + " s");
  }

 /**
  * M�todo que p�em os passageiros para passear no parque
  */
  protected void Passear() {
    log ("INDO PASSEAR PELO PARQUE");
    long tempo = Math.round( Math.random() * passeando );

    try {
      Thread.currentThread().sleep( tempo );
    } catch (InterruptedException ie) { ie.printStackTrace(); }
    log ("PASSEIO PELO PARQUE ENCERRADO");
    ja = true;
  }
}