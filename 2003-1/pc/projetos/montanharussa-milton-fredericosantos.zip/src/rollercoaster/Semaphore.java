package rollercoaster;

/**
 * <p>Title: Programa��o concorrente: Montanha Russa com um carro</p>
 * <p>Description: Programa que trata o acesso concorrente a um carro de
 * montanha russa por varios passageiros</p>
 * @author Frederico Santos do Vale
 * @author Milton C�sar de Souza Leite
 */

public interface Semaphore {
  void P();
  void V();
}