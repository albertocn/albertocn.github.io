package rollercoaster;

/**
 * <p>Title: Programa��o concorrente: Montanha Russa com um carro</p>
 * <p>Description: Programa que trata o acesso concorrente a um carro de
 * montanha russa por varios passageiros</p>
 * @author Frederico Santos do Vale
 * @author Milton C�sar de Souza Leite
 */

public class Mount {

  public static long inicio = System.currentTimeMillis();
  public static long n_assentos = 4;
  private int passageirosEsperando = 0;

 /**
  * Construtor inicia o n�mero de assentos
  *
  * @param n_assentos
  */
  public Mount( int n_assentos ) {
    if (n_assentos > 0)
      this.n_assentos = n_assentos;
  }

 /**
  * M�todo retorna a quantidade de passageiros na fila
  */

  public int getPassengersEsperando() {
     return passageirosEsperando;
  }

 /**
  * M�todo que decrementa a fila (passageiros dentro do carro)
  */

  public void decPassengersEsperando() {
      passageirosEsperando -= n_assentos;
  }

 /**
  * M�todo que incrementa a fila
  */

  public void incPassengersEsperando() {
      passageirosEsperando++; }

 /**
  * M�todo que retorna tempo de execu��o da simula��o
  */

  public long getTempoTotal() {
    return ((System.currentTimeMillis() - inicio)/1000);
  }

}