package rollercoaster;

/**
 * <p>Title: Programa��o concorrente: Montanha Russa com um carro</p>
 * <p>Description: Programa que trata o acesso concorrente a um carro de
 * montanha russa por varios passageiros</p>
 * @author Frederico Santos do Vale
 * @author Milton C�sar de Souza Leite
 */

public abstract class BaseSemaphore implements Semaphore {

  /** Se valor < 0, abs(valor) � o tamanho da fila de P() */
   protected int valor = 0;

   protected BaseSemaphore() {
     this(0);
   }

   protected BaseSemaphore(int inicial) {
     if (inicial < 0) throw new IllegalArgumentException("inicial < 0");
       valor = inicial;
   }

   public synchronized void P() {
      valor--;
      if (valor < 0) {
         while (true) {
            try {
               wait();
               break;
            } catch (InterruptedException e) {
               System.err.println
                  ("BaseSemaphore.P(): InterruptedException, esperar novamente");
               if (valor >= 0) break;
               else continue;
            }
         }
      }
   }

   public synchronized void V() {
      valor++;
      if (valor <= 0) notify();
   }

   public synchronized int valor() {
      return valor;
   }

   public synchronized String toString() {
      return String.valueOf(valor);
   }
}
