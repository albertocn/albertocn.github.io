package rollercoaster;

/**
 * <p>Title: Programa��o concorrente: Montanha Russa com um carro</p>
 * <p>Description: Programa que trata o acesso concorrente a um carro de
 * montanha russa por varios passageiros</p>
 * @author Frederico Santos do Vale
 * @author Milton C�sar de Souza Leite
 */

public class Car implements Runnable {

  protected final Mount mount;
  protected final Semaphores semaphores;
  protected long laptime = 6000;
  protected long simular = 90000;
  public static boolean rodando = false;


 /**
  * Construtor inicia montanha, Semaforos, tempo de volta e simula��o
  *
  * @param mount
  * @param semaphores
  * @param Tempo_Volta
  * @param Simulacao
  */
  public Car( Mount mount, Semaphores semaphores, long tempo_volta,long simular ) {
    this.mount = mount;
    this.semaphores = semaphores;
    if (tempo_volta > 0)
      this.laptime = tempo_volta;
    if (simular > 0)
      this.simular = simular;
  }

 /**
  * M�todo que coloca o carro em execu��o
  */
  public void run() {
     while (true) {
       if (mount.getTempoTotal() < (simular/1000)){
         log ("Esperando Passageiros");
         semaphores.passengers.P();//Esperando os passageiros ocuparem os assentos
         log ("O carro esta cheio!!");
         semaphores.mutex.P();
         mount.decPassengersEsperando();
         semaphores.car.V();
         semaphores.mutex.V();
         rodar();
         semaphores.rodando.V();
       }
       else
         System.exit(0);
     }
  }

 /**
  * M�todo que representa a volta do carro
  */
  protected void rodar() {
    log ("Come�ando a rodar");
    rodando = false;
    long tempo = Math.round( Math.random() * laptime) + laptime;
    try {
       rodando = true;
       Thread.currentThread().sleep( tempo );
    }
    catch (InterruptedException ie) {
       ie.printStackTrace();
    }
    log ("Terminando de rodar");
    rodando = false;
  }


 /**
  * M�todo exibe a a��o corrente
  *
  * @param msg
  */
  private void log (String msg) {
    System.out.println("[Carro]: " + msg + " em " + mount.getTempoTotal() + " s");
  }
}