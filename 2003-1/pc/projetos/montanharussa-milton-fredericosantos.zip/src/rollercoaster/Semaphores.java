package rollercoaster;

/**
 * <p>Title: Programa��o concorrente: Montanha Russa com um carro</p>
 * <p>Description: Programa que trata o acesso concorrente a um carro de
 * montanha russa por varios passageiros</p>
 * @author Frederico Santos do Vale
 * @author Milton C�sar de Souza Leite
 */

public class Semaphores {

  public final Semaphore mutex;
  public final Semaphore passengers;
  public final Semaphore car;
  public final Semaphore rodando;

  public Semaphores() {
    this.mutex    = criarSemMutex();
    this.passengers = criarSemPassengers();
    this.car = criarSemCar();
    this.rodando = criarSemRodando();
  }

  protected Semaphore criarSemMutex() {
//    return new DebugSemaphore( new BinarySemaphore( 1 ), "MUTEX" );
    return new BinarySemaphore( 1 );
  }
  protected Semaphore criarSemPassengers() {
//    return new DebugSemaphore( new CountingSemaphore( 0 ), "PASSENGERS" );
    return new CountingSemaphore( 0 );
  }
  protected Semaphore criarSemCar() {
//    return new DebugSemaphore( new BinarySemaphore( 0 ), "CAR" );
   return new BinarySemaphore( 0 );
  }
  protected Semaphore criarSemRodando() {
//    return new DebugSemaphore( new BinarySemaphore( 0 ), "RODANDO" );
    return new BinarySemaphore( 0 );
  }
}