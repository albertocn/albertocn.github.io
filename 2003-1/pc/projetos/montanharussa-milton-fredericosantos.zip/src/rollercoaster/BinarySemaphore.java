package rollercoaster;

/**
 * <p>Title: Programa��o concorrente: Montanha Russa com um carro</p>
 * <p>Description: Programa que trata o acesso concorrente a um carro de
 * montanha russa por varios passageiros</p>
 * @author Frederico Santos do Vale
 * @author Milton C�sar de Souza Leite
 */

public final class BinarySemaphore extends BaseSemaphore {

   public BinarySemaphore() {
     super();
   }

   public BinarySemaphore(int inicial) {
      super(inicial);
      if (inicial > 1)
        throw new IllegalArgumentException("inicial>1");
   }

   public BinarySemaphore(boolean inicial) {
      super(inicial ? 1:0);
   }

   public final synchronized void V() {
      super.V();
      if (valor > 1)
        valor = 1;
   }
}
