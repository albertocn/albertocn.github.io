package travessia.fair;

import travessia.*;

/**
 * <p>Descricao: Define as condi��es de corrida com as quais os babuinos ir�o fazer parte
 * na medida que forem solicitando atravessar o desfiladeiro e finalizar sua atravessia.
 * Como neste pacote esta sendo tratado o problema de starvation, novos semaforos foram
 * adicionados para fazer o check se h� babuinos esperando do outro lado quando ainda tem
 * babuinos chagando no mesmo sentido da ponte.</p>
 */

public class Ponte {

 //controla o contador quantPont;
  private SemaforoBinario mutexPonte = new SemaforoBinario(1);
  // identifica quantos Babuinos estao na ponte;
  private int quantPonte = 0;

  //controla o contador quantEspera;
  private SemaforoBinario mutexEspera = new SemaforoBinario(1);
  // identifica quantos Babuinos estao esperando;
  private int quantEspera = 0;

  //controla o contador quantOutroLado;
  private SemaforoBinario mutexQuantOutroLado = new SemaforoBinario(1);
  // identifica quantos Babuinos tem do outro lado esperando
  private int quantOutroLado = 0;

  // identifica quantos Babuinos tem do outro lado esperando
  private char inicio = 'D';

  // controla os babuinos do lado esquerdo;
  private SemaforoBinario semPonteE = new SemaforoBinario(1);
  // controla os babuinos do lado direito;
  private SemaforoBinario semPonteD = new SemaforoBinario(1);
  private SemaforoBinario semEsperaOutroLado = new SemaforoBinario(1);

  /**
    * Inicia a travessia dos babuinos que estao no lado direito.
    * @param baboonDireita objeto Babuino que foi criado no lado direito;
   */
  public void iniciarTravessiaDireita(Direita baboonDireita) {
    baboonDireita.mensagem("chegou no desfiladeiro.");

    // se tem o mesmo sentido da ponte e nao tem ninguem esperando;
    if ((baboonDireita.getInicio() == inicio) && (quantEspera != 0)) {
      mutexQuantOutroLado.P();
      quantOutroLado++; // incrementa a quantidade de babuinos esperando do Outro Lado;
      baboonDireita.log("esperando outro lado (quantOutroLado = " + quantOutroLado + ")");
      mutexQuantOutroLado.V();
      semEsperaOutroLado.P(); // faz os babuinos esquerdos esperarem;
    }

    // testa se o sentido do babuino � diferente do sentido q esta na ponte e testa
    // tambem se h� algum babuinos na ponte;
    if ((baboonDireita.getInicio() != inicio) && (!ponteVazia())) {
      mutexEspera.P();
      quantEspera++; // incrementa o numero de babuinos que ficarao esperando;
      baboonDireita.log("esperando (quantEspera = " + quantEspera + ")");
      mutexEspera.V(); // libera o acesso a variavel quantEspera;
      if (quantEspera == 1) {
        semEsperaOutroLado.P();
      }
      semPonteD.P(); // espera ate que os babuinos do lado esquerdo atravessem
    }
    mutexPonte.P();
    quantPonte++; // incrementa o numero de babuinos na ponte;
    if (quantPonte == 1) { // se o babuino for o primeiro;
      setInicio(baboonDireita.getInicio()); // muda o sentido da ponte;
      semPonteE.P(); // faz com que os babuinos do lado esquerdo esperem;
      baboonDireita.log("novo sentido: DIREITA -> ESQUERDA");
    }
    baboonDireita.log("comecou a atravessar. (quantPonte = " + quantPonte + ")");
    mutexPonte.V(); // libera a variavel quantPont;
  }

  /**
    * Finaliza a travessia dos babuinos que estao no lado direito.
    * @param baboonDireita objeto Babuino que foi criado no lado direito;
   */
  public void finalizarTravessiaDireita(Direita baboonDireita) {
    mutexPonte.P();
    quantPonte--;  // decrementa o numero de babuinos que estao na ponte;
    baboonDireita.log("terminou de atravessar. (quantPonte = " + quantPonte + ")");
    mutexPonte.V(); // libera o acesso a variavel quantPonte;
    if (quantPonte == 0) { // se a ponte estiver vazia, libera os Babuinos do lado esquerdo;
      liberaEsquerda();
      liberaOutroLado();
    }
    baboonDireita.mensagem("suicidou-se!!");
  }

  /**
   * Inicia a travessia dos babuinos que estao no lado esquerdo.
   * @param baboonEsquerda objeto Babuino que foi criado no lado direito;
   */
  public void iniciarTravessiaEsquerda(Esquerda baboonEsquerda) {
    baboonEsquerda.mensagem("chegou no desfiladeiro.");

    // se tem o mesmo sentido da ponte e nao tem ninguem esperando;
    if ((baboonEsquerda.getInicio() == inicio) && (quantEspera != 0)) {
      mutexQuantOutroLado.P();
      quantOutroLado++; // incrementa a quantidade de babuinos esperando do Outro Lado;
      baboonEsquerda.log("esperando outro lado (quantOutroLado= " + quantOutroLado + ")");
      mutexQuantOutroLado.V();
      semEsperaOutroLado.P(); // faz os babuinos esquerdos esperarem;
    }

    // testa se o sentido do babuino � diferente do sentido q esta na ponte e testa
    // tambem se h� algum babuinos na ponte;
    if ((baboonEsquerda.getInicio() != inicio) && (!ponteVazia())) {
      mutexEspera.P();
      quantEspera++; // incrementa o numero de babuinos que ficarao esperando;
      baboonEsquerda.log("esperando (quantEspera= " + quantEspera + ")");
      mutexEspera.V(); // libera o acesso a variavel quantEspera;
      if (quantEspera == 1) {
        semEsperaOutroLado.P();
      }
      semPonteE.P(); // espera ate que os babuinos do lado direito atravessem
    }
    mutexPonte.P();
    quantPonte++; // incrementa o numero de babuinos na ponte;
    if (quantPonte == 1) { // se o babuino for o primeiro;
      setInicio(baboonEsquerda.getInicio()); // muda o sentido da ponte;
      semPonteD.P();
      baboonEsquerda.log("novo sentido: ESQUERDA -> DIREITA");
    }
    baboonEsquerda.log("comecou a atravessar. (quantPonte = " + quantPonte + ")");
    mutexPonte.V(); // libera a variavel quantPont;
  }

  /**
   * Finaliza a travessia dos babuinos que estao no lado esquerdo.
   * @param baboonEsquerda objeto Babuino que foi criado no lado direito;
   */

  public void finalizarTravessiaEsquerda(Esquerda baboonEsquerda) {
    mutexPonte.P();
    quantPonte--; // decrementa o numero de babuinos que estao na ponte;
    baboonEsquerda.log("terminou de atravessar. (quantPonte = " + quantPonte + ")");
    mutexPonte.V(); // libera o acesso a variavel quantPonte;
    if (quantPonte == 0) { // se a ponte estiver vazia, libera os Babuinos do lado esquerdo;
      liberaDireita();
      liberaOutroLado();
    }
    baboonEsquerda.mensagem("suicidou-se!!");
  }

  /**
   * Recupera o valor do sentido da ponte.
   * @return o valor do sentido da ponte;
   */
  public char getInicio() {
    return inicio;
  }

  /**
   * Atribui o lado em que o babuino esta passado por paramentro na variavel inicio.
   * @param inic argumento do tipo char que indentifica o lado que o Babuino esta;
   */
  public void setInicio(char inic) {
    inicio = inic;
  }

  /**
   * Verifica se a ponte esta vazia.
   * @return true se a ponte estiver vazia. Caso contrario, retorna false;
   */
  private boolean ponteVazia() {
    return quantPonte == 0;
  }

  /**
   * Libera todos os babuinos do lado esquerdo que desejam atravessa o desfiladeiro.
   */
  private void liberaEsquerda() {
    mutexEspera.P();
    // libera todos os babuinos que estao esperando.
    for (int i = 0; i <= quantEspera; i++) {
      semPonteE.V();
    }
    quantEspera = 0; // zera a variavel q identifica os babuinos esperando;
    mutexEspera.V();
  }

  /**
   * Libera todos os babuinos do lado direito que desejam atravessa o desfiladeiro.
   */
  private void liberaDireita() {
    mutexEspera.P();
    for (int i = 0; i <= quantEspera; i++) {
      semPonteD.V();
    }
    quantEspera = 0; // zera a variavel q identifica os babuinos esperando;
    mutexEspera.V();
  }

  /**
   * Libera todos os babuinos que estiverem do lado contrario ao sentido da ponte.
   */
  private void liberaOutroLado() {
    mutexQuantOutroLado.P();
    for (int i = 0; i <= quantOutroLado; i++) {
      semEsperaOutroLado.V();
    }
    quantOutroLado = 0; // zera a variavel q identifica os babuinos esperando outro lado;
    mutexQuantOutroLado.V();
  }

}