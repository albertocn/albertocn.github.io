package travessia;

/**
 *
 * <p>Titulo: Babuinos atravssando o desfiladeiro</p>
 * <p>Descricao: Projeto de Programacao Concorrente - Interface Semaforo</p>
 * <p>Grupo: Jose Augusto e Edvanessa Florencio</p>
 * <p>Disciplina: Programacao Concorrente - 2003/1</p>
 * @author Augusto & Nessa
 * @version 1.0
 */
public interface Semaforo {
  void P();
  void V();
}