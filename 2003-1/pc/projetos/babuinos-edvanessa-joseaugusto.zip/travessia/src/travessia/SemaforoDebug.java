package travessia;

/**
 *
 * <p>Titulo: Babuinos atravssando o desfiladeiro</p>
 * <p>Descricao: Projeto de Programacao Concorrente - Declara��o Semaforo Debug</p>
 * <p>Grupo: Jose Augusto e Edvanessa Florencio</p>
 * <p>Disciplina: Programacao Concorrente - 2003/1</p>
 * @author Augusto & Nessa
 * @version 1.0
 */
public class SemaforoDebug implements Semaforo {

  private final Semaforo sem;
  private final String nome;

  public SemaforoDebug( Semaforo sem, String nome ) {
    this.sem = sem;
    this.nome = nome;
  }
  public void P() {
    System.out.println("[" + getNomeThread() + "] ANTES de P sobre " + getNome());
    sem.P();
    System.out.println("[" + getNomeThread() + "] DEPOIS de P sobre " + getNome());
  }
  public void V() {
    System.out.println("[" + getNomeThread() + "] ANTES de V sobre " + getNome());
    sem.V();
    System.out.println("[" + getNomeThread() + "] DEPOIS de V sobre " + getNome());
  }

  public String getNome() {
    return this.nome;
  }

  public String getNomeThread() {
    return Thread.currentThread().getName();
  }

}