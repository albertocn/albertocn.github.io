package travessia;

/**
 *
 * <p>Titulo: Babuinos atravssando o desfiladeiro</p>
 * <p>Descricao: Projeto de Programacao Concorrente - Declara��o do Semaforo Binario</p>
 * <p>Grupo: Jose Augusto e Edvanessa Florencio</p>
 * <p>Disciplina: Programacao Concorrente - 2003/1</p>
 * @author Augusto & Nessa
 * @version 1.0
 */
public final class SemaforoBinario extends SemaforoBase {

   public SemaforoBinario() {
     super();
   }

   public SemaforoBinario(int inicial) {
      super(inicial);
      if (inicial > 1)
        throw new IllegalArgumentException("inicial>1");
   }

   public SemaforoBinario(boolean inicial) {
      super(inicial ? 1:0);
   }

   public final synchronized void V() {
      super.V();
      if (valor > 1)
        valor = 1;
   }
}
