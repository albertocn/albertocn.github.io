package travessia.starvation;

/**
 * <p>Descricao: Instancia Threads que representar�o os Babuinos do lado direito.
 * Cria os babuinos do lado direito do desfiladeiro.</p>
 */
public class GeraBabuinosD implements Runnable{

  private int contD = 0;  // contador que servira para identicar os Babuinos criadas;
  private Ponte ponte;

  /**
   * O construtor pede como argumento um objeto do tipo Ponte
   * @param ponte objeto do tipo Ponte
   */
  public GeraBabuinosD(Ponte ponte) {
    this.ponte = ponte;
    new Thread(this).start();
  }

  /**
   * Metodo run � implementa��o da interface Runnable.
   */
  public void run() {
    while (true) {
      contD++; // incrementa o contador que identifica os Babuinos;
      new Direita( contD, ponte ); // Cria Babuinos do lado direito passando
                                   // sua identifica��o e um objeto;
      try {
        Thread.currentThread().sleep( tempoAleatorio(500) ); // Dormira apos ser
                                                             // criado um babuino;
      } catch (InterruptedException ie) {
        ie.printStackTrace();
      }
    }
  }

  /**
   * Calcula o tempo que o Babuino ira dormir apor ser criado.
   * @param max intervalo maximo de tempo em que o Babuino dormi ap�s ser criado;
   * @return sera retornado um valor aleatorio com limite maximo de acordo com max
   */
  public long tempoAleatorio( long max ) {
    return Math.round( Math.random() * max );
  }
}
