package travessia.starvation;

/**
 * <p>Titulo: Babuinos atravssando o desfiladeiro</p>
 * <p>Descricao: Projeto de Programacao Concorrente - Babuinos atravessando o
 * desfiladeiro.
 * Este programa tem a finalidade de controlar a passagem de babuinos atraves de
 * uma corda, a qual suporta mais de um babuino se estiverem indu no mesmo
 * sentido. Caso contrario, deve-se esperar a corda ficar vazia para entao iniciar
 * a travessia. Esta solu��o funciona, porem com a ocorrencia de starvation na
 * presen�a de conten��o</p>
 * <p>Grupo: Jose Augusto e Edvanessa Florencio</p>
 * <p>Professor: Alberto Costa Neto</p>
 * <p>Disciplina: Programacao Concorrente - 2003/1</p>
 * @author Augusto & Nessa
 * @version 1.0
 */


public class Exemplo {
/** <p>Instancia objeto do tipo Ponte, GeraBabuinosD e GeraBabuinosE </p>
 */

  public Exemplo() {
    Ponte ponte = new Ponte();
    GeraBabuinosD geraBabuinosD = new GeraBabuinosD( ponte );
    GeraBabuinosE geraBabuinosE = new GeraBabuinosE( ponte );
  }


  public static void main(String[] args) {
    new Exemplo();
  }
}