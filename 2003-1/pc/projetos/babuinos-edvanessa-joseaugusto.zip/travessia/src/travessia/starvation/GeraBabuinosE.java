package travessia.starvation;

/**
 * <p>Descricao: Instancia Threads que representar�o os Babuinos do lado esquerdo.
 * Cria os babuinos do lado esquerdo do desfiladeiro.</p>
 */
public class GeraBabuinosE implements Runnable{

  private int contE = 0; // contador que servira para identicar os Babuinos criadas;
  private Ponte ponte;

  /**
   * O construtor pede como argumento um objeto do tipo Ponte
   * @param ponte objeto do tipo Ponte
   */
  public GeraBabuinosE(Ponte ponte) {
    this.ponte = ponte;
    new Thread(this).start();
  }

  /**
    * Metodo run � implementa��o da interface Runnable.
   */
  public void run() {
    while (true) {
      contE++; // incrementa o contador que identifica os Babuinos;
      new Esquerda( contE, ponte ); // Cria Babuinos do lado esquerdo passando
                                    // sua identifica��o e um objeto;
      try {
        Thread.currentThread().sleep( tempoAleatorio(1500) ); // Dormira apos ser
                                                              // criado um babuino;
      } catch (InterruptedException ie) {
        ie.printStackTrace();
      }
    }
  }

  /**
    * Calcula o tempo que o Babuino ira dormir apor ser criado.
    * @param max intervalo maximo de tempo em que o Babuino dormi ap�s ser criado;
    * @return sera retornado um valor aleatorio com limite maximo de acordo com max
   */
  public long tempoAleatorio( long max ) {
    return Math.round( Math.random() * max );
  }

}
