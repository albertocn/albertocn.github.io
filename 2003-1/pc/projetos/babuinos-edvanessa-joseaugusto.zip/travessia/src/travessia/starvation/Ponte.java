package travessia.starvation;

import travessia.*;

/**
 * <p>Descricao: Define as condi��es de corrida com as quais os babuinos ir�o fazer parte
 * na medida que forem solicitando atravessar o desfiladeiro e finalizar sua atravessia.</p>
 */
public class Ponte {

  //controla o contador quantPont;
  private SemaforoBinario mutexPonte = new SemaforoBinario(1);
  // identifica quantos Babuinos estao na ponte;
  private int quantPonte = 0;

  //controla o contador quantEspera;
  private SemaforoBinario mutexEspera = new SemaforoBinario(1);
  // identifica quantos Babuinos estao esperando;
  private int quantEspera = 0;

  // identifica o sentido em que esta a ponte;
  private char inicio = 'D';

  // controla os babuinos do lado esquerdo;
  private SemaforoBinario mutexE = new SemaforoBinario(1);
  // controla os babuinos do lado direito;
  private SemaforoBinario mutexD = new SemaforoBinario(1);

  /**
   * Inicia a travessia dos babuinos que estao no lado direito.
   * @param baboonDireita objeto Babuino que foi criado no lado direito;
   */
  public void iniciarTravessiaDireita(Direita baboonDireita) {
    baboonDireita.mensagem("chegou no desfiladeiro.");

    // testa se o sentido do babuino � diferente do sentido q esta na ponte e testa
    // tambem se h� algum babuinos na ponte;
    if ((baboonDireita.getInicio() != inicio) && (!ponteVazia())) {
      mutexEspera.P();
      quantEspera++;   // incrementa o numero de babuinos que ficarao esperando;
      baboonDireita.log("esperando (" + quantEspera + ")");
      mutexEspera.V(); // libera o acesso a variavel quantEspera;
      mutexD.P(); // espera ate que os babuinos do lado esquerdo atravessem
    }
    mutexPonte.P();
    quantPonte++; // incrementa o numero de babuinos na ponte;
    if (quantPonte == 1) { // se o babuino for o primeiro;
      setInicio(baboonDireita.getInicio()); // muda o sentido da ponte;
      mutexE.P(); // faz com que os babuinos do lado esquerdo esperem;
      baboonDireita.log("novo sentido: DIREITA -> ESQUERDA");
    }
    baboonDireita.log("comecou a atravessar. (quantPonte = " + quantPonte + ")");
    mutexPonte.V(); // libera a variavel quantPont;
  }

  /**
   * Finaliza a travessia dos babuinos que estao no lado direito.
   * @param baboonDireita objeto Babuino que foi criado no lado direito;
   */
  public void finalizarTravessiaDireita(Direita baboonDireita) {
    mutexPonte.P();
    quantPonte--; // decrementa o numero de babuinos que estao na ponte;
    baboonDireita.log("terminou de atravessar. (quantPonte = " + quantPonte + ")");
    mutexPonte.V(); // libera o acesso a variavel quantPonte;
    if (quantPonte == 0) { // se a ponte estiver vazia, libera os Babuinos do lado esquerdo;
      liberaEsquerda();
    }
    baboonDireita.mensagem("suicidou-se!!");
  }
  /**
   * Inicia a travessia dos babuinos que estao no lado esquerdo.
   * @param baboonDireita objeto Babuino que foi criado no lado esquerdo;
   */
  public void iniciarTravessiaEsquerda(Esquerda baboonEsquerda) {
    baboonEsquerda.mensagem("chegou no desfiladeiro.");

    // testa se o sentido do babuino � diferente do sentido q esta na ponte e testa
    // tambem se h� algum babuinos na ponte;
    if ((baboonEsquerda.getInicio() != inicio) && (!ponteVazia())) {
      mutexEspera.P();
      quantEspera++; // incrementa o numero de babuinos que ficarao esperando;
      baboonEsquerda.log("esperando (" + quantEspera + ")");
      mutexEspera.V(); // libera o acesso a variavel quantEspera;
      mutexE.P(); // espera ate que os babuinos do lado direito atravessem
    }
    mutexPonte.P();
    quantPonte++; // incrementa o numero de babuinos na ponte;
    if (quantPonte == 1) { // se o babuino for o primeiro;
      setInicio(baboonEsquerda.getInicio()); // muda o sentido da ponte;
      mutexD.P(); // faz com que os babuinos do lado direito esperem;
      baboonEsquerda.log("novo sentido: ESQUERDA -> DIREITA");
    }
    baboonEsquerda.log("comecou a atravessar. (quantPonte = " + quantPonte + ")");
    mutexPonte.V(); // libera a variavel quantPont;
  }

  /**
   * Finaliza a travessia dos babuinos que estao no lado direito.
   * @param baboonDireita objeto Babuino que foi criado no lado direito;
   */
  public void finalizarTravessiaEsquerda(Esquerda baboonEsquerda) {
    mutexPonte.P();
    quantPonte--; // decrementa o numero de babuinos que estao na ponte;
    baboonEsquerda.log("terminou de atravessar. (quantPonte = " + quantPonte + ")");
    mutexPonte.V(); // libera o acesso a variavel quantPonte;
    if (quantPonte == 0) { // se a ponte estiver vazia, libera os Babuinos do lado direito;
      liberaDireita();
    }
    baboonEsquerda.mensagem("suicidou-se!!");
  }

  /**
   * Recupera o valor do sentido da ponte.
   * @return o valor do sentido da ponte;
   */
  public char getInicio() {
    return inicio;
  }

  /**
   * Atribui o lado em que o babuino esta passado por paramentro na variavel inicio.
   * @param inic argumento do tipo char que indentifica o lado que o Babuino esta;
   */
  public void setInicio(char inic) {
    inicio = inic;
  }

  /**
   * Verifica se a ponte esta vazia.
   * @return true se a ponte estiver vazia. Caso contrario, retorna false;
   */
  private boolean ponteVazia() {
    return quantPonte == 0;
  }

  /**
   * Libera todos os babuinos do lado esquerdo que desejam atravessa o desfiladeiro.
   */
  private void liberaEsquerda() {
    mutexEspera.P();
    for (int i = 0; i <= quantEspera; i++) { // para todos os babuinos que estao esperando..
      mutexE.V();
    }
    quantEspera = 0; // zera a variavel q identifica os babuinos esperando;
    mutexEspera.V();
  }

  /**
   * Libera todos os babuinos do lado direito que desejam atravessa o desfiladeiro.
   */
  private void liberaDireita() {
    mutexEspera.P();
    for (int i = 0; i <= quantEspera; i++) { // para todos os babuinos que estao esperando..
      mutexD.V();
    }
    quantEspera = 0; // zera a variavel q identifica os babuinos esperando;
    mutexEspera.V();
  }

}