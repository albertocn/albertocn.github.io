package travessia.starvation;

/**
 * <p>Descricao: Esta classe instancia novas Threds atraves da classe GeraBabuinosE.
 * As novas Threads criadas a partir dessa classe ser�o os babuinos do lado esquerdo
 * a concorrenrem a atravessia do desfiladeiro.</p>
 */
public class Esquerda implements Runnable {

  private int id;      // atributo que contem a identifica��o da Thread;
  private char inic;   // atributo que contem o lado inicial que a Thread esta;
  private Ponte ponte;

  /**
   * O construtor pede como argumentos um valor inteiro, que � o identificador da
   * Thread, e um objeto do tipo Ponte.</p>
   * @param id valor inteiro que identifica a Thread;
   * @param ponte objeto do tipo Ponte;
   */
  public Esquerda(int id, Ponte ponte ) {
    this.id = id;
    this.inic = 'E';
    this.ponte = ponte;
    new Thread(this).start();
  }

  /**
   * Metodo run � implementa��o da interface Runnable.
   */
  public void run() {
    ponte.iniciarTravessiaEsquerda(this);// o babuino (Thread) solicita um pedido
                                         // para atravessar o desfiladeiro;
    atravessar(1500); // Pedido aceito, Babuino atravessando;
    ponte.finalizarTravessiaEsquerda(this); // acabou de atravessar o desfiladeiro;
  }

  /**
    * Exibe mensagens de notifica��o das a��es do Babuino.
    * @param msg mensagem a ser dada na notifica��o;
   */
  public void log ( String msg ) {
    System.out.println("[Babuino E-" + id + "]: " + msg );
  }

  /**
   * Exibe mensagens de notifica��o das a��es do Babuino (em vermelho).
   * @param msg mensagem a ser dada na notifica��o;
   */
  public void mensagem( String msg ) {
    System.err.println("[Babuino E-" + id + "]: " + msg );
  }

  /**
   * Recupera o valor do atrbuto inic que armazena o lado em que o Babuino esta.
   * @return lado em que o Babuino est�
   */
  public char getInicio() {
    return inic;
  }

  /**
   * Identifica o tempo que o babuino ira levar para atravessar o desfiladeiro.
   * @param max intervalo maximo de tempo o qual o babuino ira atravessar;
   */
  private void atravessar (long max) {
    long tempo = Math.round( Math.random() * max );
    log( "atravessando (duracao = " + tempo + " ms)" );
    try {
      Thread.currentThread().sleep( tempo );
    } catch (InterruptedException ie) {
      ie.printStackTrace();
    }
  }

}