package Servidor;

import java.rmi.*;
import java.rmi.registry.*;
import java.rmi.server.*;
import Cliente.*;
import java.net.*;
import java.util.*;

/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: Aplica�ao servidor para o jogo Four-of-a-Kind Game</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: DCCE/UFS</p>
 * @author Jose Marcio A. Bezerra
 * @version 1.0
 */

public class ServidorAplicacao extends UnicastRemoteObject
    implements ServidorInterface{

  /**
   * Baralho a ser utilizado pelo jogo.
   */
  public static String[] baralho = {"A1","A2","A3","A4","B1","B2","B3","B4",
      "C1","C2","C3","C4","D1","D2","D3","D4","E1","E2","E3","E4","F1","F2",
      "F3","F4"};

  private ClienteInterfaceRemota[] jogadores = new ClienteInterfaceRemota[4];
  private int jogadoresCont = 0;
  private Registry sr = null;
  private boolean ServidorIniciado = false;
  private boolean JogoIniciado = false;
  private String[] BaralhoEmbaralhado = new String[baralho.length];
  private String[][] pilhas = new String[4][3];
  private String[][] CartasJogadores = new String[4][4];
  private boolean[] CartasDistribuidas = new boolean[4];
  private int JogadorAtual = -1;

  /**Cria uma nova inst�ncia do servidor.
   *
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public ServidorAplicacao() throws RemoteException{
    super();
  }

  /**Inicia o servidor.
   *
   * @return true se o servidor foi iniciado com sucesso, sen�o
   * retorna false.
   */
  public synchronized boolean iniciarServidor(){
    try{
      if (!ServidorIniciado) {
        //inicializa os jogadores com null
        jogadores[0] = null;
        jogadores[1] = null;
        jogadores[2] = null;
        jogadores[3] = null;
        //inicializa o servidor RMIRegistry
        if (sr==null){
          this.sr = LocateRegistry.createRegistry(1099);
        }
        //registra as inst�ncia no servidor no RMIRegistry
        sr.rebind("ServidorJogo", this);
        ServidorIniciado = true;
      }
      return true;
    }catch (Exception e){
      ServidorIniciado = false;
      return false;
    }
  }

  /**
   * Finaliza o servidor.
   */
  public synchronized void encerrarServidor(){
    //registra as inst�ncia no servidor no RMIRegistry
    try {
      sr.unbind("ServidorJogo");
    }
    catch (Exception e) {
    }
    for (int k=0;k<4;k++){
      if (jogadores[k] != null) {
        try {
          jogadores[k].finalizarAplicacao(
              "O servidor terminou inesperadamente a conex�o.");
        }
        catch (RemoteException ex) {
        }
      }
    }
    jogadoresCont=0;
    ServidorIniciado = false;
  }

  /**informa se o servidor est� iniciado e pronto para receber jogadores.
   *
   * @return true se o servidor estive iniciado.
   */
  public synchronized boolean isIniciado(){
      return ServidorIniciado;
  }

  /**Sinaliza a entrada do jogador.
   *
   * @param cliente Refer�ncia para a interface de comunica��o
   * remota do jogador.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public synchronized int registrarJogador(ClienteInterfaceRemota cliente)
      throws RemoteException{
    int i = -1;
    if (jogadoresCont < 4){
      jogadoresCont++;
      if (jogadores[0]==null){
        jogadores[0]=cliente;
        i=0;
      } else if (jogadores[1]==null){
        jogadores[1]=cliente;
        i=1;
      } else if (jogadores[2]==null){
        jogadores[2]=cliente;
        i=2;
      } else if (jogadores[3]==null){
        jogadores[3]=cliente;
        i=3;
      }
      if (jogadoresCont == 4){
        iniciarJogo();
      }else{
        setStatus("Faltam "+(4-jogadoresCont)+" jogadores.");
      }
    }
    return i;
  }

  /**Sinaliza a sa�da do jogador.
   *
   * @param i ID do jogador.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public synchronized void retirarJogador(int i) throws RemoteException{
    if (!JogoIniciado){
      jogadores[i] = null;
      jogadoresCont--;
      if (jogadoresCont<0){jogadoresCont=0;}
      setStatus("Faltam " + (4 - jogadoresCont) + " jogadores.");
    } else {
      JogoIniciado = false;
      for (int k=0;k<4;k++){
        if (jogadores[k] != null) {
          try {
            jogadores[k].finalizarPartida("Um jogador desistiu do jogo.");
          }
          catch (RemoteException ex) {
          }
        }
      }
      jogadores[0] = null;
      jogadores[1] = null;
      jogadores[2] = null;
      jogadores[3] = null;
      jogadoresCont=0;
    }
  }

  /**Jogador libera uma carta para a pilha.
   *
   * @param i ID do Jogador.
   * @param carta Carta a liberar.
   * @throws RemoteException Se n�o puder executar este m�todo.
   *    */
  public synchronized void descartar(int i, String carta) throws RemoteException{
    //se o jogo n�o foi iniciado ele desconcidera
    if (!JogoIniciado){
      return;
    }
    //se n�o � a vez dele jogar, ele desconsidera
    if (JogadorAtual!=i){
      return;
    }
    //coloca a carta na pilha
    removerCartaDoJogador(i, carta);
    colocarNaPilha(i, carta);
    //passa vez para o outro jogador e acorda as outras aplica�oes clientes
    JogadorAtual++;
    if (JogadorAtual>3){
      JogadorAtual=0;
    }
    setStatus("Jogador "+(JogadorAtual+1)+" est� jogando...");
    jogadores[JogadorAtual].darCartas(enviarCartas(JogadorAtual));
    //verifica se o jogador ganhou
    if (!verificarVitoria(JogadorAtual)){
      return;
    }
    //se o jogador ganhou os outros cliente s�o informados
    for (int k=0;k<4;k++){
      if (jogadores[k] != null) {
        try {
          jogadores[k].finalizarPartida("O jogador "+(JogadorAtual+1)+
                                        " ganhou o jogo.");
        }
        catch (RemoteException ex) {
        }
        jogadores[k] = null;
      }
    }
    //partida finalizada
    JogadorAtual=-1;
    jogadoresCont=0;
    JogoIniciado = false;
  }

  /**Informa se o jogador ganhou o jogo.
   *
   * @param i Id do jogador.
   * @return true se o jogador ganhou o jogo.
   */
  private boolean verificarVitoria(int i){
    return CartasJogadores[i][0].charAt(0)==CartasJogadores[i][1].charAt(0) &&
        CartasJogadores[i][1].charAt(0)==CartasJogadores[i][2].charAt(0) &&
        CartasJogadores[i][2].charAt(0)==CartasJogadores[i][3].charAt(0);
  }
  /**Envia uma carta ao jogador.
   *
   * @param i ID do jogador.
   * @return Cartas a serem enviadas.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  private String[] enviarCartas(int i){
    //verifica se as cartas iniciais ja foram distribuidas
    if (!CartasDistribuidas[i]){
      CartasDistribuidas[i] = true;
      return CartasJogadores[i];
    }
    //define a pilha para a retirada da carta
    int k = i;
    k--;
    if (k<0){
      k=3;
    }
    //retira as cartas da pilha e entrega ao usu�rio
    String c = retirarDaPilha(i);
    adicionarCartaAoJogador(i, c);
    return CartasJogadores[i];
  }

  /**
   * Inicia o jogo.
   */
  private void iniciarJogo(){
    JogoIniciado = true;
    //informa que as cartas iniciais n�o foram distribuidas
    CartasDistribuidas[0]=false;
    CartasDistribuidas[1]=false;
    CartasDistribuidas[2]=false;
    CartasDistribuidas[3]=false;
    JogadorAtual = 0;
    //embaralha as cartas e distribui por jogador
    BaralhoEmbaralhado = embaralhar(baralho);
    distribuirCartas();
    //informa inicio do jogo acordando as aplica�oes cliente
    setStatus("Jogador "+(JogadorAtual+1)+" est� jogando...");
    try {
      jogadores[JogadorAtual].darCartas(enviarCartas(JogadorAtual));
    }
    catch (RemoteException ex) {
    }
  }

  /**Enviar uma mensagem a todos os jogadores.
   *
   * @param s Mensagem a enviar
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  private void setStatus(String s){
    if (jogadores[0]!=null){
      try {
        jogadores[0].setStatus(s);
      }
      catch (RemoteException ex) {
      }
    }
    if (jogadores[1]!=null){
      try {
        jogadores[1].setStatus(s);
      }
      catch (RemoteException ex) {
      }
    }
    if (jogadores[2]!=null){
      try {
        jogadores[2].setStatus(s);
      }
      catch (RemoteException ex) {
      }
    }
    if (jogadores[3]!=null){
      try {
        jogadores[3].setStatus(s);
      }
      catch (RemoteException ex) {
      }
    }
  }

  /**Remove carta da pilha.
   *
   * @param i ID do jogador.
   * @return Carta retirada da pilha.
   */
  private String retirarDaPilha(int i){
    i--;
    if (i<0){
      i=3;
    }
    Random rgen = new Random();
    int j = rgen.nextInt(3);
    String c = pilhas[i][j];
    pilhas[i][j] = "";
    for (int k=j;k<2;k++){
      pilhas[i][k] = pilhas[i][k+1];
      pilhas[i][k+1] = "";
    }
    return c;
  }

  /**Adiciona carta na pilha.
   *
   * @param i ID do jogador.
   * @param c Carta a adicionar.
   */
  private void colocarNaPilha(int i, String c){
    pilhas[i][2] = c;
  }

  /**Remove carta do jogador.
   *
   * @param i ID do jogador.
   * @param c Carta a adicionar.
   */
  private void removerCartaDoJogador(int i, String c){
    for (int j=0;j<4;j++){
      if (CartasJogadores[i][j].equalsIgnoreCase(c)){
        CartasJogadores[i][j] = "";
        for (int k=j;k<3;k++){
          CartasJogadores[i][k] = CartasJogadores[i][k+1];
          CartasJogadores[i][k+1] = "";
        }
        break;
      }
    }
  }

  /**Adiciona uma nova carta para um jogador
   *
   * @param i ID do jogador.
   * @param c Carta a adicionar.
   */
  private void adicionarCartaAoJogador(int i, String c){
    CartasJogadores[i][3] = c;
  }

  /**
   * Distribui as cartas do baralho entre os jogadores e as pilhas
   */
  private void distribuirCartas(){
    for (int i=0;i<4;i++){
      CartasJogadores[0][i] = BaralhoEmbaralhado[i];
      CartasJogadores[1][i] = BaralhoEmbaralhado[i+4];
      CartasJogadores[2][i] = BaralhoEmbaralhado[i+8];
      CartasJogadores[3][i] = BaralhoEmbaralhado[i+12];
      if (i<2){
        pilhas[0][i] = BaralhoEmbaralhado[i+16];
        pilhas[1][i] = BaralhoEmbaralhado[i+18];
        pilhas[2][i] = BaralhoEmbaralhado[i+20];
        pilhas[3][i] = BaralhoEmbaralhado[i+22];
      }
    }
    pilhas[0][2] = "";
    pilhas[1][2] = "";
    pilhas[2][2] = "";
    pilhas[3][2] = "";
  }

  /**Mistura as cartas de um baralho
   *
   * @param s Baralho para misturar.
   * @return Baralho com as carats misturadas.
   */
  private String[] embaralhar(String[] s){
    List v = new Vector();
    int tam = s.length;
    int i,j;
    if (tam==1){
      v.add(s[0]);
      return (String[]) v.toArray();
    }else if (tam<1){
      return (String[]) v.toArray();
    }
    List b = new Vector();
    for (i=0; i < tam; i++){
      b.add(s[i]);
    }
    Random rgen = new Random();
    for (i=0; i < tam-1; i++){
      j = (int) ((tam - i) * rgen.nextFloat());
      if (j >= (tam - i)){
        j = tam - i -1;
      }
      v.add(b.get(j));
      b.remove(j);
    }
    v.add(b.get(0));
    String[] k = new String[v.size()];
    for(i=0;i<v.size();i++){
      k[i] = (String) v.get(i);
    }
    return k;
  }

}