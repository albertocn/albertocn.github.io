package Servidor;

import java.rmi.Remote;
import java.rmi.RemoteException;
import Cliente.*;

/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: Interface para comunica�ao com o servidor.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: DCCE/UFS</p>
 * @author Jose Marcio A. Bezerra
 * @version 1.0
 */

public interface ServidorInterface extends Remote{
  int  registrarJogador(ClienteInterfaceRemota cliente) throws RemoteException;
  void retirarJogador(int i) throws RemoteException;
  void descartar(int i, String carta) throws RemoteException;
}
