package ui;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.event.*;
import java.text.*;

/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: DCCE/UFS</p>
 * @author Jose Marcio A. Bezerra
 * @version 1.0
 */

public class TelaInicial extends JPanel {
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel PainelSuperior = new JPanel();
  private JPanel PainelCentral = new JPanel();
  private JLabel jLabel1 = new JLabel();
  private FlowLayout flowLayout1 = new FlowLayout();
  private JPanel PainelOpcoes = new JPanel();
  private Border border1;
  private JRadioButton radio1 = new JRadioButton();
  private JRadioButton radio2 = new JRadioButton();
  private JRadioButton radio3 = new JRadioButton();
  private GridLayout gridLayout2 = new GridLayout();
  private JLabel labBranco2 = new JLabel();
  private BorderLayout borderLayout2 = new BorderLayout();
  private JLabel labBranco1 = new JLabel();
  private JLabel labHost = new JLabel();
  private JLabel labBranco3 = new JLabel();
  private JLabel labPorta = new JLabel();
  private ButtonGroup Grupo = new ButtonGroup();
  private JPanel PainelInferior = new JPanel();
  private JButton btnIniciar = new JButton();
  private DecimalFormat formato1 = new DecimalFormat("#;#");
  private JFormattedTextField txtPorta = new JFormattedTextField(formato1);
  private JFormattedTextField txtHost = new JFormattedTextField();

  public TelaInicial() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    border1 = new TitledBorder(BorderFactory.createLineBorder(Color.black,1),"Selecione a op�ao desejada");
    this.setDebugGraphicsOptions(0);
    this.setPreferredSize(new Dimension(310, 290));
    this.setLayout(borderLayout1);
    PainelSuperior.setDebugGraphicsOptions(0);
    PainelSuperior.setPreferredSize(new Dimension(10, 30));
    PainelSuperior.setLayout(borderLayout2);
    jLabel1.setIconTextGap(4);
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 14));
    jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel1.setHorizontalTextPosition(SwingConstants.LEADING);
    jLabel1.setText("Selecione a op�ao desejada:");
    PainelCentral.setLayout(flowLayout1);
    PainelOpcoes.setEnabled(true);
    PainelOpcoes.setForeground(Color.black);
    PainelOpcoes.setBorder(null);
    PainelOpcoes.setDebugGraphicsOptions(0);
    PainelOpcoes.setPreferredSize(new Dimension(330, 150));
    PainelOpcoes.setLayout(gridLayout2);
    radio1.setFont(new java.awt.Font("Dialog", 0, 12));
    radio1.setSelected(true);
    radio1.setText("Servidor Local dedicado");
    radio1.addActionListener(new TelaInicial_radio1_actionAdapter(this));
    radio2.setFont(new java.awt.Font("Dialog", 0, 12));
    radio2.setText("Servidor Local + Cliente");
    radio2.addActionListener(new TelaInicial_radio2_actionAdapter(this));
    radio3.setFont(new java.awt.Font("Dialog", 0, 12));
    radio3.setText("Cliente");
    radio3.addActionListener(new TelaInicial_radio3_actionAdapter(this));
    gridLayout2.setColumns(2);
    gridLayout2.setRows(0);
    labHost.setFont(new java.awt.Font("Dialog", 0, 12));
    labHost.setHorizontalAlignment(SwingConstants.RIGHT);
    labHost.setText("Servidor:    ");
    labPorta.setFont(new java.awt.Font("Dialog", 0, 12));
    labPorta.setRequestFocusEnabled(true);
    labPorta.setHorizontalAlignment(SwingConstants.RIGHT);
    labPorta.setText("Porta:         ");
    labBranco3.setText("");
    labBranco1.setText("");
    labBranco2.setText("");
    PainelCentral.setPreferredSize(new Dimension(310, 210));
    PainelInferior.setPreferredSize(new Dimension(10, 50));
    btnIniciar.setText("Iniciar");
    txtPorta.setEnabled(false);
    txtHost.setEnabled(false);
    txtHost.setText("");
    this.add(PainelSuperior,  BorderLayout.NORTH);
    PainelSuperior.add(jLabel1, BorderLayout.CENTER);
    this.add(PainelCentral, BorderLayout.CENTER);
    this.add(PainelInferior, BorderLayout.SOUTH);
    PainelCentral.add(PainelOpcoes, null);
    PainelOpcoes.add(radio1, null);
    PainelOpcoes.add(labBranco1, null);
    PainelOpcoes.add(radio2, null);
    PainelOpcoes.add(labBranco2, null);
    PainelOpcoes.add(radio3, null);
    PainelOpcoes.add(labBranco3, null);
    PainelOpcoes.add(labHost, null);
    PainelOpcoes.add(txtHost, null);
    PainelOpcoes.add(labPorta, null);
    PainelOpcoes.add(txtPorta, null);
    Grupo.add(radio1);
    Grupo.add(radio2);
    Grupo.add(radio3);
    PainelInferior.add(btnIniciar, null);
  }

  void radio3_actionPerformed(ActionEvent e) {
    txtHost.setEnabled(true);
    txtHost.setText("localhost");
    txtPorta.setEnabled(false);
    txtPorta.setText("1099");
  }

  void radio1_actionPerformed(ActionEvent e) {
    txtHost.setEnabled(false);
    txtHost.setText("");
    txtPorta.setEnabled(false);
    txtPorta.setText("");
  }

  void radio2_actionPerformed(ActionEvent e) {
    txtHost.setEnabled(false);
    txtHost.setText("");
    txtPorta.setEnabled(false);
    txtPorta.setText("");
  }

  public void setBtnIniciarEvent(ActionListener a){
    btnIniciar.addActionListener(a);
  }

  public int getOpcao(){
    if (radio3.isSelected()){
      return 3;
    }else  if (radio2.isSelected()){
      return 2;
    }else{
      return 1;
    }
  }

  public String getHost(){
    return txtHost.getText();
  }

  public String getPorta(){
    return txtPorta.getText();
  }

}

class TelaInicial_radio3_actionAdapter implements java.awt.event.ActionListener {
  TelaInicial adaptee;

  TelaInicial_radio3_actionAdapter(TelaInicial adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.radio3_actionPerformed(e);
  }
}

class TelaInicial_radio1_actionAdapter implements java.awt.event.ActionListener {
  TelaInicial adaptee;

  TelaInicial_radio1_actionAdapter(TelaInicial adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.radio1_actionPerformed(e);
  }
}

class TelaInicial_radio2_actionAdapter implements java.awt.event.ActionListener {
  TelaInicial adaptee;

  TelaInicial_radio2_actionAdapter(TelaInicial adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.radio2_actionPerformed(e);
  }
}