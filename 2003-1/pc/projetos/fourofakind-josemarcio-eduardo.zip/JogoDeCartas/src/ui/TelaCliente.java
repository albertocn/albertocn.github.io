package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Cliente.*;

/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: Interface gr�fica para o cliente do jogo
 * Four-of-a-Kind Game</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: DCCE/UFS</p>
 * @author Jose Marcio A. Bezerra
 * @version 1.0
 */

public class TelaCliente extends JPanel implements ClienteInterfaceSaida{
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel PainelLog = new JPanel();
  private BorderLayout borderLayout2 = new BorderLayout();
  private JPanel PainelBotoes = new JPanel();
  private JPanel PainelCartas = new JPanel();
  private GridLayout gridLayout1 = new GridLayout();
  private GridLayout gridLayout2 = new GridLayout();
  private JButton btnCarta1 = new JButton();
  private JButton btnCarta2 = new JButton();
  private JButton btnCarta3 = new JButton();
  private JButton btnCarta4 = new JButton();
  private JLabel labCarta1 = new JLabel();
  private JLabel labCarta2 = new JLabel();
  private JLabel labCarta3 = new JLabel();
  private JLabel labCarta4 = new JLabel();
  private JLabel labJogador = new JLabel();
  private JButton btnSair = new JButton();
  private String[] cartas = new String[4];
  private ClienteInterfaceEntrada ie = null;
  private int ultimaCarta = -1;
  JLabel txtLog = new JLabel();

  public TelaCliente() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public void darCartas(String[] c){
    this.cartas = c;
    labCarta1.setIcon(new ImageIcon(cartas[0]+".jpg"));
    labCarta2.setIcon(new ImageIcon(cartas[1]+".jpg"));
    labCarta3.setIcon(new ImageIcon(cartas[2]+".jpg"));
    labCarta4.setIcon(new ImageIcon(cartas[3]+".jpg"));
    ultimaCarta = -1;
  }

  public void darCarta(String carta){
    if (ultimaCarta==0){
      this.cartas[ultimaCarta] = carta;
      labCarta1.setIcon(new ImageIcon(carta+".JPG"));
    }else if (ultimaCarta==1){
      this.cartas[ultimaCarta] = carta;
      labCarta2.setIcon(new ImageIcon(carta+".JPG"));
    }else if (ultimaCarta==2){
      this.cartas[ultimaCarta] = carta;
      labCarta3.setIcon(new ImageIcon(carta+".JPG"));
    }else if (ultimaCarta==3){
      this.cartas[ultimaCarta] = carta;
      labCarta4.setIcon(new ImageIcon(carta+".JPG"));
    }
    ultimaCarta = -1;
  }

  public void setStatus(String s){
    txtLog.setText("Status: "+s);
  }

  public void registrarIE(ClienteInterfaceEntrada ie){
    this.ie = ie;
  }

  public void limparCartas(){
    cartas = null;
    ultimaCarta = -1;
    labCarta1.setIcon(null);
    labCarta2.setIcon(null);
    labCarta3.setIcon(null);
    labCarta4.setIcon(null);
    this.repaint();
  }

  public void ativarInterface(){
    btnCarta1.setEnabled(true);
    btnCarta2.setEnabled(true);
    btnCarta3.setEnabled(true);
    btnCarta4.setEnabled(true);
  }

  public void desativarInterface(){
    btnCarta1.setEnabled(false);
    btnCarta2.setEnabled(false);
    btnCarta3.setEnabled(false);
    btnCarta4.setEnabled(false);
  }

  private void descartar(int i){
    if (i==1){
      ultimaCarta=0;
      labCarta1.setIcon(new ImageIcon("branco.jpg"));
      ie.descartar(cartas[0]);
    }else if (i==2){
      ultimaCarta=1;
      labCarta2.setIcon(new ImageIcon("branco.jpg"));
      ie.descartar(cartas[1]);
    }else if (i==3){
      ultimaCarta=2;
      labCarta3.setIcon(new ImageIcon("branco.jpg"));
      ie.descartar(cartas[2]);
    }else if (i==4){
      ultimaCarta=3;
      labCarta4.setIcon(new ImageIcon("branco.jpg"));
      ie.descartar(cartas[3]);
    }
  }

  public void encerrar(){
    btnSair.doClick();
  }

  public void setIdJogador(int i){
   labJogador.setText("Jogador "+i);
  }

  public void mostrarMensagem(String s){
    JOptionPane.showMessageDialog(this, s,
                                  "Aten��o!",
                                  JOptionPane.WARNING_MESSAGE);
  }

  public void reiniciar(){
    desativarInterface();
    limparCartas();
    txtLog.setText("");
  }

  private void jbInit() throws Exception {
    this.setLayout(borderLayout1);
    PainelLog.setPreferredSize(new Dimension(10, 60));
    PainelLog.setLayout(borderLayout2);
    PainelCartas.setPreferredSize(new Dimension(10, 130));
    PainelCartas.setLayout(gridLayout1);
    PainelBotoes.setDoubleBuffered(true);
    PainelBotoes.setPreferredSize(new Dimension(10, 30));
    PainelBotoes.setLayout(gridLayout2);
    gridLayout2.setColumns(4);
    gridLayout1.setColumns(4);
    gridLayout1.setRows(1);
    btnCarta1.setEnabled(false);
    btnCarta1.setActionCommand("jButton1");
    btnCarta1.setText("Descartar");
    btnCarta1.addActionListener(new TelaCliente_btnCarta1_actionAdapter(this));
    btnCarta2.setEnabled(false);
    btnCarta2.setText("Descartar");
    btnCarta2.addActionListener(new TelaCliente_btnCarta2_actionAdapter(this));
    btnCarta3.setEnabled(false);
    btnCarta3.setText("Descartar");
    btnCarta3.addActionListener(new TelaCliente_btnCarta3_actionAdapter(this));
    btnCarta4.setEnabled(false);
    btnCarta4.setText("Descartar");
    btnCarta4.addActionListener(new TelaCliente_btnCarta4_actionAdapter(this));
    btnSair.setActionCommand("jButton6");
    btnSair.setMnemonic('S');
    btnSair.setText("Sair");
    this.setPreferredSize(new Dimension(520, 210));
    labCarta1.setText("");
    labCarta2.setText("");
    labCarta3.setText("");
    labCarta4.setText("");
    labJogador.setFont(new java.awt.Font("Dialog", 1, 14));
    labJogador.setPreferredSize(new Dimension(70, 25));
    labJogador.setHorizontalAlignment(SwingConstants.CENTER);
    txtLog.setFont(new java.awt.Font("Dialog", 1, 12));
    txtLog.setOpaque(false);
    txtLog.setVerifyInputWhenFocusTarget(true);
    txtLog.setHorizontalAlignment(SwingConstants.LEFT);
    this.add(PainelLog, BorderLayout.NORTH);
    PainelLog.add(labJogador,  BorderLayout.NORTH);
    PainelLog.add(btnSair,  BorderLayout.EAST);
    PainelLog.add(txtLog, BorderLayout.CENTER);
    this.add(PainelBotoes, BorderLayout.SOUTH);
    PainelBotoes.add(btnCarta1, null);
    PainelBotoes.add(btnCarta2, null);
    PainelBotoes.add(btnCarta3, null);
    PainelBotoes.add(btnCarta4, null);
    this.add(PainelCartas,  BorderLayout.CENTER);
    PainelCartas.add(labCarta1, null);
    PainelCartas.add(labCarta2, null);
    PainelCartas.add(labCarta3, null);
    PainelCartas.add(labCarta4, null);
  }

  void btnCarta1_actionPerformed(ActionEvent e) {
    descartar(1);
  }

  void btnCarta2_actionPerformed(ActionEvent e) {
    descartar(2);
  }

  void btnCarta3_actionPerformed(ActionEvent e) {
    descartar(3);
  }

  void btnCarta4_actionPerformed(ActionEvent e) {
    descartar(4);
  }

  public void setBtnSairEvent(ActionListener a){
    btnSair.addActionListener(a);
  }

}

class TelaCliente_btnCarta1_actionAdapter implements java.awt.event.ActionListener {
  TelaCliente adaptee;

  TelaCliente_btnCarta1_actionAdapter(TelaCliente adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnCarta1_actionPerformed(e);
  }
}

class TelaCliente_btnCarta2_actionAdapter implements java.awt.event.ActionListener {
  TelaCliente adaptee;

  TelaCliente_btnCarta2_actionAdapter(TelaCliente adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnCarta2_actionPerformed(e);
  }
}

class TelaCliente_btnCarta3_actionAdapter implements java.awt.event.ActionListener {
  TelaCliente adaptee;

  TelaCliente_btnCarta3_actionAdapter(TelaCliente adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnCarta3_actionPerformed(e);
  }
}

class TelaCliente_btnCarta4_actionAdapter implements java.awt.event.ActionListener {
  TelaCliente adaptee;

  TelaCliente_btnCarta4_actionAdapter(TelaCliente adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.btnCarta4_actionPerformed(e);
  }
}