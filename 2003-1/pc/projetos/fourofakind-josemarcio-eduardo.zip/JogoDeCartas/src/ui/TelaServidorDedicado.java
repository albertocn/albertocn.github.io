package ui;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: DCCE/UFS</p>
 * @author Jose Marcio A. Bezerra
 * @version 1.0
 */

public class TelaServidorDedicado extends JPanel {
  private JLabel jLabel1 = new JLabel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private JButton btnSair = new JButton();

  public TelaServidorDedicado() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  public void setBtnSairEvent(ActionListener a){
    btnSair.addActionListener(a);
  }

  void jbInit() throws Exception {
    jLabel1.setFont(new java.awt.Font("Dialog", 1, 14));
    jLabel1.setRequestFocusEnabled(true);
    jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
    jLabel1.setHorizontalTextPosition(SwingConstants.LEADING);
    jLabel1.setText("Servidor do Jogo iniciado com sucesso.");
    this.setLayout(borderLayout1);
    btnSair.setText("Encerrar Servidor");
    this.add(jLabel1, BorderLayout.CENTER);
    this.add(btnSair,  BorderLayout.SOUTH);
  }
}