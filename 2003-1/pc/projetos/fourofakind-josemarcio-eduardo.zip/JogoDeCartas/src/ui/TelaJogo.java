package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import Cliente.*;
import java.rmi.*;
import Servidor.*;


/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: Interface gr�fica para iniciar o jogo
 * Four-of-a-Kind Game</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: DCCE/UFS</p>
 * @author Jose Marcio A. Bezerra
 * @version 1.0
 */

public class TelaJogo extends JFrame {
  /**Painel Inicial*/
  private TelaInicial ti;
  /**Painel para conectando*/
  private TelaConectando TConectando;
  /**Painel para cliente*/
  private TelaCliente tc;
  /**Painel para o servidor dedicado*/
  private TelaServidorDedicado tsd;
  /**Aplicacao Cliente*/
  private ClienteAplicacao ca;
  /**Aplicacao servidor*/
  private ServidorAplicacao sa;
  /**Constante para referencia ao Painel Inicial*/
  private String strPainelInicial = "PAINEL_INICIAL";
  /**Constante para referencia ao Painel Inicial*/
  private String strPainelCliente = "PAINEL_CLIENTE";
  /**Constante para referencia ao Painel Inicial*/
  private String strPainelConectando = "PAINEL_CONECTANDO";
  /**Constante para referencia ao Painel Inicial*/
  private String strPainelServidorDedicado = "PAINEL_SD";
  private BorderLayout borderLayout1 = new BorderLayout();
  private JPanel PainelPrincipal = new JPanel();
  private CardLayout cardLayout1 = new CardLayout();

  public TelaJogo() {
    super("Four-of-a-Kind Game");
    tc = new TelaCliente();
    ti = new TelaInicial();
    TConectando = new TelaConectando();
    tsd = new TelaServidorDedicado();
    try {
      ca = new ClienteAplicacao(tc);
      sa = new ServidorAplicacao();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }

  public static void main(String[] args) {
    TelaJogo telaJogo = new TelaJogo();
  }

  private void jbInit() throws Exception {
    this.getContentPane().setLayout(borderLayout1);
    PainelPrincipal.setLayout(cardLayout1);
    PainelPrincipal.setPreferredSize(new Dimension(520,310));
    PainelPrincipal.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
    this.addWindowListener(new TelaJogo_this_windowAdapter(this));
    PainelPrincipal.add(ti,strPainelInicial);
    PainelPrincipal.add(TConectando,strPainelConectando);
    PainelPrincipal.add(tc,strPainelCliente);
    PainelPrincipal.add(tsd,strPainelServidorDedicado);
    this.getContentPane().add(PainelPrincipal,  BorderLayout.CENTER);
    //Definindo eventos
    ti.setBtnIniciarEvent(new BtnIniciarEvent());
    tc.setBtnSairEvent(new BtnSairClienteEvent());
    TConectando.setBtnVoltarEvent(new BtnVoltarEvent());
    tsd.setBtnSairEvent(new BtnSairServidorEvent());
    //Fechar programa ao clicar no "X" na barra de titulo
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    //Exibindo a janela
    this.setResizable(false);
    this.pack();
    this.setExtendedState(NORMAL);
    this.setVisible(true);
  }

  public void irTelaInicial(){
    CardLayout cl = (CardLayout) (PainelPrincipal.getLayout());
    cl.show(PainelPrincipal, strPainelInicial);
  }

  public void irTelaCliente(){
    CardLayout cl = (CardLayout) (PainelPrincipal.getLayout());
    cl.show(PainelPrincipal, strPainelCliente);
  }

  public void irTelaSD(){
    CardLayout cl = (CardLayout) (PainelPrincipal.getLayout());
    cl.show(PainelPrincipal, strPainelServidorDedicado);
  }

  public void irTelaConectando(){
    CardLayout cl = (CardLayout) (PainelPrincipal.getLayout());
    cl.show(PainelPrincipal, strPainelConectando);
    TConectando.setText("Conectando ao servidor remoto...");
    TConectando.ativaBotao(false);
  }
  private class BtnIniciarEvent implements ActionListener{
    public void actionPerformed(ActionEvent e){
      if (ti.getOpcao()==3){
        //inicia apenas cliente para host e porta especificados
        irTelaConectando();
        if (!ca.conectar(ti.getHost(),ti.getPorta())){
          TConectando.setText("N�o foi possivel conectar ao servidor!");
          TConectando.ativaBotao(true);
        } else{
          irTelaCliente();
        }
      }else if(ti.getOpcao()==1){
        //inicia apenas servidor local
        irTelaConectando();
        TConectando.setText("Iniciando servidor localmente...");
        if (!sa.iniciarServidor()){
          TConectando.setText("N�o foi poss�vel iniciar o servidor localmente.");
          TConectando.ativaBotao(true);
        } else{
          irTelaSD();
        }
      }else{
        //inicia servidor local e depois cliente para host local
        irTelaConectando();
        TConectando.setText("Iniciando servidor localmente...");
        if (sa.iniciarServidor()){
          TConectando.setText("Conectando ao servidor local...");
          if (!ca.conectar("localhost","1099")){
            TConectando.setText("N�o foi poss�vel conectar-se ao servidor local.");
            TConectando.ativaBotao(true);
            sa.encerrarServidor();
          } else {
            irTelaCliente();
          }
        }else{
          TConectando.setText("N�o foi poss�vel iniciar o servidor localmente.");
          TConectando.ativaBotao(true);
        }
      }
    }
  }

  private class BtnSairServidorEvent implements ActionListener{
    public void actionPerformed(ActionEvent e){
      if (sa.isIniciado()){
        sa.encerrarServidor();
      }
      irTelaInicial();
    }
  }

  private class BtnSairClienteEvent implements ActionListener{
    public void actionPerformed(ActionEvent e){
      tc.reiniciar();
      if (ca.isConectado()){
        ca.sair();
      }
      if (sa.isIniciado()){
        sa.encerrarServidor();
      }
      irTelaInicial();
    }
  }

  private class BtnVoltarEvent implements ActionListener{
    public void actionPerformed(ActionEvent e){
      irTelaInicial();
    }
  }

  void this_windowClosing(WindowEvent e) {
    if (ca.isConectado()){
      ca.sair();
    }
    if (sa.isIniciado()){
      sa.encerrarServidor();
    }
    ca = null;
    sa = null;
    this.dispose();
  }

}

class TelaJogo_this_windowAdapter extends java.awt.event.WindowAdapter {
  TelaJogo adaptee;

  TelaJogo_this_windowAdapter(TelaJogo adaptee) {
    this.adaptee = adaptee;
  }
  public void windowClosing(WindowEvent e) {
    adaptee.this_windowClosing(e);
  }
}