package ui;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class TelaConectando extends JPanel {
  private BorderLayout borderLayout1 = new BorderLayout();
  private JButton btnVoltar = new JButton();
  private JLabel labMsg = new JLabel();

  public TelaConectando() {
    try {
      jbInit();
    }
    catch(Exception ex) {
      ex.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    btnVoltar.setEnabled(false);
    btnVoltar.setForeground(Color.black);
    btnVoltar.setPreferredSize(new Dimension(35, 40));
    btnVoltar.setFocusPainted(true);
    btnVoltar.setText("Voltar");
    this.setLayout(borderLayout1);
    labMsg.setFont(new java.awt.Font("Dialog", 1, 13));
    labMsg.setForeground(Color.black);
    labMsg.setToolTipText("");
    labMsg.setHorizontalAlignment(SwingConstants.CENTER);
    labMsg.setText("Conectando ao servidor remoto...");
    this.add(btnVoltar,  BorderLayout.SOUTH);
    this.add(labMsg,  BorderLayout.CENTER);
  }

  public void setBtnVoltarEvent(ActionListener a){
    btnVoltar.addActionListener(a);
  }

  public void setText(String s){
    labMsg.setText(s);
  }

  public void ativaBotao(boolean b){
    btnVoltar.setEnabled(b);
  }

}