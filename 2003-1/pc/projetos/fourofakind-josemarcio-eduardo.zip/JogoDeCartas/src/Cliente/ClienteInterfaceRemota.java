package Cliente;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: Defini��o do qu� pode ser solicitado
 * a aplica�ao cliente remotamente (RMI).</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: DCCE/UFS</p>
 * @author Jose Marcio A. Bezerra
 * @version 1.0
 */

public interface ClienteInterfaceRemota extends Remote{
  /**Adiciona um String ao log da interface.
   *
   * @param s String a ser adicionado.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  void setStatus(String s) throws RemoteException;

  /**Avisa ao cliente para iniciar o jogo.
   *
   * @param s Cartas do jogador.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public void darCartas(String[] s) throws RemoteException;

  /**Finaliza a partida.
   *
   * @param s Mensagem para exibir ao jogador.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public void finalizarPartida(String s) throws RemoteException;


  /**Finaliza a partida.
   *
   * @param s Mensagem para exibir ao jogador.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public void finalizarAplicacao(String s) throws RemoteException;
}
