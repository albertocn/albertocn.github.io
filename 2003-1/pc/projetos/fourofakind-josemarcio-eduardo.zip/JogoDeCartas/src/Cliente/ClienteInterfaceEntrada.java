package Cliente;

import java.rmi.*;

/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: Defini��o do qu� pode ser solicitado
 * a aplica�ao cliente.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: DCCE/UFS</p>
 * @author not attributable
 * @version 1.0
 */

public interface ClienteInterfaceEntrada {
  /**Libera a carta selecionada e solicita uma nova carta.
   *
   * @param carta Carta a ser liberada.
   */
  void descartar(String carta);
  /**
   *Encerra a aplica�ao cliente sem notificar a interface.
   */
  void sair();
}