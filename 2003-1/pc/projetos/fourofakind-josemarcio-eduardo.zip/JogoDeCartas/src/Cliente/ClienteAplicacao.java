package Cliente;

import java.rmi.server.*;
import java.rmi.*;
import Servidor.*;

/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: Aplica�ao cliente para o jogo de Four-of-a-Kind Game</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: DCCE/UFS</p>
 * @author Jose Marcio A. Bezerra
 * @version 1.0
 */

public class ClienteAplicacao extends UnicastRemoteObject
    implements ClienteInterfaceRemota, ClienteInterfaceEntrada {

  private int id= -1;
  private ClienteInterfaceSaida is = null;
  private ServidorInterface si;
  private boolean conectado = false;

  /**Inicializa um novo cliente para o Jogo de Cartas.
   *
   * @param is Objeto em imprimir� as sa�das.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public ClienteAplicacao(ClienteInterfaceSaida is) throws RemoteException{
    super();
    this.is = is;
    is.registrarIE(this);
  }

  /**Conecta o cliente a um servidor.
   *
   * @param servidor Nome ou IP do servidor.
   * @param porta Porta a conectar
   * @return true caso consiga conectar-se, sen�o false.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public boolean conectar(String servidor, String porta){
    id=-1;
    //registra  o cliente no servidor
    try {
      String name = "rmi://" + servidor + ":" + porta + "/ServidorJogo";
      si = (ServidorInterface) Naming.lookup(name);
      id = si.registrarJogador(this);
    } catch (Exception e) {
    }
    conectado = (id>=0);
    if (conectado){is.setIdJogador(id+1);}
    return conectado;
  }

  /**retorna se o cliente est� conectado.
   *
   * @return true se o cliente est� conectado.
   */
  public boolean isConectado(){
      return conectado;
  }

  /**
   *Encerra a aplica�ao cliente sem notificar a interface.
   */
  public void sair(){
    if (conectado){
      try {
        si.retirarJogador(id);
      }
      catch (Exception ex) {
      }
      si = null;
      id = -1;
      conectado = false;
    }
  }

  /**
   * Encerra a partida e automaticamente inicia uma nova, informando
   * a interface da aplica�ao cliente.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public void finalizarPartida(String s) throws RemoteException{
    is.limparCartas();
    is.desativarInterface();
    is.setStatus(s);
  }

  /**
   * Encerra a partida e automaticamente inicia uma nova, informando
   * a interface da aplica�ao cliente.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public void finalizarAplicacao(String s) throws RemoteException{
    is.limparCartas();
    is.desativarInterface();
    is.setStatus(s);
    this.si = null;
    this.conectado = false;
    is.encerrar();
  }

  /**Adiciona um String ao log da interface.
   *
   * @param s String a ser adicionado.
   * @throws RemoteException Se n�o puder executar este m�todo.
   */
  public void setStatus(String s) throws RemoteException{
    is.setStatus(s);
  }

  /**Libera a carta selecionada e solicita uma nova carta.
   *
   * @param carta Carta a ser liberada.
   */
  public void descartar(String carta){
    try{
      is.desativarInterface();
      si.descartar(id, carta);
    }catch (RemoteException e){
      is.mostrarMensagem("Ocorreu um erro ao comunicar-se ao servidor.");
      this.si = null;
      this.conectado = false;
      is.encerrar();
    }
  }

  /**Libera a carta selecionada e solicita uma nova carta.
   *
   * @param carta Carta a ser liberada.
   */
  public void darCartas(String[] cartas) throws RemoteException{
    if (conectado){
      is.darCartas(cartas);
      is.ativarInterface();
    }
  }

}