package Cliente;

/**
 * <p>Title: Jogo de Cartas</p>
 * <p>Description: Defini��o do qu� pode ser solicitado
 * pela aplica�ao cliente � Interface de Saida.</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: DCCE/UFS</p>
 * @author Jose Marcio A. Bezerra
 * @version 1.0
 */

public interface ClienteInterfaceSaida {
  void setStatus(String s);
  void ativarInterface();
  void desativarInterface();
  void darCartas(String[] cartas);
  void limparCartas();
  void registrarIE(ClienteInterfaceEntrada ie);
  void setIdJogador(int i);
  void encerrar();
  void reiniciar();
  void mostrarMensagem(String s);
}