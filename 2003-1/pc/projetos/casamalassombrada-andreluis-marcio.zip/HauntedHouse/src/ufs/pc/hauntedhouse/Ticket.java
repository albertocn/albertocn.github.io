package ufs.pc.hauntedhouse;

/**
 * Interface que representa um bilhete de carro mal-
 * assombrado.
 *
 * Ela associa um Passageiro a um semaforo e � utilizada
 * para fazer o mesmo esperar na fila (travar) ou ir para o carro
 * esperar pelo passeio (liberar).
 *
 * <p>Title: Casa Mal - Assombrada</p>
 * <p>Description: Trabalho de Programacao Concorrente</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Andre Luis & Marcio Carvalho
 * @version 1.0
 */
public interface Ticket {

  /**
   * Acesso ao passageiro dono do bilhete.
   * @return o passageiro ligado a este bilhete.
   */
  public Passageiro getPassageiro();


  /**
   * Faz o passageiro bloquear na fila ate que
   * o bilheteiro o libere.
   */
  public void travar();


  /**
   * Libera o passageiro associado a este bilhete
   * para sair da fila e entrar no carro.
   */
  public void liberar();

}