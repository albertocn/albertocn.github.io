package ufs.pc.hauntedhouse.ui;


import javax.swing.*;
import java.awt.*;
import java.awt.Image;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import javax.swing.border.*;
import javax.swing.plaf.metal.MetalLookAndFeel;
import java.util.ArrayList;

import ufs.pc.hauntedhouse.Passageiro;
import ufs.pc.hauntedhouse.TouringCar;


/**
 * Tela principal da aplica cao HauntedHouse.
 * Possui quatro abas: a primeira co  o log geral dos
 * eventos, a segunda com o log apenas das threads passageiras,
 * a terceira com os eventos do carro. Por fim, a quarta
 * aba � respons�vel por exibir o status de cada passageiro e
 * de cada carro no decorrer do tempo.
 *
 * <p>Title: Casa Mal - Assombrada</p>
 * <p>Description: Trabalho de Programacao Concorrente</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Andre Luis & Marcio Carvalho
 * @version 1.0
 */

public class LogFrame extends JFrame {
  private JPanel jPanel1 = new JPanel();
  private BorderLayout borderLayout1 = new BorderLayout();
  private JScrollPane panePassageiros = new JScrollPane();
  private JScrollPane paneTouringCar = new JScrollPane();
  private JScrollPane paneALL = new JScrollPane();
  private JTabbedPane jTabbedPane1 = new JTabbedPane();
  private JTextArea txtTudo = new JTextArea();
  private JTextArea txtPassageiros = new JTextArea();
  private JPanel paneTop = new JPanel();
  private FlowLayout flowLayout1 = new FlowLayout();
  private ImagePanel panelImage = null;
  private BorderLayout borderLayout2 = new BorderLayout();
  private JTextArea txtCar = new JTextArea();
  JSplitPane splitStatus = new JSplitPane();
  JScrollPane scrollStatusPassageiros = new JScrollPane();
  JScrollPane scrollStatusCarros = new JScrollPane();
  JList lstPassageiros = new JList();
  JList lstCarros = new JList();



  public LogFrame() {
    try {
      jbInit();
      pack();
      show();
    } catch(Exception e) {
      e.printStackTrace();
    }
  }


  private void jbInit() throws Exception {
    panelImage = new ImagePanel(Toolkit.getDefaultToolkit().getImage(
        this.getClass().getResource("scream.gif"))); //Carrega a imagem da barra superior

    UIManager.setLookAndFeel( new MetalLookAndFeel() ); //Seta o LookAndFeel da aplicacao

    jPanel1.setLayout(borderLayout1);
    jPanel1.setBackground(SystemColor.control);
    jPanel1.setBorder(BorderFactory.createEtchedBorder());
    jPanel1.setMinimumSize(new Dimension(350, 300));
    jPanel1.setOpaque(true);
    jPanel1.setPreferredSize(new Dimension(600, 400));
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    this.setEnabled(true);
    this.setForeground(Color.black);
    this.setLocale(java.util.Locale.getDefault());
    this.setResizable(true);
    this.setState(Frame.NORMAL);
    this.setTitle("Haunted House");
    this.getContentPane().setLayout(borderLayout2);
    paneALL.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    paneALL.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    paneALL.setAutoscrolls(true);
    jTabbedPane1.setTabPlacement(JTabbedPane.BOTTOM);
    jTabbedPane1.setBorder(BorderFactory.createEtchedBorder());
    jTabbedPane1.setDebugGraphicsOptions(0);
    jTabbedPane1.setDoubleBuffered(false);
    jTabbedPane1.setPreferredSize(new Dimension(350, 300));
    jTabbedPane1.setToolTipText("");
    txtTudo.setBackground(Color.black);
    txtTudo.setForeground(Color.green);
    txtTudo.setCaretColor(Color.green);
    txtTudo.setEditable(false);
    txtPassageiros.setEditable(false);
    txtPassageiros.setCaretColor(Color.green);
    txtPassageiros.setForeground(Color.green);
    txtPassageiros.setBackground(Color.black);
    paneTop.setBackground(Color.black);
    paneTop.setAlignmentX((float) 0.5);
    paneTop.setMinimumSize(new Dimension(30, 30));
    paneTop.setPreferredSize(new Dimension(30, 81));
    paneTop.setLayout(flowLayout1);
    flowLayout1.setHgap(0);
    flowLayout1.setVgap(0);
    borderLayout1.setVgap(2);
    txtCar.setEditable(false);
    txtCar.setCaretColor(Color.green);
    txtCar.setForeground(Color.green);
    txtCar.setBackground(Color.black);
    splitStatus.setOrientation(JSplitPane.VERTICAL_SPLIT);
    splitStatus.setDividerSize(8);
    splitStatus.setLastDividerLocation(120);
    splitStatus.setResizeWeight(0.5);
    lstPassageiros.setBackground(Color.black);
    lstPassageiros.setForeground(Color.green);
    lstPassageiros.setDebugGraphicsOptions(0);
    lstPassageiros.setPreferredSize(new Dimension(0, 0));
    lstPassageiros.setToolTipText("");
    lstPassageiros.setFixedCellHeight(-1);
    lstPassageiros.setSelectionForeground(Color.black);
    lstPassageiros.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    lstPassageiros.setVisibleRowCount(10);
    lstCarros.setBackground(Color.black);
    lstCarros.setForeground(Color.green);
    lstCarros.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    scrollStatusPassageiros.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
    scrollStatusPassageiros.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    scrollStatusPassageiros.setPreferredSize(new Dimension(274, 120));
    scrollStatusCarros.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
    this.getContentPane().add(jPanel1, BorderLayout.CENTER);
    jPanel1.add(jTabbedPane1, BorderLayout.CENTER);
    jTabbedPane1.add(paneALL, "Tudo");
    paneALL.getViewport().add(txtTudo, null);
    jTabbedPane1.add(panePassageiros, "Passageiros");
    panePassageiros.getViewport().add(txtPassageiros, null);
    jTabbedPane1.add(paneTouringCar, "Touring Car");
    jTabbedPane1.add(splitStatus,  "Status");
    paneTouringCar.getViewport().add(txtCar, null);
    jPanel1.add(paneTop, BorderLayout.NORTH);
    paneTop.add(panelImage, null);
    splitStatus.add(scrollStatusPassageiros, JSplitPane.TOP);
    splitStatus.add(scrollStatusCarros, JSplitPane.BOTTOM);
    scrollStatusPassageiros.getViewport().add(lstPassageiros, null);
    scrollStatusCarros.getViewport().add(lstCarros, null);
    panelImage.setLayout(flowLayout1);
    this.setLocation(100, 100);
    splitStatus.setDividerLocation(165);
    lstPassageiros.setCellRenderer(new MyCellRenderer());
    lstCarros.setCellRenderer(new MyCellRenderer());
  }


  /**
   *
   * @return
   */
  public JList getListPassageiros() {
    return this.lstPassageiros;
  }


  /**
   *
   * @return
   */
  public JList getListCarros() {
    return this.lstCarros;
  }

  /**
   *
   * @return
   */
  public JTextArea getMemoTudo() {
    return this.txtTudo;
  }


  /**
   *
   * @return
   */
  public JTextArea getMemoPassageiros() {
    return this.txtPassageiros;
  }


  /**
   *
   * @return
   */
  public JTextArea getMemoCar() {
    return this.txtCar;
  }


  /**
   * Panel que carrega a imagem passada e a redesenha em seu
   * espa�o vis�vel.
   *
   * <p>Title: Casa Mal - Assombrada</p>
   * <p>Description: Trabalho de Programacao Concorrente</p>
   * <p>Copyright: Copyright (c) 2003</p>
   * <p>Company: UFS</p>
   * @author Andre Luis & Marcio Carvalho
   * @version 1.0
   */
  private class ImagePanel extends JPanel {
    Image img = null;

    ImagePanel(Image image) {
      img = image;
      this.setPreferredSize(new Dimension(488, 81));
      this.setBackground(Color.black);
    }

    public void paintComponent(Graphics g)  {
      super.paintComponent(g);

      g.drawImage(img, 0, 0, 480, 81, Color.black, this);
    }
  }



  /**
   * Classe renderizadora de componentes, utilizado para
   * atualizar o conteudo visivel de cada item da Lista.
   * Sempre que o JList necessita redesenhar um de seus componentes,
   * o metodo unico desta classe eh invocado.
   *
   * <p>Title: Casa Mal - Assombrada</p>
   * <p>Description: Trabalho de Programacao Concorrente</p>
   * <p>Copyright: Copyright (c) 2003</p>
   * <p>Company: UFS</p>
   * @author Andre Luis & Marcio Carvalho
   * @version 1.0
   */
  class MyCellRenderer extends DefaultListCellRenderer {

    public Component getListCellRendererComponent(JList list,
                                                  Object value,
                                                  int index,
                                                  boolean isSelected,
                                                  boolean cellHasFocus)   {
      Component retValue = super.getListCellRendererComponent(
          list, value, index, isSelected, cellHasFocus);

      //Metodos definidos na Interface Listable e
      //implementados pelas threads Passageiro e
      //TouringCar
      this.setText(((Listable)value).getText());
      this.setIcon(((Listable)value).getIcon());

      return retValue;
    }
  }

}