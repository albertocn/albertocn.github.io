package ufs.pc.hauntedhouse;

import ufs.pc.hauntedhouse.ui.Listable;
import javax.swing.ImageIcon;


/**
 * <p>Classe que representa um passageiro na aplicacao casa
 * mal-assombrada. Estende Thread e implementa a interface Listable
 * que o marca como exibivel em um JList.</p>
 * <p>Seu funcionamento consiste basicamente em:
 * entrar na fila, ocupar poltrona, esperar por passeio,
 * passear e por ultimo, passear no parque.</p>
 *
 *
 * <p>Title: Casa Mal - Assombrada</p>
 * <p>Description: Trabalho de Programacao Concorrente</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Andre Luis & Marcio Carvalho
 * @version 1.0
 */
public class Passageiro extends Thread implements Listable {

  /**
   * Quando o passageiro esta dando uma volta pelo parque,
   * lanchando por exemplo.
   */
  public static final int ST_PASSEANDO_NO_PARQUE = 1;

  /**
   * Quando o passageiro esta esperando na fila para
   * entrar no carro.
   */
  public static final int ST_ESPERANDO_NA_FILA   = 2;

  /**
   * Quando o passageiro j� saiu da fila e est� esperando
   * no carro o passeio comecar.
   */
  public static final int ST_ESPERANDO_NO_CARRO  = 3;

  /**
   * Quando o passageiro est� passendo na casa mal-assombrada.
   */
  public static final int ST_PASSEANDO_NA_CASA   = 4;


  private String nome;                //Nome do Passageiro
  private int peso;                   //Seu peso em quilogramas
  private int status;                 //Variavel que guarda seu status
  private Bilheteiro manel;           //Referencia para o bilheteiro.
  private int duracaoPasseioNoParque; //Duracao m�xima da volta pelo parque.
                                      //Para lanchar ou andar em outros brinquedos.


  /**
   * Construtor padr�o do Passageiro. Inicializa suas variaveis e
   * inicia o funcionamento da thread associada a ele.
   *
   * @param nome nome do passageiro
   * @param peso peso em quilos do passageiro
   * @param duracaoPasseioNoParque duracao m�xima de uma volta pelo parque
   * @param b referencia para o bilheteiro
   */
  public Passageiro(String nome, int peso, int duracaoPasseioNoParque, Bilheteiro b) {
    super(nome); //Passa o nome para o construtor da classe Thread

    this.nome = nome;
    this.peso = peso;
    this.manel = b;
    this.duracaoPasseioNoParque = duracaoPasseioNoParque;
    this.setStatus(ST_PASSEANDO_NO_PARQUE); //Status inicial

    start();  //inicializa o funcionamento do passageiro
  }


  /**
   * Metodo principal do Passageiro. Todo o seu funcionamento
   * est� definido aqui.
   */
  public void run() {
    manel.log(this + " criado...");

    while(manel.deveContinuar()) {
      //Pede ao bilheteiro para entrar fila
      this.setStatus(ST_ESPERANDO_NA_FILA);
      manel.entrarNaFila(this);

      //Espera a vez para entrar no carro
      manel.ocuparPoltrona(this);

      //Espera o passeio come�ar
      this.setStatus(ST_ESPERANDO_NO_CARRO);
      manel.esperarPorPasseio(this);

      //Passea na casa mal-assombrada
      this.setStatus(ST_PASSEANDO_NA_CASA);
      manel.passear(this);

      //D� uma volta pelo parque...
      this.setStatus(ST_PASSEANDO_NO_PARQUE);
      passearNoParque();
    }
  }


  /**
   * Metodo acionado pelo bilheteiro no momento em que
   * o carro deve iniciar o passeio pela casa mal-assombrada.
   */
  public void passearNoParque() {
    try {
      //Calculo aleatorio da duracao do passeio
      long segs = Math.round(Math.random() * duracaoPasseioNoParque);

      manel.log("Dando uma volta pelo parque por " + segs + " segundos");

      // zzzzzzzzzzzzzzzzz....
      this.sleep( segs * 1000 );
    } catch (InterruptedException ie) {}
  }


  /**
   * Atualiza o status do passageiro.
   *
   * @param newStatus novo status
   */
  protected synchronized void setStatus(int newStatus) {
    this.status = newStatus;
  }


  /**
   * Consulta o status atual do passageiro.
   * Pode ser: ST_PASSEANDO_NO_PARQUE,
   * ST_ESPERANDO_NA_FILA, ST_ESPERANDO_NO_CARRO ou
   * ST_PASSEANDO_NA_CASA.
   *
   * @return status atual
   */
  public synchronized int getStatus() {
    return this.status;
  }


  /**
   * Consulta o nome do passageiro.
   *
   * @return nome do passageiro.
   */
  public String getNome() {
    return this.nome;
  }


  /**
   * Consulta o peso do passageiro.
   *
   * @return peso do passageiro.
   */
  public int getPeso() {
    return this.peso;
  }



  /**
   * Consulta a descri��o textual do passageiro.
   * No formato Nome: <nome> Peso: <peso>
   *
   * @return descri��o textual do passageiro.
   */
  public String toString() {
    return "Nome: " + nome + " Peso: " + peso;
  }


  /**
   * Consulta o �cone que representa o status atual
   * deste passageiro.
   * Amarelo para dando uma volta no parque,
   * Vermelho para esperando na fila,
   * Azul para aguardando o passeio no carro e
   * Rosa para passeando na casa mal-assombrada.
   *
   * @return representacao em icone do status do passageiro.
   */
  public ImageIcon getIcon() {
    switch(this.getStatus()) {
      case ST_PASSEANDO_NO_PARQUE: return this.YELLOW;
      case ST_ESPERANDO_NA_FILA:   return this.RED;
      case ST_ESPERANDO_NO_CARRO:  return this.BLUE;
      case ST_PASSEANDO_NA_CASA:   return this.MAGENTA;
    }

    return null;
  }


  /**
   * Consulta a descri��o textual do status atual do passageiro.
   *
   * @return descri��o textual do status do passageiro.
   */
  public String getText() {
    switch (this.getStatus()) {
      case ST_PASSEANDO_NO_PARQUE:
        return this.getName() + " Dando uma volta pelo parque";
      case ST_ESPERANDO_NA_FILA:
        return this.getName() + " Aguardando na fila a sua vez";
      case ST_ESPERANDO_NO_CARRO:
        return this.getName() + " Aguardando no carro o passeio come�ar";
      case ST_PASSEANDO_NA_CASA:
        return this.getName() + " Passeando na casa mal-assombrada";
    }

    return null;
  }

}