package ufs.pc.hauntedhouse.semaforo;


/**
 *
 * <p>Title: Casa Mal - Assombrada</p>
 * <p>Description: Trabalho de Programacao Concorrente</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Andre Luis & Marcio Carvalho
 * @version 1.0
 */
public class Semaforo {
  protected int count;


  public Semaforo() {
    this(0);
  }


  public Semaforo(int count) {
    this.count = count;
  }


  /**
   * @exception
   * @author
   */
  public synchronized void p() {
    --count;
    if (count < 0) {
      while(true) {
        try {
          this.wait();
          break;
        } catch(InterruptedException ie) {
          if (count >= 0) break;
          else continue;
        }
      }
    }
  }


  /**
   * @exception
   * @author
   */
  public synchronized void v() {
    ++count;
    if (count <= 0) this.notify(); //avisa a alguma thread bloqueada que pode executar
  }


  public synchronized int getValor() {
    return this.count;
  }

}