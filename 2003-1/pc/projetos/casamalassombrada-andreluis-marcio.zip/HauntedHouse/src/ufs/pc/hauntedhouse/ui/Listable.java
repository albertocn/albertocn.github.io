package ufs.pc.hauntedhouse.ui;

import javax.swing.ImageIcon;
import java.net.URL;


/**
 * <p>Interface utilizada para marcar um objeto
 * como Listavel, o que representa que pode ser
 * exibido em JList.</p>
 *
 *
 * <p>Title: Casa Mal - Assombrada</p>
 * <p>Description: Trabalho de Programacao Concorrente</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Andre Luis & Marcio Carvalho
 * @version 1.0
 */

public interface Listable {

  public static final ImageIcon RED     = new ImageIcon(LogController.getFrame().getClass().getResource("red.gif"));
  public static final ImageIcon BLUE    = new ImageIcon(LogController.getFrame().getClass().getResource("blue.gif"));
  public static final ImageIcon YELLOW  = new ImageIcon(LogController.getFrame().getClass().getResource("yellow.gif"));
  public static final ImageIcon GREEN   = new ImageIcon(LogController.getFrame().getClass().getResource("green.gif"));
  public static final ImageIcon GRAY    = new ImageIcon(LogController.getFrame().getClass().getResource("gray.gif"));
  public static final ImageIcon CYAN    = new ImageIcon(LogController.getFrame().getClass().getResource("cyan.gif"));
  public static final ImageIcon MAGENTA = new ImageIcon(LogController.getFrame().getClass().getResource("magenta.gif"));


  /**
   * Retorna um icone que representa o estado
   * atual do objeto.
   *
   * @return Icone representando o estado do objeto
   */
  public ImageIcon getIcon();


  /**
   * Retorna o texto representando o estado
   * atual do objeto.
   *
   * @return texto representando o estado do objeto
   */
  public String getText();

}