package ufs.pc.hauntedhouse;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

import ufs.pc.hauntedhouse.ui.*;

/**
 * Classe de inicializa��o da aplica��o HauntedHouse.
 *
 * <p>Title: Casa Mal - Assombrada</p>
 * <p>Description: Trabalho de Programacao Concorrente</p>
 *                 Classe Principal da aplica�ao. <br>
 *                 Uso: java -jar hauntedhouse -c <capacidade do carro em quilos>
 *                                             -t <duracao do passeio em segundos>
 *                                             -p <n�mero total de passageiros>
 *                                             -m <peso minimo em quilos>
 *                                             -M <peso m�ximo em quilos>
 *                                             -w <duracao do passeio pelo parque em segundos>
 *                                             -T <tempo total da execucao em segundos>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Andre Luis & Marcio Carvalho
 * @version 1.0
 */

public class HauntedHouse {
  public static Bilheteiro manel;

  //Valores default
  private static int capacidade             = 500;   //quilos
  private static int duracaoPasseio         = 5;     //segundos
  private static int numPassageiros         = 40;    //unitario
  private static int pesoMinimo             = 40;    //quilos
  private static int pesoMaximo             = 120;   //quilos
  private static int duracaoPasseioNoParque = 10;    //segundos
  private static int tempoTotal             = 86400; //1 dia, em segundos


  /**
   * M�todo que inicializa a aplica��o.
   */
  private static void start() {
    //Instancia a janela principal e o Controlador de log
    LogFrame lf = new LogFrame();
    LogController.init(lf);

    //O bilheteiro que controlar� o brinquedo
    manel = new Bilheteiro(tempoTotal);

    //A instancia do carro que fara os passeios na casa mal-assombrada
    TouringCar carro = new TouringCar(manel, capacidade, duracaoPasseio);
    lf.getListCarros().setListData(new TouringCar[] { carro });

    //O array de "n" passageiros
    Passageiro[] galera = new Passageiro[numPassageiros];
    for(int i = 0 ; i < galera.length ; i++) {
      galera[i] = new Passageiro("Passageiro" + (i + 1),
                           pesoMinimo + Math.round((float)Math.random() * (pesoMaximo - pesoMinimo)),
                           duracaoPasseioNoParque,
                           manel);
    }
    lf.getListPassageiros().setListData(galera);

    //Conta o tempo total de funcionamento e depois mostra uma mensagem.
    try { Thread.sleep(tempoTotal * 1000); } catch(InterruptedException ie) {}
    LogController.log("***************** Fim da execu��o *****************");
  }


  public static void main(String[] args) {
    for (int i = 0 ; i < args.length ; i += 2) {
      if (args[i].equals("-c")) {
        capacidade = Integer.parseInt(args[i +1]);
        continue;

      } if (args[i].equals("-t")) {
        duracaoPasseio = Integer.parseInt(args[i +1]);
        continue;

      } if (args[i].equals("-p")) {
        numPassageiros = Integer.parseInt(args[i +1]);
        continue;

      } if (args[i].equals("-m")) {
        pesoMinimo = Integer.parseInt(args[i +1]);
        continue;

      } if (args[i].equals("-M")) {
        pesoMaximo = Integer.parseInt(args[i +1]);
        continue;

      } if (args[i].equals("-w")) {
        duracaoPasseioNoParque = Integer.parseInt(args[i +1]);
        continue;

      } if (args[i].equals("-T")) {
        tempoTotal = Integer.parseInt(args[i +1]);
        continue;

      } if (args[i].equals("/?") || args[i].equals("-?")) {
        System.out.println("Uso: java -jar hauntedhouse -c <capacidade do carro em quilos>\n" +
                           "                            -t <duracao do passeio em segundos>\n" +
                           "                            -p <n�mero total de passageiros>\n" +
                           "                            -m <peso minimo em quilos>\n" +
                           "                            -M <peso m�ximo em quilos>\n" +
                           "                            -w <duracao do passeio pelo parque em segundos>\n" +
                           "                            -T <tempo total da execucao em segundos>");
        System.exit(0);
      }
    }

    start();
  }
}