package ufs.pc.hauntedhouse.semaforo;


/**
 *
 * <p>Title: Casa Mal - Assombrada</p>
 * <p>Description: Trabalho de Programacao Concorrente</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Andre Luis & Marcio Carvalho
 * @version 1.0
 */
public class MutEx extends Semaforo {

  public MutEx() {
    this(true);
  }

  /**
   *
   * @param b
   */
  public MutEx(boolean b) {
    super(b? 1 : 0);
  }


  public synchronized void v() {
    super.v();
    if (count > 1) count = 1;
  }
}