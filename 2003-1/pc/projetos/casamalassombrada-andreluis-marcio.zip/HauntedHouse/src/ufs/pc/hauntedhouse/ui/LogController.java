package ufs.pc.hauntedhouse.ui;

import javax.swing.JTextArea;
import javax.swing.JFrame;
import javax.swing.JScrollBar;
import javax.swing.JList;
import javax.swing.ListModel;

import ufs.pc.hauntedhouse.*;


/**
 * Classe respons�vel por controlar o log da aplicacao.
 * Ela, al�m de mandar as mensagens para a saida padrao,
 * redireciona-as para o JTextArea correspondente � Thread
 * que gerou a mensagem, no caso um Passageiro ou um TouringCar.
 *
 * <p>Title: Casa Mal - Assombrada</p>
 * <p>Description: Trabalho de Programacao Concorrente</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Andre Luis & Marcio Carvalho
 * @version 1.0
 */

public class LogController {
  private static LogFrame lf = null;               //Janela Principal
  private static JTextArea memoTudo = null;        //JTextArea geral
  private static JTextArea memoPassageiros = null; //JTextArea dos Passageiros
  private static JTextArea memoCarro = null;       //JTextArea dos Carros

  private static JList lstCarros = null;           //JList com o status dos carros
  private static JList lstPassageiros = null;      //JList com o status dos passageiros


  /**
   * Metodo de inicializa��o do LogController.
   * Com ele o LogController recebera a Janela que contem
   * os componentes que ele deve atualizar.
   *
   * @param l Instacia da Janela Principal
   */
  public static void init(LogFrame l) {
    lf = l;
    memoTudo = lf.getMemoTudo();
    memoPassageiros = lf.getMemoPassageiros();
    memoCarro = lf.getMemoCar();
    lstCarros = lf.getListCarros();
    lstPassageiros = lf.getListPassageiros();
  }


  /**
   * Envio de mensagens para a saida padrao.
   *
   * @param msg Mensagem de Texto.
   */
  public static void log(String msg) {
    log(msg, null);
  }


  /**
   * Metodo principal de envio de mensagens para a
   * saida padrao e atualiza��o da janela principal.
   *
   * @param msg mensagem de texto
   * @param o objeto que invoca a mensagem
   */
  public static void log(String msg, Object o) {
    memoTudo.append(msg + "\n");
    memoTudo.setCaretPosition(memoTudo.getCaretPosition() + msg.length() + 1);
    System.out.println(msg);

    if (o != null) {
      if (o instanceof Passageiro) {
        memoPassageiros.append(msg + "\n");
        memoPassageiros.setCaretPosition(memoPassageiros.getCaretPosition() + msg.length() + 1);
        lstPassageiros.repaint();
      }

      if (o instanceof TouringCar) {
        memoCarro.append(msg + "\n");
        memoCarro.setCaretPosition(memoCarro.getCaretPosition() + msg.length() + 1);
        lstCarros.repaint();
      }
    }
  }


  /**
   * Devolve a instancia existente de JFrame
   *
   * @return instancia interna de JFrame
   */
  public static JFrame getFrame() {
    return lf;
  }

}