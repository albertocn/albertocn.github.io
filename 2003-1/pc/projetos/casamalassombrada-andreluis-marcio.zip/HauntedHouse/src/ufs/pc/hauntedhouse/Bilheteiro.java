package ufs.pc.hauntedhouse;

import java.util.List;
import java.util.LinkedList;

import ufs.pc.hauntedhouse.semaforo.*;
import ufs.pc.hauntedhouse.ui.LogController;


/**
 * <p>Classe principal de controle da casa mal-assombrada.
 * Todas os passageiros e o carro acessam os metodos desta classe
 * que entao faz todos os controles da aplica��o.</p>
 *
 * <p>Os metodos acionados por passageiros e carro seguem a seguinte
 * seq��ncia:</p>
 *   Passageiros                        Carro
 *   ------------------------------     -----------------------------
 *   bilheteiro.entrarNaFila()          bilheteiro.carregarCarro()
 *   bilheteiro.ocuparPoltrona()        bilheteiro.descarregarCarro()
 *   bilheteiro.esperarPorPasseio()
 *   bilheteiro.esperarPorPasseio()
 *
 * <p>Title: Casa Mal - Assombrada</p>
 * <p>Description: Trabalho de Programacao Concorrente</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Andre Luis & Marcio Carvalho
 * @version 1.0
 */
public class Bilheteiro {

  //Fila de passageiros
  private List fila;

  //################# Semaforos utilizados pela aplica��o ######################
  private MutEx semFila;                 //Semaforo binario de acesso aa fila.

  private Semaforo semPassageiros;       //Semaforo contador para informar ao bilheteiro
                                         //quantos passageiros chegaram na fila.

  private Semaforo semPasseio;           //Semaforo contador que avisa um a um
                                         //os passageiros que podem entrar no
                                         //carro.

  private Semaforo semEsperaPorPasseio;  //Semaforo contador que avisa um a um
                                         //os passageiros que podem sair do carro
                                         //pois o passeio acabou.
  //############################################################################

  private long startTime;  //Instante em que a aplica��o eh iniciada.
  private int tempoTotal;      //Duracao da execucao em segundos.



  /**
   * Construtor padrao do bilheteiro. Inicializa seus
   * semaforos e marca o instante que a aplica��o
   * iniciou.
   *
   * @param tempoTotal tempo total de execucao em segundos
   */
  public Bilheteiro(int tempoTotal) {
    this.fila = new LinkedList();

    //Inicia aberto
    this.semFila = new MutEx(true);

    //Inicia fechado
    this.semPassageiros = new Semaforo(0);

    //Inicia fechado
    this.semEsperaPorPasseio = new Semaforo(0);

    //Inicia fechado
    this.semPasseio = new Semaforo(0);

    //Marca o instante em a aplica��o iniciou
    this.startTime = System.currentTimeMillis();
    this.tempoTotal = tempoTotal;
  }


  /**
   * M�todo principal de controle da entrada de passageiros no
   * carro.
   *
   * @param carro TouringCar que deseja ser carregado.
   */
  public void carregarCarro(TouringCar carro) {
    log("aguardando o bilheteiro encher o carro");

    Bilhete ticket = null;

    //Enquanto couberem passageiros no carro
    while(carro.getPesoAtual() <= carro.getCapacidade()) {
      //Faz o carro esperar por passageiros na fila
      semPassageiros.p();

      //Pede acesso exclusivo aa fila.
      semFila.p();
      ticket = (Bilhete) fila.get(0); //Consulta o primeiro bilhete da fila

      //Se carro aguenta o peso do passageiro dono do bilhete consultado
      if (ticket.getPassageiro().getPeso() + carro.getPesoAtual() <= carro.getCapacidade()) {
        //Remove o bilhete da fila
        fila.remove(0);

        //Libera o acesso aa fila
        semFila.v();

        //Adiciona o passageiro no carro...
        carro.addPassageiro(ticket.getPassageiro());
        ticket.liberar(); //...e libera o ticket

      } else {  //carro encheu e deve ser liberado
        semPassageiros.v();  //incremento o semaforo porque eu nao retirei o
                             //passageiro ao executar o "fila.get(0)" acima
        //Libero a fila
        semFila.v();

        //Para cada passageiro no carro...
        int numPass = carro.getPassageiros().size();
        for (int i = 0 ; i < numPass ; i++)
          semEsperaPorPasseio.v(); //...aviso que o passeio vai comecar

        break;
      }
    }
  }


  /**
   * Descarrega o conte�do do carro ap�s o mesmo realizar
   * um passeio pela casa mal-assombrada.
   *
   * @param carro TouringCar que deseja ser descarregado
   */
  public void descarregarCarro(TouringCar carro) {

    //Para todo passageiro no carro...
    int numPass = carro.getPassageiros().size();
    for (int i = 0 ; i < numPass ; i++)
      semPasseio.v(); //...aviso que o passeio acabou

    carro.descarregar(); //Delega a descarregamento ao proprio carro.
    log("carro descarregado.");
  }


  /**
   * Metodo invocado pelo passageiro no momento em que
   * ele deseja entrar na fila.
   *
   * @param passageiro Passageiro que deseja entrar no carro.
   */
  public void entrarNaFila(Passageiro passageiro) {
    //Pede acesso exclusivo aa fila
    semFila.p();

    Bilhete ticket = new Bilhete(passageiro);  //cria um bilhete para o passageiro
    fila.add(ticket);        //Adiciona o ticket do passageiro na fila

    semPassageiros.v();      //Avisa ao carro que tem gente na fila
    semFila.v();
    //Libera o acesso aa fila

    log("entrou na fila");
    ticket.travar();         //Trava o passageiro ligado a este bilhete
  }


  /**
   * Metodo invocado pelo passageiro ap�s entrar na fila.
   *
   * @param passageiro Passageiro que deseja entrar na fila
   */
  public void ocuparPoltrona(Passageiro passageiro) {
    log("saiu da fila");
  }


  /**
   * Metodo invocado pelo passageiro ap�s ocupar uma
   * poltrona do carro.
   *
   * @param passageiro Passageiro que deseja esperar pelo
   * passeio.
   */
  public void esperarPorPasseio(Passageiro passageiro) {
    log("est� esperando por passeio");
    semEsperaPorPasseio.p();
  }


  /**
   * Metodo invocado pelo passageiro no momento em que o
   * passeio ira comecar.
   *
   * @param passageiro Passageiro que deseja passear.
   */
  public void passear(Passageiro passageiro) {
    log("PASSEANDO NA CASA MAL-ASSOMBRADA...");
    semPasseio.p();          //Aguarda o passeio acabar zzzzzzzzzzzzz...
  }


  /**
   * Metodo principal de log.
   *
   * @param s Mensagem a ser exibida.
   */
  public void log(String s) {
    Thread t = Thread.currentThread();
    LogController.log("[" + t.getName() + "] " + s +
                       " TIME: " + (System.currentTimeMillis() - this.startTime), t);
  }


  /**
   * Informa aas outras threads controladas ate quando elas
   * devem continuar.
   *
   * @return se as threads devem continuar
   */
  public boolean deveContinuar() {
    return (System.currentTimeMillis() - this.startTime) < (this.tempoTotal * 1000);
  }


  /**
   * <p>Title: Casa Mal - Assombrada</p>
   * <p>Description: Classe que representa um bilhete, relacionando<br>
   *                 um passageiro a um lugar na fila.</p>
   * <p>Copyright: Copyright (c) 2003</p>
   * <p>Company: UFS</p>
   * @author Andre Luis & Marcio Carvalho
   * @version 1.0
   */
  private class Bilhete implements java.io.Serializable, Ticket {
    private Passageiro passageiro;
    private MutEx lock;

    /**
     * Contrutor padrao de um bilhete
     *
     * @param p Passageiro dono do bilhete.
     */
    Bilhete(Passageiro p) {
      this.passageiro = p;
      lock = new MutEx(false); //Cria um mutex
    }


    /**
     * Consulta o passageiro ligado a este bilhete.
     *
     * @return passageiro ligado a este bilhete.
     */
    public Passageiro getPassageiro() {
      return this.passageiro;
    }


    /**
     * Bloquea o passageiro at� que ele possa
     * entrar no carro.
     */
    public void travar() {
      lock.p(); //vai dormir ate ser chamado pelo Bilheteiro
    }


    /**
     * Invocado pelo bilheteiro para liberar o
     * passageiro dono deste bilhete para poder
     * entrar no carro.
     */
    public void liberar() {
      lock.v();
    }


    /**
     * Descri��o textual do bilhete. Nome do dono.
     *
     * @return nome do dono do bilhete
     */
    public String toString() {
      return passageiro.toString();
    }
  }
}