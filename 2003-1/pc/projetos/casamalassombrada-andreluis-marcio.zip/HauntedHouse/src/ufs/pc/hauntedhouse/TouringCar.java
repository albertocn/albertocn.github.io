package ufs.pc.hauntedhouse;

import java.util.List;
import java.util.LinkedList;
import java.util.Collections;
import java.util.Iterator;
import javax.swing.ImageIcon;

import ufs.pc.hauntedhouse.ui.Listable;


/**
 * Classe Carro de Passeio da aplica��o Casa Mal-assombrada.
 * Atrav�s dela que os passageiros passeam na casa.
 * Seu funcionamento consiste basicamente em pedir para o
 * bilheteiro o carregar, passear no parque e depois pedir
 * para o bilheteiro o descarregar.
 *
 * <p>Title: Casa Mal - Assombrada</p>
 * <p>Description: Trabalho de Programacao Concorrente</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Andre Luis & Marcio Carvalho
 * @version 1.0
 */
public class TouringCar extends Thread implements Listable {

  //Contador de Referencias
  private static int refCount = 0;

  /**
   * Quando o carro est� sendo carregado pelo bilheteiro.
   */
  public static final int ST_CARREGANDO    = 1;

  /**
   * Quando o carro est� levando os passageiros para passear
   * na casa mal-assombrada.
   */
  public static final int ST_PASSEANDO     = 2;

  /**
   * Quando o conte�do do carro est� sendo descarregado pelo
   * bilheteiro.
   */
  public static final int ST_DESCARREGANDO = 3;


  private int capacidade;          //capacidade em quilos do carro
  private int duracaoPasseio;      //duracao maxima do passeio no parque em segundos
  private int pesoAtual;           //peso atual ocupado pelos passageiros
  private int status;              //variavel que armazena o status da thread
  private int numAtualPassageiros;
  private List passageiros;        //O conteudo do carro
  private Bilheteiro manel;        //Referencia ao bilheteiro


  /**
   * Construtor padrao da classe TouringCar. Ele inicializa
   * as variaveis internas do objeto e ja inicia ("start()")
   * esta Thread por padrao.
   *
   * @param b referencia ao bilheteiro
   * @param capacidade quantidade em quilos que o carro suporta
   * @param duracaoPasseio duracao em segundos do passeio do carro
   */
  public TouringCar(Bilheteiro b, int capacidade, int duracaoPasseio) {
    super("TouringCar" + ++refCount);
    this.capacidade = capacidade;
    this.duracaoPasseio = duracaoPasseio;
    this.passageiros = Collections.synchronizedList(new LinkedList()); //Inicializa a lista com uma lista ligada
    this.manel = b;
    this.setStatus(ST_CARREGANDO); //status inicial

    start();  //inicaliza a thread
  }


  /**
   * Metodo principal desta classe.
   * Nele esta definido todo o funcionamento
   * de um Touring Car.
   */
  public void run() {
    manel.log(this + " iniciando...");

    while(manel.deveContinuar()) {
      //carrega o carro e o coloca pra rodar
      this.setStatus(ST_CARREGANDO);
      manel.carregarCarro(this);

      //passea na casa mal-assombrada
      this.setStatus(ST_PASSEANDO);
      this.passear();

      //descarrega o carro para aguardar por novos passageiros
      this.setStatus(ST_DESCARREGANDO);
      manel.descarregarCarro(this);
    }
  }


  /**
   * Metodo que simula o passeio de um carro na casa mal-
   * assombrada.
   */
  protected void passear() {
    //Calculo aleatorio do tempo de passeio
    long segs = Math.round(Math.random() * duracaoPasseio);

    manel.log("PASSEANDO NA CASA MAL - ASSOMBRADA POR " + segs + " SEGUNDOS");
    manel.log("Conteudo do carro: " + passageiros);

    // zzzzzzzzzzzzz....
    try { sleep( segs * 1000 ); } catch (InterruptedException ie) {}
  }


  /**
   * Metodo acionado pelo bilheteiro na hora que o carro deve
   * ser descarregado.
   */
  public void descarregar() {
    passageiros.clear();  //limpa o conteudo do carro
    pesoAtual = 0;
    numAtualPassageiros = 0;
  }


  /**
   * Metodo chamado pelo bilheteiro para adicionar
   * um passageiro neste carro.
   *
   * @param p novo passageiro
   */
  public void addPassageiro(Passageiro p) {
    this.numAtualPassageiros++;

    //insere o passageiro na lista
    this.passageiros.add(p);

    //atualiza o peso atual
    this.pesoAtual += p.getPeso();
  }


  /**
   * Atualiza o status atual do carro.
   *
   * @param newStatus novo status
   */
  protected synchronized void setStatus(int newStatus) {
    this.status = newStatus;
  }


  /**
   * Consulta o status atual do carro.
   * Pode ser: ST_CARREGANDO, ST_PASSEANDO ou ST_DESCARREGANDO.
   *
   * @return status atual
   */
  public synchronized int getStatus() {
    return this.status;
  }


  /**
   * Consulta a capacidade em quilos do carro.
   *
   * @return capacidade do carro.
   */
  public int getCapacidade() {
    return this.capacidade;
  }


  /**
   * Consulta o peso atual do carro. Ou seja o somatorio
   * dos pesos dos passageiros que estao ocupando o carro
   * neste momento.
   *
   * @return peso atual do carro.
   */
  public synchronized int getPesoAtual() {
    return this.pesoAtual;
  }


  /**
   * Consulta a duracao maxima de um passeio.
   *
   * @return duracao maxima de um passeio
   */
  public int getDuracaoPasseio() {
    return this.duracaoPasseio;
  }


  /**
   * Acesso ao conteudo do carro.
   *
   * @return lista contendo os passageiros no carro.
   */
  protected List getPassageiros() {
    return this.passageiros;
  }


  /**
   * Representacao textual deste objeto.
   *
   * @return string representando o objeto
   */
  public String toString() {
    return "Capacidade: " + this.capacidade;
  }


  /**
   * Retorna um icone representando a situacao do carro.
   * Amarelo para carregando o carro,
   * Cinza para descarregando e
   * Rosa para passeando.
   *
   * @return icone representando o status do carro.
   */
  public ImageIcon getIcon() {
    switch (this.getStatus()) {
      case ST_CARREGANDO:
        return this.YELLOW;
      case ST_DESCARREGANDO:
        return this.GRAY;
      case ST_PASSEANDO:
        return this.MAGENTA;
    }

    return null;
  }


  /**
   * Consulta uma descri��o textual do status deste carro.   *
   *
   * @return descri��o textual do status do carro.
   */
  public String getText() {
    switch (this.getStatus()) {
      case ST_CARREGANDO:
        return this.getName() + " Carregando o carro";
      case ST_DESCARREGANDO:
        return this.getName() + " Descarregando o carro";
      case ST_PASSEANDO:
        return this.getName() + " Levando os passageiros para passear no parque";
    }

    return null;
  }

}