package babuinos;

import java.awt.Container;
import java.awt.GridLayout; //gerenciador de layout usado
import java.awt.event.WindowAdapter;//
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



/** Esta � a classe principal que apresenta babu�nos em ambas as extremidades
    da corda, disputando concorrentemente o acesso � mesma. O �nico argumento
    a ser passado para esta classe � a quantidade de babu�nos a ser instanciada,
    a partir da� s�o geradas de modo n�o-determin�stico threads representando
    babu�nos desejando cruzar no setido [oeste->leste] e [leste->oeste].
   @throws NumberFormatException caso o argumento passado n�o possa ser
   convertido para um inteiro */
public class Exemplo extends JFrame{
  //private JTextArea txt_numBabuinos = new JTextArea(1,2);
  private JTextField txt_numBabuinos = new JTextField(2);
  private JTextField txt_tmax_travessia = new JTextField(2);
  private static JTextArea txtArea = new JTextArea(40,70);
  private static JScrollPane spTxtArea = new JScrollPane(txtArea,
                                             JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
  private JCheckBox assimetria = new JCheckBox();
  private JButton btnIniciar = new JButton();
  private Font font = new Font("Arial",Font.BOLD,15);

  public Exemplo(){
    Container cpainel = getContentPane();//referencia ao cotainer do JFrame
    cpainel.setLayout(null);//seta o gerenciador de layout
    //============
    btnIniciar.setText("Iniciar");
    btnIniciar.setBounds(15,1,100,30);//x,y,largura,altura
    cpainel.add(btnIniciar);
    BtnListener btn_ls = new BtnListener();
    btnIniciar.addActionListener( btn_ls );
    //=========================
    JLabel label = new JLabel("N�mero de Babu�nos:");
    label.setToolTipText( "N�mero total de babu�nos que atravessar�o o desfiladeiro");
    label.setBounds(150,1,180,30);
    label.setFont(font);
    cpainel.add(label);
    //====
    JPanel painel2 = new JPanel();
    //txt_numBabuinos.setBounds(370,7,30,20);
    txt_numBabuinos.setFont(font);
    painel2.add(txt_numBabuinos);
    painel2.setBounds(300,2,50,40);
    cpainel.add(painel2);
    //=========================
    JLabel label3 = new JLabel("Tempo M�ximo:");
    label3.setToolTipText( "Tempo m�ximo que um babuino gasta para realizar a travessia do desfiladeiro");
    label3.setBounds(380,1,120,30);
    label3.setFont(font);
    cpainel.add(label3);
    //===
    JPanel painel4 = new JPanel();
    txt_tmax_travessia.setFont(font);
    painel4.add(txt_tmax_travessia);
    painel4.setBounds(480,2,50,40);
    cpainel.add(painel4);
    //=========================
    assimetria.setText("Assimetria");
    assimetria.setSelected(true);
    CheckListener listener = new CheckListener();
    assimetria.addActionListener( listener );
    JPanel painel_ass = new JPanel();
    painel_ass.add(assimetria);
    painel_ass.setBounds(590,1,100,30);
    cpainel.add(painel_ass);
    //=========================
    JLabel labelLeste = new JLabel("Fluxo de Babu�nos Atravessando o Desfiladeiro.");
    labelLeste.setToolTipText( "Babu�nos atravessando de Oeste para Leste ou de Leste para Oeste");
    labelLeste.setBounds(140,70,500,30);
    labelLeste.setFont(new Font("Arial",Font.BOLD,17));
    cpainel.add(labelLeste);
    //=========================
    spTxtArea.setBounds(10,100,770,430);

    txtArea.setFont(font);

    cpainel.add(spTxtArea);

   addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }
  private class CheckListener implements ActionListener {
   public void actionPerformed(ActionEvent e) {
     //if (assimetria.isSelected())
         //txt_leste.setText("Assimetria selecionada");
     //else txt_leste.setText("Assimetria selecionada");
   }
  }
  private class BtnListener implements ActionListener {
  public void actionPerformed(ActionEvent e) {
    try {
        txtArea.setText("");
        int nbabuinos = new Integer(txt_numBabuinos.getText()).intValue();
        int tmax_travessia = new Integer(txt_tmax_travessia.getText()).intValue();

        Corda cj;
        if (assimetria.isSelected())
            cj = new CordaJusta();
          else
            cj = new CordaSimples();

        projB(cj,nbabuinos,tmax_travessia*1000);
    }
    catch (NumberFormatException exc){
         txtArea.setText("Erro: Par�metro Inv�lido!");
    }
  }
  }
  public void projB(Corda cj, int nbabuinos, int tmax_travessia){
      try {
        for (int i=0; i< nbabuinos; i++){
          double direcao = Math.random();
          long inicio = 0;
          long fim = System.currentTimeMillis() + Math.round(Math.random()*1000);
          //simula o tempo entre a chegada de babuinos nas estremidade
          while (inicio<fim)   inicio = System.currentTimeMillis();
          if (direcao <= 0.5)
            new Thread(new Babuino(cj,i,"leste",txtArea,tmax_travessia)).start();
          else
            new Thread(new Babuino(cj,i,"oeste",txtArea,tmax_travessia)).start();
        }
      }
      catch (NumberFormatException e){
         e.printStackTrace();
      }
  }
  public static void main(String[] args) {
    JFrame f = new Exemplo();
    f.setBounds(0,0,790,580);
    f.setTitle("Projeto Babuinos");
    //f.pack();
    f.show();

  }
}