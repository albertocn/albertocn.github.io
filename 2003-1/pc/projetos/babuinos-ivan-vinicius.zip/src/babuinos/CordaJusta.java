package babuinos;

/** Implementa a Interface Corda */

public class CordaJusta implements Corda {

/** n�mero de babu�nos atualmente atravessando <b>[oeste->leste]</b> */
  private int n_leste = 0;
/** n�mero de babu�nos atualmente atravessando <b>[leste->oeste]</b> */
  private int n_oeste = 0;
/** n�mero de babu�nos esperando para atravessar <b>[oeste->leste]</b> */
  private int n_leste_wait = 0;
/** n�mero de babu�nos esperando para atravessar <b>[leste->oeste]</b> */
  private int n_oeste_wait = 0;
/** atributo utilizado para auxiliar controle do fluxo evitando starvation
 em um dos extremos */
  private String assimetria = "";
/** N�mero de babu�nos que j� atravessaram em qualquer das duas dire��es*/
 private int cont=1;

  /** controla o fluxo de babu�nos <b>[oeste->leste]</b>*/
  public synchronized void entrar_leste() throws InterruptedException {
      ++n_leste_wait;
      while (n_oeste>0 || (n_oeste_wait>0 && (assimetria=="leste"||assimetria==""))) {
         wait();
      }
      --n_leste_wait;
      ++n_leste;
  }
  /** implementa o t�rmino da transi��o <b>[oeste->leste]</b> de um babu�no*/
  public synchronized void sair_leste() throws InterruptedException{
    --n_leste;
    assimetria = "leste";
    if (n_leste==0) notifyAll();
    ++cont;
  }

  /** controla o fluxo de babu�nos <b>[leste->oeste]</b>*/
  public synchronized void entrar_oeste() throws InterruptedException{
    ++n_oeste_wait;
    while (n_leste>0 || (n_leste_wait>0 && (assimetria=="oeste"||assimetria==""))) {
      wait();
    }
    --n_oeste_wait;
    ++n_oeste;
  }

  /** implementa o t�rmino da transi��o <b>[leste->oeste]</b> de um babu�no*/
  public synchronized void sair_oeste() throws InterruptedException{
    --n_oeste;
    assimetria = "oeste";
    if (n_oeste==0) notifyAll();
    ++cont;
  }
  /*Retorna o n�mero de babu�nos que j� atravessaram em qualquer das duas dire��es*/
  public synchronized int getCont() throws InterruptedException{
      return this.cont;
  }
}