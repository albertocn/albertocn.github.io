package babuinos;
import javax.swing.JTextArea;
import java.awt.Color;
/**
 Esta classe representa um babu�no q deseja atravessar a corda
 seja no sentido <b>[leste->oeste]</b> ou <b>[oeste->leste]</b>
 */
public class Babuino implements Runnable{

 /**Refer�ncia para um objeto que implemente a interface Corda*/
  private Corda c;
 /**Inteiro para identificar cada babu�no de modo �nico*/
  private int id;
 /**Indica a dire��o( leste ou oeste) que o babu�no vai seguir*/
  private String direcao;
 /**Indica o tempo m�ximo gasto na travessia*/
 private int tmax=4000;
 /**Indica a ordem em que os babu�nos conseguem atravessar o desfiladeiro*/
 private int cont=0;

 private JTextArea saida;

  /**Construtor padr�o da classe, apenas inicializa seus atributos*/
    public Babuino(Corda c, int id, String direcao,JTextArea saida, int tmax) {
    this.c  = c;
    this.id = id;
    this.direcao = direcao;
    this.saida = saida;
    this.tmax = tmax;
  }

  /**
   * Com base no atributo dire��o define em qual dos dois tipos se encaixa
   * o babuino:<br>
   * <b>[leste->oeste]</b> ou <b>oeste->leste]</b>
   */
  public void run() {
     if (direcao=="oeste") go_oeste();
        else if (direcao=="leste") go_leste();
                else saida.setText("Erro: dire��o invalida");
  }
  /**M�todo utilizado quando o babu�no deseja ir para o leste.
   * Respons�vel por invocar no monitor cujo babu�no tem refer�ncia
   * as opera��es de <i>entrar_leste</i> e <i>sair_leste</i> da corda
   * @throws InterruptedException situa��o na qual alguma thread que chamou
   * <i>entrar</i>ou <i>sair</i> no monitor, est� esperando e � ent�o
   * interrompida por outra thread (m�todo interrupt).
   */
  public void go_leste(){
    try {
         saida.append("[Oeste->Leste] Babu�no "+id+ " esperando...\n");
         c.entrar_leste();
         saida.append("[Oeste->Leste] Babu�no "+id+ "  atravessando...\n");
         long inicio = 0;
         long fim = System.currentTimeMillis() + Math.round(Math.random()*tmax);
         //simula o tempo de travessia do babu�no (rand�mico)
         while (inicio<fim) inicio = System.currentTimeMillis();
         saida.append("[Oeste->Leste] Babu�no "+id+ " atravessou!  ("+c.getCont()+"�)\n");
         c.sair_leste();
    }
    catch (InterruptedException e) {
      e.printStackTrace();
    }
  }
  /**M�todo utilizado quando o babu�no deseja ir para o oeste.
   * Respons�vel por invocar no monitor cujo babu�no tem refer�ncia
   * as opera��es de <i>entrar_oeste</i> e <i>sair_oeste</i> da corda
   * @throws InterruptedException situa��o na qual alguma thread que chamou
   * <i>entrar</i>ou <i>sair</i> no monitor, est� esperando e � ent�o
   * interrompida por outra thread (m�todo interrupt).
   */
  public void go_oeste(){
    try {
        saida.append("[Leste->Oeste] Babu�no "+id+ " esperando...\n");
        c.entrar_oeste();
        saida.append("[Leste->Oeste] Babu�no "+id+ "  atravessando...\n");
        long inicio = 0;
        long fim = System.currentTimeMillis() + Math.round(Math.random()*tmax);
        //simula o tempo de travessia de um babu�no (rand�mico)
        while (inicio<fim)   inicio = System.currentTimeMillis();
        saida.append("[Leste->Oeste] Babu�no "+id+ "  atravessou!  ("+c.getCont()+"�)\n");
        c.sair_oeste();
    }
    catch (InterruptedException e) {
        e.printStackTrace();
    }
  }
}