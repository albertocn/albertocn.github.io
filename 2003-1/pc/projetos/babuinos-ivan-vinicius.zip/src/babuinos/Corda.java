package babuinos;

/**
 * Interface <i>(monitor)</i> que ir� coordenar o acesso a corda
 */

public interface Corda {
       void entrar_leste() throws InterruptedException;
       void entrar_oeste() throws InterruptedException;
       void sair_leste() throws InterruptedException;
       void sair_oeste() throws InterruptedException;
       int getCont() throws InterruptedException;
}
