package carros_bate_bate;

/**
 * <p>Titulo: Semaforo </p>
 * <p>Descri��o: Impementa��o da interface semaforo utilizada no array de
 * semaforos para controlar o acesso sincronizado das pessoas aos carros. A
 * variavel do semaforo e estatica para que todo os semaforos do array possam
 * compartilhar a varivel </p>
 * @author Andre Britto de Carvalho, Rafael Melo Macieira
 * @version 1.0
 */

public class Semaforo_bate_bate implements Semaforo {

  public static int valor=0;
  public Semaforo_bate_bate() {

  }

  public synchronized void P(){
    valor--;

   if (valor < 0) {
   while (true) {
      try {
         wait();
         break;
      } catch (InterruptedException e) {
         System.err.println
            ("SemaforoBase.P(): InterruptedException, esperar novamente");
         if (valor >= 0) break;
         else continue;
      }
   }
 }
  }
  public synchronized void V(){
    valor++;

    if (valor<=0){
      notify();

    }
  }
}