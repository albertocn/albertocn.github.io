package carros_bate_bate;

/**
 * <p>Titulo: Coordenador </p>
 * <p>Descri��o:Interface do Coordenador p/ sincroniza��o de acesso aos carros </p>
 * @author Andre Britto de Carvalho, Rafael Melo Macieira
 * @version 1.0
 */

public interface Coordenador {
  void entrar_fila(Object PID);
  void preparar_carro(Object pessoa);
  void executar_passeio();
  void carregar(Object car);
  void descarregar(Object car);
}