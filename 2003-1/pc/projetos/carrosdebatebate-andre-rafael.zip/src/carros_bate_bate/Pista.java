package carros_bate_bate;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.event.*;

import java.awt.Font;

import java.util.Vector;

/**
 * <p>Titulo: Semaforo </p>
 * <p>Descri��o: Classe que implementa a interface grafica do problema, cria e
 * inicia as threads do coordenador, das pessoas e dos carros. O numeros de pessoas
 * e de carros e passado como parametro a linha de comando
 *  </p>
 * @author Andre Britto de Carvalho, Rafael Melo Macieira
 * @version 1.0
 */




public class Pista extends JFrame {

  private static JTextArea TAtexto;
  private JButton botao1;
  private JTextField TFpes;
  private JTextField TFcar;
  public static Vector vpass = new Vector();
  public static Vector vfila = new Vector();
  public static Vector vbrinc = new Vector();
  public static JList JLpass;
  public static JList JLfila;
  public static JList JLbrinc;
  private static JScrollPane SPtexto;

  /*Construtor da classe pista que inicia toda a interface grafica e recebe como
  parametro o numero de pessoas e de carros vindos da linha de comando*/

  public Pista(String pessoas, String carros) {
       super("Principal");
       Container cont = getContentPane();
       JPanel pCima = new JPanel();
       botao1 = new JButton("Come�ar");
       JLabel Lpes = new JLabel("N�mero de Pessoas: ");
       JLabel Lcar = new JLabel("N�mero de Carros");
       TFpes = new JTextField(pessoas,5);
       TFcar = new JTextField(carros,5);
       pCima.add(Lpes);
       pCima.add(TFpes);
       pCima.add(Lcar);
       pCima.add(TFcar);
       pCima.add(botao1);
       botao1.addActionListener(new comecar());
       JPanel passeando = new JPanel(new BorderLayout());
       JPanel fila = new JPanel(new BorderLayout());
       JPanel brincar = new JPanel(new BorderLayout());
       JLabel LTApass = new JLabel("Pessoas Passeando");
       LTApass.setHorizontalAlignment(SwingConstants.CENTER);
       passeando.add(LTApass,BorderLayout.NORTH);
       JLpass =  new JList(vpass);
       JLpass.setFixedCellWidth(200);
       JScrollPane SBpass = new JScrollPane(JLpass);
       passeando.add(SBpass,BorderLayout.EAST);
       JLabel LTAfila = new JLabel("Pessoas na Fila");
       LTAfila.setHorizontalAlignment(SwingConstants.CENTER);
       JLfila =  new JList(vfila);
       JLfila.setFixedCellWidth(200);
       JScrollPane SBfila = new JScrollPane(JLfila);
       fila.add(LTAfila,BorderLayout.NORTH);
       fila.add(SBfila);
       JLabel LTAcar = new JLabel("Pessoas Brincando");
       LTAcar.setHorizontalAlignment(SwingConstants.CENTER);
       JLbrinc =  new JList(vbrinc);
       JLbrinc.setFixedCellWidth(200);
       JScrollPane SBcar = new JScrollPane(JLbrinc);
       brincar.add(LTAcar,BorderLayout.NORTH);
       brincar.add(SBcar,BorderLayout.EAST);
       JPanel texto = new JPanel(new BorderLayout());
       TAtexto = new JTextArea();
       TAtexto.setRows(10);
       TAtexto.setFont(new Font("Verdana", Font.BOLD, 12));
       TAtexto.setEditable(false);
       TAtexto.setEnabled(false);
       SPtexto= new JScrollPane(TAtexto);
       JLabel Ltexto = new JLabel("Andamento...");
       texto.add(Ltexto,BorderLayout.NORTH);
       texto.add(SPtexto,BorderLayout.CENTER);
       cont.add(texto,BorderLayout.SOUTH);
       cont.add(pCima,BorderLayout.NORTH);
       cont.add(passeando,BorderLayout.WEST);
       cont.add(fila,BorderLayout.CENTER);
       cont.add(brincar,BorderLayout.EAST);
       this.addWindowListener(new WindowDemoListener());
       setSize(650,700);
       setResizable(false);
       SBpass.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
       SBfila.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
       SBcar.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
       show();

  }

  /*Metodo estatico que imprime a situacao atual de cada pessoa e de cada carro
  numa secao da interface grafica*/
   public static void imprimir(String oq){
     TAtexto.append(oq);

   }
   /*Classe que implementa a o tratamento do envento do botao que inicia as threads
   do sistema e que fecha o programa depois das threads iniciadas*/
   private class comecar implements ActionListener {

     public void actionPerformed(ActionEvent e) {

       if (botao1.getText()=="Come�ar") {
         int numcars = Integer.parseInt(TFcar.getText());
         int numpes = Integer.parseInt(TFpes.getText());
         TFcar.setEnabled(false);
         TFpes.setEnabled(false);
         Coordenador_bate_bate bilheteiro = new Coordenador_bate_bate(numpes,numcars);
         Carro[] car = new Carro[numcars];
         Pessoa[] pess = new Pessoa[numpes];
         for (int i=0;i<numcars;i++){
           car[i] = new Carro(i,bilheteiro);
         }
         for (int i=0;i<numpes;i++){
           pess[i] = new Pessoa(i,bilheteiro);
         }
         for (int i=0;i<numcars;i++){
           car[i].start();
         }
         for (int i=0;i<numpes;i++){
           pess[i].start();

         }
         JLpass.setListData(vpass);
         botao1.setText("Sair");

       }
       else{System.exit(0);}
       }
     }

  public static void main(String[] args) {
    Pista universal_park_center = new Pista(args[0],args[1]);
  }

  /*Metodo estatico que troca os nomes das pessoas das listas que elas estao
  de acordo com a situa��o das pessoas*/
  public static synchronized void nextList(String pessoa, Vector novo, Vector antigo){
    if (antigo!=null){
      antigo.remove(pessoa);}
    novo.add(pessoa);
    JLpass.setListData(vpass);
    JLfila.setListData(vfila);
    JLbrinc.setListData(vbrinc);

  }
  /*Tratamento do envento de fechar a janela*/
  class WindowDemoListener extends WindowAdapter {

  public void windowClosing(WindowEvent e)  { System.exit(0); }
}

}




