package carros_bate_bate;

/**
 * <p>Titulo: Semaforo </p>
 * <p>Descri��o: Interface de defini��o dos semaforos utilizados para
 * garantir exclus�o mutua e acesso sincronizado a secoes criticas do
 * problema </p>
 * @author Andre Britto de Carvalho, Rafael Melo Macieira
 * @version 1.0
 */

public interface Semaforo {
  void P();
  void V();
}