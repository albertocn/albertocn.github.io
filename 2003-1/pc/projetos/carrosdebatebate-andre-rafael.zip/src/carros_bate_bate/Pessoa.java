package carros_bate_bate;

/**
 * <p>Titulo:Pessoa </p>
 * <p>Descri��o: Pessoas que passeam pelo e parque e tentam ter acesso aos carros
 * utilizando metodos do coordenador </p>
 * @author Andre Britto de Carvalho, Rafael Melo Macieira
 * @version 1.0
 * @
 */


//Pessoas que andarao no brinquedo
public class Pessoa extends Thread {

  public final Integer PID; //Identifica��o da pessoa
  //public Integer CID; //Carro que a pessoa esta quando brinca
  Coordenador_bate_bate coordenador; //Coordenador do briquendo


  //Inicia a pessoa e passa o coordenado do brinquedo
  public Pessoa(int PID, Coordenador_bate_bate coord) {
    this.coordenador = coord;
    this.PID = new Integer(PID);
    setName("Pessoa " + PID);
  }


  /*
    A pessoa passeia, depois entra na filam pede um carro e come�a a brincar
    depois de brincar a pessoa sai para passear de novo e volta a brincar

  */
  public void run(){
    while(true){
    passear();
    coordenador.entrar_fila(PID);
    coordenador.preparar_carro(this);
    coordenador.executar_passeio();
    }
  }
  private void passear(){
    Pista.imprimir(Thread.currentThread().getName() + ": Passeando\n");
    Pista.nextList(Thread.currentThread().getName(),Pista.vpass,Pista.vbrinc);
    long i = (long) (Math.random() * 5000);
    try{Thread.currentThread().sleep(i);}
    catch(InterruptedException e){e.printStackTrace();}
  }

}