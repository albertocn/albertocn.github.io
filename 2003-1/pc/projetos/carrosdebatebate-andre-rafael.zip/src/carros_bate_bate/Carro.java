package carros_bate_bate;


/**
 * <p>Titulo: Carro </p>
 * <p>Descri��o: Classe que implementa o objeto carro que � disputado
 * pelas pessas e tem seu acesso contralado atraves do coordenador </p>
 * @author Andre Britto de Carvalho, Rafael Melo Macieira
 * @version 1.0
 */

public class Carro extends Thread {

  public Integer CID; //Numero do carro
  public Integer pessoa;//Pessoa carregada no carro
  private Coordenador_bate_bate coordenador; //Coordenador do brinquedo


  // Construtor do carro que recebe o numero do carro e o coordenador do brinquedo
  public Carro(int CID,Coordenador_bate_bate coord) {

    this.CID = new Integer(CID);
    this.coordenador = coord;
    setName("Carro " + CID);
    coordenador.add_fila(this);

  }


  public void andar() {

    Pista.imprimir(Thread.currentThread().getName() + ": Carro andando\n");
    long i = (long) (Math.random() * 50000);
    try{Thread.currentThread().sleep(i);}
    catch(InterruptedException e){e.printStackTrace();}

  }

  /*Acao do carro enquando estive rodando.
    Carrega uma pessoa, come�a a andar, descarrega a pessoa e volta para
    carregar outra pessoa

  */
  public void run(){

    while(true){
    coordenador.carregar(this);
    andar();
    coordenador.descarregar(this);

    }
  }
}