package carros_bate_bate;

import java.util.LinkedList;

/**
 * <p>Titulo: Coordenador </p>
 * <p>Descri��o: Classe que contem todos os metedos de sincronizacao de
 * acesso aos carros. Para acessar os carros as pessoas fazem uma requisicao
 * ao coordenador. O coordenador possui uma fila de pessoas que esperam por
 * algum carro. O coordenador tambem controla os carros que estao disponiveis
 * dando metedos para os carros poderem carregar e descarregar pessoas
 * </p>
 * @author Andre Britto de Carvalho, Rafael Melo Macieira
 * @version 1.0
 *
 */


//Objeto Coordenador que coordena a entrada e saida de pessoas no brinqudedo

public class Coordenador_bate_bate implements Coordenador {

  private int pessoas; //Numero de pessoas que vao andar no brinquedo
  private int carros; //Numero de carros do brinquedos
  private Semaforo_bate_bate[] semP; //Semaforos que irao controlar o acesso das pessoas ao brinquedo
  private LinkedList filaP; //Fila de pessoas esperando para entrar no brinquedo
  private LinkedList filaC; //Fila de carros que estao esperando uma pessoa para andar
  private static Integer p; //Pessoa que saiu da fila e se prepara para entrar em um carro
  private Semaforo semC; //Semaforo que controla a sincroniza��o dos carros com as pessoas
  private Semaforo semBrinc; //Semaforo que controla a saida da pessoa do carrinho enquanto o carro esta andando
  private Semaforo semVP; //Semaforo que controla o acesso a variavel p
  private final Object lockPes = new Object();

  /* Construtor do coordenardor do brinquedo que recebe como parametro o numero
  de pessoas e de carros e inicia os semaforos e as filas
  */

  public Coordenador_bate_bate(int num_pessoas, int num_carros) {

    pessoas = num_pessoas;
    carros = num_carros;
    semP = new Semaforo_bate_bate[pessoas+1];
    semC = new Semaforo_Carros(0);
    semBrinc = new Semaforo_Carros(0);
    semVP = new Semaforo_Carros(0);
    iniciar_semaforos(semP);
    filaP = new LinkedList();
    filaC = new LinkedList();

  }
  //Inicia o array de semaforos
  private void iniciar_semaforos(Semaforo[] sem){
    for (int i=0;i<sem.length;i++){
       sem[i] = new Semaforo_bate_bate();
    }
  }


 //Metodo no qual a pessoa pede pra entrar na fila de espera por um carro
  public void entrar_fila(Object PID){

    Integer pid = (Integer) PID;
    filaP.addLast(PID);
    Pista.imprimir(Thread.currentThread().getName()+ ": Entrou na fila\n");
    Pista.nextList(Thread.currentThread().getName(),Pista.vfila,Pista.vpass);

  }


 //Metodo que depois de ser adicionada da fila a pessoa pede um carro pra andar
  public void preparar_carro(Object pessoa){

    synchronized (lockPes) {
       Pessoa pes = (Pessoa) pessoa;
       Pista.imprimir(Thread.currentThread().getName() + ": pediu carro\n");
       try{
         semP[pes.PID.intValue()].P();} //Pede um Carro
       catch (NullPointerException e) {};
       Pista.imprimir(Thread.currentThread().getName() + ": arrumou um carro\n" );
       try{
        p = (Integer) filaP.get(0);}
       catch (ClassCastException e) {};
       semC.V();//Chama carro que esta parado esperando uma pessoa
       semVP.P();//Semaforo de acesso a variavel p
       filaP.removeFirst(); //Sai da fila de espera
       Pista.imprimir(Thread.currentThread().getName()+ ": sai da fila\n");
    }

  }

  //Metodo em que a pessoa fica "brincando no carro" e so eh liberada dele quando carro para e descarregar a pessoa

  public void executar_passeio(){
     Pista.imprimir(Thread.currentThread().getName() + ": brincando\n");
     Pista.nextList(Thread.currentThread().getName(),Pista.vbrinc,Pista.vfila);
     semBrinc.P();
     Pista.imprimir(Thread.currentThread().getName() + ": parou de brincar\n");
  }

  //Metodo em que o carro fica carrega uma pessao para poder andar

  public void carregar(Object car) {

     Carro carro = (Carro) car;
     filaC.addLast(carro);
     try{Integer num = (Integer) filaP.get(0);
     semP[num.intValue()].V();}//Avisa a primeira pessoa da fila de pessoas que o carro esta livre
     catch(IndexOutOfBoundsException i){semP[pessoas].V();}
     Pista.imprimir(Thread.currentThread().getName() + ": carro livre esperando pessoa\n");
     semC.P();//Espera pessoa vir ate o carro
     carro.pessoa = p;//carrega a pessoa
     semVP.V();
     Pista.imprimir(Thread.currentThread().getName() + ": Carregado com Pessoa " + carro.pessoa + "\n");
     filaC.remove(this); //fica pronto para andar}


  }
  //Metodo que avisa a pessoa que a corrida acabou
  public void descarregar(Object car){
     Carro carro = (Carro) car;
     Pista.imprimir(Thread.currentThread().getName() + ": Carro descarregado\n");
     semBrinc.V();
  }

  public void add_fila(Object car){
     filaC.add(car);
  }
}

