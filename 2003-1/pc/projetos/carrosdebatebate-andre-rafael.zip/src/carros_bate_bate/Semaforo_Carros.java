package carros_bate_bate;

/**
 * <p>Titulo: Semaforo </p>
 * <p>Descri��o: Impementa��o da interface semaforo utilizada em semaforos para
 * acesso sincronizado de objetos </p>
 * @author Andre Britto de Carvalho, Rafael Melo Macieira
 * @version 1.0
 */


public class Semaforo_Carros implements Semaforo {
  public int valor;
  public Semaforo_Carros(int val) {
   this.valor=val;
 }

 public synchronized void P(){
   valor--;

   if (valor < 0) {
   while (true) {
      try {
         wait();
         break;
      } catch (InterruptedException e) {
         System.err.println
            ("SemaforoBase.P(): InterruptedException, esperar novamente");
         if (valor >= 0) break;
         else continue;
      }
   }
 }
 }
 public synchronized void V(){
   valor++;
   if (valor<=0){
     notify();

   }
  }
}