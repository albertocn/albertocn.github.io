package carrosbatebate;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.Timer;

import java.util.Vector;
import java.util.List;
import java.util.Date;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

/**
 * Simula��o gr�fia dos carros de bate bate em um parque
 * de divers�es. As pessoas s�o representadas por but�es
 * cujo r�tulo � da forma 'PI' (onde I � o identificador
 * da pessoa, que vai de zero a (n�mero de pessoas - 1)).
 * Uma pessoa pode estar passeando pelo parque, conduzindo
 * um carro ou na fila. As pessoas conduzindo um carro
 * tamb�m s�o representadas por um bot�o cujo r�tulo � da
 * forma 'PICJ' (onde I � o identificador da pessoa e J �
 * o identificador do carro (que vai de zero a n�mero de
 * carros - 1)). Os carros tamb�m s�o representados por
 * but�es cujo r�tulo � da forma 'CJ' (onde J � o identificador
 * do carro (que vai de zero a n�mero de carros - 1))
 * <p>Copyright: Copyright (c) 2003</p>
 *
 * @author Manoel Messias da S. M. J�nior, Jos� Carlos do Santos J�nior
 * @version 1.0
 */

public class SimulacaoGrafica extends JFrame {

    /**
     * Representa a fila de pessoas.
     */
    private JPanel filaPanel = new JPanel();

    /**
     * Representa a pista dos carros de bate bate.
     */
    private JPanel pistaPanel = new JPanel();

    /**
     * Representa as pessoas que est�o passeando pelo parque.
     */
    private JPanel passeioPanel = new JPanel();

    /**
     * Exibe a hora atual.
     */
    private JLabel hora = new JLabel();

    /**
     * �rea de texto que representa o log das a��es das
     * pessoas.
     */
    private JTextArea logTextArea = new JTextArea();

    /**
     * Atualiza a hora.
     */
    private Timer timerHora = new Timer( 50, new TimerListener() );

    /**
     * But�es que representam as pessoas.
     */
    private JButton[] pessoas;

    /**
     * But�es que representam os carros.
     */
    private JButton[] carros;


    public SimulacaoGrafica(long tempoSimulacao,
                            double tempoConducao,
                            double tempoPasseio,
                            int numPessoas,
                            int numCarros) {

        super("Carros de Bate Bate");

        setSize(getMaximumSize());

        pessoas = new JButton[numPessoas];
        carros = new JButton[numCarros];

        criarBotoes(pessoas, 'P');
        criarBotoes(carros, 'C');

        adicionarButoes(passeioPanel, pessoas);
        adicionarButoes(pistaPanel, carros);

        Border borda = BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "FILA");

        filaPanel.setBorder(borda);
        filaPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 2, 2));

        borda = BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "PISTA");

        pistaPanel.setBorder(borda);
        pistaPanel.setLayout(new GridLayout(10, 10));

        borda = BorderFactory.createTitledBorder(
                BorderFactory.createEtchedBorder(), "PASSEIO PELO PARQUE");

        passeioPanel.setBorder(borda);
        passeioPanel.setLayout(new GridLayout(10, 10));

        // Cont�m a fila de pessoas, a pista e o local de passeio (passeioPanel)
        JPanel parque = new JPanel();
        parque.setLayout(new BorderLayout());
        parque.add(filaPanel, BorderLayout.NORTH);
        parque.add(pistaPanel, BorderLayout.WEST);
        parque.add(passeioPanel, BorderLayout.EAST);

        // Barra de status que exibe o n�mero de pessoas, carros, tempo da
        // simula��o, tempos padr�es de passeio e condu��o, e a hora.
        JPanel barraStatus = new JPanel();
        barraStatus.setLayout(new FlowLayout(FlowLayout.LEFT));
        barraStatus.add(new JLabel(" Pessoas (P) = " + numPessoas
                                  + " | Carros (C) = " + numCarros
                                  + " | Tempo Simula��o = " + (tempoSimulacao/1000.0) + " s"
                                  + " | Tempo Passeio = " + (tempoPasseio/1000.0) + " s"
                                  + " | Tempo Condu��o = " + (tempoConducao/1000.0) + " s"));
        barraStatus.add(hora);

        logTextArea.setEditable(false);

        JScrollPane sp = new JScrollPane(logTextArea);
        sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        // Cont�m o logTextArea e barraStatus
        JPanel logPanel = new JPanel();
        logPanel.setLayout(new BorderLayout());
        logPanel.add(sp, BorderLayout.CENTER);
        logPanel.add(barraStatus, BorderLayout.SOUTH);

        Container cp = getContentPane();
        cp.setLayout(new GridLayout(2, 1));
        cp.add(parque);
        cp.add(logPanel);

        timerHora.start();

        // Registra o listener para parar o timer quando a janela for fechada
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                timerHora.stop();
            }
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    /**
     * Instancia os JButton no array de JButton passado
     *
     * @param botoes array de JButton
     * @param c indica como ser� o label do JButton
     */
    private void criarBotoes(JButton[] botoes, char c) {
        for (int i = 0; i < botoes.length; i++)
            botoes[i] = new JButton("" + c + i);
    }

    /**
     * Adiciona os JButton do array 'botoes' no JPanel passado
     *
     * @param panel JPanel onde os JButton ser�o adicionados
     * @param botoes JButton a serem adicionados no JPanel 'panel'
     */
    private void adicionarButoes(JPanel panel, JButton[] botoes) {
        for (int i = 0; i < botoes.length; i++)
            panel.add(botoes[i]);
    }

    /**
     * Atualiza��o da hora pelo timer
     */
    private class TimerListener implements ActionListener {
        public void actionPerformed (ActionEvent e) {
            atualizarHora();
        }
    }


    /**
     * Atualiza o JLabel hora.
     */
    private void atualizarHora() {
       this.hora.setText( " | Hora: " + getHora());
    }

    /**
     * Pega a hora no formato "H:mm:ss"
     *
     * @return string contendo a hora.
     */
    private String getHora() {
        DateFormat df = new SimpleDateFormat( "H:mm:ss" );
        return df.format( new Date() );
    }

    /**
     * Adiciona a pessoa na fila (filaPanel). Imprime no logTextArea a chegada
     * da pessoa na fila.
     *
     * @param pid identificador da pessoa.
     */
    public void adicionarNaFila(int pid) {
        filaPanel.add(pessoas[pid]);
        logTextArea.append("Pessoa[" + pid + "] entrou na fila\n");

        // Mant�m sempre vis�vel no logTextArea a parte final do texto
        logTextArea.setCaretPosition(logTextArea.getText().length());
    }

    /**
     * Remove a primeira pessoa da fila e atualiza o componente filaPanel
     * (revalidate()).
     */
    public void removerDaFila() {
        filaPanel.remove(0);
    }

    /**
     * Adiciona uma pessoa na pista em um carro livre. Imprime o logTextArea que
     * a pessoa est� conduzindo o carro.
     *
     * @param pid identificador da pessoa.
     * @param cid identificador do carro.
     */
    public void entrarNaPista(int pid, int cid) {
        carros[cid].setText("P" + pid + carros[cid].getText());
        logTextArea.append("Pessoa[" + pid + "] conduzindo o Carro[" + cid
                           + "]\n");

        // Mant�m sempre vis�vel no logTextArea a parte final do texto
        logTextArea.setCaretPosition(logTextArea.getText().length());
    }

    /**
     * Remove a pessoa da pista e imprime no logTextArea que a pessoa terminou
     * de conduzir o carro.
     *
     * @param pid identificador da pessoa.
     * @param cid identificador do carro.
     */
    public void removerDaPista(int pid, int cid) {
        carros[cid].setText("C" + cid);
        logTextArea.append("Pessoa[" + pid + "] terminou de conduzir o Carro["
                           + cid + "]\n");

        // Mant�m sempre vis�vel no logTextArea a parte final do texto
        logTextArea.setCaretPosition(logTextArea.getText().length());
    }

    /**
     * Adiciona a pessoa no passeioPanel. Imprime no logTextArea que a pessoa
     * est� passeando pelo parque.
     *
     * @param pid identificador da pessoa.
     */
    public void comecarAPassear(int pid) {
        passeioPanel.add(pessoas[pid]);
        logTextArea.append("Pessoa[" + pid + "] passeando pelo parque\n");

        // Mant�m sempre vis�vel no logTextArea a parte final do texto
        logTextArea.setCaretPosition(logTextArea.getText().length());
    }

    /**
     * Remove a pessoa do passeioPanel
     *
     * @param pid identificador da pessoa.
     */
    public void terminarDePassear(int pid) {
        passeioPanel.remove(pessoas[pid]);
    }
}