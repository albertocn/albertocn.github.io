package carrosbatebate;

import java.util.List;
import java.util.Vector;

import semaforo.Semaforo;
import semaforo.SemaforoBinario;
import semaforo.SemaforoContador;

/**
 * Classe que cont�m m�todos que ser�o usados
 * pelas threads de Pessoa (ficarNaFila(int pid), entrarNoCarro(int pid)
 * e conduzir(int pid)) e Carro (carregar(cid) e liberar(int pid, int cid)),
 * para isto, cont�m sem�foros (controlarConducaoSems, elementos, mutexFila)
 * necess�rios para realizar a sincroniza�ao destas threads.
 * <p>Copyright: Copyright (c) 2003</p>
 *
 * @author Manoel Messias da S. M. J�nior, Jos� Carlos dos Santos J�nior
 * @version 1.0
 */
public class Coordenador {

    /**
     * Tamanho do buffer limitado que representa a fila de pessoas
     * (filaDePessoas).
     */
    private static final int TAMANHO_BUFFER = 15;

    /**
     * Uma pessoa demora um tempo, gerado aleatoriamente entre 0 e
     * tempoConducao (em milisegundos), conduzindo um carro de bate-bate.
     */
    private static double tempoConducao;

    /**
     * Mant�m o tempo da simulac�o em milisegundos.
     */
    private static double tempoSimulacao;

    /**
     * In�cio da simula��o
     */
    private static long inicio;

    /**
     * Tamanho do array de semaf�ros controlarConducaoSems
     */
    private static int tamanhoArraySems;

    /**
     * Array de sem�foros que ser� usado pelas threads de Pessoa
     * e Carro para simular a espera na fila e a condu��o de um carro
     * pelas Pessoas. Cada thread Pessoa utiliza um semaf�ro deste
     * array de acordo com o seu identificador que vai de 0 a
     * controlarConducaoSems.length - 1.
     */
    private Semaforo[] controlarConducaoSems;

    /**
     * Referencia uma inst�ncia de um sem�foro contador inicializado com zero
     * para controlar o n�mero de elementos na fila de pessoas, evitando que
     * uma thread Carro tente retirar o primeiro da fila quando a fila estiver
     * vazia.
     */
    private Semaforo elementos = new SemaforoContador(0);

    /**
     * Semaforo contador que controla o n�mero de espa�os vazios
     * no buffer limitado filaDePessoas.
     */
    private Semaforo espacos = new SemaforoContador(TAMANHO_BUFFER);

    /**
     * Referencia uma inst�ncia de um sem�foro bin�rio inicializado com 1 (um)
     * para garantir exclus�o m�tua na fila de pessoas, pista e passeio (estes
     * dois �tilimos da interface gr�fica).
     */
    private Semaforo mutex = new SemaforoBinario(1);

    /**
     * Representa a fila de pessoas esperando por um carro livre.
     * Buffer limitado de tamanho = TAMANHO_BUFFER
     */
    private List filaDePessoas;

    /**
     * Simula��o gr�fica do parque de divers�es.
     */
    private static SimulacaoGrafica sg;

    /**
     * Inicializa os atributos tempoConducao, tamanhoArraySems e sg com os
     * respectivos argumentos, instancia os sem�foros de controlarConducaoSems
     * com sem�foros bin�rios incializados com zero, calcula o tempo de in�cio
     * da simula��o e instancia um Vector para filaDePessoas.
     *
     * @param tempoConducao uma pessoa demora entre 0 e tempoConducao
     * (milisegundos) conduzindo um carro.
     * @param tamanhoArraySems tamanho do array de sem�foros
     * controlarConducaoSems.
     * @param tempoSimulacao tempo da simula��o.
     * @param sg Simula��o gr�fica.
     */
    public Coordenador(double tempoConducao,
                       int tamanhoArraySems,
                       long tempoSimulacao,
                       SimulacaoGrafica sg) {

        this.tempoConducao = tempoConducao;
        this.tempoSimulacao = tempoSimulacao;
        this.tamanhoArraySems = tamanhoArraySems;
        this.sg = sg;
        this.inicio = System.currentTimeMillis();

        controlarConducaoSems = new Semaforo[this.tamanhoArraySems];

        for (int i = 0; i < tamanhoArraySems; i++)
            controlarConducaoSems[i] = new SemaforoBinario(0);

        filaDePessoas = new Vector();
    }

    /**
     * Chamado pelas threads de Pessoa para inserir seu identificdor
     * em filaDePessoas.
     *
     * @param pid identificador da Pessoa.
     * @return posi��o na qual a pessoa se encontra na fila.
     */
    public int ficarNaFila(int pid) {
        int posicao;

        // Fica bloqueada se n�o tiver espa�o em filaDePessoas
        espacos.P();

        // Garante exclus�o m�tua na fila (da interface gr�fica e filaDePessoas)
        // de pessoas e passeio (interface graf.)
        mutex.P();

        // Na interface gr�fica a pessoa terminou de passear e foi para fila
        sg.terminarDePassear(pid);
        sg.adicionarNaFila(pid);

        // Adiciona o identificador da pessoa no final da fila de pessoas.
        filaDePessoas.add(new Integer(pid));


        // Calcula a posi��o da pessoa na fila.
        posicao = filaDePessoas.size();

        // Libera o acesso a se��o cr�tica
        mutex.V();

        // Indica que a fila de pessoas n�o est� vazia
        elementos.V();

        return posicao;
    }

    /**
     * Chamado pelas threads de Pessoa que ficam bloqueadas na fila
     * at� que tenha um carro livre para ser conduzido.
     *
     * @param pid identificador da Pessoa.
     */
    public void entrarNoCarro(int pid) {
        controlarConducaoSems[pid].P();
    }

    /**
     * Chamado pelas threads de Pessoa que ficam bloquedas enquanto
     * estiverem conduzindo um carro.
     *
     * @param pid identificador da Pessoa.
     */
    public void conduzir(int pid) {
        controlarConducaoSems[pid].P();
    }

    /**
     * Chamado por um carro livre para carregar a primeira pessoa
     * da fila para conduzi-lo.
     *
     * @return identificador da pessoa da primeira posi��o da fila.
     */
    public int carregar(int cid) {
        // A thread carro fica bloqueada caso a fila esteja vazia
        elementos.P();

        // Garante exclus�o m�tua na fila (da interface gr�fica e filaDePessoas)
        // de pessoas e pista (interface gr�fica)
        mutex.P();

        // Remove a primeira pessoa da fila
        Integer pid = (Integer) filaDePessoas.remove(0);

        // Na interface gr�fica a pessoa sai da fila e entra em um carro na pista
        sg.removerDaFila();
        sg.entrarNaPista(pid.intValue(), cid);

        // Libera esta pessoa para entrar no carro.
        controlarConducaoSems[pid.intValue()].V();

        // Libera o acesso a se��o cr�tica
        mutex.V();

        // Indica que filaDePessoas tem espa�o
        espacos.V();

        return pid.intValue();
    }

    /**
     * Chamado por um carro que est� sendo conduzido para liberar a
     * pessoa para passear pelo parque quando o tempo de condu��o
     * se esgotar.
     *
     * @param pid identificador da pessoa
     * @param cid identificador do carro
     */
    public void liberar(int pid, int cid) {

        // Garante a thread de carro exclus�o m�tua na pista e passeio da
        // interface gr�fica
        mutex.P();

        // Na interface gr�fica a pessoa sai da pista e vai passear
        sg.removerDaPista(pid, cid);
        sg.comecarAPassear(pid);

        // libera o acesso a se��o cr�tica
        mutex.V();

        controlarConducaoSems[pid].V();
    }

    /**
     * Faz a thread corrente domir pelo tempo especificado em milisegundos.
     *
     * @param tempo tempo em milisegundos.
     */
    public void dormir(long tempo) {
      try {
        Thread.currentThread().sleep( tempo );
      } catch (InterruptedException ie) { ie.printStackTrace(); }
    }

    /**
     * Calcula o tempo de condu��o que deve estar entre 0 e tempoConducao.
     *
     * @return tempo que a pessoa ficar� conduzindo um determinado carro.
     */
    public long calcularTempoConducao() {
        return Math.round( Math.random() * tempoConducao );
    }

    /**
     * Verifica se o tempo da simula��o n�o se esgotou
     *
     * @return true se o tempo da simula��o ainda n�o se esgotou, caso contr�rio
     * retorna false.
     */
    public static boolean deveContinuar() {
        return System.currentTimeMillis() < inicio + tempoSimulacao;
    }
}