package carrosbatebate;

/**
 * Classe que representa um carro de bate bate de um parque de
 * divers�o.
 *
 * <p>Copyright: Copyright (c) 2003</p>
 * @author Manoel Messias da S. M. Junior, Jos� Carlos dos Santos J�nior
 * @version 1.0
 */
public class Carro implements Runnable {

    /**
     * O carro chama os m�todos do coordenador para carregar e liberar
     * uma pessoa.
     */
    private Coordenador coordenador;

    /**
     * Identificador do carro.
     */
    private int cid;

    /**
     * Identificador da pessoa que est� conduzindo o carro em um
     * determinado momento.
     */
    private int pid;

    public Carro(Coordenador coordenador, int cid) {
        this.coordenador = coordenador;
        this.cid = cid;
        this.pid = -1;
    }

    private void log(String msg) {
        System.out.println(msg);
        System.out.flush();
    }

    /**
     * A thread carro fica executando enquanto o tempo da simulac�o do parque
     * n�o se esgota.
     */
    public void run() {
        while (Coordenador.deveContinuar()) {
            long tempo;

            // Carrega a primeira pessoa da fila e o notifica para que
            // entre no carro. Mant�m o identificador da pessoa
            pid = coordenador.carregar(cid);

            log("Pessoa[" + pid + "] entrou no carro[" + cid + "]");
            log("Pessoa[" + pid + "] come�ou a conduzir o Carro[" +
                cid + "]");

            // o coordenador calcula o tempo da condu��o
            tempo = coordenador.calcularTempoConducao();

            // Dorme, simulando que a pessoa est� conduzindo o carro
            coordenador.dormir(tempo);
            log("Pessoa[" + pid + "] terminou de conduzir o Carro[" +
                cid + "] por " + tempo + " ms");

            // Libera a pessoa para passear pelo parque
            coordenador.liberar(pid, cid);
        }
    }
}