package carrosbatebate;

/**
 * Representa a simula��o dos carros de bate bate de um parque de divers�o,
 * mant�m os valores padr�es para o tempo da simula��o, tempo de conduc�o de
 * um carro, tempo de passeio pelo parque, n�mero de motoristas e n�mero de
 * carros. Estes valores podem ser sobrepostos atrav�s dos argumentos passados
 * pela linha de comando da seguinte forma:
 * <br> -r NM -c NC -b TC -w TP -R TS </br>
 * Onde:
 * <br> NM: n�mero de motoristas </br>
 * <br> NC: n�mero de carros </br>
 * <br> TC: Tempo de Condu��o (em segundos) </br>
 * <br> TP: Tempo de passeio pelo parque (em segundos) </br>
 * <br> TS: Tempo da Simula��o (em segundos) </br>
 * <p>Copyright: Copyright (c) 2003</p>
 *
 * @author Manoel Messias da S. M. J�nior, Jos� Carlos dos Santos J�nior
 * @version 1.0
 */
public class Simulacao {

    /**
     * Mant�m o tempo da simulac�o em milisegundos. O padr�o � 60000
     * milisegundos.
     */
    private static long   tempoSimulacao = 60000;

    /**
     * Mant�m o tempo de condu��o de um carro em milisegundos. O padr�o �
     * 5000 milisegundos.
     */
    private static double tempoConducao  = 5000.0;

    /**
     * Mant�m o tempo de passeio pelo parque em milisegundos. O padr�o �
     * 10000 milisegundos.
     */
    private static double tempoPasseio   = 10000.0;

    /**
     * N�mero de motorista. O Padr�o � 10.
     */
    private static int    numPessoas  = 10;

    /**
     * N�mero padr�o de carros. O padr�o � 5.
     */
    private static int    numCarros      = 5;

    public Simulacao(String[] args) {

        // Trata os argumentos da linha de comando
        tratarLinhaComando(args);

        // Checa os valores dos atributos e lan�a uma exce��o caso seja
        // um valor inv�lido

        if (tempoSimulacao <= 0)
            throw new IllegalArgumentException("tempoSimulacao <= 0");

        if (tempoConducao <= 0)
            throw new IllegalArgumentException("tempoConducao <= 0");

        if (tempoPasseio <= 0)
            throw new IllegalArgumentException("tempoPasseio <= 0");

        if (numPessoas <= 0)
            throw new IllegalArgumentException("numMotoristas <= 0");

        if (numCarros <= 0)
            throw new IllegalArgumentException("numCarros <= 0");


        // Imprime os atributos na tela
        imprimirDados();

        // Instancia a interface gr�fica da simula��o
        SimulacaoGrafica sg = new SimulacaoGrafica(tempoSimulacao,
                                                   tempoConducao,
                                                   tempoPasseio,
                                                   numPessoas,
                                                   numCarros);

        // Exibe a interface na tela.
        sg.show();


        // Instancia o coordenador
        Coordenador coordenador = new Coordenador(tempoConducao,
                                                  numPessoas,
                                                  tempoSimulacao,
                                                  sg);

        // Instancia as threads de Pessoa passando o coordenador
        // anteriormente instanciado
        for (int i = 0; i < numPessoas; i++)
            new Thread(new Pessoa(coordenador, i, tempoPasseio),
                       "Pessoa[" + i + "]").start();


        // Instancia as threads de Carro passando o coordenador
        // anteriormente instanciado.
        for (int i = 0; i < numCarros; i++)
            new Thread(new Carro(coordenador, i), "Carro[" + i + "]").start();
    }

    private static void tratarLinhaComando(String[] args) {

        // Atribui os argmentos da linha de comando aos respectivos
        // atributos, convertendo para o tipo correspondente, caso a
        // convers�o n�o possa ser feita, gera uma exce��o indicando
        // o erro de convers�o para o tipo correspondente.
        for (int i = 0; i < args.length; i += 2) {
            String tipo = "";
            try {
                switch(args[i].charAt(1)) {
                    case 'r':
                        tipo = "int";
                        numPessoas  = Integer.parseInt(args[i + 1]);
                        break;
                    case 'c':
                        tipo = "int";
                        numCarros      = Integer.parseInt(args[i + 1]);
                        break;
                    case 'b':
                        tipo = "double";
                        tempoConducao  = Double.parseDouble(args[i + 1]) * 1000;
                        break;
                    case 'w':
                        tipo = "double";
                        tempoPasseio   = Double.parseDouble(args[i + 1]) * 1000;
                        break;
                    case 'R':
                        tipo = "long";
                        tempoSimulacao = Long.parseLong(args[i + 1]) * 1000;
                        break;
                }
            } catch (NumberFormatException nfe) {
                throw new NumberFormatException("Nao eh possivel coneverter " +
                args[i + 1] + " para " + tipo);
            }
        }
    }

    /**
     * Imprime os valores na tela: n�mero de carros, n�mero de pessoas,
     * tempos da simula��o, do passeio e da condu��o.
     */
    private static void imprimirDados() {
        System.out.println( "==========================================="
                           + "\nN�mero de carros.... = " + numCarros
                           + "\nN�mero de motoristas.= " + numPessoas
                           + "\nTempo da simula��o.. = " + tempoSimulacao + " ms"
                           + "\nTempo de condu��o... = " + tempoConducao + " ms"
                           + "\nTempo de passeio.... = " + tempoPasseio + " ms"
                           + "\n"
                           + "==========================================="
                           + "\n\n" );
    }

    public static void main (String[] args) {
        new Simulacao(args);
    }
}