package carrosbatebate;

/**
 * Classe que representa uma Pessoa em um parque de divers�o.
 * <p>Copyright: Copyright (c) 2003</p>
 *
 * @author Manoel Messias da S. M. J�nior, Jos� Carlos dos Santos J�nior
 * @version 1.0
 */
public class Pessoa implements Runnable {

    /**
     * A pessoa chama os m�todos do coordenador para entrar na fila,
     * entrar no carro e conduzir.
     */
    private Coordenador coordenador;

    /**
     * Identificador da pessoa.
     */
    private int pid;

    /**
     * Uma pessoa passeia pelo parque por um tempo gerado aleatoriamente
     * entre 0 e tempoPasseio.
     */
    private static double tempoPasseio;

    public Pessoa(Coordenador coordenador,
                     int pid,
                     double tempoPasseio) {

        this.coordenador = coordenador;
        this.pid = pid;
        this.tempoPasseio = tempoPasseio;
    }

    private long cacularTempoPasseio() {
        return Math.round( Math.random() * tempoPasseio );
    }

    private void log(String msg) {
        System.out.println("Pessoa[" + pid + "] " + msg);
        System.out.flush();
    }

    /**
     * A thread Pessoa fica executando enquanto o tempo da simulac�o do
     * parque n�o se esgota.
     */
    public void run() {
        while (Coordenador.deveContinuar()) {
            int posicao;

            // Calcula o tempo de passeio pelo parque
            long tempo = cacularTempoPasseio();
            log("passeando pelo parque durante " + tempo + " ms");

            // Dorme, simulando que a pessoa est� passeando pelo parque
            coordenador.dormir(tempo);

            // Solicita ao coordenador uma posi��o na fila
            posicao = coordenador.ficarNaFila(pid);
            log("entrou na posicao " + posicao + " da fila");

            // Quando a pessoa for a primeira da fila entra em um carro
            // livre, casso contr�rio fica na fila esperando.
            coordenador.entrarNoCarro(pid);

            // Conduz o carro, na verdade fica esperando, simulando a candu��o,
            // at� que receba uma notifica��o de que a condu��o acabou, e desta
            // forma, volte a passear pelo parque.
            coordenador.conduzir(pid);
        }
    }
}