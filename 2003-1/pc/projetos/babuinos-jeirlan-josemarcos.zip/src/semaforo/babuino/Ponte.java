package semaforo.babuino;

import semaforo.SemaforoBinario;

import java.io.IOException;
import java.io.Writer;
/**
  Classe representa o meio compartilhado pelos babuinos: a Ponte.
  Estutura semelhante � vista em sala de aula com a classe BD no exemplo
  de Sem�foro.
  A diferen�a � que � adicionado um Sem�foro para sincronizar o acesso
  de todas as Threads ao m�todo Iniciar
*/
public class Ponte {

  private Writer arq;
  private int numLeste, numOeste = 0; //Conta n�mero de babu�nos que est�o na Ponte
  private SemaforoBinario mutexLeste = new SemaforoBinario(1);//Controla acesso � vari�vel compartilhada numLeste
  private SemaforoBinario mutexOeste = new SemaforoBinario(1);//Controla acesso � vari�vel compartilhada numOeste
  private SemaforoBinario semPonte = new SemaforoBinario(1);//Controla acesso � Ponte - Sincroniza��o Condicional no acesso
  private SemaforoBinario mutexIniciar = new SemaforoBinario(1);//Sincroniza o acesso de todas as Threads ao m�todo Iniciar

  String sLeste,sOeste;

  public Ponte(Writer arq) {
     this.arq = arq;
   }

  public void iniciarTravessiaLeste(Leste bLeste) throws IOException{
     sLeste = bLeste.logFile (" " + Thread.currentThread().getName());
     arq.write(sLeste + System.getProperty("line.separator"));
     arq.flush();

     //Sincroniza o acesso ao m�todo iniciar. Desta forma, somente um babu�no
     //poder� iniciarTravessia por vez, estando ele em qualquer lado (leste ou oeste)
     mutexIniciar.P();
     mutexLeste.P();
     bLeste.log ("| L |  quer atravessar                                       |numLeste=" + numLeste + "|");

     numLeste++;
     if (numLeste == 1) {
        semPonte.P();
     }

     bLeste.log ("|   |  < < < < come�ou a atravessar                          |numLeste=" + numLeste + "|");
     mutexLeste.V();
     mutexIniciar.V(); //Libera para que outros babu�nos possam iniciarTravessia
  }

  public void encerrarTravessiaLeste(Leste bLeste) {
     mutexLeste.P();
     numLeste--;
     bLeste.log ("|   |  < < < < < < < < terminou de atravessar                |numLeste=" + numLeste + "|");
     if (numLeste == 0)
       semPonte.V();
     mutexLeste.V();
  }

  public void iniciarTravessiaOeste(Oeste bOeste) throws IOException {
     sOeste = bOeste.logFile (" " + Thread.currentThread().getName());
     arq.write(sOeste + System.getProperty("line.separator"));
     arq.flush();

     mutexIniciar.P();//Sincroniza o acesso ao m�todo iniciar
     mutexOeste.P();
     bOeste.log ("| O |  quer atravessar                           |numOeste=" + numOeste + "|");
     numOeste++;
     if (numOeste == 1) {
        semPonte.P();
     }
     bOeste.log ("|   |  > > > > come�ou a atravessar              |numOeste=" + numOeste + "|");
     mutexOeste.V();
     mutexIniciar.V();
  }

  public void encerrarTravessiaOeste(Oeste bOeste) {
    mutexOeste.P();
    numOeste--;
    bOeste.log ("|   |  > > > > > > > > terminou de atravessar    |numOeste=" + numOeste + "|");
    if (numOeste == 0)
      semPonte.V();
    mutexOeste.V();
  }
}