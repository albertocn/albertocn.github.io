package semaforo.babuino;

import semaforo.Semaforo;

import java.io.IOException;

/**
  Classe representa babuinos que querem atravessar a Ponte, partindo do Oeste.
  Opera��es semelhantes �s opera��es das classes Leitor e Escritor vistas
  em sala de aula no exemplo de Sem�foro.
*/
public class Oeste implements Runnable {

  private int id;
  private Ponte ponte;

  public Oeste( int id, Ponte ponte ) {
    this.id = id;
    this.ponte = ponte;
    new Thread(this).start();
  }

  public void run() {
    try {
      dormir ( 1000 );
      ponte.iniciarTravessiaOeste( this );
      dormir ( 5000 );
      ponte.encerrarTravessiaOeste( this );
    } catch (IOException a){

     }


  }

  public void log ( String msg ) {
    if (id >= 10)
       System.out.println("[Oeste] " + id + "  " + msg );
    else
       System.out.println("[Oeste] 0" + id + "  " + msg );
  }


  public String logFile ( String msg ) {
     if (id >= 10)
        return "[Oeste] " + id + "  " + msg;
     else
        return "[Oeste] 0" + id + "  " + msg;
  }


  private void dormir (long max) {
    long tempo = Math.round( Math.random() * max );
    try {
      Thread.currentThread().sleep( tempo );
    } catch (InterruptedException ie) {
      ie.printStackTrace();
    }
  }
}