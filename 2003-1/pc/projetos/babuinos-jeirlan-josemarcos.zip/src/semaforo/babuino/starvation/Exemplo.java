package semaforo.babuino.starvation;

import java.lang.Integer;

public class Exemplo {

  public static int N_LESTE = 6;
  public static int N_OESTE = 20;

  public Exemplo() {
    Ponte ponte = new Ponte();
    criarBabuinosLeste( ponte );
    criarBabuinosOeste( ponte );
  }

  public Exemplo(int nLeste, int nOeste) {
    Ponte ponte = new Ponte();
    this.N_LESTE = nLeste;
    this.N_OESTE = nOeste;
    criarBabuinosLeste( ponte );
    criarBabuinosOeste( ponte );
  }

  private void criarBabuinosLeste( Ponte ponte ) {
    for (int i = 1; i <= N_LESTE; i++) {
      new Leste( i, ponte );
    }
  }

  private void criarBabuinosOeste( Ponte ponte ) {
    for (int i = 1; i <= N_OESTE; i++) {
      new Oeste( i, ponte );
    }
  }

  public static void main(String[] args) {
    try{
      if (args.length >= 2)
        new Exemplo(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
      else
        new Exemplo();
    } catch (Exception e){
      System.out.println("Par�metros inv�lidos. Informe param�metros inteiros");
    }
  }
}