package semaforo.babuino.starvation;

import semaforo.SemaforoBinario;

/**
  Classe representa o meio compartilhado pelos babuinos: a Ponte.
  Estutura semelhante � vista em sala de aula com a classe BD no exemplo
  de Sem�foro.
*/
public class Ponte {

  private int numLeste, numOeste = 0; //Conta n�mero de babu�nos que est�o na Ponte
  private SemaforoBinario mutexLeste = new SemaforoBinario(1);//Controla acesso � vari�vel compartilhada numLeste
  private SemaforoBinario mutexOeste = new SemaforoBinario(1);//Controla acesso � vari�vel compartilhada numOeste
  private SemaforoBinario semPonte = new SemaforoBinario(1);//Controla acesso � Ponte - Sincroniza��o Condicional no acesso

  public Ponte() { }

  public void iniciarTravessiaLeste(Leste bLeste) {
     mutexLeste.P();
     bLeste.log ("| L |  quer atravessar                                       |numLeste=" + numLeste + "|");

     numLeste++;
     if (numLeste == 1) { //Se primeiro do Leste a tentar acessar a ponte
        semPonte.P();
     }

     bLeste.log ("|   |  < < < < come�ou a atravessar                          |numLeste=" + numLeste + "|");
     mutexLeste.V();
  }

  public void encerrarTravessiaLeste(Leste bLeste) {
     mutexLeste.P();
     numLeste--;
     bLeste.log ("|   |  < < < < < < < < terminou de atravessar                |numLeste=" + numLeste + "|");
     if (numLeste == 0) //Se �ltimo do Leste, libera a ponte
       semPonte.V();
     mutexLeste.V();
  }

  public void iniciarTravessiaOeste(Oeste bOeste) {
     mutexOeste.P();
     bOeste.log ("| O |  quer atravessar                           |numOeste=" + numOeste + "|");
     numOeste++;
     if (numOeste == 1) { //Se primeiro do Oeste a tentar acessar a ponte
        semPonte.P();
     }
     bOeste.log ("|   |  > > > > come�ou a atravessar              |numOeste=" + numOeste + "|");
     mutexOeste.V();
  }

  public void encerrarTravessiaOeste(Oeste bOeste) {
    mutexOeste.P();
    numOeste--;
    bOeste.log ("|   |  > > > > > > > > terminou de atravessar    |numOeste=" + numOeste + "|");
    if (numOeste == 0) //Se �ltimo do Oeste, libera a ponte
      semPonte.V();
     mutexOeste.V();
  }
}