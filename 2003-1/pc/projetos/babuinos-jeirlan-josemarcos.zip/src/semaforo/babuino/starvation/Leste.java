package semaforo.babuino.starvation;

/**
  Classe representa babuinos que querem atravessar a Ponte, partindo do Leste.
  Opera��es semelhantes �s opera��es das classes Leitor e Escritor vistas
  em sala de aula no exemplo de Sem�foro.
*/
public class Leste implements Runnable {

  private int id;
  private Ponte ponte;

  public Leste(int id, Ponte ponte) {
    this.id = id;
    this.ponte = ponte;
    new Thread(this).start();
  }

  public void run() {
    dormir(1000);
    ponte.iniciarTravessiaLeste(this);
    dormir(5000);
    ponte.encerrarTravessiaLeste(this);
  }

  public void log ( String msg ) {
    if (id >= 10){
       System.out.println("[Leste] " + id + "  " + msg );
    }
    else{
       System.out.println("[Leste] 0" + id + "  " + msg );
    }
  }

  private void dormir(long max) {
    long tempo = Math.round(Math.random() * max);
//    log("dormindo por " + tempo + " ms");
    try {
      Thread.currentThread().sleep(tempo);
    }
    catch (InterruptedException ie) {
      ie.printStackTrace();
    }
  }
}