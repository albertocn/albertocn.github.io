package semaforo.babuino;

import semaforo.Semaforo;

import java.io.IOException;

/**
  Classe representa babuinos que querem atravessar a Ponte, partindo do Leste.
  Opera��es semelhantes �s opera��es das classes Leitor e Escritor vistas
  em sala de aula no exemplo de Sem�foro.
*/
public class Leste implements Runnable {

  private int id;
  private Ponte ponte;

  public Leste( int id, Ponte ponte ) {
    this.id = id;
    this.ponte = ponte;
    new Thread(this).start();
  }

  public void run() {
     try {
       dormir(1000);
       ponte.iniciarTravessiaLeste(this);
       dormir(5000);
       ponte.encerrarTravessiaLeste(this);
     } catch (IOException a){

     }
  }

  public void log ( String msg ) {
    if (id >= 10)
       System.out.println("[Leste] " + id + "  " + msg );
    else
       System.out.println("[Leste] 0" + id + "  " + msg );
  }

  public String logFile ( String msg ) {
    if (id >= 10)
      return "[Leste] " + id + "  " + msg;
    else
      return "[Leste] 0" + id + "  " + msg;
  }

  private void dormir (long max) {
    long tempo = Math.round( Math.random() * max );
    try {
      Thread.currentThread().sleep( tempo );
    } catch (InterruptedException ie) {
      ie.printStackTrace();
    }
  }
}