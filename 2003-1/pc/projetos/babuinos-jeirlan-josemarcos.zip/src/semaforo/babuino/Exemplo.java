package semaforo.babuino;

import java.io.IOException;
import java.io.Writer;
import java.io.FileWriter;
import java.io.File;

public class Exemplo {

  public static int N_LESTE = 6;
  public static int N_OESTE = 20;

  public Exemplo(Writer w) {
    Ponte ponte = new Ponte(w);
    criarBabuinosLeste( ponte );
    criarBabuinosOeste( ponte );
  }

  public Exemplo(Writer w,int nLeste, int nOeste) {
    Ponte ponte = new Ponte(w);
    this.N_LESTE = nLeste;
    this.N_OESTE = nOeste;
    criarBabuinosLeste( ponte );
    criarBabuinosOeste( ponte );
  }

  private void criarBabuinosLeste( Ponte ponte ) {
    for (int i = 1; i <= N_LESTE; i++) {
      new Leste( i, ponte );
    }
  }

  private void criarBabuinosOeste( Ponte ponte ) {
    for (int i = 1; i <= N_OESTE; i++) {
      new Oeste( i, ponte );
    }
  }

  public static void main(String[] args) throws IOException {

   String arquivo = "ORDEM.txt";
   Writer w = new FileWriter(arquivo);

    try{
      if (args.length >= 2)
        new Exemplo(w, Integer.parseInt(args[0]), Integer.parseInt(args[1]));
      else
        new Exemplo(w);
    } catch (Exception e){
      System.out.println("Par�metros inv�lidos. Informe param�metros inteiros");
    }
  }
}