package hauntedhousefinal;

public class SemHouse {

  public static SemaforoFIFO semFila = new SemaforoFIFO(1);
  public static SemaforoFIFO semAssentos = new SemaforoFIFO(1);

//  public static SemaforoBinario semFila = new SemaforoBinario(1);
//  public static SemaforoBinario semAssentos = new SemaforoBinario(1);
  public static SemaforoBinario semSincro = new SemaforoBinario(1);

}