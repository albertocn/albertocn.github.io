package hauntedhousefinal;

public class HauntedHouse {

  private int wCar, tTour, nPass, wMin, wMax, tWander, tTotal;
  private Carro carro;


  public HauntedHouse() {
    criarCarro();
    criarPassageiros();
  }

  public HauntedHouse(int wCar, int tTour, int nPass, int wMin, int wMax,
                      int tWander) {
    criarCarro(wCar, tTour);
    criarPassageiros(nPass, wMin, wMax, tWander);
  }


  public void criarPassageiros() {
    char[] letras = {'A','B','C','D','E','F','G','H','I','J'};
    for (int i = 0; i < 10; i++) {
      Pessoa pas = new Pessoa(carro, 10, letras[i]);
      Thread t = new Thread(pas);
      t.start();
    }
  }

  public void criarPassageiros(int nPass, int wMin, int wMax, int tWander) {
    for (char i ='A' ; i < nPass ; i++) {
      Pessoa pas = new Pessoa(carro, tWander, i, wMin, wMax);
      Thread t = new Thread(pas);
      t.start();
    }
  }

  public void criarCarro() {
    carro = new Carro();
    Thread t = new Thread(carro);
    t.start();
  }

  public void criarCarro(int wCar, int tTour) {
    carro = new Carro(wCar,tTour);
    Thread t = new Thread(carro);
    t.start();
  }



  public static void main(String[] args) {
    long inicio = System.currentTimeMillis();
    if (args.length != 0) {
        new HauntedHouse(Integer.parseInt(args[0]),
                         Integer.parseInt(args[1]),
                         Integer.parseInt(args[2]),
                         Integer.parseInt(args[3]),
                         Integer.parseInt(args[4]),
                         Integer.parseInt(args[5])
                         );
        while (System.currentTimeMillis() < inicio + Long.parseLong(args[6]))
            {};
        System.exit(0);

    } else {
      new HauntedHouse();
      while (System.currentTimeMillis() < inicio + 30) {};
      System.exit(0);
    }
  }
}