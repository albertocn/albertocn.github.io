package hauntedhousefinal;
import java.util.List;
import java.util.Iterator;

public class Carro implements Runnable{
  private int wCar, tRandon, tTour, weight = 0;
  private char cid;

  public void run() {
    while(true) {}
  }

  public Carro(){
    wCar = 1000;
    tRandon = 5;
  }

  public Carro(int weight, int tRandon){
    wCar = weight;
    this.tRandon = tRandon;
  }

  public void load(char cid, int capacity){
    weight += capacity;
  }

  public void unload(char cid, int passengers){
    weight = 0;
  }

  public int getWeight() {
    return weight;
  }

  public int getWcar(){
    return wCar;
  }

  public void passear() {
    tTour = (int)((Math.random() * tRandon));
    try { Thread.currentThread().sleep( tTour );
    } catch (InterruptedException ie) { ie.printStackTrace(); }
    weight = 0;
  }
}