package hauntedhousefinal;

import java.util.List;
import java.util.Iterator;

public class Pessoa implements Runnable{
  private int wPessoa, tWonder;
  private char pid;
  private List fila;
  private Carro carro;
  private int cont; // vari�vel axiliar usada para impedir
                    // multiplas requisi��es de takeAride

  public void run(){
    while (true) {
      getInLine(pid, wPessoa);
      takeAseat(pid);
      SemHouse.semAssentos.V();
      try { Thread.currentThread().sleep( (int)((Math.random() * tWonder)) );
      } catch (InterruptedException ie) { ie.printStackTrace(); }
      System.out.println("THREAD " + pid + " PAROU DE DORMIR");
    }
  }

  public Pessoa(Carro carro, int tWonder, char pid){
    wPessoa = (int)((Math.random()*350)+50);
    this.pid = pid;
    this.carro = carro;
    cont = 0;
  }

  public Pessoa(Carro carro, int tWonder, char pid ,int wMin, int wMax){
    wPessoa = (int)((Math.random() * (wMax - wMin) + wMin));
    this.pid = pid;
    this.carro = carro;
    this.tWonder = tWonder;
    cont = 0;
  }

// Coloca a thread em uma fila de espera
  public void getInLine(char pid, int weight){
    System.out.println("[Thread Passageiro: " + pid + " deseja entrar na fila.]");
    SemHouse.semFila.P();
    System.out.println("[Thread Passageiro: " + pid + " entrou na fila.]");
  }

// Retira um thread da fila e caso haja espa�o no carro a thread entra em uma
// fila associada aos assentos do carro, caso contrario fica esperando.

  public void takeAseat(char pid){
    SemHouse.semSincro.P();
    if (carro.getWeight() + wPessoa <= carro.getWcar()) {
      System.out.println("[Thread " + pid + " entrou no carro");
      SemHouse.semFila.V();
      waitCarFull(pid);
      carro.load('c', wPessoa);
      System.out.println("Atual peso do carro = " + carro.getWeight());
      SemHouse.semSincro.V();
      SemHouse.semAssentos.P();
    } else if (cont == 0){
      SemHouse.semSincro.V();
      cont ++;
      takeAride(pid);
      takeAseat(pid);
    } else {
      takeAseat(pid);
    }
    cont = 0;
  }

// Envia um mensagem de espera
  public void waitCarFull(char pid){
    System.out.println("[Thread " + pid + " esperando o carro encher");
  }

// Faz com que o carro comece a passear
  public void takeAride(char pid){
    System.out.println("[Thread carro come�ou a passear.]");
    carro.passear();
    System.out.println("[Thread carro terminou de passear.]");

  }

}
