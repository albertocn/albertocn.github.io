package hauntedhousefinal;

import java.util.List;
import java.util.LinkedList;
import java.util.Collections;

/* SemaforoFIFO utilizada para colocar as threads em uma fila e retirar sempre
   a primeira do topo.
*/
public class SemaforoFIFO implements Semaforo {

  private int valor;
  private List fila;

  public SemaforoFIFO(int valor) {
    this.valor = valor;
    fila = Collections.synchronizedList(new LinkedList());
  }

  private synchronized boolean testarValor() {
    valor--;
    return valor >= 0;
  }

  public void P() {
      if (!testarValor()) {
        Object esperar = new Object();
        synchronized (esperar) {
          fila.add(esperar);
          try {
            esperar.wait();
          } catch (InterruptedException e) {}

        }
      }
  }

  public synchronized void V() {
    valor++;
    if ((valor <= 0) || (!fila.isEmpty())) {
      synchronized (fila.get(0)) {
        fila.remove(0).notify();
      }
    }
  }

}

