package montrussa;

/**
 * Classe que testa a Formata��o dos parametros passados como
 * argumento na inicializa��o.
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public final class Formatacao {

    private static String[] argumentos;

    /**
     * Construtor padr�o que recebe um argumento como parametro.
     * @param args Argumentos que ser�o submetidos a testes
     */
    Formatacao(String args[]){
       this.argumentos = args;
    }

    /**
     * M�todo que verifica se um dado argumento obedece a formata��o padr�o
     * que o programa necessita.
     * @return Retorna um booleano informando se a formata��o est� correta
     */
    public boolean correta(){
       if ( (argumentos[0].compareToIgnoreCase("-C") == 0) &&
            (argumentos[2].compareToIgnoreCase("-T") == 0) &&
            (argumentos[4].compareToIgnoreCase("-N") == 0) &&
            (argumentos[6].compareToIgnoreCase("-W") == 0) &&
            (argumentos[8].compareToIgnoreCase("-R") == 0) ){
                return true;
       }else return false;
    }
}