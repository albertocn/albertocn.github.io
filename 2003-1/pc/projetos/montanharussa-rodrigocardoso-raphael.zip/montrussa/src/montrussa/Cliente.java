package montrussa;

/**
 * Classe que representa a abstra��o de um cliente que interage
 * com o parque e implementa o comportamento perante o carrinho.
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public class Cliente implements Runnable{

     private static double TEMPO_RETORNO;  /* VALOR W */

     private int id;
     private Parque parque;
     private Carro carro;
     private Semaforos semaforos;
     /* Atributos que identificam o tempo que a thread espera
        para sentar no carrinho */
     private long tempoInicialEspera = 0, tempoFinalEspera = 0;

     /**
      * Construtor do Cliente
      * @param id Identifica��o do Cliente
      * @param parque Parque no qual o cliente est�
      * @param carro Carrinho ao qual o cliente se vincula para andar
      * @param semaforos Sem�foros que controlar�o o fluxo do programa
      * @param tempor Tempo que o cliente gasta na volta ao parque
      */
     public Cliente( int id, Parque parque, Carro carro,
                     Semaforos semaforos, double tempor) {
         this.id             = id;
         this.carro          = carro;
         this.parque         = parque;
         this.semaforos      = semaforos;
         this.TEMPO_RETORNO  = tempor;
     }

     /**
      * Execucao da Thread Cliente, que tenta sucessivamente andar no carrinho
      * e depois d� voltas ao parque, para ent�o tornar a dar mais uma volta no
      * carrinho.
      */
     public void run() {
        while(true){
          /* Cliente tenta ver se h� lugar dispon�vel
             e se o carro est� totalmente desocupado */
          semaforos.mutex.P();
          if ( carro.carroPronto() ){
             solicitarPasseio();
             calcularEspera();
             /* Cliente dando a volta na Montanha Russa (ocupando os assentos) */
             semaforos.dandoVolta.P();
             liberarLugares();
             darVoltaParque();
          }else{ esperaNaFila(); }
        } /* Fim do While */
     }

     /**
       * M�todo que o clinte utiliza para solicitar
       * uma volta no carrinho da Montanha Russa
       */
     private void solicitarPasseio(){
         /* Cliente se prepara para ocupar um lugar no carrinho */
         carro.incLugaresOcupados();
         /* Libera os clientes para andarem caso a quantidade
            de passageiros for atingida */
         if (carro.getLugaresDisponiveis() == 0){
            semaforos.clientes.V();
            /* Carro n�o estar� pronto para receber mais clientes,
               pois j� est� rodando */
            carro.setCarroPronto(false);
         }
         /* Recebe o tempo inicial que o Cliente come�a
            a esperar para andar no carrinho */
         tempoInicialEspera = parque.getTempoTotal();
         log ("Esperando a liberacao do carrinho");
         /* Clientes esperam pela liberacao do carrinho para rodar.
            Caso haja voltas anteriores, espera esvaziar o carrinho */
         semaforos.mutex.V();
         semaforos.carrinho.P();
     }

     /**
      * M�todo que o clinte utiliza para calcular o
      * tempo que esperou para dar uma volta no
      * carrinho da Montanha Russa
      */
     private void calcularEspera(){
        /* Recebe o tempo final de espera para finalmente
           dar a volta no Carrinho. � necess�rio a utiliza��o
           do Sem�foro para garantir a Exclus�o M�tua */
        semaforos.mutex.P();
        tempoFinalEspera = parque.getTempoTotal();
        /* Adiciona no tempo total o tempo de espera do cliente atual */
        parque.adicionarTempoEspera(tempoFinalEspera - tempoInicialEspera);
        /* Incrementa o n�mero de Threads que esperaram para rodar */
        parque.incVezesEsperando();
        semaforos.mutex.V();
     }

     /**
      * M�todo que o clinte utiliza para liberar os
      * lugares que ocupou para que outros clientes
      * possam finalmente entrar no carrinho
      */
     private void liberarLugares(){
        semaforos.mutex.P();
        /* Clientes saindo do Carrinho */
        carro.decLugaresOcupados();
        /* Quando todos os clientes desocuparem o carro, o mesmo estar�
           pronto para outra volta na Montanha Russa */
        semaforos.mutex.V();
     }

     /**
      * Tempo em que um cliente gasta dando uma volta no parque
      * ap�s uma volta no carrinho.
      */
     private void darVoltaParque() {
        log ("Indo dar uma volta no parque");
        /* Tempo que fica dando uma volta (Randomico) */
        long tempo = Math.round( Math.random() * TEMPO_RETORNO );
        try { Thread.currentThread().sleep( tempo );
        } catch (InterruptedException ie) { ie.printStackTrace(); }
        log ("Finalizando a volta pelo parque");
     }

    /**
     * M�todo no qual o clinte, impossibilitado de andar no
     * carrinho, utiliza para ser colocado numa fila que ser�
     * notificada assim que o carrinho estiver dispon�vel.
     */
    private void esperaNaFila(){
         /* Cliente deve esperar numa fila at� que possa andar no
             carrinho. Cada cliente possui um sem�foro para sinaliza��o */
         String identificacao = Thread.currentThread().getName();
         parque.clientesEsperando.add(identificacao);
         Integer posicao = new Integer(identificacao);
         semaforos.mutex.V();
         /* Coloca o cliente para esperar */
         semaforos.esperando[ (posicao.intValue() - 1) ].P();
    }

     /**
      * Imprime uma mensagem referente ao cliente
      * @param msg Mensagem a ser impressa no video
      */
    private void log (String msg) {
        System.out.println("[Cliente" + id + "]: " + msg + " em " + parque.getTempoTotal() + " ms");
     }
}