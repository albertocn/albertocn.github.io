package montrussa.semaforos;

/**
 * Interface para a defini��o do sem�foro usado
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public interface Semaforo {
  void P();
  void V();
}
