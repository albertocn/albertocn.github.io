package montrussa.semaforos;

/**
 * Classe contendo a implementa��o b�sica para um sem�foro
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public abstract class SemaforoBase implements Semaforo {

   protected int valor = 0;

   /**
    * Construtor que fornece o valor padr�o de 0 para o semaforo.
    * Se o valor for menor que 0, abs(valor) ser� o tamanho de
    * threads esperando na fila de P().
    */
   protected SemaforoBase() {
     this(0);
   }

   /**
    * Valor usado para utiliza��o de um n�mero acima de 0.
    * @param inicial Valor inicial do sem�foro
    */
   protected SemaforoBase(int inicial) {
     if (inicial < 0) throw new IllegalArgumentException("Valor inicial < 0");
         valor = inicial;
   }

   /**
    * Implementa��o do m�todo Up para sincroniza��o do sem�foro
    */
   public synchronized void P() {
      valor--;
      if (valor < 0) {
          while (true) {
             try {
                wait();
                break;
             } catch (InterruptedException e) {
                 System.err.println("SemaforoBase.P(): InterruptedException, esperar novamente");
                 if (valor >= 0) break;
                 else continue;
               } // Fim do Catch
         } // Fim do While
       } // Fim do If
   }

   /**
    * Implementa��o do m�todo Down para sincroniza��o do sem�foro
    */
   public synchronized void V() {
      valor++;
      if (valor <= 0) notify();
   }

   /**
    * M�todo para retornar o conte�do da vari�vel valor.
    * @return Retorna o valor da vari�vel
    */
   public synchronized int valor() {
      return valor;
   }

   /**
    * M�todo de impress�o do conte�do de Valor.
    * @return Retorna a impressao do valor
    */
   public synchronized String toString() {
      return String.valueOf(valor);
   }
}