package montrussa.semaforos;

/**
 * Classe contendo a implementa��o do Sem�foro Bin�rio
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public final class SemaforoBinario extends SemaforoBase {

   /**
    * Construtor padr�o com valor inicial 0
    */
   public SemaforoBinario() {
     super();
   }

   /**
    * Construtor que aceita valor obrigat�rio de 0 ou 1
    * @param inicial Valor inicial do sem�foro
    */
   public SemaforoBinario(int inicial) {
      super(inicial);
      if (inicial > 1) throw new IllegalArgumentException("Valor diferente de 0 ou 1");
   }

   /**
    * Construtor que aceita valores booleanos como par�metro
    * @param inicial Valor inicial do sem�foro
    */
   public SemaforoBinario(boolean inicial) {
      super(inicial ? 1:0);
   }

   /**
    * Implementa��o do m�todo Down do sem�foro.<p>
    * OBS: O m�todo Up j� � definido na superclasse e funciona
    *      perfeitamente para o Sem�foro Bin�rio
    */
   public final synchronized void V() {
      super.V();
      if (valor > 1) valor = 1;
   }
}