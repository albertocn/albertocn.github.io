package montrussa.semaforos;

/**
 * Classe contendo a implementa��o do Sem�foro Contador
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public final class SemaforoContador extends SemaforoBase {

   /**
    * Defini��o do construtor padr�o com valor inicial 0
    */
   public SemaforoContador() {
     super();
   }

   /**
    * Defini��o do construtor com valor inicial diferente do padr�o
    * @param inicial Valor inicial do sem�foro
    */
   public SemaforoContador(int inicial) {
      super(inicial);
   }
}