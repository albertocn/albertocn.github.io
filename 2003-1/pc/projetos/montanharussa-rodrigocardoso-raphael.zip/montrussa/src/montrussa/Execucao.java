package montrussa;

/**
 * Classe que executa a aplica��o como um todo
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public class Execucao {

   /* Valores padr�o de execu��o */
   private static byte ASSENTOS         = 4;      /* VALOR C */
   private static double TEMPO_DA_VOLTA = 6000;   /* VALOR T */
   private static int NUM_CLIENTES      = 10;     /* VALOR N */
   private static double TEMPO_RETORNO  = 5000;   /* VALOR W */
   private static double TEMPO_EXECUCAO = 90000;  /* VALOR R */

   private Semaforos semaforos;
   private Parque parque;

   /**
    * Instanci��o dos Sem�foros e atribui��o dos valores padr�es
    */
   public Execucao() {
      this.semaforos = new Semaforos(NUM_CLIENTES);
   }

   /**
    * Instancia��o dos Sem�foros e atribui��o dos valores n�o padr�es
    * @param argumentos Parametros utilizados na linha de comando
    */
   public Execucao(String[] argumentos) {
      atribuirValores(argumentos);
      this.semaforos = new Semaforos(NUM_CLIENTES);
   }

   /**
    * M�todo que verifica se a quantidade de assentos � maior que a de clientes
    * disponiveis no parque para a volta no carrinho.
    */
   public void assentoDeSobra(){
      if (NUM_CLIENTES < ASSENTOS){
         System.out.println("[ERRO]: C > N");
         System.out.println("Numero de clientes insuficiente para a quantidade de assentos dispon�veis");
         System.exit(0);
      }
   }

   /**
    * Verifica os elementos passados como par�metro atribuindo os valores
    * nas vari�veis especificadas.
    * @param argumentos Argumentos da linha de comando que ser�o testados
    */
   public void atribuirValores(String[] argumentos) {
      if ( new Formatacao(argumentos).correta() ){
          this.ASSENTOS        = Byte.parseByte    ( argumentos[1] );
          this.TEMPO_DA_VOLTA  = Double.parseDouble( argumentos[3] );
          this.NUM_CLIENTES    = Integer.parseInt  ( argumentos[5] );
          this.TEMPO_RETORNO   = Double.parseDouble( argumentos[7] );
          this.TEMPO_EXECUCAO  = Double.parseDouble( argumentos[9] );
          assentoDeSobra();
      }else {
         System.out.println("[ERRO]: Parametros incorretos!");
         System.out.println("Use: java Execucao -C c -T t -N n -W w -R r ");
         System.exit(0);
      }
   }

   /**
    * M�todo que executa a aplicacao como um todo, instanciando-se o Parque,
    * os Clientes e o Carrinho
    */
   public void executar() {
      parque = new Parque();
      Carro carro = new Carro( parque, this.semaforos, ASSENTOS, TEMPO_DA_VOLTA, TEMPO_EXECUCAO );
      new Thread( carro , "Carro" ).start();
      new Thread( new GerarClientes( NUM_CLIENTES, parque, carro, this.semaforos, TEMPO_RETORNO), "GerarClientes" ).start();
   }

   /**
    * Programa principal que recebe os parametros do teclado para execucao. Caso n�o haja argumentos,
    * os valores padr�es ser�o preenchidos.
    * Deve seguir a forma " java Execucao -C c -T t -N n -W w -R r " onde: <p>
    * C - indica a quantidade de lugares de um carrinho (default 4)<p>
    * T - indica o tempo que cada carrinho gasta para percorrer o trajeto (default 6s)<p>
    * N - indica o n�mero de visitantes do parque que dar� voltas no carrinho (default 10)<p>
    * W - indica o tempo que cada cliente gasta dando um passeio no parque ap�s a volta (default 5s)<p>
    * R - indica o tempo de execu��o do algoritmo (default 90s)<p>
    * @param args Parametros de execu��o
    */
   public static void main(String[] args) {
      if (args.length > 0){  new Execucao(args).executar(); }
         else {  new Execucao().executar();  }
   }
}