package montrussa;

import java.util.List;
import java.util.LinkedList;

/**
 * Classe que controla o tempo de execu��o do programa e,
 * consequentemente, do carrinho na Montanha Russa
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public class Parque {

  /**
   * Cria uma estrutura de armazenamento das Threads clientes que
   * ficar�o esperando apos tentar uma volta no parque
   */
  public static List clientesEsperando = new LinkedList();

  /**
   * Informa o tempo inicial de execu��o do programa
   */
  public static final long inicio = System.currentTimeMillis();

  /**
   * Atributo que calcula o tempo total que as Threads Clientes
   * esperam para zarparem no carrinho da Montanha Russa
   */
  public static long tempoTotalEspera = 0;

  /**
   * Atributo que quantifica a quantidade de vezes que as threads
   * esperam para andar no carrinho
   */
  public static int vezesEsperando = 0;

  /**
   * M�todo que incrementa a quantidade de Threads esperando
   */
  public void incVezesEsperando(){
     this.vezesEsperando++;
  }

  /**
   * M�todo que adiciona o intervalo de tempo de espera de cada cliente
   * no tempo total.
   * @param tempo Tempo que se adiciona ao j� existente
   */
  public void adicionarTempoEspera(long tempo){
     this.tempoTotalEspera += tempo;
  }

  /**
   * M�todo que calcula o tempo m�dio que as threads esperaram para finalmente
   * dar uma volta na Montanha Russa. A id�ia � somar os valores de espera de
   * todas as threads e dividir pelas vezes que as mesmas juntas ficaram esperando
   * pelo carrinho.
   * @return Tempo de espera m�dio de cada Thread
   */
  public long calculaTempoMedioEspera(){
      try{
         tempoTotalEspera = tempoTotalEspera / vezesEsperando;
      }catch (Exception ex){ System.out.println(ex); }
      return tempoTotalEspera;
  }

   /**
    * Tempo de execu��o em rela��o ao in�cio da execu��o do Programa
    * @return Retorna o tempo decorrido ap�s execu��o do programa
    */
  public long getTempoTotal() {  return System.currentTimeMillis() - inicio;   }
}