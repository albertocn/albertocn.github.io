package montrussa;

import java.util.Iterator;

/**
 * Classe que representa a abstra��o do carrinho do parque
 * de divers�es.
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public class Carro implements Runnable{

    private static double TEMPO_EXECUCAO;  /* VALOR W */
    private static double TEMPO_DA_VOLTA;  /* VALOR T */
    private static byte ASSENTOS;          /* VALOR C */

    private static byte lugares_ocupados = 0;
    private Parque parque;
    private Semaforos semaforos;
    private static boolean pronto = true;
    private int i;

    /**
     * Construtor padrao que recebe um par�metro C de assentos T de segundos
     * gasto no tempo da volta
     * @param parque Refer�ncia do parque ao qual o carrinho est� inserido
     * @param semaforos Referencia �s vari�veis de controle do uso do carrinho
     * @param assentos Assentos dispon�veis no carrinho
     * @param tempov Tempo da volta que o carrinho d� no percurso
     * @param tempoe Tempo de atividade do carrinho
     */
    public Carro(Parque parque, Semaforos semaforos, byte assentos,
                 double tempov, double tempoe){
        this.parque   = parque;
        this.semaforos = semaforos;
        this.ASSENTOS = assentos > 0 ? assentos : 4;
        this.TEMPO_DA_VOLTA = tempov;
        this.TEMPO_EXECUCAO = tempoe;
    }

    /**
     * Execucao da Thread Carro enquanto n�o se exceder o tempo de execu��o.
     * Funciona como se o carro tivesse um predeterminado tempo de rodagem.
     */
    public void run(){
      while( parque.getTempoTotal() <= TEMPO_EXECUCAO ){
          esperandoClientes();
          liberarCarro();
          zarparCarro();
          liberarAssentos();
          liberarClientesEsperando();
          /* Carro pronto para todas as Threads solicitarem um passeio */
          setCarroPronto(true);
      }
      fecharParque();
    }

    /**
    * M�todo respons�vel pela espera do carrinho pelos clientes
    * que est�o solicitando uma volta na Montanha Russa.
    */
    private void esperandoClientes(){
        log("ESPERANDO ATINGIR A LOTACAO DE " + ASSENTOS + " PASSAGEIROS");
        /* Espera todos os clientes chegarem */
        semaforos.clientes.P();
        log("CARRINHO CHEIO. PRONTO PARA PARTIR");
    }

    /**
     * M�todo que libera o carrinho para todos os clientes que
     * estavam esperando solicitarem a entrada no carrinho da Montanha Russa
     */
    private void liberarCarro(){
       i = 0; // Contador zerado
       while ( i < lugares_ocupados ){
          /* Carrinho sendo liberado aos clientes
             para dar a volta na Montanha Russa */
          semaforos.carrinho.V();
          i++;
       }
    }

    /**
     * M�todo respons�vel pela corrida do carrinho em torno do trajeto
     * da Montanha Russa. O TEMPO_DA_VOLTA informa exatamente esse tempo
     * gasto na corrida.
     */
    private void zarparCarro(){
      log ("COMECANDO O TRAJETO");
      try { Thread.currentThread().sleep( (long) TEMPO_DA_VOLTA );
      } catch (InterruptedException ie) { ie.printStackTrace(); }
      log ("TERMINANDO O TRAJETO");
    }

    /**
     * M�todo que libera os assentos para os clientes que solicitaram
     * o carrinho possam efetivamente sentar no mesmo para iniciar
     * a volta pela Montanha Russa
     */
    private void liberarAssentos(){
       i = 0; // Contador Zerado
       while ( i < ASSENTOS ){
         /* Libera��o dos assentos do carrinho para pr�xima volta */
         semaforos.dandoVolta.V();
         i++;
      }
    }

    /**
     * M�todo que libera os clientes que estavam esperando para
     * solicitar uma volta no carrinho.
     */
     private void liberarClientesEsperando(){
        /* Percorrre toda a lista em busca de clientes eserando */
        Iterator it = parque.clientesEsperando.iterator();
        while(it.hasNext()){
           /* Retira os elementos que est�o esperando na fila */
           String s = parque.clientesEsperando.get(0).toString();
           Integer posicao = Integer.valueOf(s);
           semaforos.esperando[ (posicao.intValue() - 1) ].V();
           parque.clientesEsperando.remove(0);
        }
     }

    /**
     * M�todo que termina a execu��o do programa
     */
     private void fecharParque(){
       /* Sa�da do Sistema (Esperando terminar a �ltima volta j� iniciada) */
       System.out.println("O PARQUE FECHOU!!!");
       System.out.println("Tempo medio de espera de cada cliente eh de "+
                           parque.calculaTempoMedioEspera()+" ms");
       System.exit(0);
     }

    /**
     * M�todo que incrementa o valor dos lugares ocupados.
     * Usado quando algum cliente ocupa um assento no carrinho da Montanha Russa
     */
    public void incLugaresOcupados(){
        lugares_ocupados = lugares_ocupados <= ASSENTOS ? ++lugares_ocupados : lugares_ocupados;
    }

    /**
     * M�todo que decrementa o valor dos lugares ocupados.
     * Usado quando algum cliente desocupa um assento no carrinho da Montanha Russa
     */
    public void decLugaresOcupados(){
        lugares_ocupados = lugares_ocupados > 0 ? --lugares_ocupados : lugares_ocupados;
    }

    /**
     * Informa a quantidade de lugares no carrinho dispon�veis.
     * @return Retorna a quantidade em bytes dos lugares dispon�veis
     */
    public byte getLugaresDisponiveis()  {
        return  (byte)(ASSENTOS - lugares_ocupados);
    }

    /**
     * Informa o tempo que um carrinho faz para percorrer o trajeto de corrida
     * @return Retorna o tempo gasto na volta que o carrinho d� no trajeto
     */
    public double getTempoVolta() {  return  TEMPO_DA_VOLTA; }

    /**
     * Verifica se o carro est� pronto para correr no trajeto da Montanha Russa.
     * Em outras palavras, verifica se todos os passageiros que estavam � bordo
     * j� sa�ram do carrinho para dar lugar aos seguintes.
     * Caso seja a primeira volta do carrinho, esse valor j� � verdadeiro.
     * @return Retorna um booleando dizendo se o carro est� pronto ou n�o.
     */
    public boolean carroPronto() {  return pronto; }

    /**
     * Qualifica o status do carro como pronto ou nao
     * @param status Novo status que o carro recebe
     */
    public void setCarroPronto( boolean status ) {
        this.pronto = status;
    }

    /**
     * Imprime uma mensagem referente ao carrinho
     * @param msg Mensagem a ser impressa no video
     */
    private void log (String msg) {
       System.out.println("[Carro]: " + msg + " em " + parque.getTempoTotal() + " ms");
    }
}