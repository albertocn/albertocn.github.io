package montrussa;

/**
 * Classe que gera os Clientes que usar�o a Montanha Russa
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public class GerarClientes implements Runnable{

    private static int NUM_CLIENTES;       /* VALOR N */
    private static double TEMPO_RETORNO;   /* VALOR W */
    private static double TEMPO_DA_VOLTA;  /* VALOR T */

    private Parque parque;
    private Carro carro;
    private Semaforos semaforos;
    /**
     * Informa um intervalo de tempo para a cria��o das Threads
     */
    public static final double intervalo = 1000.0;

    /**
     * Gera os clientes da aplica��o de acordo com a quantidade e o tempo
     * que cada cliente ir� gastar ap�s dar uma volta no carrinho
     * @param numClientes N�mero de clientes da aplica��o
     * @param parque Parque onde os clientes estar�o
     * @param carro Carrinho que ser� compartilhado pelos mesmos
     * @param semaforos Sem�foros que controlar�o os clientes
     * @param tempor Tempo que os clientes gastar�o ap�s volta no carrinho
     */
    public GerarClientes( int numClientes, Parque parque, Carro carro, Semaforos semaforos, double tempor ) {
       this.parque        = parque;
       this.carro         = carro;
       this.semaforos     = semaforos;
       this.NUM_CLIENTES  = numClientes;
       this.TEMPO_RETORNO = tempor;
    }

    /**
     * Cria um Cliente em espec�fico, informando o seu ID e tempo de passeio no parque
     * @param id Identifica��o do Cliente no programa
     * @param tempor Tempo que o cliente gastar� na volta ao parque
     * @return Retorna um cliente com as caracter�sticas informadas
     */
    public Cliente criarCliente(int id, double tempor) {
       return new Cliente( id, parque, carro, semaforos, tempor);
    }

    /**
     * Execu��o da classe geradora de clientes, que instancia n threads clientes
     * cujos nomes s�o Cliente n. Ao se criar os clientes, as threads dormem por um
     * intervalo aleat�rio de tempo
     */
    public void run(){
       for (int i = 1; i <= NUM_CLIENTES; i++ ) {
          Thread t = new Thread(criarCliente(i, TEMPO_RETORNO),String.valueOf(i));
          t.start();

          long tempo = Math.round( Math.random() * intervalo );
          try { Thread.currentThread().sleep( tempo );
          } catch (InterruptedException ie) { ie.printStackTrace(); }
       }
    }
}