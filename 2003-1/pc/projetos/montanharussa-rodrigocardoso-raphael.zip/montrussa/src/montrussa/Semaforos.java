package montrussa;

import montrussa.semaforos.Semaforo;
import montrussa.semaforos.SemaforoBinario;
import montrussa.semaforos.SemaforoContador;

/**
 * Classe que define os sem�foros que compor�o o projeto
 * @author Raphael Hirose e Rodrigo Cardoso Mesquita
 * @version 1.0
 */

public class Semaforos {
   /**
    * Um array de sem�foros para cada cliente
    */
    public final Semaforo[] esperando;
   /**
    * Informa quando o carrinho est� pronto para partir (Lota��o satisfeita)
    */
    public final Semaforo clientes;
   /**
    * Controla a quantidade de clientes no carro
    */
    public final Semaforo carrinho;
   /**
    * Controla os clientes que est�o dando uma volta no carrinho
    */
    public final Semaforo dandoVolta;
   /**
    * Garante a exclus�o m�tua no acesso aos lugares (assentos)
    */
    public final Semaforo mutex;

    /**
     * Construtor dos Sem�foros.<p>
     * Possui 2 tipos de sem�foros: Um contador para carrinho e assentos e
     * outro bin�rio para o mutex e clientes.
     */
    public Semaforos(int num) {
       this.clientes   = new SemaforoBinario(0);
       this.carrinho   = new SemaforoContador(0);
       this.dandoVolta = new SemaforoContador(0);
       this.mutex      = new SemaforoBinario(1);
       this.esperando  = new Semaforo[num];
       for (int i = 0; i < num; i++){
          this.esperando[i]  = new SemaforoBinario(0);
       }
   }
}