package semaforo;

/**
 * <p>T�tulo: Semaforo</p>
 * <p>Descri��o: Classe que extende a classe SemaforBase definida igualmente</p>
 * @author Alberto Costa Neto
 */

public final class SemaforoContador extends SemaforoBase
{
   public SemaforoContador()
   {
      super();
   }

   public SemaforoContador(int initial)
   {
      super(initial);
   }
}