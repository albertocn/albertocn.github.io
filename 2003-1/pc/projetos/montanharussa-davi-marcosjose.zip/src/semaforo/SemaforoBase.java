package semaforo;

/**
 * <p>T�tulo: Semaforo</p>
 * <p>Descri��o: Classe de implementa��o da interface Semaforo</p>
 * @author Alberto Costa Neto
 */

public abstract class SemaforoBase implements Semaforo
{
   // Se valor < 0, abs(valor) � o tamanho da fila de P()
   protected int valor = 0;

   protected SemaforoBase()
   {
      this(0);
   }

   protected SemaforoBase(int inicial)
   {
      if (inicial < 0)
         throw new IllegalArgumentException("inicial<0");
      valor = inicial;
   }

   public synchronized void P()
   {
      valor--;
      if (valor < 0)
      {
         while (true)
         {
            try
            {
               wait();
               break;
            }
            catch (InterruptedException e)
            {
               System.err.println
                  ("SemaforoBase.P(): InterruptedException, esperar novamente");
               if (valor >= 0)
                  break;
               else
                  continue;
            }
         }
      }
   }

   public synchronized void V()
   {
      valor++;
      if (valor <= 0)
         notify();
   }

   public synchronized int valor()
   {
      return valor;
   }

   public synchronized String toString()
   {
      return String.valueOf(valor);
   }
}