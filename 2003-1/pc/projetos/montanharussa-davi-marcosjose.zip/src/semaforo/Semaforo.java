package semaforo;

/**
 * <p>T�tulo: Semaforo</p>
 * <p>Descri��o: Interface de sem�foros que ser�o implementados</p>
 * @author Alberto Costa Neto
 */

public interface Semaforo
{
  void P();
  void V();
}