package montanha;

/**
 * <p>T�tulo: Semaforos</p>
 * <p>Descri��o: Traz os 4 sem�foros utilizados no projeto</p>
 * <p>DAVI GAMA HARDMAN <p>MARCOS JOS� RIBEIRO BARR�TO</p>
 */

import semaforo.*;

public class Semaforos
{
  public final Semaforo mutex;
  public final Semaforo passageiros;
  public final Semaforo carrinho;
  public final Semaforo andando;

  public Semaforos()
  {
    this.mutex = criarSemaforoMutex();
    this.passageiros = criarSemaforoPassageiros();
    this.carrinho = criarSemaforoCarrinho();
    this.andando = criarSemaforoAndando();
  }

  protected Semaforo criarSemaforoMutex()
  {
    return new SemaforoBinario(1);
  }

  protected Semaforo criarSemaforoPassageiros()
  {
    return new SemaforoContador(0);
  }

  protected Semaforo criarSemaforoCarrinho()
  {
    return new SemaforoContador(0);
  }

  protected Semaforo criarSemaforoAndando()
  {
    return new SemaforoContador(0);
  }
}