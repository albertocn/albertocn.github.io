package montanha;

/**
 * <p>T�tulo: Brinquedo</p>
 * <p>Descri��o: Possui m�todos que controlam os passageiros no carrinho</p>
 * <p>DAVI GAMA HARDMAN <p>MARCOS JOS� RIBEIRO BARR�TO</p>
 */


public class Brinquedo
{
  public static final int NUMERO_BANCOS = 4;

  public static final long inicio = System.currentTimeMillis();
  public static final long tempo = 90000;

  public int passageirosNoCarrinho = 0;

  public int getPassageirosNoCarrinho()
  {
    return passageirosNoCarrinho;
  }

  public void decPassageirosNoCarrinho()
  {
    passageirosNoCarrinho--;
  }

  public void incPassageirosNoCarrinho()
  {
    passageirosNoCarrinho++;
  }

  public long getTempoTotal()
  {
    return System.currentTimeMillis() - inicio;
  }
}