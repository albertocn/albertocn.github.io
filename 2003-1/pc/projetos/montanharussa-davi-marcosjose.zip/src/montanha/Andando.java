package montanha;

/**
 * <p>T�tulo: Andando</p>
 * <p>Descri��o: Faz o carrinho andar desde que os passageiros estejam prontos
 * no carrinho</p>
 * <p>DAVI GAMA HARDMAN <p>MARCOS JOS� RIBEIRO BARR�TO</p>
 */

public class Andando implements Runnable
{
  public static final long TEMPO_VOLTA = 6000;

  protected final Brinquedo montanha;
  protected final Semaforos semaforos;

  public Andando (Brinquedo montanha, Semaforos semaforos)
  {
    this.montanha = montanha;
    this.semaforos = semaforos;
  }

  public void run()
  {
    while (montanha.getTempoTotal() <= montanha.tempo)
    {
      mensagem ("Esperando passageiro para brincar");
      semaforos.passageiros.P();
      mensagem ("Um passageiro quer brincar");
      semaforos.mutex.P();
      mensagem ("Colocando o passageiro no carrinho");
      if (montanha.getPassageirosNoCarrinho() == montanha.NUMERO_BANCOS)
      {
        int i = 0;
        while ( i < montanha.NUMERO_BANCOS)
        {
          semaforos.carrinho.V();
          i++;
        }

        andar();

        i = 0;
        while ( i < montanha.NUMERO_BANCOS)
        {
          semaforos.andando.V();
          i++;
        }
      }
      semaforos.mutex.V();
    }
  }

  protected void andar()
  {
    mensagem ("COME�ANDO A VOLTA NA MONTANHA");
    try
    {
      Thread.currentThread().sleep(TEMPO_VOLTA);
    }
    catch (InterruptedException ie)
    {
      ie.printStackTrace();
    }
    mensagem ("TERMINANDO A VOLTA NA MONTANHA");
  }

  private void mensagem (String msg)
  {
    System.out.println("[MONTANHA]: " + msg + " EM " + montanha.getTempoTotal()
                          + " ms");
  }
}