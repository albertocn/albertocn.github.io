package montanha;

/**
 * <p>T�tulo: GerarPassageiros</p>
 * <p>Descri��o: Inicia as threads de passageiros</p>
 * <p>DAVI GAMA HARDMAN <p>MARCOS JOS� RIBEIRO BARR�TO</p>
 */


public class GerarPassageiros implements Runnable
{
  public static final double INTERVALO = 5000.0;

  protected final Brinquedo montanha;
  protected final Semaforos semaforos;

  public GerarPassageiros (Brinquedo montanha, Semaforos semaforos)
  {
     this.montanha = montanha;
     this.semaforos = semaforos;
  }

  public Passageiro criarPassageiro (int id)
  {
     return new Passageiro (id, montanha, semaforos);
  }

  public void run()
  {
    for (int cont = 1; cont <= 10; cont++)
    {
      Thread volta = new Thread (criarPassageiro(cont), "Passageiro " + cont);
      volta.start();
      long tempo = Math.round(Math.random() * INTERVALO);
      try
      {
        Thread.currentThread().sleep(tempo);
      }
      catch (InterruptedException ie)
      {
        ie.printStackTrace();
      }
    }
  }
}