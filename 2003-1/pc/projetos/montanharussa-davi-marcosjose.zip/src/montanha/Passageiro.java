package montanha;

/**
 * <p>T�tulo: Passageiro</p>
 * <p>Descri��o: Classe que roda as threads e observa se pode ou n�o entrar no
 * carrinho</p>
 * <p>DAVI GAMA HARDMAN <p>MARCOS JOS� RIBEIRO BARR�TO</p>
 */

public class Passageiro implements Runnable
{
  protected final int id;
  protected final Brinquedo montanha;
  protected final Semaforos semaforos;

  public static final double INTERVALO = 5000.0;

  // Construtor pincipal da classe Passageiro
  public Passageiro (int id, Brinquedo montanha, Semaforos semaforos)
  {
    this.id = id;
    this.montanha = montanha;
    this.semaforos = semaforos;
  }

  public void run()
  {
    while (montanha.getTempoTotal() <= montanha.tempo)
    {
      semaforos.mutex.P();
      if (montanha.getPassageirosNoCarrinho() < montanha.NUMERO_BANCOS)
      {
        montanha.incPassageirosNoCarrinho();
        semaforos.passageiros.V();
        semaforos.mutex.V();
        mensagem ("Pronto no carrinho para a volta");
        semaforos.carrinho.P();
        semaforos.andando.P();
        mensagem ("Acabou de dar a volta na montanha");
        semaforos.mutex.P();
        montanha.decPassageirosNoCarrinho();
        semaforos.mutex.V();
      }
      else
      {
        System.out.println("[SEM_VAGA]: O Passageiro " + id + " volta depois");
        try
        {
          Thread.currentThread().sleep(20);
        }
        catch (InterruptedException ie)
        {
          ie.printStackTrace();
        }
        semaforos.mutex.V();
      }
    }
  }

  private void mensagem (String msg)
  {
    System.out.println("[Passageiro " + id + "]: " + msg + " EM "
                          + montanha.getTempoTotal() + " ms");
  }
}