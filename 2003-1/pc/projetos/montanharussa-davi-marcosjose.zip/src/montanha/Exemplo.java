package montanha;

/**
 * <p>T�tulo: Exemplo</p>
 * <p>Descri��o: Classe principal que constr�i o brinquedo e inicia threads</p>
 * <p>DAVI GAMA HARDMAN <p>MARCOS JOS� RIBEIRO BARR�TO</p>
 */

public class Exemplo
{
  private Semaforos semaforos;
  private Brinquedo montanha;

  public Exemplo()
  {
    this.semaforos = new Semaforos();
  }

  public void executar()
  {
    montanha = new Brinquedo();
    new Thread (new Andando (montanha, this.semaforos), "Montanha").start();
    new Thread (new GerarPassageiros (montanha, this.semaforos),
                   "GerarPassageiros").start();
  }

  public static void main(String[] args)
  {
    new Exemplo().executar();
  }
}