package errosexcecoes;

public class CapturarRelancar {

  public static void main(String[] args) {
    Long l = null;
    Long l2 = new Long(2);
    try {
      System.out.println( l.toString() ); // NullPointerException
    } catch (NullPointerException e) {
      if (l2 != null) {
        l = l2;
      } else {
        throw e;
      }
    }
  }
}