package errosexcecoes;

public class ExemploFinally {

  public static void main(String[] args) {
     try {
       int x = 1, y = 0;

       // Provoca uma java.lang.ArithmeticException
//       int z = x / y;

     } catch (ArithmeticException e) {
       System.out.println("Entrou no catch");

     } finally {
       System.out.println("Entrou no finally");
     }
  }
}