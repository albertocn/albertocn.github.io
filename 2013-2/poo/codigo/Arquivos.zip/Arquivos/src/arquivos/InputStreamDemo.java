package arquivos;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.IOException;

public class InputStreamDemo {

    public InputStreamDemo(String caminho) throws IOException {

        // Cria uma InputStream para o arquivo especificado
        InputStream is = new FileInputStream(caminho);

        // Faz a leitura dos bytes na stream, transforma em
        // uma String e imprime na tela
        System.out.print(lerString(is));

        // Fecha a stream
        is.close();
    }

    private String lerString(InputStream is) throws IOException {
        // Cria um ByteArrayOutputStream que mant�m os bytes
        // em um array e permite obt�-los posteriormente
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        // Faz a leitura de cada byte por vez. O m�todo read
        // Retorna um valor entre 0 e 255 ou -1 quando chega
        // ao final do arquivo
        int i;
        while ((i = is.read()) != -1) {

            // Como o int lido est� entre 0 e 255 e representa
            // um byte, ele deve ser convertido e colocado
            // no objeto ByteArrayOutputStream
            baos.write((byte) i);
        }

        // Retorna todos os bytes lidos do arquivo na
        // forma de uma String
        return baos.toString();
    }


    public static void main(String[] args) {
        try {
            String arquivo = "arqs" +
                             System.getProperty("file.separator") +
                             "OutputStream.txt";
            System.out.println("Lendo " + arquivo + "...");
            new InputStreamDemo(arquivo);
            System.out.println("Arquivo lido");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}