package arquivos;

import java.io.IOException;
import java.io.OutputStream;
import java.io.FileOutputStream;
import java.io.PrintStream;

public class RedirecionarSaidaArquivo {

    public RedirecionarSaidaArquivo(String caminho) throws IOException {

        OutputStream os = new FileOutputStream(caminho);
        PrintStream ps = new PrintStream(os);

        // Guarda a sa�da padr�o atual
        PrintStream outDef = System.out;

        // Redireciona a sa�da padr�o para um objeto
        // PrintStream, que grava em um arquivo
        System.setOut(ps);

        // Essas linhas n�o ser�o mostradas na tela
        // mas gravadas no arquivo
        System.out.println("Linha 1");
        System.out.println("Linha 2");

        // Restaura a sa�da padr�o
        System.setOut(outDef);

        // Imprime na sa�da padr�o (tela)
        System.out.println("Arquivo gravado");
    }

    public static void main(String[] args) {
        try {
          String arquivo = "arqs" +
                           System.getProperty("file.separator") +
                           "RedirecionarSaida.txt";

          new RedirecionarSaidaArquivo(arquivo);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}