package swing;

import java.awt.Font;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class JCheckBoxDemo extends JFrame {

  private JLabel selecionados = new JLabel();
  private JCheckBox negrito, italico, grande;

  public JCheckBoxDemo() {
    super("JCheckBox Demo");

    JPanel painel;

    // Constr�i um painel com os checkboxes
    negrito = new JCheckBox();
    negrito.setText("Negrito");
    italico = new JCheckBox("It�lico");
    grande = new JCheckBox("Grande");
    grande.setEnabled(true);
    painel = new JPanel();
    painel.add(negrito);
    painel.add(italico);
    painel.add(grande);
    painel.add(selecionados);

    getContentPane().add(painel);

    CheckListener listener = new CheckListener();
    negrito.addActionListener( listener );
    italico.addActionListener( listener );
    grande.addActionListener( listener );

    pack();
    show();
  }

  private class CheckListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      String texto = "";

      int estilo = estilo = Font.PLAIN;
      int tamanho = 14;

      if (negrito.isSelected()) {
        texto += negrito.getText() + ' ';
        estilo += Font.BOLD;
      }

      if (italico.isSelected()) {
        texto += italico.getText() + ' ';
        estilo += Font.ITALIC;
      }

      if (grande.isSelected()) {
        texto += grande.getText() + ' ';
        tamanho += 4;
      }

      selecionados.setFont( new Font("Courier New", estilo, tamanho ) );
      selecionados.setText( texto.trim() );
      pack();
    }
  }

  public static void main( String args[] ) {
    JCheckBoxDemo application = new JCheckBoxDemo();
    application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }
}