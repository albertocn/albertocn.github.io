package swing;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.awt.BorderLayout;
import java.awt.Container;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;

import javax.swing.Timer;

public class JComboBoxDemo extends JFrame {

  private Object[] formatos = { "dd MMMMM yyyy",
                                "dd.MM.yy",
                                "MM/dd/yy",
                                "yyyy.MM.dd G 'at' hh:mm:ss z",
                                "EEE, MMM d, ''yy",
                                "h:mm a",
                                "H:mm:ss:SSS",
                                "K:mm a,z",
                                "yyyy.MMMMM.dd GGG hh:mm aaa" };

  private JComboBox comboFormatos = new JComboBox( formatos );
  private JLabel dataHora = new JLabel();
  private Timer timerDataHora = new Timer( 50, new TimerListener() );

  public JComboBoxDemo() {
    super( "JComboBox Demo" );

    Container contentPane = getContentPane();
    contentPane.setLayout( new BorderLayout() );

    comboFormatos.setEditable(true);
    comboFormatos.addActionListener( new FormatosListener() );

    contentPane.add( BorderLayout.CENTER, comboFormatos );
    contentPane.add( BorderLayout.SOUTH, dataHora );

    inicializarComponentes();

    pack();
    show();
  }

  private void inicializarComponentes() {
    comboFormatos.setSelectedIndex(0);
    timerDataHora.start();

    // Registra o listener para parar o timer quando a janela for fechada
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        timerDataHora.stop();
      }
    });
  }

  private class FormatosListener implements ActionListener {
    public void actionPerformed (ActionEvent e) {
      adicionarSeNovo();
      atualizarDataHora();
    }
  }

  private class TimerListener implements ActionListener {
    public void actionPerformed (ActionEvent e) {
      atualizarDataHora();
    }
  }

  private void adicionarSeNovo() {
    Object itemEditado = comboFormatos.getEditor().getItem();
    for ( int i = 0; i < comboFormatos.getItemCount(); i++ ) {
      if ( comboFormatos.getItemAt( i ).equals( itemEditado ) ) {
        return;
      }
    }
    // Item novo deve ser adicionado no in�cio da lista
    comboFormatos.insertItemAt( itemEditado, 0 );
  }

  private void atualizarDataHora() {
    this.dataHora.setText( getDataHora() );
  }

  private String getDataHora() {
    String formato = (String) comboFormatos.getSelectedItem();
    DateFormat df = new SimpleDateFormat( formato );
    return df.format( new Date() );
  }

  public static void main( String args[] ) {
    JComboBoxDemo application = new JComboBoxDemo();
    application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }
}
