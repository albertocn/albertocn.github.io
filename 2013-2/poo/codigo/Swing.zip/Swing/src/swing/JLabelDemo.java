package swing;

import java.awt.Container;
import java.awt.BorderLayout;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class JLabelDemo extends JFrame {

   private JLabel label1, label2, label3;

   public JLabelDemo() {
      super( "JLabel Demo" );

      Container container = getContentPane();
      container.setLayout( new BorderLayout() );

      // Cria um JLabel com um texto
      label1 = new JLabel( "JLabel com texto" );
      label1.setToolTipText( "label1" );
      container.add( label1, BorderLayout.NORTH );

      // Cria um JLabel com um texto, um �cone e especificando alinhamento
      Icon java = new ImageIcon( "javalogo.gif" );
      label2 = new JLabel( "JLabel com texto e �cone alinha",
                          java,
                          SwingConstants.LEFT );
      label2.setToolTipText( "label2" );
      container.add( label2, BorderLayout.CENTER );

      // Cria um JLabel sem passar argumentos. Especifica posteriormente
      // o texto, o �cone, o alinhamento e a dica
      label3 = new JLabel();
      label3.setText( "JLabel com �cone e texto abaixo" );
      label3.setIcon( java );
      label3.setHorizontalAlignment( SwingConstants.RIGHT );
      label3.setHorizontalTextPosition( SwingConstants.CENTER );
      label3.setVerticalTextPosition( SwingConstants.BOTTOM );
      label3.setToolTipText( "label3" );
      container.add( label3, BorderLayout.SOUTH );

      setSize( 300, 250 );
      show();
   }

   public static void main( String args[] ) {
      JLabelDemo application = new JLabelDemo();
      application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
   }
}