package swing;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class GridLayoutDemo extends JFrame {

  public GridLayoutDemo() {
    Container contentPane = getContentPane();

    // Cria um GridLayout com um n�mero n�o especificado de linhas,
    // com 2 colunas, que mant�m uma dist�ncia horizontal de 5 pixels
    // e uma dist�ncia vertical de 10 pixels entre os componentes
    contentPane.setLayout(new GridLayout(0,2,5,10));

    contentPane.add(new Button("Button 1"));
    contentPane.add(new Button("2"));
    contentPane.add(new Button("Button 3"));
    contentPane.add(new Button("Button com nome grande 4"));
    contentPane.add(new Button("Button 5"));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }

  public static void main(String args[]) {
    JFrame f = new GridLayoutDemo();
    f.setTitle("GridLayoutDemo");
    f.pack();
    f.show();
  }
}