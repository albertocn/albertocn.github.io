package exemplos.ex07;

public class Main {

	public static void main(String[] args) {
		SubSistema s = new SubSistema();
		Fachada f = new Fachada(s);
		
		System.out.println(">Pela fachada: " + f.getStatus());
		
		s.setStatus("Esperando");
		
		System.out.println(">Direto da classe Main: " + s.getStatus());
		
		System.out.println(">Atribuindo null ao status");
		s.setStatus(null);
		
		System.out.println("Status final" + f.getStatus());
	}
}
