package exemplos.ex07;

public class Fachada {
	private SubSistema s;
	
	public Fachada(SubSistema s) {
		this.s = s;		
	}
	
	public String getStatus() {
		System.out.println("Executando a fachada");
		return s.getStatus();
	}

}
