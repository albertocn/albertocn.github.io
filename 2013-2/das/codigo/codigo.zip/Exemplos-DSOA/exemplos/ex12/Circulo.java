package exemplos.ex12;

/** C�rculo puro */
public class Circulo {
	
	private int x,y,r;
	
	public Circulo(int x, int y, int r) {
		this.x = x;
		this.y = y;
		this.r = r;
	}
	
	public int getX() { return x; }
	public int getY() { return y; }
	public int getRaio() { return r; }
	public void setX(int x) { this.x = x; }
	public void setY(int y) { this.y = y; }
	public void setRaio(int r) { this.r = r; }
	
	public void mover(int offsetX, int offsetY) {
		this.x += offsetX;
		this.y += offsetY;
	}
	
	public double area() {
		System.out.println("Calculando a area");
		return Math.PI * r * r;
	}

	public static void main(String[] args) {
		Circulo f = new Circulo(0,0,100);
		f.mover(10, 10);
		f.setX(5);
		f.setY(15);		
		f.setRaio(200);
		System.out.println("Area:" + f.area());
		System.out.println("Area:" + f.area());
		f.setRaio(300);
		System.out.println("Area:" + f.area());		
		System.out.println("Area:" + f.area());		
	}	
}