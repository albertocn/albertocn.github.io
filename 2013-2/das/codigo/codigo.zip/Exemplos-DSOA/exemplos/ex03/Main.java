package exemplos.ex03;

public class Main {
	
	public static void main(String args[]) {
		Pessoa p = new Pessoa("Alberto", "123", "abc@ufs.br");
		ClasseA a = new ClasseA();
		ClasseB b = new ClasseB();
		
		printPessoa(p);
		
		System.out.println("Chamando setNome em Main");
		p.setNome("Neto");
		
		System.out.println("Chamando setCpf em Main");
		p.setCpf("789");
		
		System.out.println("Chamando setEmail em Main");
		p.setEmail("def@ufs.br");
		
		printPessoa(p);		
		
		a.setX(1);
		long x = a.getX();
		
		b.setY(2);
		int y = b.getY();
		
		System.out.println("Valor de (x,y) = (" + x + "," + y + ")");
	}
	
	private static void printPessoa(Pessoa p) {
		System.out.println("<printPessoa> " + p.getNome() + ", " +
				           p.getCpf() + ", " + p.getEmail());		
	}
}
