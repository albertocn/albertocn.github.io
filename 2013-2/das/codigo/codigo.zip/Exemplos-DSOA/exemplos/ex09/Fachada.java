package exemplos.ex09;

public class Fachada {
	private SubSistema s;
	
	public Fachada(SubSistema s) {
		System.out.println("Chamando do construtor");
		s.setStatus("XYZ");
		this.s = s;		
	}
	
	public String getStatus() {
		System.out.println("Executando a fachada");
		return s.getStatus();
	}

	public void setStatus(String status) {
		s.setStatus(status);
	}
}
