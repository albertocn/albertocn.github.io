package exemplos.ex02;

public class Quadrado {
	
	private int x,y,lado;
	
	public Quadrado(int x, int y, int lado) {
		this.x = x;
		this.y = y;
		this.lado = lado;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public int getLado() {
		return lado;
	}

	public void setLado(int lado) {
		this.lado = lado;
	}
	
	public void mover(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public double area() {
		return lado * lado;
	}
	
	public static void main(String args[]) {
		Quadrado q = new Quadrado(0,0,100);
		q.mover(10, 10);
		q.setX(5);
		q.setY(15);		
		q.setLado(200);
		System.out.println("Area:" + q.area());
		System.out.println("Area:" + q.area());
		q.setLado(300);
		System.out.println("Area:" + q.area());		
		System.out.println("Area:" + q.area());
	}
}
