package exemplos.ex10;

public class Main {
	
	private void executar() {
		System.out.println("Inic�o executar()");		
		executarAlgo();
		executarAlgoMais();
		System.out.println("Fim executar()");
	}
	
	private void executarAlgo() {
		System.out.println(gerarString(10000, 'A'));		
	}
	
	private void executarAlgoMais() {
		System.out.println(gerarString(30000, 'b'));		
	}
	
	private String gerarString(int n, char c) {
		String s = "";
		for (int i = 0; i < n; i++) {
			s += c;
		}
		return s;		
	}
	
	public static void main(String[] args) {
		
		Main m = new Main();
		
		m.executarAlgo();
		m.executarAlgoMais();
		
		m.executar();
	}

}
