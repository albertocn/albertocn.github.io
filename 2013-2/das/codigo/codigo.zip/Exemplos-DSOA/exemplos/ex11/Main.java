package exemplos.ex11;

public class Main {
	
	private int x = 0;
	
	public void metodoY() {
		System.out.println("Executando metodoY");
	}

	public static void main(String[] args) {
		
		Main m = new Main();
		
		m.x = 10;
		
		m.metodoY();
	}
}
