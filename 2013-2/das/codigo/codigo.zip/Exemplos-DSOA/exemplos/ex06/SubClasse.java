package exemplos.ex06;

public class SubClasse extends ClasseBase {

	SubClasse() {
//		super();
		System.out.println("*Executando o construtor de Subclasse");
		i = 3;
	}

}
