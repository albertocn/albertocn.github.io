package exemplos.ex04;

public class Main {
	
	public static void main(String args[]) {
		Pessoa p = new Pessoa("Alberto", "123", "abc@ufs.br");
		
		printPessoa(p);
		
		System.out.println("Chamando setNome em Main");
		p.setNome("Beto");
		
		System.out.println("Chamando setCpf em Main");
		p.setCpf("456");
		
		System.out.println("Chamando setEmail em Main");
		p.setEmail("xyz@ufs.br");
		
		printPessoa(p);		
		
		Pessoa p2 = new Pessoa("Savio", "789", "xxx");
	}
	
	private static void printPessoa(Pessoa p) {
		System.out.println("<printPessoa> " + p.getNome() + ", " +
				           p.getCpf() + ", " + p.getEmail());		
	}
}