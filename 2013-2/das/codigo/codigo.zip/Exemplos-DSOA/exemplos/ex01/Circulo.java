package exemplos.ex01;

/** C�rculo com cache e log */
public class Circulo {
	
	private int x,y,r;
	
	private Double areaCache = null;
	
	public Circulo(int x, int y, int r) {
		this.x = x;
		this.y = y;
		this.r = r;
	}	
	public int getX() { return x; }
	public int getY() { return y; }
	public int getRaio() { return r; }
	
	public void setX(int x) { 
		this.x = x; 
		log(); 
	}
	
	public void setY(int y) { 
		this.y = y; 
		log();
	}
	
	public void setRaio(int r) { 
	   this.r = r;
	   System.out.println("Limpando o cache");
	   this.areaCache = null;
	}
	
	public void mover(int offsetX, int offsetY) {
		this.x += offsetX;
		this.y += offsetY;
		log();
	}
	
	public double area() {
    	if (temCache()) {
        	System.out.println("Pegando do cache");    		
    	} else {
    		System.out.println("Calculando a area");
    		areaCache = new Double( Math.PI * r * r );
        	System.out.println("Gravando no cache");    		
    	}
    	return areaCache.doubleValue();		
	}

	private void log() {
		System.out.println("Moveu!");
	}
	
	private boolean temCache() {
		return areaCache != null;
	}	
	
	public static void main(String[] args) {
		Circulo c = new Circulo(0,0,100);
		c.mover(10, 10);
		c.setX(5);
		c.setY(15);		
		c.setRaio(200);
		System.out.println("Area:" + c.area());
		System.out.println("Area:" + c.area());
		c.setRaio(300);
		System.out.println("Area:" + c.area());		
		System.out.println("Area:" + c.area());		
	}	
}
