package exemplos.ex01;

/** Ret�ngulo com cache e log */
public class Retangulo {
	
	private int x,y,base,altura;
	
	private Double areaCache = null;
	
	public Retangulo(int x, int y, int base, int altura) {
		this.x = x;
		this.y = y;
		this.base = base;
		this.altura = altura;
	}	
	public int getX() { return x; }
	public int getY() { return y; }
	public int getBase() { return base; }
	public int getAltura() { return altura; }
	
	public void setX(int x) { 
		this.x = x; 
		log(); 
	}
	
	public void setY(int y) { 
		this.y = y; 
		log();
	}
	
	public void setBase(int base) { 
	   this.base = base;
	   System.out.println("Limpando o cache");
	   this.areaCache = null;
	}

	public void setAltura(int altura) { 
	   this.altura = altura;
	   System.out.println("Limpando o cache");
	   this.areaCache = null;
	}
	
	public void mover(int offsetX, int offsetY) {
		this.x += offsetX;
		this.y += offsetY;
		log();
	}
	
	public double area() {
    	if (temCache()) {
        	System.out.println("Pegando do cache");    		
    	} else {
    		System.out.println("Calculando a area");
    		areaCache = new Double( base * altura );
        	System.out.println("Gravando no cache");    		
    	}
    	return areaCache.doubleValue();		
	}

	private void log() {
		System.out.println("Moveu!");
	}
	
	private boolean temCache() {
		return areaCache != null;
	}	
	
	public static void main(String[] args) {
		Retangulo q = new Retangulo(0,0,100,200);
		q.mover(10, 10);
		q.setX(5);
		q.setY(15);		
		q.setBase(200);
		System.out.println("Area:" + q.area());
		System.out.println("Area:" + q.area());
		q.setAltura(300);
		System.out.println("Area:" + q.area());		
		System.out.println("Area:" + q.area());		
	}	
}
