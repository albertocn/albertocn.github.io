package exercicios;

import java.util.List;
import java.util.LinkedList;

public class Pilha {
	
	private List p = new LinkedList();
	
	public void empilhar(Object o) {
		if (o == null) {
			throw new IllegalArgumentException("Par�metro inv�lido");
		}
		p.add(0, o);
	}
	
	public Object desempilhar() {
		if (p.isEmpty()) {
			return null;
		} else {
			return p.remove(0);
		}
	}
	
	public boolean vazia() {
		return p.isEmpty();
	}
}
