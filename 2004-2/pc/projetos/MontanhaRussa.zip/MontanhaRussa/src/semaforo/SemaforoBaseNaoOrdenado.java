package semaforo;

public class SemaforoBaseNaoOrdenado extends SemaforoBase {

  protected SemaforoBaseNaoOrdenado() {
    super();
  }

  protected SemaforoBaseNaoOrdenado(int inicial) {
    super( inicial );
  }

  public synchronized void P() {
 // 	 System.out.println("P - Valor Semaforo Antes: "+ valor);
     valor--;
  //   System.out.println("P - Valor Semaforo Depois: "+ valor);
     if (valor < 0) {
        while (true) {
          try {
               wait();
              break;
           } catch (InterruptedException e) {
              System.err.println
                 ("SemaforoBase.P(): InterruptedException, esperar novamente");
              if (valor >= 0) break;
              else continue;
           }
        }
        
     }
  }

  public synchronized void V() {
 //	 System.out.println("V - Valor Semaforo Antes: "+ valor);
     valor++;
 //    System.out.println("V - Valor Semaforo Depois: "+ valor);
     if (valor <= 0) {
     	notify();
     }
  }

}