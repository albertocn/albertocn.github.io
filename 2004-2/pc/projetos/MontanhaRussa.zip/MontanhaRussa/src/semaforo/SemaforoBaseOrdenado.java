package semaforo;

import java.util.List;
import java.util.LinkedList;

public class SemaforoBaseOrdenado extends SemaforoBase {

   // Armazena uma lista com as Threads esperando em P()
   private List fila = new LinkedList();
   // Usada para impedir que um notifyAll acorde mais de uma Thread.
   private boolean notificou = false;

   protected SemaforoBaseOrdenado() {
     super();
   }

   protected SemaforoBaseOrdenado(int inicial) {
     super( inicial );
   }

   public synchronized void P() {
     valor--;
     if (valor < 0) {
        System.out.println("SemaforoOrdenado ( P ): "+Thread.currentThread().getName());
         fila.add( Thread.currentThread() );
         while (true) {
            try {
               wait();

               // Ningu�m foi notificado e a thread corrente � a 1� da fila
               if (!notificou && (fila.get(0) == Thread.currentThread())) {
                  fila.remove(0);
                  notificou = true;
                  break;
               // A 1� j� da fila j� foi notificada ou a Thread atual n�o
               // � a primeira da fila
               } else {
                  continue;
               }
            } catch (InterruptedException e) {
               System.err.println
                  ("SemaforoBase.P(): InterruptedException, esperar novamente");
               if (valor >= 0) break;
               else continue;
            }
         }
      }
   }

   public synchronized void V() {
     valor++;
     // Verifica se h� threads esperando em P()
      if (valor <= 0) {
        notificou = false;
        notifyAll();
      }
   }
}