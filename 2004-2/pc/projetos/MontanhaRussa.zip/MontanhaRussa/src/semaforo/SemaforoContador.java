package semaforo;

public final class SemaforoContador implements Semaforo {

   private SemaforoBase semaforo;

   public SemaforoContador() {
     this (false);
   }

   public SemaforoContador( boolean ordenado ) {
     this (ordenado, 0);
   }

   public SemaforoContador(int initial) {
      this (false, initial);
   }

   public SemaforoContador( boolean ordenado, int inicial ) {
     if (ordenado) {
       this.semaforo = new SemaforoBaseOrdenado(inicial);
     } else {
       this.semaforo = new SemaforoBaseNaoOrdenado(inicial);
     }
   }

   public void P() { semaforo.P(); }
   public void V() { semaforo.V(); }
   
   public String toString() {
   	 return semaforo.toString();
   }
}
