/*
 * Created on 18/02/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package semaforo;

import java.util.concurrent.Semaphore;


public class Semaforos {

  /**
   * mutex: exclusao mutua em se��es criticas no acesso a variaveis
   */
  public final Semaphore mutex;
  /**
   * andando: Sinaliza se o carrinho esta passeando na Montanha 
   */
  public final Semaforo andando;
  /**
   * passageiros: Sinaliza se a qtde de passageiros � suficiente pra carrinho sair
   */
  public final Semaforo passageiros;
  /**
   * carro: avisa passageiros para entrarem no carrinho
   */
  public final Semaforo carro;
  /**
   * Bloqueia threads em espera ate q o carrinho esteja livre novamente
   */
 // public Semaforo[] filaEspera;  

  public Semaforos(int qtdePassageiros) {
    this.mutex    = criarSemafMutex();
    this.passageiros = criarSemafPassageiros();
    this.carro = criarSemafCarro();
    this.andando = criarSemafAndando(); 
   // this.filaEspera = criarSemafFilaEspera(qtdePassageiros);
  }

  protected Semaphore criarSemafMutex() {
    return new Semaphore( 1 );
  }
  protected Semaforo criarSemafPassageiros() {
    return new SemaforoContador( true, 4 );
  }
  protected Semaforo criarSemafCarro() {
   return new SemaforoBinario( true,  0 );
  }
  protected Semaforo criarSemafAndando() {
    return new SemaforoContador( 0 );
  }
}