/*
 * Created on 18/02/2005
 */
package montanha;

import semaforo.Semaforos;


/**
 * @author RITA KALILE ALMEIDA ANDRADE
 * 				 SUEANE SANTOS BOMFIM
 */
public class Passageiro implements Runnable{

  protected final int id;
  protected final Parque parque;
  protected final Semaforos semaforos;
  protected final int tempoVoltaParque;

  /**
   * 
   */
  public Passageiro( int id, Parque parque, Semaforos semaforos , int tempoVoltaParque ) {
    this.id = id;
    this.parque = parque;
    this.semaforos = semaforos;
    this.tempoVoltaParque = tempoVoltaParque; 
  }

  public void run() {
  	try {

    while(parque.getTempoTotal() <= parque.tempoExecucao ){  
    	semaforos.mutex.acquire();  
        avisaCarro(); //passageiros.V()
      	vaiAndarNaMontanha();
      	darUmaVoltaParque();
    }
    
    } catch (Exception e) {e.printStackTrace();  }

  }
  
  /**
   * Se os assentos foram ocupados notifica carrinho com passageiros.V() e seta
   * estado do Carrinho pra Nao-Livre.
   * 
   * @throws InterruptedException
   */
  public void avisaCarro() throws InterruptedException {
  	log("CHEGUEI NA FILA**********");  
  	semaforos.passageiros.P();
  //	semaforos.carro.V();
    parque.incAssentosOcupados();
    if (parque.getAssentosOcupados()==parque.getNumAssentos())
    	semaforos.carro.V();
  	semaforos.mutex.release();
  }

  /**
   * Anda na montanha ate q carrinho avise que passeio acabou.
   * Depois decrementa numero de AssentosOcupados.
   * Se carrinho vazio seta carrinho para Livre 
   */
  private void vaiAndarNaMontanha() throws InterruptedException {
    semaforos.andando.P();
    log("Ebaaaaaaaaaa eu andei!!!!  AssentosOcupados:" + parque.getAssentosOcupados());
  }
  
  private void darUmaVoltaParque() {
    log("Agora vou dar uma volta no Parque!!!");
  	try {
      Thread.sleep(Math.round( Math.random() * tempoVoltaParque ));
      
    } catch (InterruptedException e1) {
        e1.printStackTrace();
    }
    log("Cansei de dar volta no Parque!!! Vou voltar p a montanha!!");
  }
  
  private void log (String msg) {
    System.out.println("[Passageiro" + id + "]: " + msg + " em " + parque.getTempoTotal() + " ms");
  }
}