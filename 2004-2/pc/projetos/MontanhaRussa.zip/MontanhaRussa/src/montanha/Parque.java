/*
 * Created on 19/02/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package montanha;

import java.util.LinkedList;
import java.util.List;

/**
 * @author RITA KALILE ALMEIDA ANDRADE
 * 				 SUEANE SANTOS BOMFIM
 */


public class Parque {

  public static final int N_FILAESPERA = 10;
  public static final long inicio = System.currentTimeMillis();
  
  private boolean carrinhoLivre = true; 
  private final int numAssentos;
  private List passageirosEsperando = new LinkedList();
  private int assentosOcupados = 0;
  public final int tempoExecucao;
  
  public Parque (int num, int tempo){
   this.numAssentos = num;
   this.tempoExecucao = tempo;
  }
  
  public boolean pedidosSuficientes() { return assentosOcupados==numAssentos; }

  public boolean passageirosEntraramNoCarro () {  return (assentosOcupados==numAssentos); }
  public int getAssentosOcupados() { return assentosOcupados; }
  
  public void decAssentosOcupados() { 
  	assentosOcupados--; 
  }
  public void incAssentosOcupados() { 
    assentosOcupados++; 
  }

  public long getTempoTotal() {
    return System.currentTimeMillis() - inicio;
  }

  public int getNumAssentos() {
    return numAssentos;
  }

public void setCarrinhoLivre(boolean carrinhoLivre) {
	this.carrinhoLivre = carrinhoLivre;
}

public boolean carrinhoLivre() {
	return carrinhoLivre;
}

public List getPassageirosEsperando() {
	return passageirosEsperando;
}
}