/*
 * Created on 19/02/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package montanha;

import semaforo.Semaforos;

/**
 * @author RITA KALILE ALMEIDA ANDRADE
 * 				 SUEANE SANTOS BOMFIM
 */
public class GerarPassageiros implements Runnable {

  public static final double INTERVALO = 2000.0;

  protected final Parque parque;
  protected final Semaforos semaforos;
  protected final int tempo;
  protected final int numPassageiros;

  public GerarPassageiros( Parque parque, Semaforos semaforos , int numPassageiros, int tempo) {
    this.parque = parque;
    this.semaforos = semaforos;
    this.numPassageiros = numPassageiros;
    this.tempo = tempo;
    System.out.println("<< Vai come�ar a gerar passageiros >>");
  }

  public Passageiro criarPassageiro(int id, int tempo) {
    return new Passageiro( id, parque, semaforos, tempo );
  }

  public void run() {
    
    for (int cont = 1; cont <= numPassageiros; cont++) {
      System.out.println("<< Criado o Passageiro" + cont+" >>");
      Thread t = new Thread(criarPassageiro(cont, tempo), "Passageiro " + cont);
      t.start();
      
      long tempo = Math.round( Math.random() * INTERVALO );
      try { Thread.sleep( tempo );
      } catch (InterruptedException ie) { ie.printStackTrace(); }
    }
     
    }
    
  
}
