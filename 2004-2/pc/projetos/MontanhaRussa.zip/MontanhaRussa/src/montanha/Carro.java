/*
 * Created on 18/02/2005
 */
package montanha;

import semaforo.Semaforos;

/**
 * @author RITA KALILE ALMEIDA ANDRADE
 * 				 SUEANE SANTOS BOMFIM
 */
public class Carro implements Runnable {
    
  private Semaforos semaforos;
  private Parque parque;
  private final int tempoRodada;
  
  private int cont = 0;  

  public Carro(Parque parque, Semaforos semaforos, int tempoRodada) {
    super();
    this.semaforos = semaforos;
    this.parque = parque;
    this.tempoRodada = tempoRodada;
  }

 
  public void run()  {
  try {
    
  	while ( parque.getTempoTotal() <= parque.tempoExecucao ){  
  	  esperaOcuparAssentos();
  	  andarNaMontanha();
  	  liberarPassageiros();
  	}
  	
  	log("PARQUE VAI FECHAR!!! A BRINCADEIRA ACABOU!! AGORA S� AMANHA!");
    System.exit(0);
    
	} catch (InterruptedException e) {e.printStackTrace();} 
    
  }
  
  /**
   * Espera o passageiro que ocupar o ultimo assento avisar 
   * atraves de semaforos.passageiros.V()
   */
  public void esperaOcuparAssentos() {
    log ("Carro espera passageiros suficientes");
    semaforos.carro.P(); // Espera passageiro que ocupara o ultimo assento
    log ("<< Todos os assentos j� ocupados >>");
  }
  
  /**
   * Da a volta na montanha durante o tempo T especificado
   *
   */
  private void andarNaMontanha() {
  	
    log("COME�OU O PASSEIO NA MONTANHA ..." +cont);
    try {
      Thread.sleep((long)(tempoRodada));
    } catch (InterruptedException e) {  
      e.printStackTrace();
    }
    log("TERMINOU O PASSEIO NA MONTANHA ..." +cont);
  }

  /**
   * Libera os passageiros que estavam no carro aguardando aviso 
   * de que o passeio terminou  
   * 
   * @throws InterruptedException
   */
  public void liberarPassageiros() throws InterruptedException {
   	for(int i=0;i<parque.getNumAssentos();i++){
   		log("Liberando passageiro... " +(i+1));
   		parque.decAssentosOcupados();
   		semaforos.andando.V();  //libera quem tava brincando
   		semaforos.passageiros.V(); //libera quem tava na fila esperando   		
    }
  }
    
  private void log (String msg) {
    System.out.println("[Carro]: " + msg + " em " + parque.getTempoTotal() + " ms");
  }
}
