/*
 * Created on 18/02/2005
 */
package montanha;

import semaforo.Semaforos;


/**
 * @author RITA KALILE ALMEIDA ANDRADE
 * 				 SUEANE SANTOS BOMFIM
 */
public class MontanhaRussa {

 
private Semaforos semaforos;
private Parque parque;

public MontanhaRussa() {
  
}

public void executar(String[] args) {
if (verificaArgumentos(args)){
  int numAssentos =  Integer.parseInt(args[1]);
  int tempoVoltaMontanha = Integer.parseInt  (args[3]);//
  int qtdePassageiros = Integer.parseInt  (args[5]);
  int tempoVoltaParque = Integer.parseInt  (args[7]);
  int tempoExecucao = Integer.parseInt  (args[9]);
  
  parque = new Parque(numAssentos, tempoExecucao);
  semaforos = new Semaforos(qtdePassageiros);
  new Thread( new Carro( parque, this.semaforos, tempoVoltaMontanha ), "Carro" ).start();
  new Thread( new GerarPassageiros( parque, this.semaforos , qtdePassageiros, tempoVoltaParque), "GerarClientes" ).start();
} 
else System.out.println("Argumentos invalidos.\n"+
    " Formato valido: java MontanhaRussa -C c -T t -N n -W w -R r "+
    "\n C(numero de Assentos) | T(tempo do passeio na montanha | "+
    "\n N(n�mero total de passageiros | W (tempo da volta do parque) |"+
    "\n R(tempo total de execucao)");
}

public boolean verificaArgumentos(String[] args){
  if ( (args[0].compareToIgnoreCase("-C") == 0) &&
       (args[2].compareToIgnoreCase("-T") == 0) &&
       (args[4].compareToIgnoreCase("-N") == 0) &&
       (args[6].compareToIgnoreCase("-W") == 0) &&
       (args[8].compareToIgnoreCase("-R") == 0) ){
           return true;
  }else return false;
}

public static void main(String[] args) {
  
  new MontanhaRussa().executar(args);
}

}
