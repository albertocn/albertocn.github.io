package babuinos;

public class Util {
	
	  public static void dormir (long max) {
	    long tempo = Math.round( Math.random() * max );  
	    try {
	      Thread.currentThread().sleep( tempo );
	    } catch (InterruptedException ie) {
	      ie.printStackTrace();
	    }
	  }

}
