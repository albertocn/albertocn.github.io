package starvation;

import java.util.concurrent.Semaphore;

/*
 * UNIVERSIDADE FEDERAL DE SERGIPE
 * Disciplina: Programa��o Concorrente
 * Prof�: Alberto Costa Neto
 * Alunos: 	Kalil Araujo Bispo
 * 			Tiago Nunes Mota de Aquino
 * 
 * Projeto 1:  
 * Problema dos babuinos querendo atravesar um desfiladeiro atrav�s 
 * de uma Corda
 *  
 */

public class Corda {
	
	public static Corda corda = new Corda(); 
	
	public int atravessandoDIR = 0, atravessandoESQ = 0;
	
	public Semaphore semaforoDonoDaCorda = new Semaphore(1); 
	// semaforo bin�rio que indica quem est� com o dominio da ponte
	public Semaphore semaforoMutexDireita = new Semaphore(1);
	// semaforo bin�rio que controla a variavel atravessandoDIR 
	public Semaphore semaforoMutexEsquerda = new Semaphore(1);
	// semaforo bin�rio que controla a variavel atravessandoESQ

	
	public void iniciarTravessiaEsquerda() throws InterruptedException
	{
		semaforoMutexEsquerda.acquire(); // este sem�foro trata da exclus�o m�tua do recurso compartilhado: atravessandoESQ
		atravessandoESQ++;
		logBaboo(true, "QUER ATRAVESSAR" );
		if (atravessandoESQ == 1) { 	// caso base para adquirir o controle da corda 
			semaforoDonoDaCorda.acquire();
			logCorda("CONTROLE DOS BABU�NOS DA ESQUERDA");
		}
		logBaboo(true, "ATRAVESSANDO A CORDA" );
		semaforoMutexEsquerda.release(); // libera o recurso: atravessandoESQ
	}

	public void terminarTravessiaEsquerda() throws InterruptedException
	{
		semaforoMutexEsquerda.acquire(); // este sem�foro trata da exclus�o m�tua do recurso compartilhado: atravessandoESQ
		atravessandoESQ--;
		logBaboo(true, "ATRAVESSOU... AINDA TEM " +atravessandoESQ +" BABU�NOS NA CORDA");
		if (atravessandoESQ == 0) {  // caso n�o haja mais babuinos a atravessar ent�o libera a corda
			semaforoDonoDaCorda.release();
			logCorda("CORDA VAZIA");
		}
		
		semaforoMutexEsquerda.release();
	}

	public void iniciarTravessiaDireita() throws InterruptedException
	{
		semaforoMutexDireita.acquire(); // este sem�foro trata da exclus�o m�tua do recurso compartilhado: atravessandoDIR
		atravessandoDIR++;
		logBaboo(false, "QUER ATRAVESSAR" );
		if (atravessandoDIR == 1) {   // caso base para adquirir o controle da corda 
			semaforoDonoDaCorda.acquire();
			logCorda("CONTROLE DOS BABU�NOS DA DIREITA");
		}
		logBaboo(false, "ATRAVESSANDO A CORDA" );
		semaforoMutexDireita.release(); // libera o recurso: atravessandoDIR
	}

	public void terminarTravessiaDireita() throws InterruptedException
	{
		semaforoMutexDireita.acquire(); // este sem�foro trata da exclus�o m�tua do recurso compartilhado: atravessandoDIR
		atravessandoDIR--;
		logBaboo(false, "ATRAVESSOU... AINDA TEM " +atravessandoDIR +" BABU�NOS NA CORDA");
		if (atravessandoDIR == 0) { // caso n�o haja mais babuinos a atravessar ent�o libera a corda
			semaforoDonoDaCorda.release();
			logCorda("CORDA VAZIA");
		}
		semaforoMutexDireita.release();
	}
	
	
	
	public void logBaboo(boolean isEsquerda, String msg)
	{
		System.out.print("[Babu�no #" +Thread.currentThread().getName() + " da ");
		if (isEsquerda){
			System.out.print("ESQUERDA]: ");
			
		} else
		{
			System.out.print("DIREITA]: ");
		}
		System.out.println(msg);
	}

	public void logCorda(String msg)
	{
		System.out.println("[CORDA] :" +msg);
	}

	
}
