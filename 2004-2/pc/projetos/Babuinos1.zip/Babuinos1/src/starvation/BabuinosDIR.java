package starvation;

import babuinos.Util;

public class BabuinosDIR implements Runnable {
	 

	public void run() {
		try {
			Util.dormir(1000);	
			Corda.corda.iniciarTravessiaDireita();
			Util.dormir(1000);
			Corda.corda.terminarTravessiaDireita();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
