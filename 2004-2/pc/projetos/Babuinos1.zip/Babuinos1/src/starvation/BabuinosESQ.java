package starvation;

import babuinos.Util;

public class BabuinosESQ implements Runnable {

	public void run() {
		try {
			Util.dormir(1000);
			Corda.corda.iniciarTravessiaEsquerda();
			Util.dormir(1000);
			Corda.corda.terminarTravessiaEsquerda();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
