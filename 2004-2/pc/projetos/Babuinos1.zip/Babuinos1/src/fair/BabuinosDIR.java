package fair;

import babuinos.Util;

public class BabuinosDIR implements Runnable {
	 

	public void run() {
		try {
			Util.dormir(1000);	
			CordaFair.corda.iniciarTravessiaDireita();
			Util.dormir(1000);
			CordaFair.corda.terminarTravessiaDireita();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
