package fair;


public class ProblemaFair {

	public static final int NUM_ESQ = 10;

	public static final int NUM_DIR = 10;

	public static void main(String[] args) {

		for (int c = 0; c < NUM_DIR; c++) {
			(new Thread(new BabuinosDIR(), c + "")).start();
		}
		for (int c = 0; c < NUM_ESQ; c++) {
			(new Thread(new BabuinosESQ(), c + "")).start();
		}

	}
}
