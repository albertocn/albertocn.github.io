package fair;

import babuinos.Util;

public class BabuinosESQ implements Runnable {

	public void run() {
		try {
			Util.dormir(1000);
			CordaFair.corda.iniciarTravessiaEsquerda();
			Util.dormir(1000);
			CordaFair.corda.terminarTravessiaEsquerda();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
