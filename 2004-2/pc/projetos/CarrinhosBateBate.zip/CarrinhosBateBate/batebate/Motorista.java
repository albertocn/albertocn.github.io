/*
 * Created on 23/02/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package batebate;

/**
 * @author Diego e Christiano
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
class Motorista implements Runnable{
    public Coordenador coord = null;   // Coord chama os metodos passear, entrar_fila, preparar_carro e executar_passeio
    public int id = -1;                //identificador do carro
    public Carro carro = null;         //Motorista, necess�rio para associa carro a um motorista 
    public int TempodePasseio;         //TempodePasseio, cada motorista ter� um tempo m�ximo para passear no parque 
 
    /**
     * Construtor da Classe Motorista
     *
     * @param id Identificador da classe Motorista, 
     * cada Motorista tem um identificador �nico. 
     * @param c Coordenador que � repons�vel 
     * pelo acesso exclusivo a vari�veis compartilhadas.
     */ 
    public Motorista ( int id,   Coordenador c) {  
      	this.id = id;
      	coord = c;
    }
    
    /**
     * A Thread Motorista fica executando at� a aplica��o terminar.
     */
    
    public void run(){
	  while(true)	  {
	    coord.passear(TempodePasseio);  //O motorista est� passenado pelo parque, simulado pelo sleep()
	    coord.entrar_fila(this);        //Adiciona o motorista na fila de espera para entrar no batebate
	    coord.preparar_carro(this);     //Remove o primeiro motorista da fila de espera
	    coord.executar_passeio(this);   //Associa o motorista ao carro livre a mais tempo
	  }
    }
}
