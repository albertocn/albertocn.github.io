/*
 * Created on 23/02/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package batebate;

import java.util.concurrent.Semaphore;
import java.util.Vector;

/**
 * @author Diego
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
class Coordenador {	
    private Semaphore mutexmotorista = new Semaphore( 1 );    //  Sem�foro bin�rio inicializado com 1 (um) para garantir exclus�o m�tua na fila de pessoas.
    private Vector filademotoristas = new Vector();           // fila de motoristas
  
    private Semaphore mutexcarro = new Semaphore( 1 );        // Semaforo binario para controlar o n� de carros da fila de espera
    private Vector filadecarros = new Vector();               // fila de carros
    
  	
    public Coordenador(){  
    }
    
    public void entrar_fila(Motorista m){
    	try{
    		mutexmotorista.acquire();
    		filademotoristas.add(m);
    		log ("Acabou o seu passeio e est� na fila para o batebate.  Qdade de motoristas na fila= " + filademotoristas.size());
    		mutexmotorista.release();
    		boolean teste = true;
        	while (teste) {
        		mutexcarro.acquire();
        		mutexmotorista.acquire();
        		teste = (filadecarros.isEmpty()) || (m.id != ((Motorista)filademotoristas.elementAt(0)).id);
        		mutexmotorista.release();
        		mutexcarro.release();
        	};
    	} catch (InterruptedException e){
    		System.err.println("InterruptedException, esperar novamente");
    	}	
    }
    
    public void preparar_carro(Motorista m)    {
  		try {
  			mutexcarro.acquire();
  			mutexmotorista.acquire();
  			if ((! filademotoristas.isEmpty()) && (! filadecarros.isEmpty())) {
  				filademotoristas.remove(0);
  				m.carro = (Carro)filadecarros.remove(0);
  			}
  			mutexmotorista.release();
  			mutexcarro.release();
  		} catch (InterruptedException e) {};
	  System.out.println( "Motorista " + m.id + " ==> sua vez de entrar no bate-bate.  Qdade de Motoristas na fila = " + filademotoristas.size());
   }

    public void executar_passeio(Motorista m) {
      log ( "Andando no carro " + m.carro.cid);
      m.carro.motorista = m;
      while (m.carro != null) {};
    }
    
    public void carregar(Carro c){
      try{	
	    mutexcarro.acquire();           
	    filadecarros.add(c);
	    mutexcarro.release();
	    log (" carregando.  Carros em espera = " + filadecarros.size());
      } catch (InterruptedException e){
      	 System.err.println("InterruptedException, esperar novamente");
      }
      while (c.motorista == null) {};
    }
	
    public void descarregar(Carro i){
    	log ("saiu do bate-bate e liberou motorista " + i.motorista.id);
    	i.motorista.carro = null;
    	i.motorista = null;
    }
    
    //chamado pelo motorista
    public void passear(long i) {
    	long tempo = Math.round( Math.random() * i );
    	log ("Come�ou a passear pelo parque");	   
	    try { Thread.currentThread().sleep( tempo );
	    } catch (InterruptedException ie) { ie.printStackTrace(); }
	    log("Passeando pelo parque por "+ tempo +" ms");	
	  }
     
    // chamado pelo carro
	  protected void Andar(long i) {	  	
	    long tempo = Math.round( Math.random() * i );
	    try { Thread.currentThread().sleep( tempo );
	    } catch (InterruptedException ie) { ie.printStackTrace(); }
	    log ("Tem acesso a pista de bate bate por "+ tempo +" ms");
	  }
	  
	  //Chamado pelo simula��o
	  protected void dormir(long i) {
	    try { Thread.currentThread().sleep(i);
	    } catch (InterruptedException ie) { ie.printStackTrace(); }
	  }
	  
	  private void log (String msg) {
	    System.out.println(Thread.currentThread().getName() +" ==> "+ msg );
	  } 
}