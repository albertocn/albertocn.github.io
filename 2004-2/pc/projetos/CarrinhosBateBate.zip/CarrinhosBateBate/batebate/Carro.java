/*
 * Created on 23/02/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package batebate;

/**
 * @author Diego
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * Classe que representa um carro de bate bate 
 */
class Carro implements Runnable{
    private Coordenador coord = null;   // Coord chama os metodos carregar e descarregar pessoa
    public int cid = -1;                //identificar para cada carro
    public Motorista motorista = null;  //Motorista, necess�rio para associar motorista a um carro
    public int TempodeBatidas;          //TempodeBatidas, cada carro ter� um tempo m�ximo para ficar no batebate
    
    public Carro ( int id,  Coordenador c){
    	this.cid = id;
      	this.coord = c;  
    }
    /**
     * A Thread Carro fica executando at� a aplica��o terminar.
     */
    public void run(){
	  while(true){
	    coord.carregar(this);                 // Coloca o carro na fila de espera ate chegar um motorista
        coord.Andar(TempodeBatidas);          // Dorme, simulando que a pessoa est� conduzindo o carro
	    coord.descarregar(this);              // Libera o carro para ser acessado por outro motorista e libera o atual
	  }
    }
}
