/*
 * Created on 23/02/2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package batebate;



/**
 * @author Diego Vasconcelos e Christiano Lima
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
class Simulacao{	
	
	  
	 public static void main(String[] args) {
   	   	int N_Motorista = 10;       	int N_Carro = 1;      	int Tempodebatidas = 1000;   
      	int Tempodepasseio = 1000;       	int temposimulacao = 6000;  
        for (int h = 0; h < args.length; h += 1) {
            if (h==0) N_Motorista = Integer.parseInt(args[0]);            
            if (h==1) N_Carro =     Integer.parseInt(args[1]);
            if (h==2) Tempodebatidas = Integer.parseInt(args[2]);
            if (h==3) Tempodepasseio = Integer.parseInt(args[3]);    
            if (h==4) temposimulacao = Integer.parseInt(args[4]);   
        }	
      	System.out.println("************************************************************"); 
      	System.out.println("N� de Motoristas                        =" +  N_Motorista + ",\n" +
      			           "N� de Carros                            =" + N_Carro + ", \n" +
      			           "Tempo M�ximo de simula��o de cada carro =" + Tempodebatidas + " ms, \n" +
      			           "Tempo M�ximo de passear pelo parque     =" + Tempodepasseio + " ms, \n" +
      			           "Tempo de Execu��o de toda a simula��o   =" + temposimulacao + " ms");
      	System.out.println("************************************************************");

      	Coordenador c = new Coordenador();
	    
        //Criando as Threads Carros 
      	for (int cont = 1; cont <= N_Carro; cont++) {
      		Carro carros = new Carro(cont,c);
      		carros.TempodeBatidas = Tempodebatidas;          
	        Thread t = new Thread(carros, "Carro " + cont);
	        t.start();
        }
	    
        //Criando as Threads Motoristas  
	    for (int i = 1; i <=  N_Motorista; i++) {
	    	  Motorista motoristas = new Motorista(i,c);
	    	  motoristas.TempodePasseio = Tempodepasseio;
		      Thread t = new Thread(motoristas, "Motorista " + i);
		      t.start();
	        }
       // A Thread Atual dorme por um tempo passado como par�metro.
      	c.dormir(temposimulacao); 
      	System.exit(0); 
    }
}
