package semaforos;

public interface Semaforo {
  void P();
  void V();
}
