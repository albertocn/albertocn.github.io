package semaforos;

public final class SemaforoBinario implements Semaforo {

  private SemaforoBase semaforo;

  public SemaforoBinario() {
    this (false);
  }

  public SemaforoBinario( boolean ordenado ) {
    this (ordenado, 0);
  }

  public SemaforoBinario(int initial) {
     this (false, initial);
  }

  public SemaforoBinario( boolean ordenado, int inicial ) {
    if (inicial > 1)
      throw new IllegalArgumentException("inicial>1");

    if (ordenado) {
      this.semaforo = new SemaforoBaseOrdenado(inicial);
    } else {
      this.semaforo = new SemaforoBaseNaoOrdenado(inicial);
    }
  }

  public void P() {
    semaforo.P();
  }

  public void V() {
    if (semaforo.valor() < 1)
      semaforo.V();
  }

  public String toString() {
  	return semaforo.toString();
  }
}
