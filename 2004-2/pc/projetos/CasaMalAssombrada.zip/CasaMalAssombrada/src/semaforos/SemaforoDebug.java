package semaforos;

public class SemaforoDebug implements Semaforo {

  private final Semaforo sem;
  private final String nome;

  public SemaforoDebug( Semaforo sem, String nome ) {
    this.sem = sem;
    this.nome = nome;
  }
  public void P() {
    System.out.println("[" + getNomeThread() + "] ANTES de P sobre " + getNome());
    sem.P();
    System.out.println("[" + getNomeThread() + "] DEPOIS de P sobre " + getNome());
  }
  public void V() {
    System.out.println("[" + getNomeThread() + "] ANTES de V sobre " + getNome());
    sem.V();
    System.out.println("[" + getNomeThread() + "] DEPOIS de V sobre " + getNome());
  }

  public String getNome() {
    return this.nome;
  }

  public String getNomeThread() {
    return Thread.currentThread().getName();
  }

  public String toString() {
  	return sem.toString();
  }
}
