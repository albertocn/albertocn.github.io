package semaforos;

public abstract class SemaforoBase implements Semaforo {

   // Se valor < 0, abs(valor) � o tamanho da fila de P()
   protected int valor = 0;

   protected SemaforoBase() {
     this(0);
   }

   protected SemaforoBase(int inicial) {
     if (inicial < 0) throw new IllegalArgumentException("inicial<0");
       valor = inicial;
   }

   public synchronized int valor() {
      return valor;
   }

   public synchronized String toString() {
      return String.valueOf(valor);
   }
}
