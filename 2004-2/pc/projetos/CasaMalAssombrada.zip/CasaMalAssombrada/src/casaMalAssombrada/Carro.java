package casaMalAssombrada;

public class Carro implements Runnable {

  public static final double TEMPO_VOLTA = 5000.0;

  protected final CasaMalAssombrada casa;
  protected final Semaforos semaforos;

  public Carro(CasaMalAssombrada casa, Semaforos semaforos) {
    this.casa = casa;
    this.semaforos = semaforos;
  }

  public void run() {
    while (true) {
      logCarro ("Aguardando passageiro para passear");
      semaforos.passageiros.P(); // Espera algum passageiro chegar
      logCarro ("H� algum passageiro");
      semaforos.mutex.P();
      casa.decPassageirosEsperando();
      logCarro ("Passageiro entrando no carro");
      semaforos.carro.V();
      semaforos.mutex.V();
      passear();
      semaforos.passeando.V();
    }
  }

  protected void passear() {
    logCarro ("Come�ando sua volta na casa");
    long tempo = Math.round( Math.random() * TEMPO_VOLTA );
    try { Thread.sleep( tempo );
    } catch (InterruptedException ie) { ie.printStackTrace(); }
    logCarro ("Terminando sua volta na casa");
  }

  private void logCarro (String msg) {
    System.out.println("[Carro]: " + msg + " em " + casa.getTempoTotal() + " ms");
  }
}
