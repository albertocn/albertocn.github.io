package casaMalAssombrada;

public class CasaMalAssombrada {

  public static final int N_CADEIRAS = 5;
  public static final long inicio = System.currentTimeMillis();
  public static final double pesoMax = 400;
  public static final double pesoMin = 50;

  private int passageirosEsperando = 0;

  public int getPassageirosEsperando() { return passageirosEsperando; }
  public void decPassageirosEsperando() { passageirosEsperando--; }
  public void incPassageirosEsperando() { passageirosEsperando++; }

  public long getTempoTotal() {
    return System.currentTimeMillis() - inicio;
  }
}
