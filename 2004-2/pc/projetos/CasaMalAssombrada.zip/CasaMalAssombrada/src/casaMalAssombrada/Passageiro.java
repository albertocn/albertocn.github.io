package casaMalAssombrada;

public class Passageiro implements Runnable {

  protected final int id;
  protected final double peso;
  protected final CasaMalAssombrada casa;
  protected final Semaforos semaforos;

  public Passageiro( int id, double peso, CasaMalAssombrada casa, Semaforos semaforos  ) {
    this.id = id;
    this.peso = peso;
    this.casa = casa;
    this.semaforos = semaforos;
  }

  public void run() {
    semaforos.mutex.P();
    if (casa.getPassageirosEsperando() < CasaMalAssombrada.N_CADEIRAS) {
      casa.incPassageirosEsperando();
      semaforos.passageiros.V();
      semaforos.mutex.V();
      logPassageiro ("Eu quero passear na casa");
      semaforos.carro.P();
      semaforos.passeando.P();
      logPassageiro ("�ba!!! Passeei na casa");
    } else {
      semaforos.mutex.V();
      System.out.println("Que pena que agora t� cheio! Depois volto ");
    }
  }

  private void logPassageiro (String msg) {
    System.out.println("[Passageiro" + id + "]: " + msg + " em " + casa.getTempoTotal() + " ms");
  }
}
