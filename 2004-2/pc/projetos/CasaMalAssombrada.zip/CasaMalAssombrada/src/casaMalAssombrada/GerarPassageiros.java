package casaMalAssombrada;

public class GerarPassageiros implements Runnable {

  public static final double INTERVALO = 2000.0;

  protected final CasaMalAssombrada casa;
  protected final Semaforos semaforos;

  public GerarPassageiros (CasaMalAssombrada casa, Semaforos semaforos) {
    this.casa = casa;
    this.semaforos = semaforos;
  }

  public Passageiro criarPassageiro(int id, double peso) {
    return new Passageiro( id, peso, casa, semaforos );
  }

  public void run() {
    for (int cont = 1; cont <= 5; cont++) {
      double peso = Math.round (Math.random() * (casa.pesoMax - casa.pesoMin) + casa.pesoMin);

      Thread t = new Thread(criarPassageiro(cont, peso), "Passageiro " + cont);
      t.start();

      long tempo = Math.round( Math.random() * INTERVALO );
      try { Thread.sleep( tempo );
      } catch (InterruptedException ie) { ie.printStackTrace(); }
    }
  }
}
