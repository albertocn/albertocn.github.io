package casaMalAssombrada;

public class Exemplo {

  private Semaforos semaforos;
  private CasaMalAssombrada casa;

  public Exemplo() {
    this.semaforos = new Semaforos();
  }

  public void executar() {
    casa = new CasaMalAssombrada();
    new Thread( new Carro (casa, this.semaforos), "Carro" ).start();
    new Thread( new GerarPassageiros (casa, this.semaforos), "GerarPassageiros" ).start();
  }

  public static void main(String[] args) {
    new Exemplo().executar();
  }
}
