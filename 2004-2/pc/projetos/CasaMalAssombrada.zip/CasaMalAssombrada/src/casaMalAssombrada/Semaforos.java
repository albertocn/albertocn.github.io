package casaMalAssombrada;

import semaforos.Semaforo;
import semaforos.SemaforoBinario;
import semaforos.SemaforoContador;

public class Semaforos {

  public final Semaforo mutex;
  public final Semaforo passageiros;
  public final Semaforo carro;
  public final Semaforo passeando;

  public Semaforos() {
    this.mutex       = criarSemMutex();
    this.passageiros = criarSemPassageiros();
    this.carro       = criarSemCarro();
    this.passeando   = criarSemPasseando();
  }

  protected Semaforo criarSemMutex() {
//    return new SemaforoDebug( new SemaforoBinario( 1 ), "MUTEX" );
    return new SemaforoBinario( 1 );
  }
  protected Semaforo criarSemPassageiros() {
//    return new SemaforoDebug( new SemaforoContador( 0 ), "CLIENTES" );
    return new SemaforoContador( 0 );
  }
  protected Semaforo criarSemCarro() {
//    return new SemaforoDebug( new SemaforoBinario( 0 ), "BARBEIRO" );
   return new SemaforoBinario( 0 );
  }
  protected Semaforo criarSemPasseando() {
//    return new SemaforoDebug( new SemaforoBinario( 0 ), "CORTANDO" );
    return new SemaforoBinario( 0 );
  }
}
