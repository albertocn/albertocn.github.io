package pc.venda;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

import pc.ui.Log;
import pc.mensagem.Rendezvous;
import pc.mensagem.ExtendedRendezvousRemote;
import pc.padaria.*;


public class ClienteRemote {

  private String nomeCustomer;
  private int porta;
  private String nomeServer;
  private Log logSalesperson;
  private Log logCustomer;
  private int paoJaco;
  private int paoDoce;
  private long tempoInicio;

  private Rendezvous rendezvous;

  public ClienteRemote(String nomeCustomer, String nomeServer, int porta, int paoJaco,
                       int paoDoce, Log logCustomer, long tempoInicio) {
    this.nomeCustomer = nomeCustomer;
    this.nomeServer = nomeServer;
    this.porta = porta;
    this.logCustomer = logCustomer;
    this.paoJaco = paoJaco;
    this.paoDoce = paoDoce;
    this.tempoInicio = tempoInicio;
  }

  public void iniciar() {
    rendezvous = new ExtendedRendezvousRemote(nomeServer, porta);
    criarCustomers( nomeCustomer );
  }

  public void close() {
    rendezvous.close();
  }

  public void criarCustomers( String nomeCustomer ) {
    new Customer(rendezvous, nomeCustomer, paoJaco, paoDoce, logCustomer, tempoInicio).iniciar();
  }
}
