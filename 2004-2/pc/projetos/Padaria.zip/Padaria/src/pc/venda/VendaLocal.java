package pc.venda;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */


import pc.ui.Log;
import pc.mensagem.Rendezvous;
import pc.mensagem.ExtendedRendezvous;
import pc.padaria.*;


public class VendaLocal{

  private int salesperson;
  private int customer;
  private Log log;
  private long tempoInicio;

  private Rendezvous rendezvous;

  public VendaLocal(int salesperson, int customer, Log log, long tempoInicio) {
    this.salesperson = salesperson;
    this.customer = customer;
    this.tempoInicio = tempoInicio;
    this.log = log;
  }

  public void iniciar() {
    rendezvous = new ExtendedRendezvous();
    criarSalespersons( salesperson );
    criarCustomers( customer );
  }

  public void close() {
    rendezvous.close();
  }

  public void criarSalespersons( int numSalesperson ) {
    for ( int i = 1; i <= numSalesperson; i++)
      new Salesperson(rendezvous, "VENDEDOR "+i, log, tempoInicio).iniciar();
  }

  public void criarCustomers( int numCostumer ) {
    for ( int i = 1; i <= numCostumer; i++)
      new Customer(rendezvous, "CLIENTE "+i, 10, 5, log, tempoInicio).iniciar();
  }
}