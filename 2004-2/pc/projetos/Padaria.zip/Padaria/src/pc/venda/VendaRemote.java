package pc.venda;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

import pc.ui.Log;
import pc.mensagem.Rendezvous;
import pc.mensagem.ExtendedRendezvousRemote;
import pc.padaria.*;


public class VendaRemote {

  private int salesperson;
  private int porta;
  private Log logSalesperson;
  private long tempoInicio;

  private Rendezvous rendezvous;

  public VendaRemote(int salesperson, int porta, Log logSalesperson, long tempoInicio) {
    this.salesperson = salesperson;
    this.porta = porta;
    this.logSalesperson = logSalesperson;
    this.tempoInicio = tempoInicio;
  }

  public void iniciar() {
    rendezvous = new ExtendedRendezvousRemote(porta);
    criarSalespersons( salesperson );
  }

  public void close() {
    rendezvous.close();
  }

  public void criarSalespersons( int numSalesperson ) {
    for ( int i = 1; i <= numSalesperson; i++)
      new Salesperson(rendezvous, "VENDEDOR "+i, logSalesperson, tempoInicio).iniciar();
  }
}
