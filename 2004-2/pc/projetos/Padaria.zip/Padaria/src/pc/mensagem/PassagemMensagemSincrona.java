package pc.mensagem;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

import semaforo.SemaforoContador;
import semaforo.SemaforoBaseOrdenado;

/**
 * <p>Implementa a passagem de mensagens s�ncronas intra-JVM
 * <p>Tanto o envio como a recep��o s�o s�ncronos (Rendezvous).
 */
public final class PassagemMensagemSincrona implements PassagemMensagem {

   private Object msg = null;
   private final Object enviando = new Object();
   private final Object recebendo = new Object();
   private final SemaforoContador semEnviando = new SemaforoContador(true, 0);
   private final SemaforoContador semRecebendo = new SemaforoContador(true, 0);

   public final void enviar(Object m) {
     if (m == null) {
       throw new NullPointerException("N�o � permitida uma mensagem null");
     }
     synchronized (enviando) {
       msg = m;
       semEnviando.V();
       semRecebendo.P();
     }
   }

  public final Object receber() {
    Object mensagemRecebida = null;
    synchronized (recebendo) {
      semEnviando.P();
      mensagemRecebida = msg;
      semRecebendo.V();
    }
    return mensagemRecebida;
  }

  public void close() {}
}
