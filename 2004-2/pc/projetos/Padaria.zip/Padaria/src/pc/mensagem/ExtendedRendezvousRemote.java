package pc.mensagem;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

import java.net.Socket;
import java.net.ServerSocket;
import java.io.IOException;

public class ExtendedRendezvousRemote implements Rendezvous {

  private ServerSocket serverSocket = null;
  private String nomeServidor;
  private int porta;

  private PassagemMensagem in = null;
  private PassagemMensagem out = null;

  /** Inter-JVM chamado pelo cliente */
  public ExtendedRendezvousRemote(String nomeServidor, int porta) {
    this.nomeServidor = nomeServidor;
    this.porta = porta;
  }

  /** Inter-JVM chamado pelo servidor */
  public ExtendedRendezvousRemote(int porta) {
    createSocket(porta);
  }


  /**
   * Chamado pelo cliente, retornando apenas quando o servidor tiver
   * processado a requisi��o.
   * @param m Mensagem usada durante o processamento pelo servidor
   * @return Mensagem de resposta do servidor
   */
  public Object remetenteFazRequisicaoEsperaResposta(Object m) {
     PassagemMensagem pm = obterConexao(nomeServidor, porta);
     this.in = pm;
     this.out = pm;
     in.enviar( m );
     return out.receber();
  }

  /**
   * Chamado pelo Servidor para bloque�-lo at� que o cliente envie
   * uma requisi��o
   *
   * @return Retorna o objeto passado pelo cliente ao fazer a requisi��o
   */
  public Object destinatarioRecebeRequisicao() {
    PassagemMensagem pm = obterConexao();
    this.in = pm;
    this.out = pm;
    return in.receber();
  }

  /**
   * Chamado pelo servidor ap�s processar a requisi��o
   *
   * @param m Mensagem de resposta para o cliente
   */
  public void destinatarioEnviaResposta(Object m) {
     out.enviar( m );
  }

  public void close() {
    in.close();
    out.close();
  }

  public void createSocket(int porta) {
    try {
      serverSocket = new ServerSocket(porta);
    }
    catch (IOException e) {
      e.printStackTrace();
      //throw new PassagemMensagemException();
    }
  }

  public PassagemMensagem obterConexao() {
    Socket socket = null;
    try {
      socket = serverSocket.accept();
    } catch (IOException e) {
      throw new PassagemMensagemException();
    }
    return new PassagemMensagemPipeObjeto(socket);
  }

  public PassagemMensagem obterConexao(String nomeServidor, int porta) {
    Socket socket = null;
    try {
      socket = new Socket(nomeServidor, porta);
    } catch (IOException e) {
      throw new PassagemMensagemException();
    }
    return new PassagemMensagemPipeObjeto(socket);
  }


}