package pc.mensagem;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

public interface Rendezvous {

   /** Remetente faz requisi��o e espera at� que o servidor responda */
   Object remetenteFazRequisicaoEsperaResposta(Object m);

   /** Destinat�rio recebe requisi��o do remetente */
   Object destinatarioRecebeRequisicao();

   /** Destinat�rio envia resposta para o remtente */
   void destinatarioEnviaResposta(Object m);

   /** Encerra o rendezvous */
   void close();
}
