package pc.mensagem;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

/** Indica um erro ocorrido durante a passagem de mensagem */
public final class PassagemMensagemException extends RuntimeException {
   public PassagemMensagemException()         { super(); }
   public PassagemMensagemException(String s) { super(s); }
}
