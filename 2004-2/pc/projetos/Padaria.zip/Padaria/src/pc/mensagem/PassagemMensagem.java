package pc.mensagem;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 *
 * Interface para passagem de mensagens
 */

public interface PassagemMensagem {

  /** Faz um envio de uma mensagem */
  void enviar(Object m);

  /** Espera a resposta da mensagem enviada */
  Object receber();

  /** Finaliza o processo */
  void close();
}
