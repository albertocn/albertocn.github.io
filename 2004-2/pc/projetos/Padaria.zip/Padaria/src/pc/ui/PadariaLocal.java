package pc.ui;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import pc.venda.VendaLocal;


public class PadariaLocal extends JFrame {

  VendaLocal venda = null;

  //Cria��o dos Componentes que ser�o utilizados no Frame
  private JLabel lblVendedores = new JLabel("N�MERO DE VENDEDORES: ");
  private JTextField vendedoresField = new JTextField(5);

  private JLabel lblClientes = new JLabel("N�MERO DE CLIENTES: ");
  private JTextField clientesField = new JTextField(5);

  private JLabel lblResultados = new JLabel(" ");
  private JTextArea resultados = new JTextArea(20, 60);

  private JButton btnAbrirPadaria = new JButton("Abrir Padaria");
  private JButton btnFecharPadaria = new JButton("Fechar Padaria");

  public PadariaLocal() {
    Container cp = getContentPane();

    // Cria um GridLayout com um n�mero n�o especificado de linhas,
    // com 2 colunas, que mant�m uma dist�ncia horizontal de 5 pixels
    // e uma dist�ncia vertical de 10 pixels entre os componentes
    cp.setLayout(new BorderLayout());
    // Adiciona os bot�es ao grupo


    resultados.setFont(new Font("Serif", Font.BOLD, 16));
    JPanel cima = new JPanel(new BorderLayout());
    //JPanel dentroBaixo = new JPanel(new BorderLayout());
    JPanel pn00 = new JPanel(new FlowLayout());
    JLabel titulo = new JLabel("PADARIA DO SEU MANEL \n");
    Font fonte = new Font("Serif", Font.BOLD, 35);
    titulo.setFont(fonte);
    titulo.setForeground( Color.BLUE );
    pn00.add( titulo );
    JPanel pn0 = new JPanel(new GridLayout(0,4,6,10));
    //pn0.setAlignmentX( JPanel.LEFT_ALIGNMENT );
    pn0.add(lblVendedores);
    vendedoresField.setText("2");
    pn0.add(vendedoresField);
    pn0.add(lblClientes);
    clientesField.setText("10");
    pn0.add(clientesField);

    cima.add(BorderLayout.NORTH, pn00);
    //cima.add(dentroCima, BorderLayout.NORTH);

    JPanel grid = new JPanel(new BorderLayout());
    cima.add(BorderLayout.CENTER, grid);

    cima.add(BorderLayout.SOUTH, lblResultados);

    JPanel pn3 = new JPanel(new FlowLayout());
    JScrollPane spTextArea = new JScrollPane(resultados,
                                             JScrollPane.
                                             VERTICAL_SCROLLBAR_ALWAYS,
                                             JScrollPane.
                                             HORIZONTAL_SCROLLBAR_ALWAYS);

    pn3.add(spTextArea);
    cp.add(BorderLayout.CENTER, pn3);

    JPanel pn4 = new JPanel(new FlowLayout());
    pn0.add(btnAbrirPadaria);
    pn0.add(btnFecharPadaria);

    cp.add(BorderLayout.NORTH, cima);
    cp.add(BorderLayout.SOUTH, pn0);

    btnAbrirPadaria.addActionListener(new BotaoAbrirListener());
    btnFecharPadaria.addActionListener(new BotaoFecharListener());
  }

  private class BotaoAbrirListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      try {
        //Busca os dados da interface
        int vendedores = (new Integer("0" + vendedoresField.getText())).intValue();
        int clientes   = (new Integer("0" + clientesField.getText())).intValue();

        resultados.setText("");
        //Intancia o local do Log onde vai ser impressa
        Log log = new Log(resultados);
        long tempoInicio = System.currentTimeMillis();
        //Inicia uma venda na m�quina local
        venda = new VendaLocal(vendedores, clientes, log, tempoInicio);
        venda.iniciar();
      }
      catch (Exception erro) {
        erro.printStackTrace();
        JOptionPane.showMessageDialog(null, "Erro nos dados informados!",
                                      "Erro", JOptionPane.ERROR_MESSAGE);
      }
    }
  }

  private class BotaoFecharListener
      implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      if ( venda != null )
        venda.close();
    }
  }

  public static void main(String args[]) {
    JFrame f = new PadariaLocal();
    f.pack();
    f.show();

    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }
}
