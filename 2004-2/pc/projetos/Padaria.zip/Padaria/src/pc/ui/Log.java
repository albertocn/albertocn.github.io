package pc.ui;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

import javax.swing.*;

public class Log {

  private JTextArea result;

  public Log(JTextArea result) {
    this.result = result;
  }

  public Log() {
    result = null;
  }

  public void println(String msg) {
    if ( result == null )
      System.out.println( msg );
    else
      result.append( msg + "\n");
  }

}