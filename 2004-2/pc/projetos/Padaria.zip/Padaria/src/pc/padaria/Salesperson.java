package pc.padaria;

import pc.mensagem.Rendezvous;
import pc.mensagem.Tarefa;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

import pc.ui.Log;

/** Representa ops vendedores que ficam na padaria a espera de algum cliente
 * para atender.
 */

public class Salesperson implements Runnable {

  /* Canal de comunica��o */
  private Rendezvous rendezvous;

  /* Nome dos vendedores */
  private String nomeSalesperson;

  /* Dados para impress�o */
  private Log print;
  private long tempoInicio;

  /** Construtor padr�o */
  public Salesperson(Rendezvous rendezvous, String nomeSalesperson, Log print, long tempoInicio) {
    this.rendezvous = rendezvous;
    this.nomeSalesperson = nomeSalesperson;
    this.tempoInicio = tempoInicio;
    this.print = print;
  }

  /** Inicia o trabalho de vendedores */
  public void iniciar() {
    Thread t = new Thread (this, nomeSalesperson);
    t.start();
  }

  public void run() {
    while (true) {
      log ("Chama o pr�ximo cliente");
      Tarefa tarefa = (Tarefa) rendezvous.destinatarioRecebeRequisicao();
      log ("Come�a a atender o cliente [" + tarefa.getSolicitador()+ "]");
      tarefa.executar();
      log ("Buscando os p�es no forno do cliente [" + tarefa.getSolicitador()+ "]");
      rendezvous.destinatarioEnviaResposta(tarefa);
      log ("P�es entregues ao cliente [" + tarefa.getSolicitador()+ "]");
    }
  }

  private void log(String msg) {
    long tempo = System.currentTimeMillis() - tempoInicio;
    print.println("[ "+nomeSalesperson+" ]  " + msg + " em "+tempo+" ms");
  }
}
