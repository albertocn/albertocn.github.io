package pc.padaria;

import pc.mensagem.Tarefa;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

/** Implementa a tarefa que vai ser enviada pelo cliente para ser executada
 *  no servidor.
 */

public class ComprarPao implements Tarefa {

  /** Quantidade solicitada de p�es jac� */
  private int quantidadePaoJaco;
  /** Quantidade solicitada de p�es doce */
  private int quantidadePaoDoce;
  /** Nome do consumidor que socita a tarefa */
  private String nomeCustomer;


  /** Construtor padr�o */
  public ComprarPao(int quantidadePaoJaco, int quantidadePaoDoce, String nomeCustomer) {
    this.quantidadePaoJaco = quantidadePaoJaco;
    this.quantidadePaoDoce = quantidadePaoDoce;
    this.nomeCustomer = nomeCustomer;
  }

  /** Executa a tarefa incrementando em 1 unidade o n�mero de p�es doce e p�es jac� */
  public void executar() {
    try { Thread.sleep(1000); }
    catch (InterruptedException ie) {}

    //incrementa os p�es da promo��o
    quantidadePaoDoce++;
    quantidadePaoJaco++;
  }

  public int getQuantidadePaoDoce() {
    return quantidadePaoDoce;
  }

  public int getQuantidadePaoJaco() {
    return quantidadePaoJaco;
  }

  public String getSolicitador() {
    return nomeCustomer;
  }
}
