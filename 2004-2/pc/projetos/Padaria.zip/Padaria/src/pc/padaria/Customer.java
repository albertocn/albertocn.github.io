package pc.padaria;

/**
 * <p>Title: Lamport's Bakery</p>
 * <p>Description: Implementa uam solu��o para o problema utilizando Rendezvous</p>
 * <p>Copyright: Copyright (c) 2005</p>
 * <p>Company: DCCE - UFS</p>
 * @author Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

import pc.mensagem.Tarefa;
import pc.mensagem.Rendezvous;
import pc.ui.Log;

/** Representa os clientes que v�o a padaria para comprar os p�es */
public class Customer implements Runnable {

  /* Canal de comunica��o */
  private Rendezvous rendezvous;

  /* Dados da venda */
  private String nomeCustomer;
  private int paoJaco;
  private int paoDoce;

  /* Dados para impress�o */
  private Log printLog;
  private long tempoInicio;

  /** Construtor padr�o */
  public Customer(Rendezvous rendezvous, String nomeCustomer, int paoJaco, int paoDoce, Log printLog, long tempoInicio) {
    this.rendezvous = rendezvous;
    this.nomeCustomer = nomeCustomer;
    this.paoJaco = paoJaco;
    this.paoDoce = paoDoce;
    this.printLog = printLog;
    this.tempoInicio = tempoInicio;
  }

  /** Inicia o trabalho dos vendedores na padaria */
  public void iniciar() {
    Thread t = new Thread (this, nomeCustomer);
    t.start();
  }

  public void run() {
    log ("Entra na padaria e descansa");
    descansa();
    Tarefa tarefa = new ComprarPao(paoJaco, paoDoce, nomeCustomer);
    log ("Busca seu blihete de ordem de atendimento");
    Object resp = rendezvous.remetenteFazRequisicaoEsperaResposta( tarefa );
    log ("Chamado e sendo atendido");
    ComprarPao cp = (ComprarPao) resp;
    log ("Conferido "+ cp.getQuantidadePaoJaco()+ " p�es jac� e " +
         cp.getQuantidadePaoDoce() + " p�es doce. Gostei da Promo��o!");
    log( "Cliente sai da padaria" );
  }

  private void log(String msg) {
    long tempo = System.currentTimeMillis() - tempoInicio;
    printLog.println("[ "+nomeCustomer+" ]  " + msg + " em "+tempo+" ms");
  }

  private void descansa() {
    long tempo = Math.round( Math.random() * 2000 );
    try { Thread.sleep( tempo );
    } catch (InterruptedException ie) { ie.printStackTrace(); }
  }

}