package babuinosmonitor;

import java.util.*;

/**
 * <p>Description: Monitor que controla a corda para os babu�nos.</p>
 */
public class MonitorCorda {

//Momento em que o monitor foi criado.
  private final long inicial;
//Limite de babuinos que podem atravessar de cada lado quando h� concorrencia.
  private int num_Limite;
//Controla a quantidade de babu�nos que ir�o atravessar por vez havendo concorrencia.
  private int cont_Corda;
//N�mero de babu�nos que est�o atravessando da esquerda para a direita.
  private int num_Bab_Esq = 0;
//N�mero de babu�nos que est�o atravessando da direita para a esquerda.
  private int num_Bab_Dir = 0;
//Listas de babu�nos que est�o esperando em cada um dos lados.
  private List bab_Esperando_Esq = criarList();
  private List bab_Esperando_Dir = criarList();

  /**
   * Contrutor da classe
   */
  public MonitorCorda() {
    inicial = System.currentTimeMillis();
  }

  /**
   * Cria uma lista sincronizada do tipo Linked List.
   * @return Uma lista sincronizada.
   */
  protected List criarList() {
    return Collections.synchronizedList(new LinkedList());
  }

  /**
   * Inicia a travessia da esquerda para a direita
   */
  public void iniciarTravessiaED() {
    //cria um lock para cada um dos babu�nos.
    Object lock = new Object();
    synchronized (lock) {
      System.out.println("[E->D] " + Thread.currentThread().getName() +
          " quer atravessar!                   Numero de babuinos atravessando na" +
          " sua direcao = " + num_Bab_Esq + ".");
      //A thread dorme caso n�o possa atravessar.
      if (naoPodeAtravessarED(lock)) {
        try {
          System.out.println("[E->D] " + Thread.currentThread().getName() +
                             " esta esperando na fila!");
          lock.wait();
          System.out.println(
              "[E->D] " + Thread.currentThread().getName() +
              " esta atravessando!                 Numero de babuinos atravessando = " +
              num_Bab_Esq + ".");
          /*  Ao acordar, ela acorda a pr�xima thread na fila se: existe
           mais algu�m atr�s dela e o contador estiver abaixo do seu limite,
           ou se ultrapassar o contador mas n�o houver babuinos esperando do
           outro lado. */
          if (!bab_Esperando_Esq.isEmpty() &&
              (cont_Corda < num_Limite || bab_Esperando_Dir.isEmpty())) {
            synchronized (bab_Esperando_Esq.get(0)) {
              bab_Esperando_Esq.get(0).notify();
              //remo��o da thread acordada
              bab_Esperando_Esq.remove(0);
              num_Bab_Esq++;
              cont_Corda++;
            }
          }
        }
        catch (InterruptedException ie) {}
      }
      else
        System.out.println(
            "[E->D] " + Thread.currentThread().getName() +
            " esta atravessando!                 Numero de babuinos atravessando = " +
            num_Bab_Esq + ".");
    }
  }

  /**
   * Metodo checa se o babu�no pode atravessar da esquerda para a direita.
   * @param lock Lock atribuido a cada babu�no que espera na fila.
   * @return True se ele n�o pode passar. False caso contr�rio.
   */
  private synchronized boolean naoPodeAtravessarED(Object lock) {
    /*if q coloca a thread na fila de espera se h� alguem na corda vindo em
     dire��o contr�ria ou se a fila do lado oposto tem algum babuino. Caso
     contr�rio, incrementa os valores de babu�no na corda e o contador */
    if (num_Bab_Dir > 0 || !bab_Esperando_Dir.isEmpty()) {
      bab_Esperando_Esq.add(lock);
      return true;
    }
    else {
      num_Bab_Esq++;
      cont_Corda++;
      return false;
    }
  }

  /**
   * Termina a travessia do babu�no da esquerda para a direita.
   */
  public synchronized void terminarTravessiaED() {
    num_Bab_Esq--;
    long tempo = System.currentTimeMillis()-inicial;
    //if para deixar a impress�o um pouco mais organizada.
    if (tempo >= 1000)
      System.out.println("[E->D] " + Thread.currentThread().getName() +
                         " atravessou em " +
                         (tempo) +
                         " milissegundos!  " +
                         "Numero de babuinos atravessando na corda" +
                         " em sua direcao = " + num_Bab_Esq + ".");
    else
      System.out.println("[E->D] " + Thread.currentThread().getName() +
                         " atravessou em " +
                         (tempo) +
                         " milissegundos!   " +
                         "Numero de babuinos atravessando na corda" +
                         " em sua direcao = " + num_Bab_Esq + ".");
          /*se o babu�no � o ultimo a atravessar na sua dire��o, o contador � zerado
           e o limite passa a ser o n�mero de babu�nos da fila do lado onde ele chegou.*/
    if (num_Bab_Esq == 0) {
      cont_Corda = 0;
      num_Limite = bab_Esperando_Dir.size();
      /*Se h� alguem na fila onde o babu�no chegou, ele o acorda.*/
      if (!bab_Esperando_Dir.isEmpty()) {
        synchronized (bab_Esperando_Dir.get(0)) {
          bab_Esperando_Dir.get(0).notify();
          bab_Esperando_Dir.remove(0);
          num_Bab_Dir++;
          cont_Corda++;
        }
      }
    }
  }

  /**
   * Inicia a travessia da direita para a esquerda.
   */
  public void iniciarTravessiaDE() {
    //cria um lock para cada um dos babu�nos.
    Object lock = new Object();
    synchronized (lock) {
      System.out.println("[E<-D] " + Thread.currentThread().getName() +
          " quer atravessar!                   Numero de babuinos atravessando na" +
          " sua direcao = " + num_Bab_Dir + ".");
      //A thread dorme caso n�o possa atravessar.
      if (naoPodeAtravessarDE(lock)) {
        try {
          System.out.println("[E<-D] " + Thread.currentThread().getName() +
                             " esta esperando na fila!");
          lock.wait();
          System.out.println("[E<-D] " + Thread.currentThread().getName() +
              " esta atravessando!                 Numero de babuinos atravessando = " +
              num_Bab_Dir + ".");
          /*  Ao acordar, ela acorda a pr�xima thread na fila se: existe
               mais algu�m atr�s dela e o contador estiver abaixo do seu limite,
               ou se ultrapassar o contador mas n�o houver babuinos esperando do
               outro lado. */
          if (!bab_Esperando_Dir.isEmpty() &&
              (cont_Corda < num_Limite || bab_Esperando_Esq.isEmpty())) {
            synchronized (bab_Esperando_Dir.get(0)) {
              bab_Esperando_Dir.get(0).notify();
              //remo��o da thread acordada
              bab_Esperando_Dir.remove(0);
              num_Bab_Dir++;
              cont_Corda++;
            }
          }
        }
        catch (InterruptedException ie) {}
      }
      else
        System.out.println("[E<-D] " + Thread.currentThread().getName() +
            " esta atravessando!                 Numero de babuinos atravessando = " +
            num_Bab_Dir + ".");
    }
  }

  /**
   * Metodo checa se o babu�no pode atravessar da direita para a esquerda.
   * @param lock Lock atribuido a cada babu�no que espera na fila.
   * @return True se ele n�o pode passar. False caso contr�rio.
   */
  private synchronized boolean naoPodeAtravessarDE(Object lock) {
    /*if q coloca a thread na fila de espera se h� alguem na corda vindo em
      dire��o contr�ria ou se a fila do lado oposto tem algum babu�no. Caso
      contr�rio, incrementa os valores de babu�no na corda e o contador */
    if (num_Bab_Esq > 0 || !bab_Esperando_Esq.isEmpty()) {
      bab_Esperando_Dir.add(lock);
      return true;
    }
    else {
      num_Bab_Dir++;
      cont_Corda++;
      return false;
    }
  }

  /**
   * Termina a travessia do babu�no da direita para a esquerda.
   */
  public synchronized void terminarTravessiaDE() {
    num_Bab_Dir--;
    long tempo = System.currentTimeMillis()-inicial;
    //if para deixar a impress�o um pouco mais organizada.
    if (tempo >= 1000)
      System.out.println("[E<-D] " + Thread.currentThread().getName() +
                         " atravessou em " + tempo + " milissegundos!  " +
                         "Numero de babuinos atravessando a corda" +
                         " em sua direcao = " + num_Bab_Dir + ".");
    else
      System.out.println("[E<-D] " + Thread.currentThread().getName() +
                         " atravessou em " + tempo + " milissegundos!   " +
                         "Numero de babuinos atravessando a corda" +
                         " em sua direcao = " + num_Bab_Dir + ".");
          /*se o babu�no � o ultimo a atravessar na sua dire��o, o contador � zerado
           e o limite passa a ser o n�mero de babu�nos da fila do lado onde ele chegou.*/
    if (num_Bab_Dir == 0) {
      cont_Corda = 0;
      num_Limite = bab_Esperando_Esq.size();
      /*Se h� alguem na fila onde o babu�no chegou, ele o acorda.*/
      if (!bab_Esperando_Esq.isEmpty()) {
        synchronized (bab_Esperando_Esq.get(0)) {
          bab_Esperando_Esq.get(0).notify();
          bab_Esperando_Esq.remove(0);
          num_Bab_Esq++;
          cont_Corda++;
        }
      }
    }
  }

}