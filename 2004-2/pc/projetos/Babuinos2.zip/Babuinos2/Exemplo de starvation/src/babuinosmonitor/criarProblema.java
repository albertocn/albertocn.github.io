package babuinosmonitor;

import java.util.*;

/**
 * <p>Titulo: Babu�nos atravessando o desfiladeiro</p>
 * <p>Descricao: Projeto da Disciplina Programa��o Concorrente - Babu�nos atravessando o
 * desfiladeiro.
 * <p>Grupo: Mateus Novaes e Beatriz Trinch�o</p>
 * <p>Professor: Alberto Costa Neto</p>
 * @author Beatriz e Mateus
 * @version 1.0
 */

//Classe que cria o monitor corda e instancia os babu�nos.
public class criarProblema {

  public int nBab_Dir = 0;
  public int nBab_Esq = 0;

  /**
   * Construtor da classe, gera o problema dos babu�nos criando uma corda e babu�nos.
   * @param esq N�mero de babu�nos do lado esquerdo.
   * @param dir N�mero de babu�nos do lado direito.
   */
  public criarProblema(String esq, String dir) {
    nBab_Dir = new Integer(dir).intValue();
    nBab_Esq = new Integer(esq).intValue();
    MonitorCorda corda = new MonitorCorda();
    gerarBabuinos(corda);
  }

  /**
  * Construtor utilizado no caso de o usu�rio n�o fornecer os valores iniciais
   * para os babu�nos da esquerda e da direta. Seus valores por padr�o s�o
   * definidos como 30.
   */
  public criarProblema() {
    nBab_Dir = 49;
    nBab_Esq = 5;
    MonitorCorda corda = new MonitorCorda();
    gerarBabuinos(corda);
  }

  /**
   * Cria a quantidade de babu�nos definida por um dos construtores. Os da
   * esquerda ter�o como identidade um n�mero par, e os da direita, �mpar
   * (para melhor visualiza��o do problema).
   * @param corda Monitor da corda onde os babu�nos gerados devem passar.
   */
  private void gerarBabuinos(MonitorCorda corda) {
    int i = 0;
    int j = 0;
    while ( (i < nBab_Dir) || (j < nBab_Esq)) {
      if (i < nBab_Dir)
        new Babuinos(i * 2 + 1, 1, corda);
      if (j < nBab_Esq)
        new Babuinos(j * 2, 0, corda);
      i++;
      j++;
    }
  }

  /**
   *
   * @param args N�mero dos macacos da esquerda e da direita(opcional).
   */
  public static void main(String[] args) {
    if (args.length == 2)
      new criarProblema(args[0], args[1]);
    else
      new criarProblema();
  }
}
