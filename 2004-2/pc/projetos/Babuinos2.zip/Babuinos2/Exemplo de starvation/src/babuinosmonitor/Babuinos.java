package babuinosmonitor;

/**
 * <p>Description: Classe que implementa os babu�nos</p>
 */
public class Babuinos implements Runnable{
  protected MonitorCorda corda;
  private int id;
  private int lado;

  /**
   * Construtor da classe babu�nos
   * @param id Identificador do babu�no.
   * @param lado Indica o lado que o babuino est� no desfiladeiro: 0 - esquerda; 1 - direita.
   * @param corda Monitor da corda do desfiladeiro.
   */
  public Babuinos(int id, int lado, MonitorCorda corda) {
    this.id = id;
    this.lado = lado;
    this.corda = corda;
    if (id >= 10)
      new Thread(this, "Babuino " + this.id).start();
    else
      new Thread(this, "Babuino 0" + this.id).start();
  }

  public void run(){
//    while (true) { // Serve para que os mesmos babu�nos fiquem indo e voltando
//      passear(2000);
      atravessar();
 //   }
  }

  /**
   * Faz o babu�no atravessar do lado em que ele est� para o outro.
   */
  public void atravessar(){
    if (lado==0){
      corda.iniciarTravessiaED();
      atravessando(1000);
      corda.terminarTravessiaED();
      lado = 1;//representa a mudan�a de lado do babu�no.
    } else {
      corda.iniciarTravessiaDE();
      atravessando(1000);
      corda.terminarTravessiaDE();
      lado = 0;
    }
  }
  /**
   * Representa o tempo que leva ate o babu�no desejar atravessar o desfiladeiro.
   * @param max Tempo m�ximo que vai levar o passseio.
   */
  public void passear(long max){
    dormir(max);
  }

  /**
   * Representa o tempo que o babu�no leva para atravessar o desfiladeiro.
   * @param max Tempo m�ximo que leva a travessia.
   */
  public void atravessando(long max){
    dormir(max);
  }

  /**
   * Faz a Thread dormir por um tempo aleat�rio de no m�ximo max
   * @param max Tempo m�ximo que a Thread pode dormir.
   */
  public void dormir(long max){
    long tempo = Math.round(Math.random()*max);
    try {
      Thread.sleep( tempo );
    } catch (InterruptedException ie) {
      ie.printStackTrace();
    }

  }
}