package semaforo.pcbi;

import semaforo.Semaforo;
import java.util.List;

public class Consumidor implements Runnable {

  protected List buffer;
  protected Semaforo elementos;
  protected long inicio;

  public Consumidor( List buffer, Semaforo elementos ) {
    this.buffer = buffer;
    this.elementos = elementos;
    this.inicio = System.currentTimeMillis();
  }

  public void run() {
    try {
      System.out.println("CONSUMIDOR DORMINDO");
      Thread.sleep( 50 );
      System.out.println("CONSUMIDOR ACORDADO");
    } catch (InterruptedException ie) { ie.printStackTrace(); }
    while (deveContinuar()) {
      elementos.P();
      consumir();
    }
    System.out.println("CONSUMIDOR ENCERRADO");
  }

  protected void consumir() {
    Object obj = buffer.remove(0);
    System.out.println( "CONSUMIU " + obj );
  }

  protected boolean deveContinuar() {
    return System.currentTimeMillis() < inicio + 150;
  }
}