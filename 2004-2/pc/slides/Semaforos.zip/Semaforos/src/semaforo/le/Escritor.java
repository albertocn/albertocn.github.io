package semaforo.le;

public class Escritor implements Runnable {

  private int id;
  private BD bd;

  public Escritor( int id, BD bd ) {
    this.id = id;
    this.bd = bd;
    new Thread(this).start();
  }

  public void run() {
    while (true) {
      dormir ( 100 );
      bd.iniciarEscrita( this );
      dormir ( 5000 );
      bd.encerrarEscrita( this );
    }
  }

  public void log ( String msg ) {
    System.out.println("[Escritor" + id + "]: " + msg );
  }

  private void dormir (long tempo) {
    try {
      Thread.sleep( tempo );
    } catch (InterruptedException ie) {
      ie.printStackTrace();
    }
  }
}
