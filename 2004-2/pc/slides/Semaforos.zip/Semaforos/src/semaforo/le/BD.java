package semaforo.le;

import semaforo.*;

public class BD {

  private int numLeitores = 0;
  private SemaforoBinario mutex = new SemaforoBinario(1);
  private SemaforoBinario semBD = new SemaforoBinario(1);

  public void iniciarLeitura(Leitor leitor) {
     mutex.P();
     leitor.log ("quer ler (numLeitores=" + numLeitores + ")");
     numLeitores++;
     if (numLeitores == 1) {
        semBD.P();
     }
     leitor.log ("come�ou a ler (numLeitores=" + numLeitores + ")");
     mutex.V();
  }

  public void encerrarLeitura(Leitor leitor) {
     mutex.P();
     numLeitores--;
     leitor.log ("terminou de ler (numLeitores=" + numLeitores + ")");
     if (numLeitores == 0)
       semBD.V();
     mutex.V();
  }

  public void iniciarEscrita(Escritor escritor) {
     escritor.log ("deseja escrever");
     semBD.P();
     escritor.log ("come�ou a escrever");
  }

  public void encerrarEscrita(Escritor escritor) {
    escritor.log("terminou de escrever");
    semBD.V();
  }
}