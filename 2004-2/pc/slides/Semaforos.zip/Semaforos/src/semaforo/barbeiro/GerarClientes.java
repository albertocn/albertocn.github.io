package semaforo.barbeiro;

public class GerarClientes implements Runnable {

  public static final double INTERVALO = 2000.0;

  protected final Salao salao;
  protected final Semaforos semaforos;

  public GerarClientes( Salao salao, Semaforos semaforos ) {
    this.salao = salao;
    this.semaforos = semaforos;
  }

  public Cliente criarCliente(int id) {
    return new Cliente( id, salao, semaforos );
  }

  public void run() {
    for (int cont = 1; cont <= 5; cont++) {
      Thread t = new Thread(criarCliente(cont), "Cliente " + cont);
      t.start();

      long tempo = Math.round( Math.random() * INTERVALO );
      try { Thread.sleep( tempo );
      } catch (InterruptedException ie) { ie.printStackTrace(); }
    }
  }
}