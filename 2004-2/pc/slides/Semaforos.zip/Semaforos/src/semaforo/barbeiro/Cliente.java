package semaforo.barbeiro;

public class Cliente implements Runnable {

  protected final int id;
  protected final Salao salao;
  protected final Semaforos semaforos;

  public Cliente( int id, Salao salao, Semaforos semaforos  ) {
    this.id = id;
    this.salao = salao;
    this.semaforos = semaforos;
  }

  public void run() {
    semaforos.mutex.P();
    if (salao.getClientesEsperando() < Salao.N_CADEIRAS) {
      salao.incClientesEsperando();
      semaforos.clientes.V();
      semaforos.mutex.V();
      log ("AVISANDO AO BARBEIRO QUE CHEGOU");
      semaforos.barbeiro.P();
      semaforos.cortando.P();
      log ("CORTADO");
    } else {
      semaforos.mutex.V();
      System.out.println("DESIT�NCIA do Cliente " + id);
    }
  }

  private void log (String msg) {
    System.out.println("[Cliente" + id + "]: " + msg + " em " + salao.getTempoTotal() + " ms");
  }
}