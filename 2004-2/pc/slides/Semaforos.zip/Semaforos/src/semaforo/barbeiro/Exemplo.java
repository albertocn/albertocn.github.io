package semaforo.barbeiro;

public class Exemplo {

  private Semaforos semaforos;
  private Salao salao;

  public Exemplo() {
    this.semaforos = new Semaforos();
  }

  public void executar() {
    salao = new Salao();
    new Thread( new Barbeiro( salao, this.semaforos ), "Barbeiro" ).start();
    new Thread( new GerarClientes( salao, this.semaforos ), "GerarClientes" ).start();
  }

  public static void main(String[] args) {
    new Exemplo().executar();
  }
}