package semaforo.exemplo;

import semaforo.Semaforo;
import semaforo.SemaforoBinario;
import semaforo.SemaforoContador;
//import semaforo.SemaforoDebug;

/**
 * <p>Um B deve ser impresso antes de qualquer C ser impresso
 *
 * <p>B e C devem ser impressos de forma alternada
 *
 * <p>O n�mero total de B's e C's que j� foram impressos n�o pode
 *    exceder o n�mero de A's impressos
 */
public class ABC {

  /** Conta o n�mero de caracteres A impressos */	 
  protected static final Semaforo semA = new SemaforoContador(0);
  protected static final Semaforo semB = new SemaforoBinario(0);
  protected static final Semaforo semC = new SemaforoBinario(1);
  
  /*	
  protected static final Semaforo semA = new SemaforoDebug( new SemaforoContador(0), "A");
  protected static final Semaforo semB = new SemaforoDebug( new SemaforoBinario(0),  "B");
  protected static final Semaforo semC = new SemaforoDebug( new SemaforoBinario(1),  "C");
  */
  protected long random(long n) {
    return Math.round( Math.random() * n + 1);
  }

  protected void imprimir( char c ) {
    System.out.println(c);
    System.out.flush();
  }

  protected void dormir( int tempo ) {
    try {
      Thread.sleep( random( tempo ) );
    } catch (InterruptedException ie) { ie.printStackTrace(); }
  }

  public static void main(String[] args) {
    Thread pa = new Thread(new Pa(), "Pa");
    Thread pb = new Thread(new Pb(), "Pb");
    Thread pc = new Thread(new Pc(), "Pc");

    pa.start(); pb.start(); pc.start();

    try {
      Thread.sleep(5000);
    } catch (InterruptedException ie) { ie.printStackTrace(); }

    System.out.println();
    System.out.println("semA=" + semA + ", semB=" + semB + ", semC=" + semC);
    System.exit(0);
  }
}

class Pa extends ABC implements Runnable {
   public void run () {
      while (true) {
        dormir (500);
        imprimir ('A');
        semA.V();
      }
   }
}

class Pb extends ABC implements Runnable {
   public void run () {
      while (true) {
         dormir (100);
         semC.P();
         semA.P();
         imprimir ('B');
         semB.V();
      }
   }
}

class Pc extends ABC implements Runnable {
   public void run () {
      while (true) {
        dormir (800);
        semB.P();
        semA.P();
        imprimir ('C');
        semC.V();
      }
   }
}
