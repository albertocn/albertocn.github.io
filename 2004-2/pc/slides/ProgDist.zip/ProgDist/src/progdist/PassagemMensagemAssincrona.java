package progdist;

import java.util.List;
import java.util.Vector;

/**
 * <p>Implementa a passagem de mensagens ass�ncronas intra-JVM, mantendo
 * as mensagens em uma fila
 * <p>O envio � ass�ncrono, mas a recep��o � s�ncrona.
 */

public final class PassagemMensagemAssincrona implements PassagemMensagem {

   // Se numMessages < 0, ent�o abs(numMensagens) � o n�mero de
   // Threads esperando (wait) no m�todo receber por uma mensagem
   private int numMensagens = 0;
   private List mensagens = new Vector();

   public final synchronized void enviar(Object m) {
      if (m == null) {
        throw new NullPointerException("N�o � permitida uma mensagem null");
      }
      numMensagens++;
      mensagens.add(m);
      if (numMensagens <= 0) {
        notify();
      }
   }

   public final synchronized Object receber() {
      Object mensagemRecebida = null;
      numMensagens--;
      if (numMensagens < 0) {
         while (true) {
            try {
               wait();
               break;
            }
            catch (InterruptedException e) {
               if (numMensagens >= 0) break;
               else continue;
            }
         }
      }
      mensagemRecebida = mensagens.get(0);
      mensagens.remove(0);
      return mensagemRecebida;
   }

   public void close() {
     mensagens = null;
   }
}
