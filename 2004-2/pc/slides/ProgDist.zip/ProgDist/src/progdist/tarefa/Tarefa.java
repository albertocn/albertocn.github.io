package progdist.tarefa;

import java.io.Serializable;

public interface Tarefa extends Serializable{
  void executar();
}