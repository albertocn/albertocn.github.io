package progdist.tarefa;

import progdist.PassagemMensagem;
import progdist.PassagemMensagemSincrona;
import progdist.PassagemMensagemAssincrona;

public class Exemplo {

  private PassagemMensagem pmTarefasNaoExecutadas = new PassagemMensagemAssincrona();
  private PassagemMensagem pmTarefasExecutadas = new PassagemMensagemSincrona();

  public void executar() {
    new ServidorTarefas( pmTarefasNaoExecutadas, pmTarefasExecutadas );
    new ClienteTarefas( pmTarefasNaoExecutadas, pmTarefasExecutadas );
  }

  public static void main(String[] args) {
    new Exemplo().executar();
    try { Thread.sleep(500);
    } catch (InterruptedException ie) {}
    System.exit(0);
  }
}
