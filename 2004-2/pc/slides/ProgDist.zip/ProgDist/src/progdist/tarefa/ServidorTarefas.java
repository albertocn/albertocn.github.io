package progdist.tarefa;

import progdist.PassagemMensagem;

public class ServidorTarefas implements Runnable {

  private PassagemMensagem pmTarefasNaoExecutadas;
  private PassagemMensagem pmTarefasExecutadas;
  private long inicio;

  public ServidorTarefas( PassagemMensagem pmTarefasNaoExecutadas,
                          PassagemMensagem pmTarefasExecutadas) {
    this.pmTarefasNaoExecutadas = pmTarefasNaoExecutadas;
    this.pmTarefasExecutadas = pmTarefasExecutadas;
    this.inicio = System.currentTimeMillis();

    Thread t = new Thread (this, "SERVIDOR");
    t.start();
  }

  public void run() {
    log( "INICIADO" );
    while (deveContinuar()) {
      log ("Esperando tarefa");
      Tarefa tarefa = (Tarefa) pmTarefasNaoExecutadas.receber();
      log ("Tarefa recebida");
      log ("Tarefa sendo executada");
      tarefa.executar();
      log ("Tarefa executada");
      pmTarefasExecutadas.enviar(tarefa);
      log ("Tarefa enviada de volta ao CLIENTE");
    }
    log( "PARADO" );
  }

  private void log(String msg) {
    System.out.println("SERVIDOR: " + msg);
  }

  private boolean deveContinuar() {
     return inicio + 500 > System.currentTimeMillis();
  }
}