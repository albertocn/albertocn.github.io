package progdist;

public interface PassagemMensagem {

  void enviar(Object m);
  Object receber();
  void close();
}
