package progdist;

import semaforo.Semaforo;
import semaforo.SemaforoContador;

/*
 * <p>Passagem de mensagens usando um buffer limitado.
 * <p>Suporta m�ltiplas threads produtoras e consumidoras
 */
public final class PassagemMensagemBufferLimitado implements PassagemMensagem {

   private int tam = 0;
   private Object[] buffer = null;
   private int pontoInsercao = 0;
   private int pontoRetirada = 0;
   private Semaforo elementos = null;
   private Semaforo spacos = null;
   private Object mutexS = null;
   private Object mutexR = null;

   public PassagemMensagemBufferLimitado(int tamanho) {
     if (tamanho <= 0)
       throw new IllegalArgumentException("tamanho <= 0");

     this.tam = tamanho;
     buffer = new Object[tamanho];
     elementos = new SemaforoContador(0);
     spacos = new SemaforoContador(tamanho);
     mutexS = new Object();
     mutexR = new Object();
   }

   public final void enviar(Object m) {
     if (m == null) {
       throw new NullPointerException("N�o � permitida uma mensagem null");
     }
     synchronized (mutexS) {
       spacos.P();
       buffer[pontoInsercao] = m;
       pontoInsercao = (pontoInsercao + 1) % tam;
       elementos.V();
     }
   }

   public final Object receber() {
    Object value = null;
    synchronized (mutexR) {
     elementos.P();
     value = buffer[pontoRetirada];
     pontoRetirada = (pontoRetirada + 1) % tam;
     spacos.V();
    }
    return value;
   }

   public void close() {}
}
