package progdist.pcbl;

import progdist.PassagemMensagem;
import progdist.PassagemMensagemAssincrona;

public class Exemplo {

  protected PassagemMensagem pm = new PassagemMensagemAssincrona();

  public void executar() {
    for (int i = 1; i <= 3; i++) {
      criarConsumidor(i);
    }

    criarProdutor('A');
    criarProdutor('B');
  }

  protected Produtor criarProdutor(char a) {
    return new Produtor( this.pm, a );
  }

  protected Consumidor criarConsumidor(int i) {
    return new Consumidor( this.pm, i );
  }

  public static void main(String[] args) {
    new Exemplo().executar();
    try { Thread.sleep(5000);
    } catch (InterruptedException ie) {}
    System.exit(0);
  }
}