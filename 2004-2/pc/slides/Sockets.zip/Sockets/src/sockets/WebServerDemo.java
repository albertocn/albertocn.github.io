package sockets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

import java.net.Socket;
import java.net.ServerSocket;

import java.util.Date;

public class WebServerDemo {

  private HttpServer server;

  // Cria e inicia um servidor web usando a porta padr�o
  public WebServerDemo() {
    server = new HttpServer();
    iniciarHttpServer();
  }

  // Cria e inicia um servidor web usando a porta informada
  public WebServerDemo(int porta) {
    server = new HttpServer(porta);
    iniciarHttpServer();
  }

  // Inicia o servidor Http em um Thread separado
  private void iniciarHttpServer() {

    Runnable r = new Runnable() {
      public void run() {
        try {
          server.iniciar();
        } catch (IOException e) {
          e.printStackTrace();
          System.exit(1);
        }
      }
    };

    (new Thread(r)).start();
  }

  public static void main(String[] args) {
    if (args.length != 1) {
      new WebServerDemo();
    } else {
      new WebServerDemo(Integer.parseInt(args[0]));
    }
    System.out.println("Aperte <CTRL> + C para encerrar");
  }
}

class HttpServer {

  private int porta;

  public HttpServer() {
    this(80);
  }

  public HttpServer(int porta) {
    this.porta = porta;
  }

  public void iniciar() throws IOException {

    // Cria um objeto ServerSocket para ficar "escutando",
    // na porta especificada, requisi��es de conex�o
    ServerSocket ss = new ServerSocket(porta);

    while (true) {

      // O m�todo accept bloqueia at� que um cliente fa�a
      // uma requisi��o de conex�o. Quando isso acontece,
      // � criado um novo socket, que usa outra porta
      Socket s = ss.accept();

      // Um objeto Tarefa utiliza o socket passado para
      // obter os par�metros da requisi��o HTTP e
      // processar de acordo com os mesmos
      Tarefa t = new Tarefa(s);

      // Cada tarefa recebe um thread para permitir que
      // o servidor volte a escutar por novas requisi��es
      // de conex�o
      (new Thread(t)).start();
    }
  }
}

class Tarefa implements Runnable {

  private Socket s;

  public Tarefa(Socket s) {
    this.s = s;
  }

  public void run() {
    try {
      BufferedReader br = new BufferedReader(
                              new InputStreamReader(
                                  s.getInputStream()));

      // Faz a leitura da linha de comando HTTP
      String comando = br.readLine();

      // Solicita o processamento do comando, gerando
      // a sa�da para a OutputStream
      processarComando(comando, s.getOutputStream());

      // Fecha o socket pois no protocolo HTTP cada
      // requisi��o � feita atrav�s de um socket. N�o
      // � poss�vel reutilizar o mesmo socket para
      // fazer outra requisi��o HTTP
      s.close();

    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  // Processa o comando e envia a resposta para o OutputStream
  private void processarComando(String cmd, OutputStream os)
          throws IOException {

    String resp = "Data/Hora atual : " + new Date();
    os.write(resp.getBytes());
    os.flush();
  }
}