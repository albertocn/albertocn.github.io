package sockets;

import java.net.URL;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class LendoURL {
    public static void main(String[] args) throws Exception {

        if (args.length != 1) {
            System.out.println("Use: java LendoURL <url>");
            System.out.println("Ex.: java LendoURL http://java.sun.com");
            System.exit(1);
        }

        URL url = new URL(args[0]);
        BufferedReader in = new BufferedReader(
                                new InputStreamReader(
                                    url.openStream()));

        String linha;

        while ((linha = in.readLine()) != null) {
            System.out.println(linha);
        }

        in.close();
    }
}
