package sockets;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class InetAddressDemo {

    public InetAddressDemo() {
        InetAddress endereco = null;

        try {
            // Obt�m o InetAddress do host local
            endereco = InetAddress.getLocalHost();
        } catch (UnknownHostException e) {
            e.printStackTrace();
            System.exit(1);
        }

        // Imprime o nome do host
        System.out.println("Nome....: " + endereco.getHostName());
        // Imprime o endere�o do host
        System.out.println("Endereco: " + endereco.getHostAddress());
    }

    public static void main(String[] args) {
        new InetAddressDemo();
    }
}