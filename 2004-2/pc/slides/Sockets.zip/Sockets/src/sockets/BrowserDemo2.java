package sockets;

import java.awt.Frame;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class BrowserDemo2 extends BrowserDemo {

    // Carrega a p�gina usando a URL especificada no campo
    // de texto
    protected void trazerPagina() {
        try {
            HttpURLClient cliente = new HttpURLClient();

            // Obt�m o arquivo relativo � URL passada
            byte[] arq = cliente.getArquivo(getURL());

            // Exibe o conte�do do arquivo na �rea de texto
            setTexto(new String(arq, 0, arq.length));

        } catch (IOException ex) {

            // Imprime a situa��o da pilha em uma String
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            ex.printStackTrace(pw);

            // Exibe a exce��o na �rea de texto
            setTextoErro(sw.toString());
        }
    }

    // Cria um objeto URL a partir do conte�do do campo
    // de texto que cont�m a URL da p�gina. Se a URL
    // n�o inv�lida, ser� lan�ada uma exce��o
    private URL getURL() throws MalformedURLException {
        return new URL(tfURL.getText());
    }

    public static void main(String[] args) {
        Frame f = new BrowserDemo2();
        f.setTitle("BrowserDemo2");
        f.pack();
        f.show();
    }
}

class HttpURLClient {

    // Utiliza a URL especificada para se conectar
    // e retornar a resposta como um array de bytes
    public byte[] getArquivo(URL url) throws IOException {

        URLConnection con = url.openConnection();
        return receberResposta(con.getInputStream());
    }

    // Recebe a resposta do servidor pela InputStream do socket
    private byte[] receberResposta(InputStream is) throws IOException {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        int i;
        while ((i = is.read()) != -1) {
            baos.write((byte) i);
        }
        return baos.toByteArray();
    }
}