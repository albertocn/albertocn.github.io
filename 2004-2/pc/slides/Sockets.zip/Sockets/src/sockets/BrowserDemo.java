package sockets;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.PrintStream;
import java.io.PrintWriter;

import java.net.Socket;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.net.URL;

public class BrowserDemo extends Frame {

  private TextArea   taTexto;
  private Button     btnIr;
  private Color      corTA;
  private Color      corErroTA;

  protected TextField  tfURL;

  public BrowserDemo() {

    tfURL = new TextField("http://localhost:80/index.htm", 60);
    btnIr = new Button("Ir");

    Panel pSup = new Panel();
    pSup.setBackground(Color.lightGray);
    pSup.setLayout(new FlowLayout(FlowLayout.LEFT));
    pSup.add(tfURL);
    pSup.add(btnIr);

    Panel pCentro = new Panel();
    pCentro.setLayout(new GridLayout());
    taTexto = new TextArea(40, 80);
    taTexto.setEditable(false);
    pCentro.add(taTexto);

    setLayout(new BorderLayout());
    add(BorderLayout.NORTH,  pSup);
    add(BorderLayout.CENTER, pCentro);

    corTA = taTexto.getForeground();
    corErroTA = Color.red;

    criarListeners();
  }

  // Retorna a dimens�o preferida para a janela
  public Dimension getPreferredSize() {
    return new Dimension(640, 480);
  }

  // Cria os listeners para a caixa de texto da URL,
  // para o bot�o de Ir e para o fechamento da janela
  private void criarListeners() {

    class MudarURLListener implements ActionListener {
      public void actionPerformed(ActionEvent e) {
          tfURL.setEnabled(false);
          btnIr.setEnabled(false);

          trazerPagina();

          tfURL.setEnabled(true);
          btnIr.setEnabled(true);
      }
    }

    tfURL.addActionListener(new MudarURLListener());
    btnIr.addActionListener(new MudarURLListener());

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }

  // Altera o texto da �rea de texto e ajusta a cor para
  // a cor normal
  protected void setTexto(String texto) {
    taTexto.setForeground(corTA);
    taTexto.setText(texto);
  }

  // Altera o texto da �rea de texto e ajusta a cor para
  // a cor que indica um erro
  protected void setTextoErro(String texto) {
    taTexto.setForeground(corErroTA);
    taTexto.setText(texto);
  }

  // Carrega a p�gina usando a URL especificada no campo
  // de texto
  protected void trazerPagina() {
    try {
      HttpClient cliente = new HttpClient();

      URL url = getURL();

      // Se o n�mero da porta n�o foi informado, assume
      // que � 80
      int porta = url.getPort();
      if (porta == -1) {
        porta = 80;
      }

      // Obt�m o arquivo passando o nome do servidor,
      // a porta e o caminho do arquivo
      byte[] arq = cliente.getArquivo(url.getHost(),
                                      porta,
                                      url.getFile());

      // Exibe o conte�do do arquivo na �rea de texto
      setTexto(new String(arq, 0, arq.length));

    } catch (IOException ex) {

      // Imprime a situa��o da pilha em uma String
      StringWriter sw = new StringWriter();
      PrintWriter pw = new PrintWriter(sw);
      ex.printStackTrace(pw);

      // Exibe a exce��o na �rea de texto
      setTextoErro(sw.toString());
    }
  }

  // Cria um objeto URL a partir do conte�do do campo
  // de texto que cont�m a URL da p�gina. Se a URL
  // n�o inv�lida, ser� lan�ada uma exce��o
  private URL getURL() throws MalformedURLException {
    return new URL(tfURL.getText());
  }

  public static void main(String[] args) {
    Frame f = new BrowserDemo();
    f.setTitle("BrowserDemo");
    f.pack();
    f.show();
  }
}

class HttpClient {

  // Conecta-se ao servidor informado usando a
  // porta especificada. Em seguida, requisita
  // o arquivo cujo caminho foi passado como
  // argumento e retorna o conte�do do arquivo
  // como um array de bytes
  public byte[] getArquivo(String servidor, int porta,
                           String caminho)
          throws UnknownHostException, IOException {

    Socket s = new Socket(servidor, porta);
    enviarGet(caminho, s.getOutputStream());
    byte[] resp = receberResposta(s.getInputStream());
    s.close();
    return resp;
  }

  // Envia o comando GET atrav�s do OutputStream do socket
  // para obter a p�gina especificada do servidor
  private void enviarGet(String caminho, OutputStream os) {
    PrintStream ps = new PrintStream(os);
    ps.println("GET " + caminho + " HTTP/1.0\n\n");
  }

  // Recebe a resposta do servidor pela InputStream do socket
  private byte[] receberResposta(InputStream is) throws IOException {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    int i;
    while ((i = is.read()) != -1) {
        baos.write((byte) i);
    }
    return baos.toByteArray();
  }
}