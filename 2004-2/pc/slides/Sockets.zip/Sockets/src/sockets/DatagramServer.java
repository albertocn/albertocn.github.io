package sockets;
import java.io.*;
import java.net.*;
import java.util.*;

// Classe que implementa um servidor de nomes
// simples usando Datagramas
public class DatagramServer {

    private DatagramSocket dSocket;
    private Map            enderecos;

    public DatagramServer(String arquivo)
            throws SocketException, IOException {

        // Cria um DatatagramSocket que escuta na porta 5000
        dSocket = new DatagramSocket(5000);

        enderecos = lerEnderecosDeArquivo(arquivo);
        iniciar();
    }

    // Constr�i um mapa que associa um nome a um endere�o
    // O mapa � criado a partir do arquivo especificado
    private Map lerEnderecosDeArquivo(String arquivo)
            throws IOException {

        FileInputStream fis = new FileInputStream(arquivo);
        Properties prop = new Properties();
        prop.load(fis);
        return prop;
    }

    // Inicia o servidor
    private void iniciar() throws IOException {

        System.out.println("Servidor de nomes iniciado");
        System.out.println("Aperte <CTRL> + C para sair");

        while (true) {

            // Recebe um datagrama
            DatagramPacket recebido = esperarPacote();

            // Busca o endere�o associado ao nome contido
            // no pacote
            String endereco = buscarEndereco(recebido);

            // Cria o datatagrama de resposta contendo o
            // endere�o associado ao nome
            DatagramPacket resposta =
                    criarPacoteResposta(recebido.getAddress(),
                                        recebido.getPort(),
                                        endereco);

            // Envia o datagrama de resposta
            dSocket.send(resposta);
        }
    }

    // Espera receber um pacote
    private DatagramPacket esperarPacote() throws IOException {

        // Cria o buffer e cria um pacote de datagrama
        byte[] buf = new byte[256];
        DatagramPacket pacote = new DatagramPacket(buf, buf.length);

        // Recebe um datagrama do socket. Quando este m�todo
        // retorna, o buffer do DatagramPacket est� preenchido
        // com os dados recebidos.
        //
        // O pacote do datagrama tamb�m cont�m o IP e o n�mero
        // da porta do m�quina que o enviou
        //
        // Este m�todo bloqueia at� que um datagrama seja recebido
        //
        // O atributo length do objeto DatagramPacket cont�m o
        // tamanho da mensagem recebida
        //
        // Se a menssagem for maior que o tamanho do que o tamanho
        // do buffer, a mensagem � truncada
        dSocket.receive(pacote);

        return pacote;
    }

    // Retira o nome do datagrama e busca o endere�o pelo nome
    private String buscarEndereco(DatagramPacket datagrama) {
        byte[] dados = datagrama.getData();
        String nome = new String(dados, 0, datagrama.getLength());
        return getEndereco(nome);
    }

    // Retorna o endere�o da m�quina com o nome especificado
    // ou "" se n�o encontrar
    private String getEndereco(String nome) {
        String end = (String) enderecos.get(nome);
        return (end != null) ? end : "";
    }

    // Cria um datagrama a ser enviado para o endere�o especificado,
    // usando a porta passada e contendo a String s
    private DatagramPacket criarPacoteResposta(InetAddress address,
                                               int         porta,
                                               String      s) {
        byte[] buf = s.getBytes();
        DatagramPacket p = new DatagramPacket(buf,     buf.length,
                                              address, porta);
        return p;
    }

    public static void main(String[] args) {
        try {
            String arquivo = "DatagramServer.txt";

            new DatagramServer(arquivo);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}