package thread;

import javax.swing.JOptionPane;

/**
 * Thread que demonstra a utiliza��o de join.
 */
public class ThreadJoin extends Thread {

    /** Intervalo de tempo que a thread deve dormir */
    protected static final long INTERVALO = 1000;

    public ThreadJoin(String str) {
        super(str);
    }

    /**
     * Imprime uma mensagem quando a execu��o � iniciada, coloca a thread
     * para dormir e ap�s ela acordar imprime uma mensagem indicando o
     * final da execu��o da Thread.
     */
    public void run() {
       System.out.println("INICIO da Thread " + getName());
       try {
           sleep( INTERVALO );
        } catch (InterruptedException e) {}
        System.out.println("FIM da Thread " + getName());
    }

    /**
     * Quando nenhum par�metro � passado na linha de comando, � executado
     * um join, o que n�o ocorre quando algum par�metro � fornecido.
     */
    public static void main(String[] argv) {
        Thread a = new ThreadJoin("A");

        if ( executarJoin() ) {
           a.start();
           try {
              a.join();
           } catch (InterruptedException e) {}
        } else {
           a.start();
        }

        System.out.println("FIM do programa");
        System.exit(0);
    }

   /** Exibe uma janela confirmando se o join deve ser executado */
   private static boolean executarJoin() {
      Object[] opcoes = { "Sim", "N�o" };
      int resp = JOptionPane.showOptionDialog ( null
                                              , "Executar o Join?"
                                              , "Confirmar Join"
                                              , JOptionPane.DEFAULT_OPTION
                                              , JOptionPane.QUESTION_MESSAGE
                                              , null
                                              , opcoes
                                              , opcoes[1] );

      return resp == JOptionPane.YES_OPTION;
   }
}