package thread;

/**
 * Sincroniza os m�todos da superclasse Conta.
 */
public class ContaSincronizada extends Conta {

    /**
     * Usa o modificador synchronized para sincronizar o m�todo
     * da superclasse.
     */
    public synchronized void depositar(long valor) {
        super.depositar(valor);
    }

    /**
     * Cria um bloco de c�digo sincronizado para sincronizar o m�todo
     * da superclasse
     */
    public long getSaldo() {
        synchronized (this) {
            return super.getSaldo();
        }
    }
}
