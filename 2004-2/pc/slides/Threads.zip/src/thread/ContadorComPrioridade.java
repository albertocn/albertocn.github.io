package thread;

/**
 * Demonstra a especifica��o de Prioridades em Threads.
 */
public class ContadorComPrioridade implements Runnable {

  /** N�mero de itera��es que ser�o executadas */
  private static final long NUM_ITERACOES = 1000000;

  // Valor do contador
  private Long valor = new Long(0);

  // Tempo a Thread ficar� dormindo
  private long intervalo;

  /**
   * Construtor
   *
   * @param intervalo Intervalo de tempo que a Thread permanecer� dormindo
   *                  entre as opera��es de incremento.
   */
  public ContadorComPrioridade( long intervalo ) {
    this.intervalo = intervalo;
  }

  /**
   * Executa um la�o o n�mero de vez indicadas por NUM_ITERACOES, incrementa
   * o valor e coloca a Thread corrente para dormir.
   */
  public void run() {
    for (int i = 0; i < NUM_ITERACOES; i++)
    {
      synchronized (this) {
        valor = new Long( valor.longValue() + 1 );
        try {
          Thread.sleep( intervalo );
        } catch (InterruptedException ie) {}
      }
    }
  }

  /**
   * Retorna o valor do contador
   * @return Valor do contador
   */
  public synchronized Long getValor() {
    return valor;
  }

  public static void main(String[] args) {
    ContadorComPrioridade contMin = new ContadorComPrioridade(0);
    ContadorComPrioridade contMax = new ContadorComPrioridade(0);

    Thread tMinPrio = new Thread ( contMin );
    Thread tMaxPrio = new Thread ( contMax );

    tMinPrio.setPriority( Thread.MIN_PRIORITY );
    tMaxPrio.setPriority( Thread.MAX_PRIORITY );

    tMinPrio.start();
    tMaxPrio.start();

    while ( tMinPrio.isAlive() || tMaxPrio.isAlive() ) {
      Long min = contMin.getValor();
      Long max = contMax.getValor();
      System.out.println("Min = " + min + " | Max = " + max);
      try {
        Thread.sleep( 50 );
      } catch (InterruptedException ie) {}
    }
  }
}