package thread;

/**
 * Demonstra como criar Threads estendendo a classe java.lang.Runnable.
 */
public class RunnableSimples implements Runnable {

   /**
    * Imprime o contador e o nome da Thread (Implementa o m�todo
    * run da interface Runnable).
    */
   public void run() {
      for (int i = 1; i <= 500; i++) {
         System.out.println(i + " " + Thread.currentThread().getName());
      }
      System.out.println("FIM " + Thread.currentThread().getName());
   }

   /** Instancia e inicia Threads passando os Runnable's. */
   public static void main(String[] argv) {
      new Thread(new RunnableSimples(), "A").start();
      new Thread(new RunnableSimples(), "B").start();
   }
}