package thread;

/**
 * Demonstra como criar Threads estendendo a classe java.lang.Thread
 */
public class ThreadSimples extends Thread {

    /** Construtor que recebe o nome da Thread como par�metro. */
    public ThreadSimples(String str) {
        super(str);
    }

    /**
     * Imprime o contador e o nome da Thread (Sobreposi��o do m�todo
     * run da superclasse Thread).
     */
    public void run() {
        for (int i = 1; i <= 500; i++) {
            System.out.println(i + " " + getName());
        }
        System.out.println("FIM " + getName());
    }

    /** Instancia e inicia as Threads. */
    public static void main(String[] argv) {
        new ThreadSimples("A").start();
        new ThreadSimples("B").start();
    }
}