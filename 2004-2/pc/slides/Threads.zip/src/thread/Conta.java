package thread;

/**
 * Representa uma conta corrente.
 */
public class Conta {

    // Saldo atual da conta
    private long saldo = 0;

    /**
     * Obt�m o saldo atual da conta, coloca a Thread para dormir por um
     * tempo aleat�rio e depois efetiva o dep�sito
     */
    public void depositar(long valor) {
        long saldoTemp = saldo;
        try {
            Thread.sleep((long) (Math.random() * 10));
        } catch (InterruptedException e) {}
        saldo = saldoTemp + valor;
    }

    /**
     * Retorna o saldo atual da conta
     */
    public long getSaldo() {
        return saldo;
    }
}
