package monitor.le;

public class Exemplo {

  public static final int N_LEITORES = 3;
  public static final int N_ESCRITORES = 2;

  public Exemplo() {
    MonitorBD bd = new MonitorBD();
    criarLeitores( bd );
    criarEscritores( bd );
  }

  private void criarLeitores( MonitorBD bd ) {
    for (int i = 1; i <= N_LEITORES; i++) {
      new Leitor( i, bd );
    }
  }

  private void criarEscritores( MonitorBD bd ) {
    for (int i = 1; i <= N_ESCRITORES; i++) {
      new Escritor( i, bd );
    }
  }

  public static void main(String[] args) {
    new Exemplo();
  }
}