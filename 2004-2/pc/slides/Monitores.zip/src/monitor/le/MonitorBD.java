package monitor.le;

import java.util.Collections;
import java.util.List;
import java.util.LinkedList;

public class MonitorBD {

  private int numLeitores = 0;
  private boolean escrevendo = false;
  private List leitoresEsperando = criarList();
  private List escritoresEsperando = criarList();

  protected List criarList() {
    return Collections.synchronizedList( new LinkedList() );
  }

  public void iniciarLeitura(Leitor leitor) {
     leitor.log ("quer ler (numLeitores=" + numLeitores + ")");
     Object lock = new Object();
     synchronized (lock) {
       if ( naoPodeLer(lock) ) {
         try { lock.wait(); }
         catch (InterruptedException ie) {}
       }
       leitor.log ("come�ou a ler (numLeitores=" + numLeitores + ")");
     }
  }

  private synchronized boolean naoPodeLer( Object lock ) {
    if (escrevendo || !escritoresEsperando.isEmpty()) {
      leitoresEsperando.add( lock );
      return true;
    } else {
      numLeitores++;
      return false;
    }
  }

  public synchronized void encerrarLeitura(Leitor leitor) {
     numLeitores--;
     if (numLeitores == 0 && !escritoresEsperando.isEmpty()) {
       synchronized ( escritoresEsperando.get(0) ) {
         escritoresEsperando.get(0).notify();
       }
       escritoresEsperando.remove(0);
       escrevendo = true;
     }
     leitor.log ("terminou de ler (numLeitores=" + numLeitores + ")");
  }

  public void iniciarEscrita(Escritor escritor) {
    escritor.log ("deseja escrever");
    Object lock = new Object();
    synchronized (lock) {
      if (naoPodeEscrever(lock) ) {
        try { lock.wait(); }
        catch (InterruptedException ie) {}
      }
    }
    escritor.log ("come�ou a escrever");
  }

  private synchronized boolean naoPodeEscrever( Object lock ) {
    if (escrevendo || numLeitores > 0) {
      escritoresEsperando.add( lock );
      return true;
    } else {
      escrevendo = true;
      return false;
    }
  }

  public synchronized void encerrarEscrita(Escritor escritor) {
    escrevendo = false;
    if (!leitoresEsperando.isEmpty()) {
      while (!leitoresEsperando.isEmpty()) {
        synchronized (leitoresEsperando.get(0)) {
          leitoresEsperando.get(0).notify();
        }
        leitoresEsperando.remove(0);
        numLeitores++;
      }
    } else if (!escritoresEsperando.isEmpty()) {
      synchronized (escritoresEsperando.get(0)) {
        escritoresEsperando.get(0).notify();
      }
      escritoresEsperando.remove(0);
      escrevendo = true;
    }
    escritor.log("terminou de escrever");
  }
}