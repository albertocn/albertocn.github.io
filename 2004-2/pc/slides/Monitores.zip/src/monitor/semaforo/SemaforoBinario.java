package monitor.semaforo;

public final class SemaforoBinario extends SemaforoBase {

   public SemaforoBinario() {
     super();
   }

   public SemaforoBinario(int inicial) {
      super(inicial);
      if (inicial > 1)
        throw new IllegalArgumentException("inicial>1");
   }

   public SemaforoBinario(boolean inicial) {
      super(inicial ? 1:0);
   }

   public final synchronized void V() {
      super.V();
      if (valor > 1)
        valor = 1;
   }
}
