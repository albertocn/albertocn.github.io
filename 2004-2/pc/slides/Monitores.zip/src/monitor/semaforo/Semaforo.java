package monitor.semaforo;

public interface Semaforo {
  void P();
  void V();
}