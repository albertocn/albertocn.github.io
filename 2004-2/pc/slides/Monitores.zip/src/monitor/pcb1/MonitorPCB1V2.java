package monitor.pcb1;

public class MonitorPCB1V2 implements MonitorPC {

  private Object obj;
  private boolean vazio = true;

  private Object lockCons = new Object();
  private Object lockProd = new Object();

  public Object retirar() {

    Object res = null;

    synchronized (lockCons) {
      System.out.println( Thread.currentThread().getName() + " tentando RETIRAR");

      while (vazio) {
        System.out.println("WAIT sobre " + Thread.currentThread().getName());
        try { lockCons.wait(); }
        catch (InterruptedException ie) {}
      }

      System.out.println(Thread.currentThread().getName() + " vai RETIRAR");
      res = obj;
      obj = null;
      vazio = true;
    }
    synchronized (lockProd) {
      lockProd.notify();
    }
    return res;
  }

  public void colocar( Object obj ) {
    System.out.println( Thread.currentThread().getName() + " tentando COLOCAR");

    synchronized (lockProd) {

      while (!vazio) {
        System.out.println("WAIT sobre " + Thread.currentThread().getName());
        try { lockProd.wait(); }
        catch (InterruptedException ie) {}
      }

      System.out.println(Thread.currentThread().getName() + " vai PRODUZIR");
      this.obj = obj;
      vazio = false;
    }
    synchronized (lockCons) {
      lockCons.notify();
    }
  }
}