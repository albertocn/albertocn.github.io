package monitor.pcb1;

public interface MonitorPC {
  Object retirar();
  void colocar( Object obj );
}