package monitor.pcb1;

public class Produtor implements Runnable {

  protected MonitorPC monitor;
  private String nome;
  private long cont;

  public Produtor( MonitorPC monitor, char c) {
    this.monitor = monitor;
    this.nome = "P" + c;

    Thread t = new Thread (this, this.nome);
    t.start();
  }

  public void run() {
    while (deveContinuar()) {
      produzir();
    }
  }

  protected void produzir() {
    String obj = Thread.currentThread().getName() + ++cont;
    monitor.colocar( obj );
    System.out.println("Produzido (" + obj + ")");
  }

  protected boolean deveContinuar() {
    return cont < 5;
  }
}