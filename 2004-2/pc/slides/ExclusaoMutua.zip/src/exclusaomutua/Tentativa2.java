package exclusaomutua;

public class Tentativa2
       extends TentativaBase
       implements Arbitro {

  public void entrarSC(int i) {
    while (desejaSC[outro(i)].valor) // Espera ocupada
      Thread.yield();
    desejaSC[i].setValor(true);
  }

  public void sairSC(int i) {
    desejaSC[i].setValor(false);
  }

  public static void main(String args[]) {
    Tentativa2 arb = new Tentativa2();
    No no1 = new No("No", 0, 1000, 1000, arb);
    No no2 = new No("No", 1, 1000, 1000, arb);
    ChecarFlags cf = new ChecarFlags( arb.desejaSC );
  }
}

class ChecarFlags implements Runnable {

  private Flag[] flagsChecar;

  public ChecarFlags(Flag[] flags) {
    flagsChecar = flags;
    Thread t = new Thread(this);
    t.setPriority( Thread.MAX_PRIORITY );
    t.start();
  }

  public void run() {
    while (true) {
      if (flagsChecar[0].valor && flagsChecar[1].valor) {
        System.out.println("ERRO: Ambos os Flags com valor true");
        System.exit(0);
      }
      try {
        Thread.sleep(10);
      } catch (InterruptedException ie) { ie.printStackTrace(); }
    }
  }
}