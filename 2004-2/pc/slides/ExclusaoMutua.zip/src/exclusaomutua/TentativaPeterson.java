package exclusaomutua;

public class TentativaPeterson
       extends TentativaBase
       implements Arbitro {

  public void entrarSC(int i) {
    desejaSC[i].valor = true;
    ultimo = i;
    while (desejaSC[outro(i)].valor && ultimo == i) // Espera ocupada
      Thread.yield();
  }

  public void sairSC(int i) {
    desejaSC[i].setValor(false);
  }

  public static void main(String args[]) {
    TentativaPeterson arb = new TentativaPeterson();
    No no1 = new No("No", 0, 0, 100, arb);
    No no2 = new No("No", 1, 0, 100, arb);
  }
}