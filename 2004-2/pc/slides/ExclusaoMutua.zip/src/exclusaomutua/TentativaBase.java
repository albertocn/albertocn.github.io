package exclusaomutua;

public abstract class TentativaBase {

  /** N�mero de n�s que ser�o controlados */
  protected static final int NUM_NOS = 2;

  /** Usado apenas por Tentativa1 e TentativaDekker */
  protected volatile int vez = 0;

  /** Usado apenas por TentativaPeterson */
  protected volatile int ultimo = 0;

  /**
   * Usado apenas por Tentativa2, Tentativa3, Tentativa4,
   * TentativaDekker e TentativaPeterson
   */
  protected Flag[] desejaSC = new Flag[ NUM_NOS ];

  public TentativaBase() {
    for (int i = 0; i < desejaSC.length; i++)
      desejaSC[i] = new Flag(i);
  }

  /** 
   * Dada o identificador de um n�, retorna o identificador
   * de outro n�.
   *  
   * @param i identificador do n�
   * @return identificador de outro n�
   */
  protected int outro(int i) {
    return (i + 1) % NUM_NOS;
  }
}