package exclusaomutua;

public class Tentativa1
       extends TentativaBase
       implements Arbitro {

  public void entrarSC(int i) {
    while (vez != i) // Espera ocupada
      Thread.yield();
  }

  public void sairSC(int i) {
    vez = outro( i );
  }

  public static void main(String args[]) {
    Tentativa1 arb = new Tentativa1();
    No no1 = new No("No", 0, 100, 50, arb);
    No no2 = new No("No", 1, 10000, 50, arb);
  }
}