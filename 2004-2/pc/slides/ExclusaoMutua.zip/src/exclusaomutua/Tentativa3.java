package exclusaomutua;

public class Tentativa3
       extends TentativaBase
       implements Arbitro {

  public void entrarSC(int i) {
    desejaSC[i].valor = true;
    //dormir(); // Usado para for�ar o deadlock
    while (desejaSC[outro(i)].valor) { // Espera ocupada
      Thread.yield();
    }
  }

  public void sairSC(int i) {
    desejaSC[i].setValor(false);
  }

  private void dormir() {
  	try { Thread.sleep(10);  		
  	} catch (InterruptedException e) {}
  }
  
  public static void main(String args[]) {
    Tentativa3 arb = new Tentativa3();
    No no1 = new No("No", 0, 10, 10, arb);
    No no2 = new No("No", 1, 10, 10, arb);
  }
}