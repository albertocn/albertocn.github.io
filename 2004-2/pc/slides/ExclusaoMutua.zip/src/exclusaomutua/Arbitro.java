package exclusaomutua;

/** Traz m�todos para controlar o acesso � Se��o Cr�tica */
public interface Arbitro {

  /** Controla a entrada */
  public void entrarSC(int i);

  /** Controla a sa�da */
  public void sairSC(int i);
}