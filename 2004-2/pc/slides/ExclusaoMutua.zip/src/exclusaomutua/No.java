package exclusaomutua;

/** Implementa um N� */

public class No implements Runnable {

   private static long inicio = System.currentTimeMillis();

   private String nome;
   private int id = 0;
   private int tempoDormirForaSC = 0;
   private int tempoDormirDentroSC = 0;
   private Arbitro arb = null;

   /**
    * Cria um n�
    *
    * @param nome Nome do n�
    * @param id Identificador
    * @param tempoDormirForaSC Tempo m�ximo dormindo fora da se��o cr�tica
    * @param tempoDormirDentroSC Tempo m�ximo dormindo dentro da se��o cr�tica
    * @param arb �rbitro que controla o acesso � se��o cr�tica
    */
   public No(String nome, int id, int tempoDormirForaSC,
             int tempoDormirDentroSC, Arbitro arb) {
     this.nome = nome + " " + id;
     this.id = id;
     this.tempoDormirForaSC = tempoDormirForaSC;
     this.tempoDormirDentroSC = tempoDormirDentroSC;
     this.arb = arb;
     System.out.println(getNome() + " est� VIVO, tempoDormirForaSC="
         + tempoDormirForaSC + ", tempoDormirDentroSC=" + tempoDormirDentroSC);

     Thread t = new Thread( this );
     t.start();
   }

   public String getNome() { return nome; }

   private void foraSC() {
      long tempo = tempoDormirForaSC == 0 ? 0 : random(tempoDormirForaSC) + 1;
      log( getNome() + " dormindo FORA da SC por " + tempo + " ms");
      dormir( tempo );
   }

   private void dentroSC() {
      long tempo = tempoDormirDentroSC == 0 ? 0 : random(tempoDormirDentroSC) + 1;
      log( getNome() + " dormindo DENTRO da SC por " + tempo + " ms");
      dormir( tempo );
   }

   public void run() {
      for (int i = 0; i < 25; i++) {
         foraSC();
         log( getNome() + " quer ENTRAR na SC");
         arb.entrarSC( id );
         dentroSC();
         arb.sairSC( id );
      }
   }

   private long random (long x) {
     return (long) (Math.random() * x);
   }

   public void dormir( long tempo ) {
     try {
       Thread.sleep( tempo );
     } catch (InterruptedException ie) { ie.printStackTrace(); }
   }

   public long tempoDeVida() {
     return System.currentTimeMillis() - inicio;
   }

   private void log(String s) {
     System.out.println("tempoDeVida=" + tempoDeVida() + ", " + s);
   }
}

