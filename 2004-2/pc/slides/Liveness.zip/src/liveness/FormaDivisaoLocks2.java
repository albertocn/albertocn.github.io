package liveness;

/**
 * Altera��o na classe Forma usando divis�o de locks,
 * onde um deles � o pr�prio objeto
 */
public class FormaDivisaoLocks2 {

  // Acessados pelos m�todos: x, y e ajustarLocalizacao
  protected double x = 0.0;
  protected double y = 0.0;

  // Acessados pelos m�todos: largura, altura e ajustarDimensoes
  protected double largura = 0.0;
  protected double altura  = 0.0;

  // Objetos que ser�o usados para controle de lock
  protected Object lockLocalizacao = new Object();

  public double x() { synchronized (lockLocalizacao) { return x; } }
  public double y() { synchronized (lockLocalizacao) { return y; } }
  public void ajustarLocalizacao() {
    synchronized (lockLocalizacao) {
      x = calculoDemorado1();
      y = calculoDemorado2();
    }
  }

  public synchronized double largura() { return largura; }
  public synchronized double altura()  { return altura; }
  public synchronized void ajustarDimensoes() {
    largura = calculoDemorado3();
    altura = calculoDemorado4();
  }

  // M�todos n�o implementados
  protected double calculoDemorado1() { return Math.random(); }
  protected double calculoDemorado2() { return Math.random(); }
  protected double calculoDemorado3() { return Math.random(); }
  protected double calculoDemorado4() { return Math.random(); }
}
