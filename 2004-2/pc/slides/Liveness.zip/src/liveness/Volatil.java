package liveness;

/** Demontra o funcionamento do modificador volatile */
public class Volatil {

  public static void main(String[] args) {
    final int CONT = 100;
    Thread[] arr = new Thread[ CONT ];

    // Cria todas as threads
    Thread ta = new Thread(new ChamaA());
    for (int i = 0; i < CONT; i++) {
      arr[i] = new Thread(new ChamaB());
    }

    // Inicia metade das threads contidas no array
    for (int i = 0; i < (CONT / 2); i++) {
      arr[i].start();
    }

    // Inicia a thread que far� a chamada do m�todo a()
    ta.start();

    // Inicia metade restante das threads contidas no array
    for (int i = (CONT / 2); i < CONT; i++) {
      arr[i].start();
    }
  }
}

// Respons�vel pela chamada do m�tod a()
class ChamaA implements Runnable {
  public void run() {
    System.out.println("++ Antes de a()");
    Ex3.a(); // Alterar para Ex2.a() ou Ex3.a()
    System.out.println("++ Depois de a()");
  }
}

// Respons�vel pela chamada do m�tod b()
class ChamaB implements Runnable {
  public void run() {
    Ex3.b(); // Alterar para Ex2.b() ou Ex3.b()
  }
}

// sem qualquer prote��o
class Ex1 {
  static int i = 0, j = 0;
  static void a() {
    i++;
    Thread.currentThread().yield();
    j++;
    Thread.currentThread().yield();
  }
  static void b() {
    System.out.println("i=" + i + " j=" + j);
  }
}

// Utilizando sincroniza��o
class Ex2 {
  static int i = 0, j = 0;
  static synchronized void a() {
    i++;
    Thread.currentThread().yield();
    j++;
    Thread.currentThread().yield();
  }
  static synchronized void b() {
    System.out.println("i=" + i + " j=" + j);
  }
}

// Utilizando vari�veis vol�teis
class Ex3 {
  static volatile int i = 0, j = 0;
  static void a() {
    i++;
    Thread.currentThread().yield();
    j++;
    Thread.currentThread().yield();
  }
  static void b() {
    System.out.println("i=" + i + " j=" + j);
  }
}