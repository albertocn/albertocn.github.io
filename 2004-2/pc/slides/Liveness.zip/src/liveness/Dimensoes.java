package liveness;

public class Dimensoes {

  // Acessados pelos m�todos: largura, altura e ajustarDimensoes
  protected double largura = 0.0;
  protected double altura  = 0.0;

  public synchronized double largura() { return largura; }
  public synchronized double altura()  { return altura; }
  public synchronized void ajustar() {
    largura = calculoDemorado3();
    altura = calculoDemorado4();
  }

  // M�todos n�o implementados
  protected double calculoDemorado3() { return Math.random(); }
  protected double calculoDemorado4() { return Math.random(); }
}