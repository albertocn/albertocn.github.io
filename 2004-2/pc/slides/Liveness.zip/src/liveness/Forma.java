package liveness;

/** Representa uma forma geom�trica */

public class Forma {
  // Acessados pelos m�todos: x, y e ajustarLocalizacao
  protected double x = 0.0;
  protected double y = 0.0;

  // Acessados pelos m�todos: largura, altura e ajustarDimensoes
  protected double largura = 0.0;
  protected double altura  = 0.0;

  public synchronized double x() { return x; }
  public synchronized double y() { return y; }
  public synchronized void ajustarLocalizacao() {
    x = calculoDemorado1();
    y = calculoDemorado2();
  }

  public synchronized double largura() { return largura; }
  public synchronized double altura()  { return altura; }
  public synchronized void ajustarDimensoes() {
    largura = calculoDemorado3();
    altura = calculoDemorado4();
  }

  // M�todos n�o implementados
  protected double calculoDemorado1() { return Math.random(); }
  protected double calculoDemorado2() { return Math.random(); }
  protected double calculoDemorado3() { return Math.random(); }
  protected double calculoDemorado4() { return Math.random(); }
}