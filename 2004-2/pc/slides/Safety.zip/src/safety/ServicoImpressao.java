package safety;

/**
 * Representa um servi�o que compartilha com outros um
 * recurso exclusivo
 */
public class ServicoImpressao {

  protected ServicoImpressao vizinho = null;
  protected Impressora impressora = null;

  private static ServicoImpressao[] servicos = null;

  public synchronized void imprimir( String doc ) {
    if ( impressora == null ) // obt�m do vizinho
      impressora = vizinho.pegarImpressora();
    impressora.imprimir( doc );
  }

  public synchronized Impressora pegarImpressora() {
    if ( impressora != null ) {
      Impressora imp = impressora;
      impressora = null;
      return imp;
    }
    else
      return vizinho.pegarImpressora(); // propaga
  }

  public static ServicoImpressao obter( int i ) {
    return servicos[i];
  }

  public synchronized void setVizinho( ServicoImpressao v ) {
    vizinho = v;
  }

  public synchronized void darImpressora( Impressora imp ) {
    impressora = imp;
  }

  public synchronized static void iniciarServicos (int n, Impressora imp) {
    if ( n <= 0 || imp == null)
      throw new IllegalArgumentException();
    servicos = new ServicoImpressao[ n ];
    for (int i = 0; i < n; ++i)
      servicos[i] = new ServicoImpressao();
    for (int i = 0; i < n; ++i)
      servicos[i].setVizinho( servicos[(i + 1) % n]);
    servicos[0].darImpressora( imp );
  }
}