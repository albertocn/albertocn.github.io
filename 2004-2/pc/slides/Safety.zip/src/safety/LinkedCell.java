package safety;

/** Lista no estilo LISP */
public class LinkedCell {

  protected long valor;
  protected final LinkedCell prox;

  public LinkedCell (long v, LinkedCell p) {
    valor = v;
    prox = p;
  }

  public synchronized long valor() { return valor; }
  public synchronized void setValor( long v ) { valor = v; }

  /**
   * Retorna o pr�ximo item da lista. Esse m�todo n�o �
   * sincronizado porque o pr�ximo item � imut�vel.
   */
  public LinkedCell prox() {
    return prox;
  }

  public long soma() {
    long v = valor(); // valor() � synchronized
    if (prox() != null)
      v += prox().soma();
    return v;
  }

  /** Retorna true se o valor procurado est� na lista */
  public boolean inclui( long x ) {
    synchronized(this) {   // para acessar o valor
      if ( valor == x )
        return true;
    }
    if ( prox() == null )
      return false;
    else
      return prox().inclui(x);
  }
}