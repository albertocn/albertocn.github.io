package safety;

import java.util.NoSuchElementException;

/** Array que pode ser redimensionado � medida que for necess�rio */
public class ArrayDinamico {
  private int tam;
  private Object[] dados;

  /** Construtor que recebe a capacidade inicial do array */
  public ArrayDinamico( int capacidadeInicial ) {
    this.dados = new Object[ capacidadeInicial ];
    this.tam = 0;
  }

  /** Retorna a capacidade do array */
  public synchronized int tamanho() { return tam; }

  /** Busca e retorna o objeto na posi��o indicada */
  public synchronized Object buscar( int pos )
      throws NoSuchElementException {
    if (pos < 0 || pos > tam)
      throw new NoSuchElementException();
    else
      return dados[pos];
  }

  /** Adiciona um objeto no final do array */
  public synchronized void adicionarNoFinal( Object o ) {
    if (tam >= dados.length) {
      Object[] antigos = dados;
      dados = new Object[2 * dados.length];
      for (int i = 0; i < tam; i++) {
        dados[i] = antigos[i];
      }
    }
    dados[tam++] = o;
  }

  /**
   * Remove o �ltimo elemento do array, atribuindo null na posi��o
   */
  public synchronized void removerUltimo()
      throws NoSuchElementException
  {
    if (tam == 0)
      throw new NoSuchElementException();
    else
      dados[--tam] = null;
  }

  /** Retorna o conte�do do array em uma String */
  public synchronized String toString() {
    StringBuffer sb = new StringBuffer("[");
    for (int i = 0; i < tam; i++) {
      sb.append( dados[i] );
      sb.append(',');
    }
    sb.deleteCharAt(sb.length() - 1);
    sb.append(']');
    return sb.toString();
  }

  public static void main(String[] args) {
    ArrayDinamico ad = new ArrayDinamico(2);
    for (int i = 1; i <= 6; i++)
       ad.adicionarNoFinal( new Long(i) );
    ad.removerUltimo();
    System.out.println( "Conte�do:" + ad.toString() );
  }
}