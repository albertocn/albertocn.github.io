package safety;

/** Classe cujos atributos s�o todos constantes */
public class Login {
  private final String uid;
  private final String senha;

  public Login( String uid, String senha ) {
    this.uid = uid;
    this.senha = senha;
  }

  public String getUID() { return uid; }
  public String getSenha() { return senha; }

  public boolean senhaValida( String senhaTestar ) {
    return senha.equals( senhaTestar );
  }
}