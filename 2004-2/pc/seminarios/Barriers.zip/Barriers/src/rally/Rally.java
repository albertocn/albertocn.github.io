package rally;

import java.util.concurrent.CyclicBarrier;

public class Rally {
  
  int num_corredores;
  int num_etapas;
  CyclicBarrier chegada;

  public Rally(int num_corredores, int num_etapas) {
    this.num_corredores = num_corredores;
    this.num_etapas = num_etapas;
    chegada = new CyclicBarrier(num_corredores, new Aviso());
    iniciarCorrida(); 
  }
  
  public void iniciarCorrida(){

    System.out.println("*****************************");
  	System.out.println("*     COME�OU O RALLY!      *"); 
    System.out.println("*****************************");
    for (int j=1; j<=num_corredores; j++){
      new Piloto(j,chegada,num_etapas);
    }  
  }
  
  public static void main(String[] args) {
    int num_corredores = 5;
    int num_etapas = 3;
    new Rally(num_corredores, num_etapas);
  }
}