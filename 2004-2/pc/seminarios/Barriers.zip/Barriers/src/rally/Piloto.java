package rally;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class Piloto implements Runnable{
  
  int id = 0;
  CyclicBarrier chegada;
  int num_etapas;
  int ult_colocacao;
  
  public Piloto(int id, CyclicBarrier barreira, int num_etapas) {
    this.id = id;													
    this.num_etapas = num_etapas;
    this.chegada = barreira;
    new Thread(this).start();
  }

  public void run(){ 
    for (int i=1; i<=num_etapas; i++){
       dormir(5000);
       try {
         ult_colocacao = chegada.await()+1;
         System.out.println("O piloto " + id + " chegou em " + ((chegada.getParties() +1 ) - ult_colocacao) + "� lugar!"); 
       } catch (InterruptedException e) {
         e.printStackTrace();
       } catch (BrokenBarrierException e) {
         e.printStackTrace();
       }
    } 
  }

  private void dormir (long max) {
  long tempo = Math.round( Math.random() * max );
  try {
    Thread.sleep( tempo );
    System.out.println( "O piloto " + id + " chegou em " + tempo + " ms." );
  } catch (InterruptedException ie) {
    ie.printStackTrace();
    }
  }
}