package rally;

//classe que implementa runnable e � chamada no construtor da barreira
public class Aviso implements Runnable{

  public Aviso() {
    super();
  }
  
//A��o que � executada quando a barreira � rompida - imprime que a etapa terminou
  public void run(){
  	System.out.println();
    System.out.println("*****************************");
    System.out.println("*    ACABOU ESTA ETAPA!     *");
    System.out.println("*****************************");
    System.out.println("         RESULTADOS:         ");
 
  }
}
