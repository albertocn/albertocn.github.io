package colecoes;

import java.util.concurrent.BlockingQueue;

public class ConcorrenteProdutor implements Runnable {

	private final BlockingQueue queue;

	public ConcorrenteProdutor(BlockingQueue q) {
		queue = q;
	}

	public void run() {
		try {
			while (true) {
				String nome = Thread.currentThread().getName();
				System.out.println("[" + nome + "] DESEJA PRODUZIR");
				queue.put(produce());
				System.out.println("[" + nome + "] PRODUZIU");
				Thread.sleep(100);
			}
		} catch (InterruptedException ex) {
			System.err.println("ERRO: " + ex);
		}
	}

	public Object produce() {
		return "algo";
	}
}
