package colecoes;

import java.util.concurrent.BlockingQueue;

public class ConcorrenteConsumidor implements Runnable {

	private final BlockingQueue queue;

	ConcorrenteConsumidor(BlockingQueue q) {
		queue = q;
	}

	public void run() {
		try {
			while (true) {
				String nome = Thread.currentThread().getName();
				System.out.println("[" + nome + "] DESEJA CONSUMIR");
				consume(queue.take());
				System.out.println("[" + nome + "] CONSUMIU");
				Thread.sleep(10);
			}
		} catch (InterruptedException ex) {
			System.err.println("ERRO: " + ex);
		}
	}

	void consume(Object x) {
	}
}
