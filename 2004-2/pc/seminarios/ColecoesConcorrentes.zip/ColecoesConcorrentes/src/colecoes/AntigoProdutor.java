package colecoes;

import java.util.Queue;

public class AntigoProdutor implements Runnable {

	private final Queue queue;

	public AntigoProdutor(Queue q) {
		queue = q;
	}

	public void run() {
		try {
			while (true) {
				String nome = Thread.currentThread().getName();
				System.out.println("[" + nome + "] DESEJA PRODUZIR");
				queue.add(produce());
				System.out.println("[" + nome + "] PRODUZIU");
				Thread.sleep(100);
			}
		} catch (InterruptedException ex) {
			System.err.println("ERRO: " + ex);
		}
	}

	public Object produce() {
		return "algo";
	}
}
