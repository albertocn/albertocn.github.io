package colecoes;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

import javax.swing.JOptionPane;

public class Exemplo {

	
	/** Exibe uma janela confirmando qual queue executar */
	private static boolean qualQueue() {
		Object[] opcoes = { "Usando Antigo Queue", "Usando BlockingQueue" };
		int resp = JOptionPane.showOptionDialog(null, "Qual Queue devo executar?",
				"Programa��o Concorrente", JOptionPane.DEFAULT_OPTION,
				JOptionPane.QUESTION_MESSAGE, null, opcoes, opcoes[1]);

		return resp == JOptionPane.YES_OPTION;
	}

	public static void main(String[] args) {

		if (qualQueue()) {
			Queue q = new LinkedList();
			new Thread(new AntigoProdutor(q), "P1").start();
			new Thread(new AntigoProdutor(q), "P2").start();
			new Thread(new AntigoConsumidor(q), "C1").start();
			new Thread(new AntigoConsumidor(q), "C2").start();
		} else {
			BlockingQueue q = new ArrayBlockingQueue(10);
			new Thread(new ConcorrenteProdutor(q), "P1").start();
			new Thread(new ConcorrenteProdutor(q), "P2").start();
			new Thread(new ConcorrenteConsumidor(q), "C1").start();
			new Thread(new ConcorrenteConsumidor(q), "C2").start();
		}

		long tempo = System.currentTimeMillis();
		while ((System.currentTimeMillis() - tempo) < 1000) {
		}
		System.exit(0);
	}
}
