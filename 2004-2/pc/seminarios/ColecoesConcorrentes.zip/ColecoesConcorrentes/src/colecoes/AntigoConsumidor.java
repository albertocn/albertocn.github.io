package colecoes;

import java.util.Queue;

public class AntigoConsumidor implements Runnable {

	private final Queue queue;

	public AntigoConsumidor(Queue q) {
		queue = q;
	}

	public void run() {
		try {
			while (true) {
				String nome = Thread.currentThread().getName();
				System.out.println("[" + nome + "] DESEJA CONSUMIR");
				consume(queue.remove());
				System.out.println("[" + nome + "] CONSUMIU");
				Thread.sleep(10);
			}
		} catch (Exception ex) {
			System.err.println("ERRO: " + ex);
		}
	}

	public void consume(Object x) {
	}
}