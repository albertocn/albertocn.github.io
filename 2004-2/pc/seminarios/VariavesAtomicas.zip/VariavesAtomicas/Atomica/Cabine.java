package Atomica;

public class Cabine
{
	private int ncab;
	public Cabine ( int n )
	{
		ncab = n;
	}

	public synchronized  void Pega()
	{ try
	  {
		while ( ncab == 0 ) wait();
		ncab--;
           }
	   catch ( Exception e ){}
	}
	public synchronized void Larga()
	{
		ncab++;
		notify();
	}
}