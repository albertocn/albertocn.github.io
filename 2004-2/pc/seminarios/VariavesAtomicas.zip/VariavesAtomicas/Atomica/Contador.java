package Atomica;

public class Contador {
	
	public int cont;
	public final int N_treads = 15;
	
	public Contador(int contador){
		this.cont = contador; 
		
	}
	
	public void incrementar() {	
		int contTemp = cont;
        try {
           Thread.currentThread().sleep((long) (Math.random() * 10));
        } catch (InterruptedException e) {}
	    cont = contTemp + 1;
	  }
	
	  public void decrementar() {
		int contTemp = cont;
        try {
            Thread.currentThread().sleep((long) (Math.random() * 10));
        } catch (InterruptedException e) {}
	    cont = contTemp - 1;
	  }
	  public Integer getCont() {
	    return cont;
	  }	  
     
	  public void inicializar(Contador c){
	     TreadInc teste[];
	     teste = new TreadInc[N_treads];
		 for ( int i = 0; i < N_treads; i++ )
		 {
		 	teste[i]= new TreadInc(c);
			teste[i].start();
		 }
		 boolean vivas = true ;
		 while (vivas){
		 	for ( int i = 0; i < N_treads; i++ ){
		 		if (teste[i].isAlive()){
		 			break;
		 		}
		 		if (i == N_treads - 1){
		 			vivas = false;
		 		}	 		
		 		  
		 	}

         }
	  }
	  


}