package Atomica;

import java.util.Date;

public class tempo {
    private Date inicio = null;
    private Date fim = null;
    
    public tempo(){
    	inicio = new Date(0);
    	fim = new Date(0);
    }
    
	public void iniciartempo(){
		inicio.setTime( System.currentTimeMillis() );
	}
	
	public void finalizartempo(){
		fim.setTime( System.currentTimeMillis() );
	}
	
	public long getTempo(){
		return fim.getTime() - inicio.getTime();
	}
    

}
