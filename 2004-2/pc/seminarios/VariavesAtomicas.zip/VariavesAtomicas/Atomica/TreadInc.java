package Atomica;

public class TreadInc extends Thread{
	public Contador cont = null;	
	
    public TreadInc(Contador c){
     this.cont =  c;	
    }
    
	public void run(){
	  for(int i = 0; i < 100; i++){
        if (i<90){
	  	  cont.incrementar();
        }else
           cont.decrementar();	
	  	System.out.println("[Contador(" + Thread.currentThread().getName() +")] = " + cont.getCont());
	  }
	}

}
