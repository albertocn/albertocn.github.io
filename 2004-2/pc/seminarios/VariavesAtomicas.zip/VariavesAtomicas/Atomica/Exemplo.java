package Atomica;
import javax.swing.JOptionPane;

public class Exemplo {
	Contador contador = null;
	ContadorSincronizado contadorsincronizado = null;
	ContadorVA contadorVA = null;
	
	
	
	public void criarcontador(){
         Contador c = new Contador(0);       
		 tempo t = new tempo();
		 t.iniciartempo();
		 c.inicializar(c);
		 t.finalizartempo();
		 System.out.println("Contador => O Processamento demorou " + t.getTempo() + " milesegundos");
	}
	
	public void criarcontadorsincronizado(){
        Contador c = new ContadorSincronizado(0);       
		tempo t = new tempo();
		t.iniciartempo();
		c.inicializar(c);
		t.finalizartempo();
		System.out.println("ContadorSincronizado => O Processamento demorou " + t.getTempo() + " milesegundos");		
	}	


	public void criarcontadorVA(){
		ContadorVA c = new ContadorVA(0);
		tempo t = new tempo();
		t.iniciartempo();
		c.inicializar(c);
		t.finalizartempo();		
        System.out.println("Contador Sincronizado lock-free => O Processamento demorou " + t.getTempo() + " milesegundos");
	}
	
	public static void main(String[] args) {
		String entrada;
		for (int j =0;j<5;j++){
		  entrada = JOptionPane.showInputDialog("Digite 1 para Contador Sem Sincroniza��o\n" +
				                              "Digite 2 para Contador com Sincroniza��o com Lock\n" +
				                              "Digite 3 para Contador com Sincroniza��o Lock-free\n" +
				                              "Digite 4 para sair\n");
		  int escolha = Integer.parseInt( entrada );
		  Exemplo ex = new Exemplo();
		
		  switch (escolha){
		  case 1: ex.criarcontador();
		          break;
		  case 2: ex.criarcontadorsincronizado();
			      break;
		  case 3: ex.criarcontadorVA();
			      break;
		  case 4: System.exit(0);
				  break;
		  default: System.out.println("Entrada Inv�lida");
		
		}
	  }	
	}
}
