package Atomica;

public class Cesto
{
	private int ncesto;
	public Cesto ( int n )
	{
		ncesto = n;
	}
	public synchronized  void Pega()
	{ try
	  {
        	while ( ncesto == 0 )	wait();
		ncesto--;
	  }
	  catch (Exception e ){}
	}
 
	public synchronized void Larga()
	{
		ncesto++;
		notify();
	}
}

