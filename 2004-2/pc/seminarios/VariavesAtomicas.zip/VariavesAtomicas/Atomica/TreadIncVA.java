package Atomica;

public class TreadIncVA extends Thread {
	public ContadorVA cont = null;	
	
    public TreadIncVA(ContadorVA c){
     this.cont =  c;	
    }
	public void run(){
	  for(int i = 0; i < 100; i++){
        if (i<90){
  	  	  cont.incrementar();
          }else
             cont.decrementar();	
	  	System.out.println("[Contador(" + Thread.currentThread().getName() +")] = " + cont.getCont());
	  }
	}


}

