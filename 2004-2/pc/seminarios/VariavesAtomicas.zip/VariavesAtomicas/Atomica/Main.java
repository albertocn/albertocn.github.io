package Atomica;


public class Main
{
	public static void main ( String args[])
	{
		Cabine cab;
		Cesto  cesto;
		Nadador nadador[];
		
		cab   = new Cabine( 5 );

		cesto = new Cesto ( 5 ); 
		
		nadador = new Nadador[ 20 ];
				
		for ( int i = 0; i <= 5; i++ )
		{
		   nadador[i]= new Nadador(i,cesto,cab);
		   nadador[i].start();
		}
	}
 }

