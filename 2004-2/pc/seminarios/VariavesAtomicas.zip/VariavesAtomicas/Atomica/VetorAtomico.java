
package Atomica;
import java.util.concurrent.atomic.*;

public class VetorAtomico {
	private AtomicIntegerArray vetor;
	
	public void inc(){
		vetor.getAndIncrement(1);
		vetor.getAndAdd(2,3);
		
	}
	public VetorAtomico(int valor[]){
		vetor = new AtomicIntegerArray(valor);
	}


}
