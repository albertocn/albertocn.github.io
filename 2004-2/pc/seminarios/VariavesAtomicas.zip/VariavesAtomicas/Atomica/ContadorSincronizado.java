package Atomica;

public class ContadorSincronizado extends Contador {	
		
	public ContadorSincronizado(int contador){
		super(contador);
	}
	
	public synchronized void incrementar() {
	    super.incrementar();
	  }

	  public synchronized void decrementar() {
	    super.decrementar();
	  }
	  public synchronized Integer getCont() {
	    return super.getCont();
	  }
	  


}
