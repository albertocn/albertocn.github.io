package Atomica;
import java.util.concurrent.atomic.*;

public class ContadorVA {
    
	private AtomicInteger bilhete = null;
	public final int N_treads = 15;
	
	public ContadorVA(int valor){
		bilhete = new AtomicInteger(valor);
	
	}

	  public void incrementar() {
        
	  	try {
            Thread.currentThread().sleep((long) (Math.random() * 10));
        } catch (InterruptedException e) {}
	    bilhete.getAndAdd(1);
	  }

	  public void decrementar() {
	  	try {
            Thread.currentThread().sleep((long) (Math.random() * 10));
        } catch (InterruptedException e) {}
	  	bilhete.getAndDecrement();
	  }

	  public Integer getCont() {
	    return bilhete.get();
	  }
	  
	  
	  public void inicializar(ContadorVA c){
	     TreadIncVA teste[];
	     teste = new TreadIncVA[N_treads];
		 for ( int i = 0; i < N_treads; i++ )
		 {
		 	teste[i]= new TreadIncVA(c);
			teste[i].start();
		 }
		 boolean vivas = true ;
		 while (vivas){
		 	for ( int i = 0; i < N_treads; i++ ){
		 		if (teste[i].isAlive()){
		 			break;
		 		}
		 		if (i == N_treads - 1){
		 			vivas = false;
		 		}	 		
		 		  
		 	}

        }
	  }
	  
  
}
