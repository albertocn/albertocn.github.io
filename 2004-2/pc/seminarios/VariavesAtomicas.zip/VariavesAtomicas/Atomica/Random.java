package Atomica;
import java.util.concurrent.atomic.*;

public class Random {
	private AtomicLong seed;
	public Random(long s){
		seed = new AtomicLong(s);
	}
	long next(){
		for(;;) {
			long s = seed.get();
			System.out.println(s);
			long nexts = s * 5;
			System.out.println(nexts);
		
			nexts = nexts +3;
			if (seed.compareAndSet(s,nexts)){
				return s;
			}
		}
	}
	public static void main(String[] args) {
		Random random = new Random(15);
		
		System.out.println("Achou " + random.next());
	}
}
