
package Atomica;

public class Nadador extends Thread
{
	String nome;
	Cesto  cesto;
	Cabine cabine;
	int n;
	public Nadador ( int n, Cesto cesto, Cabine cabine )
	{
		this.n      = n;
		this.cesto  = cesto;
		this.cabine = cabine;
	}
	public void run()
	{ try
	  {
		cesto.Pega();
		cabine.Pega();
		System.out.println("..... "+ n + "   RETIRANDO A ROUPA");
		sleep ( (int) ( Math.random() * 5000 ));
		cabine.Larga();
		System.out.println("..... "+ n +"   NADANDO ");
		sleep ( (int) ( Math.random() * 5000 ));
		cabine.Pega();
		System.out.println("..... "+ n +"   COLOCANDO A ROUPA");
		sleep ( (int) ( Math.random() * 5000 ));
		cabine.Larga();
		cesto.Larga();
	   }
	  catch ( Exception e ) {}	
	}
}
