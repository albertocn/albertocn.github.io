package br.ufs.semaphore.pcbi;

/**
 * <p>Title: Syncronizers - Semaphores </p>
 * <p>Description: Implementa��o do Produtor/Consumidor utilizando a classe
 *                 Semaphore implementada pela vers�o Java 1.5 </p>
 * @author Adapta��o do c�digo do Prof. Alberto Costa Neto 
 *         realizada por Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

//import semaforo.Semaforo;
//import semaforo.SemaforoContador;
//import semaforo.SemaforoDebug;
import java.util.concurrent.Semaphore;
import br.ufs.semaphore.SemaphoreDebug;

import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Exemplo {
	
	protected List buffer;
	protected Semaphore elementos;
	
	public Exemplo() {
		this.buffer = criarBuffer();
		this.elementos = criarSemaforo();
	}
	
	public void executar() {
		Produtor prod = criarProdutor();
		Consumidor cons = criarConsumidor();
		
		Thread tp = new Thread (prod, "P");
		Thread tc = new Thread (cons, "C");
		
		tp.start();
		tc.start();
					
		try {
			tp.join();
			tc.join();
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}
		
		System.out.println("Situa��o do Buffer: " + buffer);
	}
	
	protected List criarBuffer() {
		return Collections.synchronizedList( new LinkedList() );
	}
	
	protected Semaphore criarSemaforo() {
		return new SemaphoreDebug( new Semaphore(0), "Elementos" );
	}
	
	protected Produtor criarProdutor() {
		return new Produtor( this.buffer, this.elementos );
	}
	
	protected Consumidor criarConsumidor() {
		return new Consumidor( this.buffer, this.elementos );
	}
	
	public static void main(String[] args) {
		new Exemplo().executar();
	}
}
	