package br.ufs.semaphore.caixa;

import java.util.concurrent.Semaphore;

/**
 * <p>Title: Syncronizers - Semaphores </p>
 * <p>Description: Implementa��o do atendimento de Clientes por um Caixa 
 *                 utilizando a classe Semaphore implementada pela vers�o 
 *                 Java 1.5 </p>
 * @author Adapta��o do c�digo do Prof. Alberto Costa Neto 
 *         realizada por Marcos D�sea e Josnei Macedo
 * @version 1.0
 */
public class Exemplo {
      private static final int NUM_CAIXAS = 4;
      private static final int NUM_CLIENTES = 25;
      
	  protected Semaphore sem;

	  public Exemplo() {
	    this.sem = criarSemaforo();
	  }

	  public void executar() {
	    for ( int i = 1; i <= NUM_CAIXAS; i++){
	  	  Caixa caixa = criarCaixa();
	      Thread threadCaixa = new Thread (caixa, "Caixa "+i);
	      threadCaixa.start();
	    }  

	    Pessoa[] pessoas = new Pessoa[25];
	    for (int i = 0; i < pessoas.length; i++) {
	       pessoas[i] = criarPessoa( i );
	       Thread t = new Thread (pessoas[i], "Pessoa" + i);
	       t.start();
	       try { Thread.sleep(20); }
	       catch (InterruptedException ie) { ie.printStackTrace(); }

	    }
	  }

	  protected Semaphore criarSemaforo() {
	    //Sem�foro FIFO
	  	return new Semaphore(0, true);
	  }

	  protected Pessoa criarPessoa( int n ) {
	    return new Pessoa( n, sem );
	  }

	  protected Caixa criarCaixa() {
	    return new Caixa( sem );
	  }

	  public static void main(String[] args) {
	    new Exemplo().executar();
	  }
	}
