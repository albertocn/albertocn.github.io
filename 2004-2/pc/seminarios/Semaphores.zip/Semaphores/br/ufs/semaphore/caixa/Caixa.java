package br.ufs.semaphore.caixa;

import java.util.concurrent.Semaphore;

/**
 * <p>Title: Syncronizers - Semaphores </p>
 * <p>Description: Implementa��o do atendimento de Clientes por um Caixa 
 *                 utilizando a classe Semaphore implementada pela vers�o 
 *                 Java 1.5 </p>
 * @author Adapta��o do c�digo do Prof. Alberto Costa Neto 
 *         realizada por Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

public class Caixa implements Runnable {

	  private final Semaphore sem;

	  public Caixa( Semaphore sem ) {
	    this.sem = sem;
	  }

	  public void run() {
	    while (true) {
	      log("Caixa est� livre e descansando!");
	      try { Thread.sleep(50); }
	      catch (InterruptedException ie) { ie.printStackTrace(); }
	      log("Caixa chama pr�ximo cliente na fila."); 
	      sem.release();
	    }
	  }

	  private void log ( String msg ) {
	    System.out.println("["+ Thread.currentThread().getName()+"] " + msg);
	  }
	}