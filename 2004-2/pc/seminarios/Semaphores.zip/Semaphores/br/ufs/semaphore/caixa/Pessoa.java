package br.ufs.semaphore.caixa;

import java.util.concurrent.Semaphore;

/**
 * <p>Title: Syncronizers - Semaphores </p>
 * <p>Description: Implementa��o do atendimento de Clientes por um Caixa 
 *                 utilizando a classe Semaphore implementada pela vers�o 
 *                 Java 1.5 </p>
 * @author Adapta��o do c�digo do Prof. Alberto Costa Neto 
 *         realizada por Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

public class Pessoa implements Runnable {

	  private final int n;
	  private final Semaphore sem;

	  public Pessoa( int n, Semaphore sem ) {
	    this.n = n;
	    this.sem = sem;
	  }

	  public int getN() { return n; }

	  public void run() {
	    log("Chamando P");
	    if ( sem.tryAcquire() ){  //sem.P()
	      log("P foi atendido no momento que chegou na fila!");      
	    } else sem.acquireUninterruptibly();
	    log("Sendo atendido");
	    log ("Ainda existem "+sem.getQueueLength()+ " pessoas na fila esperando.");    
	  }

	  private void log ( String msg ) {
	    System.out.println("[P" + n + "] " + msg);
	  }
	}
