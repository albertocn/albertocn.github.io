package br.ufs.semaphore.pcbiUn;

//import semaforo.Semaforo;
import java.util.List;
import java.util.concurrent.Semaphore;

/**
 * <p>Title: Syncronizers - Semaphores </p>
 * <p>Description: Implementa��o do Produtor/Consumidor utilizando a classe
 *                 Semaphore implementada pela vers�o Java 1.5 </p>
 * @author Adapta��o do c�digo do Prof. Alberto Costa Neto 
 *         realizada por Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

public class Produtor implements Runnable {
	protected List buffer;
	protected Semaphore elementos;
	protected long cont;
	
	public Produtor( List buffer, Semaphore elementos ) {
		this.buffer = buffer;
		this.elementos = elementos;
		this.cont = 0;
	}
	
	public void run() {
		while (deveContinuar()) {
			produzir();
			elementos.release();
		}
	}
	
	protected void produzir() {
		if (cont % 3 == 0) {
			try {
				long tempo = Math.round(Math.random() * 200);
				System.out.println("Produtor dormindo por " + tempo + " ms");
				Thread.sleep( tempo );
			} catch (InterruptedException ie) { ie.printStackTrace(); }
		}
		String obj = "" + ++cont + "� OBJ";
		buffer.add( obj );
		System.out.println("Produzido (" + obj + ")");
	}
	
	protected boolean deveContinuar() {
		return cont < 10;
	}
}