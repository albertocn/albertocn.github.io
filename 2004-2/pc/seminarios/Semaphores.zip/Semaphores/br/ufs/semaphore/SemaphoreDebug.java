package br.ufs.semaphore;

//import semaforo.Semaforo;
import java.util.concurrent.Semaphore;

public class SemaphoreDebug extends Semaphore {

	  private static final long serialVersionUID = 0;
	  private final Semaphore sem;
	  private final String nome;

	  public SemaphoreDebug( Semaphore sem, String nome ) {
	  	super( sem.availablePermits() );
	    this.sem = sem;
	    this.nome = nome;
	  }
	  public void acquire() throws InterruptedException {
	    System.out.println("[" + getNomeThread() + "] ANTES de P sobre " + getNome());
	    sem.acquire();  //sem.P()
	    System.out.println("[" + getNomeThread() + "] DEPOIS de P sobre " + getNome());
	  }
	  
	  public void acquireUninterruptibly(){
	    System.out.println("[" + getNomeThread() + "] ANTES de P sobre " + getNome());
	    sem.acquireUninterruptibly();  //sem.P()
	    System.out.println("[" + getNomeThread() + "] DEPOIS de P sobre " + getNome());
	  }
	  
	  public void release() {
	    System.out.println("[" + getNomeThread() + "] ANTES de V sobre " + getNome());
	    sem.release();      //sem.V()
	    System.out.println("[" + getNomeThread() + "] DEPOIS de V sobre " + getNome());
	  }

	  public String getNome() {
	    return this.nome;
	  }

	  public String getNomeThread() {
	    return Thread.currentThread().getName();
	  }

	  public String toString() {
	  	return sem.toString();
	  }
	}