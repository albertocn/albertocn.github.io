package br.ufs.semaphore.pcbi;

/**
 * <p>Title: Syncronizers - Semaphores </p>
 * <p>Description: Implementa��o do Produtor/Consumidor utilizando a classe
 *                 Semaphore implementada pela vers�o Java 1.5 </p>
 * @author Adapta��o do c�digo do Prof. Alberto Costa Neto 
 *         realizada por Marcos D�sea e Josnei Macedo
 * @version 1.0
 */

//import semaforo.Semaforo;
import java.util.concurrent.Semaphore;
import java.util.List;

public class Consumidor implements Runnable {
	
	protected List buffer;
	protected Semaphore elementos;
	protected long inicio;
	
	public Consumidor( List buffer, Semaphore elementos ) {
		this.buffer = buffer;
		this.elementos = elementos;
		this.inicio = System.currentTimeMillis();
	}
	
	public void run() {
		try {
			System.out.println("CONSUMIDOR DORMINDO");
			Thread.sleep( 5 );
			System.out.println("CONSUMIDOR ACORDADO");
		} catch (InterruptedException ie) { ie.printStackTrace(); }
		
		
		while (deveContinuar()) {
			//Nessa forma do acquire se houver interrup��o a Thread sai do sem�foro 
			//e executa a pr�xima instru��o sem permiss�o. Por isso a repeti��o.  
			while (true){
				try {
					elementos.acquire(); //elementos.P()
					break;
				} catch (InterruptedException e) {
					System.err.println("InterruptedException, esperar novamente");
					if (elementos.availablePermits() >= 0) break;
					else continue;
				}  
			}
			consumir();
		}	
		System.out.println("CONSUMIDOR ENCERRADO");
	}
	
	protected void consumir() {
		Object obj = buffer.remove(0);
		System.out.println( "CONSUMIU " + obj );
	}
	
	protected boolean deveContinuar() {
		return System.currentTimeMillis() < inicio + 150;
	}
}