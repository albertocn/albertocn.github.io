package exchange;

import java.util.concurrent.Exchanger;

/*
 * Created on 16/02/2005
 */

/**
 * @author RITA KALILE ALMEIDA ANDRADE
 * 		     SUEANE SANTOS BOMFIM
 * 
 * Esta classe gera strings de forma simplificada apenas c o objetivo
 * de testar o uso da classe <java.util.concurrent.Exchanger>.
 * Exchanger implementa m�todos para troca sincronizada de objetos entre 
 * um par de threads.  
 *
 */
public class GerarSenhas implements Runnable {
	
	private Exchanger exchanger;

	  final String[] LOWER = {"a","b","c","d","e","f","g","h","i","j","k",
		  		              "l","m","n","o","p","q","r","s","t","u","v",
							  "w","x","y","z"};

	  public GerarSenhas(Exchanger exchanger) { 
	  	this.exchanger = exchanger;
	  }

	  public void run() {
    	String senhaAtual="", senhaAnterior="", sucesso="false";
    	int count = 0;
    	
    	for (int i=0; i<26; i++)
	      	for (int j=0; j<26; j++)
		      	for (int k=0; k<26; k++) {
		      			count++;
			      		senhaAnterior = senhaAtual;
			      		senhaAtual = /*LOWER[l]+*/LOWER[k]+LOWER[j]+LOWER[i];
			      		System.out.println("[GerarSenhas ] <<GEROU '" + senhaAtual + "'>>");
						
						    try {
						      //////////////////////////////
						      System.out.println("[GerarSenhas ] PEDE exchange " + count);
						      sucesso = (String) exchanger.exchange(senhaAtual);
						      System.out.println("[GerarSenhas ] 	    REALIZOU exchange " + count);
									//////////////////////////////
						    } catch (InterruptedException e) {
						      e.printStackTrace();
						    }

				      	if (sucesso.equals("true")) {
					      	i=26;j=26;k=26;//l=26;
				      	}
					}
    	
    	if (sucesso.equals("false")) {
    		try {
    		  //verificar se a ultima senha funcionou
    		  sucesso = (String) exchanger.exchange("");
    		} catch (InterruptedException e) {
    		  e.printStackTrace();
    		}
    	}
			
    	System.out.println("FIM GerarSenhas");
    }
   
  }