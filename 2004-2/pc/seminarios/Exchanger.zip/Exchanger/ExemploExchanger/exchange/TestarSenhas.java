package exchange;

import java.util.concurrent.Exchanger;

/*
 * Created on 16/02/2005
 */
/**
 * @author RITA KALILE ALMEIDA ANDRADE
 * 		   	 SUEANE SANTOS BOMFIM
 * 
 * Esta classe testa senhas de forma simplificada por comparar o valor de 
 * uma string argumento com o valor de uma string local. 
 * O objetivo � testar o uso da classe <java.util.concurrent.Exchanger>.
 * Exchanger implementa m�todos para troca sincronizada de objetos entre 
 * um par de threads.  
 *
 */
public class TestarSenhas implements Runnable {
	
	private Exchanger exchanger;
	
	  public TestarSenhas(Exchanger exchanger) { 
	  	this.exchanger = exchanger;
	  }

	  public void run() {
    	int count = 0;
    	String senhacerta = "boa";
    	
    	// Os objetos trocados entre as threads devem ser da mesma classe/tipo
    	String senha="", tentativa = "false"; 
    	
    	while (tentativa.equals("false")) {
    		count++;
    		try {
    			/////////////
    		  System.out.println("[TestarSenhas] PEDE exchange " + count);
    		  senha = (String) exchanger.exchange(tentativa);
    		  System.out.println("[TestarSenhas]      REALIZOU exchange " + count);
    		  /////////////
    		} catch (InterruptedException e) {
    		  e.printStackTrace();
    		}
			
    		System.out.println("[TestarSenhas] TESTE - " + " Candidata: " + senha + " | Correta: " + senhacerta);
			
    		// "Teste" de senha
    		if (senha.equals(senhacerta))
    		  tentativa = "true";
    		else tentativa = "false";
    	}//while
    	
    	try {
    	  //informa a outra thread que a tentativa foi um sucesso
    	  System.out.println("[TestarSenhas] Ultimo exchange: informa a outra thread que a ultima senha foi a desejada");
    	  exchanger.exchange(tentativa);
    	} catch (InterruptedException e) {
    	  e.printStackTrace();
    	} 

    	System.out.println(" -~<<([ SUCESSSOOO!! ])>>~-   SENHA ENCONTRADA: '"+senha+"'");
    	System.out.println("FIM TestarSenhas"); 	
    }
  }

