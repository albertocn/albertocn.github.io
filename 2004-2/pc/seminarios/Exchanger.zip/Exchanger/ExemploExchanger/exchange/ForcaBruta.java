package exchange;
/*
 * Created on 15/02/2005
 */
import java.util.concurrent.Exchanger;

/**
 * @author RITA KALILE ALMEIDA ANDRADE
 * 		     SUEANE SANTOS BOMFIM
 *
 */
public class ForcaBruta {
	
    public static void main(String[] args) {
	    Exchanger exchanger = new Exchanger();
	    System.out.println("Iniciando threads: GerarSenhas e TestarSenhas");
	    new Thread(new GerarSenhas(exchanger)).start();
	    new Thread(new TestarSenhas(exchanger)).start();	    
	}

}
