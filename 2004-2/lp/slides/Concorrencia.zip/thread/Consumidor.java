package thread;

/**
 * Retira valores do buffer limitado.
 */
public class Consumidor implements Runnable {

	private BufferLimitado buffer;
	
	public Consumidor(BufferLimitado buffer) {
		this.buffer = buffer;
	}

	/**
	 * M�todo que cont�m os comandos a executados pela Thread
	 */
	public void run() {
		int elem;
		while (true) {
			try {
				elem = buffer.retirar();
				System.out.println("consumido: " + elem);
				Thread.sleep((int)(Math.random() * 1000));
				
			} catch (InterruptedException e) {
				System.out.println("O consumidor causou o seguinte erro:" +
						           e.getMessage());
			}
		}
	}
}
