package thread;

/**
 * Implementa um BufferLimitado cuja capacidade � determinada
 * no momento da instancia��o.
 */
public class BufferLimitado {
	private int capacidade;
	private int n;
	private int buffer[];
	private int fim;
	private int ini;
	
	/**
	 * Cria uma inst�ncia do buffer com a capacidade especificada
	 * @param capacidade Capacidade do buffer
	 */
	public BufferLimitado (int capacidade) {
		this.capacidade = capacidade;
		n = 0;
		fim = 0;
		ini = 0;
		buffer = new int[capacidade];
	}
	
	/**
	 * Insere um elemento no buffer. Quando n�o h� espa�o, a thread
	 * espera at� que algum elemento seja removido por outra thread
	 * 
	 * @param elemento Valor a ser inseriro no buffer
	 */
	public synchronized void inserir(int elemento) 
	    throws InterruptedException
	{
	   while (n == capacidade)
	      wait(); // coloca a thread em espera
	   buffer[fim] = elemento;
	   fim = (fim + 1) % capacidade;
	   n = n + 1;
	   notify(); // notifica uma das threads esperando (wait) 
	}
	
	public synchronized int retirar() 
	    throws InterruptedException
	{
	   while (n == 0)
	      wait(); // coloca a thread em espera
	   int elem = buffer[ini];
	   ini = (ini + 1) % capacidade;
	   n = n - 1;
	   notify(); // notifica uma das threads esperando (wait)
	   return elem;
	}
}
