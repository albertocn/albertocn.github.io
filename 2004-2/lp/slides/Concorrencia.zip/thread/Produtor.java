package thread;

/**
 * Thread que produz valores e insere no buffer limitado
 */
public class Produtor extends Thread {
	
	private BufferLimitado buffer;
		
	public Produtor(BufferLimitado buffer) {
		this.buffer = buffer;
	}

	/**
	 * M�todo que cont�m os comandos a executados pela Thread
	 */
	public void run() {
		int elem;
		while (true) {
			elem = (int) (Math.random() * 10000);
			try {
				buffer.inserir(elem);
				System.out.println("produzido: " + elem);
				Thread.sleep((int)(Math.random() * 1000));
				
			} catch (InterruptedException e) {
				System.out.println("O produtor causou o seguinte erro:" +
						           e.getMessage());
			}
		}
	}
}
