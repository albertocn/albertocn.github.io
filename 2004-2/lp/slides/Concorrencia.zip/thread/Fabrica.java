package thread;

/**
 * Cria o Buffer, instancia e inicia as threads do consumidor e produtor
 */
public class Fabrica {
	
	public static void main(String args[]) throws InterruptedException {
		BufferLimitado buf = new BufferLimitado(10);
		Produtor p = new Produtor(buf);
		Consumidor c = new Consumidor(buf);
		p.start();
		Thread tc = new Thread(c);
		tc.start();
		p.join();  // Faz com que a thread corrente aguarde o
		tc.join(); // encerramento da outra thread para passar
		           // ao comando seguinte
	}

}
