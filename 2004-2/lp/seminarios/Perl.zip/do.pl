#!/usr/local/bin/perl

do

{

        print "Senha? ";        # pede pela senha

        $a = <STDIN>;           # l� do teclado

        chop $a;                # remove o �ltimo caractere, newline

}

#while ($a ne "teste");          # repete enquanto a senha for errada

                                # usando until no lugar de while,

until ($a eq "teste");       # repete at� que a senha esteja correta


