#!/usr/local/bin/perl

$x=10;
$y=0;

print "Valor de Y: ".$y."\n";
print "Valor de x: ".$x."\n\n";

if($x == $y) {
      print "X e igual a Y\n";
}
elsif($x > 0) {
      print "X e maior do que zero\n";
}
else {
      print "X e diferente de Y e menor do que zero\n";
}
