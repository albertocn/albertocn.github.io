#!/usr/local/bin/perl

@cores = ("azul","verde","amarelo","vermelho");

foreach $cor (@cores) {
    print $cor."\n";
}

