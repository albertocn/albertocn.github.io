#!/usr/local/bin/perl

$x=0;


until($x >= 20) {
      print "X=".$x."\n";
          $x++;
}
