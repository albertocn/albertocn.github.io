#!/usr/local/bin/perl

$x=15;


print "Valor de x =".$x."\n\n";
print "X e menor do que 20\n" unless $x >= 20;
