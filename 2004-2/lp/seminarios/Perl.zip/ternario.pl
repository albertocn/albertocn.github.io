#!/usr/local/bin/perl

$primeiro=0;

$segundo="mike";

$terceiro="gabriel";

print $primeiro ? $segundo : $terceiro;


