#!/usr/local/bin/perl
#atribui��o e apresenta��o de array

@linguagens=("perl","c++","vfp");
@usuarios=("mike",23,"diego",19);

print "@linguagens";
print "\n";
print "@usuarios";
