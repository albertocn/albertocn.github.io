#!/usr/local/bin/perl

package Classe;

sub new{
print " Classe::foi chamada\n";
my $type = shift;            
my $self = {};               
return bless $self, $type;   


}

sub DESTROY{
print "Classe::Destroy foi chamado\n";
}

sub MeuMetodo{
print "Classe::MeuMetodo foi chamado\n";
}


$objeto=Classe->new();
$objeto->MeuMetodo();

undef $objeto;