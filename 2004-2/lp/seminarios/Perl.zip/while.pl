#!/usr/local/bin/perl

$x=0;


while($x <= 10) {

     print "X=".$x."\n";
     $x++;
}
