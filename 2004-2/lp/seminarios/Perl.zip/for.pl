#!/usr/local/bin/perl

$x=0;

for ($x = 100;$x <= 200;$x++) {
    print "X = ",$x," ";
}

