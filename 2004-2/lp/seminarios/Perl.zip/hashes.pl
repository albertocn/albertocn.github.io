#!/usr/local/bin/perl

%dados=("nome","mike","idade",23,"cidade","Aracaju");
%dadosorganizados=(nome => "carina", idade => 21, cidade => "dores");

#joga valores e chaves para arrays

@chaves1= keys %dados;
@chaves2= keys %dadosorganizados;
@valores1=values %dados;
@valores2=values %dadosorganizados;


print "Chaves de %dados\n";
print "@chaves1";
print "\n";
print "Valores de %dados\n";
print "@valores1";
print "\n\n";

print "Chaves de %dadosorganizados\n";
print "@chaves2";
print "\n";
print "Valores de %dados\n";
print "@valores2";
print "\n";
