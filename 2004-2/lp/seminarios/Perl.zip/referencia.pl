#!/usr/local/bin/perl

$a = "oi";
$b = \$a;

print "como � uma refer�ncia n�o exibe\n";
print "$b\n";
print "Agora exibe pq � a vari�vel\n";
print "$a";