$arquivo = 'mike.txt';       # nome do arquivo
open(INFO, $arquivo);           # abre o arquivo
@linhas = <INFO>;               # coloca ele em uma matriz
close(INFO);                    # fecha o arquivo
print @linhas;                  # exibe a matriz
