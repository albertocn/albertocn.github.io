tamPadrao = 20

function tablePrinter(T,tam)
	fim = 0;
	
	if (tam) then fim = tam; 
	else fim = tamPadrao;
	end
	
	for count = 1,fim do
		i = count;
		print("Elemento " .. i .. " = " .. T[count] .. "\n");				
	end
end


tabela = {
	"valor 0",
	"valor 1",
	"valor 2",
	"valor 3",
	"valor 4",
	"valor 5",
	"valor 6",
	"valor 7",
	"valor 8",
	"valor 9"
}



-- tratando exce��o
function secureTablePrinterError()
	if ( pcall(tablePrinter,tabela) )  then
		tablePrinter(tabela);
	else
		error("Tamanho da tabela eh menor que o Padrao", 2);
	end
end 


function secureTablePrinterErrorHandler()

	if ( pcall(tablePrinter,tabela) )  then
		tablePrinter(tabela);
	else
		tablePrinter(tabela, table.getn(tabela) ); 
		-- getn obtem o tamanho da tabela semelhante a uma lista
	end
end 




-- pode dar erro
--tablePrinter(tabela);

-- se der erro, imprime mensagem
--secureTablePrinterError();

-- se der erro, o mesmo � tratado
secureTablePrinterErrorHandler();
