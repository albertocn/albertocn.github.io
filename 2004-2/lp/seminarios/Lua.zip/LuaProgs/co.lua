maxExecucoes = 15;
pronto = "verdadeiro";

co1 = coroutine.create(function (nome)
local cont = 1;
while (cont < maxExecucoes) do
	math.randomseed(cont);
	fim = cont + math.random(5);
	for i = cont,fim  do
		cont = cont +1;
		if (cont > maxExecucoes) then
			pronto = nil; break;
		end
		print(nome,": ", i);
	end
	coroutine.yield();
end
		return "Fim"; 
end)

co2 = coroutine.create(function (nome)
local cont = 1;
while (cont < maxExecucoes) do
    math.randomseed(cont);
	fim = cont + math.random(5);
	for i = cont,fim  do
		cont = cont +1;
		if (cont > maxExecucoes) then 
			pronto = nil; break;
		end
		print(nome,": ", i);
	end
	coroutine.yield();
end
		return "Fim"; 
end)

while (pronto) do
	coroutine.resume(co1, "co-rotina.1");
	coroutine.resume(co2, "co-rotina.2");	
end



