var1 = "valor1";
var2 = "valor2";

-- fun��es de impress�o e troca

imprime = function() print("variavel 1 = " .. var1 .. "\n" .. "variavel 2 = " .. var2 .. "\n"); end

troca = function () var1, var2 = var2, var1; end


-- processamento da troca:

imprime();

troca();

imprime();