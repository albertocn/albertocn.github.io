-- Definindo fun��o de impress�o
function imprimeTabela(T)
	campo, valor = next(T,nil);
	while (campo) do
		print("campo " .. campo .. " = " .. valor);
		campo, valor = next(T,campo);
	end	
end


-- Criando a tabela
tabela = {
	1, 2, 3,
	"string1", "string2", "string3",
	linguagem = "Lua versao 5.0"	
}

tabela[50] = "valor na posicao 50";


imprime = imprimeTabela;

imprime(tabela);