package tpv;

public class TPV {

    private Loja               loja;
    private Cat�logoDeProdutos cat�logo;
    private Venda              venda;

    public TPV(Loja loja, Cat�logoDeProdutos cat�logo) {
        this.loja = loja;
        this.cat�logo = cat�logo;
    }

    public void finalizarVenda() {
        venda.finalizar();
        loja.gravarVenda(venda);
    }

    public void entrarItem(C�digoDeProduto c�digo, int quantidade) {
        if (vendaNova()) {
            venda = new Venda();
        }

        venda.criarLinhaDetalhe(cat�logo.especifica��o(c�digo),
		                        quantidade);
    }

    public void fazerPagamento(Dinheiro valorFornecido) {
        venda.fazerPagamento(valorFornecido);
    }

    private boolean vendaNova() {
        return (venda == null) || venda.finalizada();
    }
}