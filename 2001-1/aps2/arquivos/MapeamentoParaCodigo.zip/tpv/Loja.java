package tpv;

import java.util.*;

public class Loja {

    private String   nome;
    private Endere�o endere�o;

    private Collection vendasFinalizadas = new LinkedList();
    private Cat�logoDeProdutos cat�logo = new Cat�logoDeProdutos();
    private TPV tpv = new TPV(this, cat�logo);

    public Loja(String nome, Endere�o endere�o) {
        this.nome = nome;
        this.endere�o = endere�o;
    }

    public String getNome()       { return nome; }
    public Endere�o getEndere�o() { return endere�o; }
    public TPV getTPV()           { return tpv; }

    public Collection getVendasFinalizadas() { 
	    return Collections.unmodifiableCollection(vendasFinalizadas);
    }

    public void gravarVenda(Venda venda) {
        vendasFinalizadas.add(venda);
    }
}