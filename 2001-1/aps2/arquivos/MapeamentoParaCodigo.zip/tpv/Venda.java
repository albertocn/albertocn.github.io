package tpv;

import java.util.*;

public class Venda {

    private boolean finalizada = false;
    private Date dataEHora = new Date();

    private Collection linhasDetalhe = new Vector();
    private Pagamento pagamento = null;

    public boolean finalizada() {
	    return finalizada; 
    }

    public void finalizar() {
	    finalizada = true;
    }

    public void criarLinhaDetalhe(Especifica��oDeProduto especifica��o,
	                              int quantidade) {
        linhasDetalhe.add(new LinhaDetalheVenda(especifica��o,
		                                        quantidade));
    }

    public void fazerPagamento(Dinheiro valorFornecido) {
        pagamento = new Pagamento(valorFornecido);
    }

    public Dinheiro total() {
        Dinheiro total = new Dinheiro(0);

        Iterator it = linhasDetalhe.iterator();
        while (it.hasNext()) {
            LinhaDetalheVenda det = (LinhaDetalheVenda) it.next();
            total = total.somar(det.subtotal());
        }

        return total;
    }

    public Dinheiro troco() {
        return pagamento.getValor().subtrair(total());
    }
}