package tpv;

public class Especifica��oDeProduto {

    private String          descri��o;
    private C�digoDeProduto c�digo;
    private Dinheiro        pre�o;

    public Especifica��oDeProduto(String          descri��o,
                                  C�digoDeProduto c�digo,
                                  Dinheiro        pre�o) {
        this.descri��o = descri��o;
        this.c�digo = c�digo;
        this.pre�o = pre�o;
    }

    public String getDescri��o()       { return descri��o; }
    public C�digoDeProduto getC�digo() { return c�digo; }
    public Dinheiro getPre�o()         { return pre�o; }
}