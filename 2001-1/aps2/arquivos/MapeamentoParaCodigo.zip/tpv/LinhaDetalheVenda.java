package tpv;

public class LinhaDetalheVenda {

    private final int quantidade;

    private final Especifica��oDeProduto especifica��o;

    public LinhaDetalheVenda(Especifica��oDeProduto especifica��o, 
	                         int quantidade) {
        this.especifica��o = especifica��o;
        this.quantidade = quantidade;
    }

    public Especifica��oDeProduto getEspecifica��o() { 
	    return especifica��o; 
	}

    public int getQuantidade() {
        return quantidade;
    }

    public Dinheiro subtotal() {
        return new Dinheiro(especifica��o.getPre�o()
		                                 .getValor() * quantidade);
    }
}