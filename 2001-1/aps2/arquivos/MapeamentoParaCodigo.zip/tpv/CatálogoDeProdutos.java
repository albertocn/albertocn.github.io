package tpv;

import java.util.Map;
import java.util.HashMap;

public class Cat�logoDeProdutos {

    private Map especifica��esDeProdutos;

    public Cat�logoDeProdutos() {
        this.especifica��esDeProdutos = createEspecifica��es();
    }

    public Cat�logoDeProdutos(Map especifica��es) {
        this.especifica��esDeProdutos = especifica��es;
    }

    public Especifica��oDeProduto especifica��o(C�digoDeProduto c�digo) {
        return (Especifica��oDeProduto) especifica��esDeProdutos.get(c�digo);
    }

    protected Map createEspecifica��es() {
        Map especifica��es = new HashMap();

        Especifica��oDeProduto p1, p2, p3;

        p1 = new Especifica��oDeProduto("Livro A",
                                        new C�digoDeProduto("12345-X"),
                                        new Dinheiro(100.0));

        p2 = new Especifica��oDeProduto("Livro B",
                                        new C�digoDeProduto("23456-X"),
                                        new Dinheiro(200.0));

        p3 = new Especifica��oDeProduto("Livro C",
                                        new C�digoDeProduto("34567-X"),
                                        new Dinheiro(300.0));

        especifica��es.put(p1.getC�digo(), p1);
        especifica��es.put(p2.getC�digo(), p2);
        especifica��es.put(p3.getC�digo(), p3);

        return especifica��es;
    }
}