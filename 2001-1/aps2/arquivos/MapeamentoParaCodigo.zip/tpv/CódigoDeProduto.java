package tpv;

public class C�digoDeProduto {

    private String valor;

    public C�digoDeProduto(String valor) {
        if (valor == null) 
		    throw new IllegalArgumentException("valor == null");

        this.valor = valor;
    }

    public String getValor() { return valor; }
}