package tpv;

public class Dinheiro {

    private final double valor;

    public Dinheiro(double valor) {
        this.valor = valor;
    }

    public double getValor() {
        return valor;
    }

    public Dinheiro somar(Dinheiro outro) {
        return new Dinheiro(valor + outro.valor);
    }

    public Dinheiro subtrair(Dinheiro outro) {
        return new Dinheiro(valor - outro.valor);
    }
}