package tpv;

public class Pagamento {

    private final Dinheiro valor;

    public Pagamento(Dinheiro valor) {
        this.valor = valor;
    }

    public Dinheiro getValor() {
	    return valor; 
	}
}