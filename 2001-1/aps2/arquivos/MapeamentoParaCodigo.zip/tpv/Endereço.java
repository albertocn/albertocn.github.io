package tpv;

public class Endere�o {

    private String logradouro;
    private String bairro;
    private String complemento;
    private String cidade;
    private String estado;
    private String cep;

    public Endere�o(String logradouro,  String bairro,
                    String complemento, String cidade,
                    String estado,      String cep) {
        setLogradouro(logradouro);
        setBairro(bairro);
        setComplemento(complemento);
        setCidade(cidade);
        setEstado(estado);
        setCep(cep);
    }

    public String getLogradouro()  { return logradouro; }
    public String getBairro()      { return bairro; }
    public String getComplemento() { return complemento; }
    public String getCidade()      { return cidade; }
    public String getEstado()      { return estado; }
    public String getCep()         { return cep; }


    public void setLogradouro(String logradouro) {
        this.logradouro = logradouro;
    }

    public void setBairro(String bairro) {
        this.bairro = bairro;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setCep(String cep) {
        this.cep = cep;
    }
}