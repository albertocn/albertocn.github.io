package test.plp.parsers;

import java.io.StringReader;

import org.junit.Test;

import plp.ProgramaPLP;
import plp.expressions2.parser.Exp2Parser;

public class Expr2ParserTest extends BaseParserTest {
	
	@Test
	public void testSoma() {
		String program = "let var x = 10, var y = 5 in let var z = x + y in x + y + z";
		testarProgramaOk(program, "30");
	}

	@Test
	public void testVarDeclaration() {
		testarProgramaOk("let var x = 10 in x", "10");
	}
	
	@Test
	public void testExpressao() {
		testarProgramaOk("10 + 5 - 3", "12");
	}
	
//	@Test
//	public void testVarDeclarationErro() {
//		testarProgramaOk("let var x = 10, var y = x + 5 in " +
//				             "let var z = x + y in " + 
//                                "x + y + z"
//				         , "10");
//	}

	public ProgramaPLP parse(String codigoFonte) throws Exception {
		return new Exp2Parser(new StringReader(codigoFonte)).Input();
	}	
}
