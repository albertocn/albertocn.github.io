package test.plp.parsers;

import java.io.StringReader;

import org.junit.Test;

import plp.ProgramaPLP;
import plp.functional3.parser.ParseException;
import plp.functional3.parser.Func3Parser;

public class Func3ParserTest extends BaseParserTest {
	
	@Test
	public void testValorLista() {		
		testarProgramaOk("[1, 2, 3]", "[1, 2, 3]");
	}
	
	@Test
	public void testHeadLista() {		
		testarProgramaOk("head([1, 2, 3])", "1");
	}
	
	@Test
	public void testTailLista() {		
		testarProgramaOk("tail([1, 2, 3])", "[2, 3]");
	}
	
	@Test
	public void testConsLista() {
		testarProgramaOk("1 : []", "[1]");
		testarProgramaOk("1 : [2, 3]", "[1, 2, 3]");
		testarProgramaOk("1 : 2 : 3 : []", "[1, 2, 3]");
	}
	
	@Test
	public void testConcatLista() {		
		testarProgramaOk("[] ^^ []",         "[]");
		testarProgramaOk("[1, 2, 3] ^^ [4]", "[1, 2, 3, 4]");
		testarProgramaOk("[1, 2, 3] ^^ []",  "[1, 2, 3]");		
		testarProgramaOk("[] ^^ [1, 2, 3]",  "[1, 2, 3]");
	}
	
	@Test
	public void testGeradorLista1() {
		testarProgramaOk("[x*2 for x in 1..3]", "[2, 4, 6]");
	}
	
	@Test
	public void testGeradorLista2() {
		testarProgramaOk("[x*y for x in 1..3, for y in 10..12]", 
				         "[10, 11, 12, 20, 22, 24, 30, 33, 36]");
	}
	
	@Test
	public void testGeradorListaIf() {
		testarProgramaOk("[x*2 for x in 1..10 if x < 5]", "[2, 4, 6, 8]");
	}

	public ProgramaPLP parse(String codigoFonte) throws ParseException {
		return new Func3Parser(new StringReader(codigoFonte)).Input();
	}	
}
