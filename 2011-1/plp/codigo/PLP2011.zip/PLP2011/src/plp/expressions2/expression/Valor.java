package plp.expressions2.expression;

/**
 * <code>Valor</code> agrupa valores concretos e abstratos
*/

public interface Valor extends Expressao {

 

}