package plp.expressions2.memory;

import plp.expressions1.util.Tipo;

public interface AmbienteCompilacao extends Ambiente<Tipo> {

}
