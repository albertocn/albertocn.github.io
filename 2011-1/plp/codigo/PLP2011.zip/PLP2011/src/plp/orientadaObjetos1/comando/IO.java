package plp.orientadaObjetos1.comando;
/**
 * Representa um comando de entrada e sa�da.
 */
public interface  IO extends  Comando{

}
