package exemplos.ex06;

public class ClasseBase {

	static int i = 1;

	public ClasseBase() {
		System.out.println("*Executando o construtor de ClasseBase");
		i = 2;
	}

}
