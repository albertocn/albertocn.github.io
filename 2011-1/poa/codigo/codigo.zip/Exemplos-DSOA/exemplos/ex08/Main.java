package exemplos.ex08;

public class Main {
	
	static int x = 0;
	
	public Main() { System.out.println("Main");}
	
   public static void main(String[] args) {
	   
	   x = 10;
	  
	   a();
   }
   
   private static void a() {
	   new Main();
   }
}
