package exemplos.ex04;

public class Pessoa {
	
	{
		System.out.println("Inicializa��o est�tica");
	}
	
	private String nome = null;
	private String cpf = null;
	private String email = null;
	
	public Pessoa(String n, String cpf, String e) {
		System.out.println("In�cio do construtor");
		this.nome = n;
		this.cpf = cpf;
		this.email = e;
		System.out.println("Fim do construtor");		
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}
