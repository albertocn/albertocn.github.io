package exemplos.ex05;

public class MinhaExcecao extends Exception {

}
