package exemplos.ex05;

import java.io.*;


public class Main {

	public static void main(String[] args) throws Throwable {
		for (int i = 0; i < 5; i++) {
			try {
				System.out.println("i == " + i);
				if (i == 0)
					throw new MinhaExcecao();
				if (i == 1)
					throw new IOException();
				if (i == 2)
					throw new IllegalArgumentException();
				if (i == 3)
					throw new Exception();
				if (i == 4)
					throw new Throwable();
			} catch (MinhaExcecao e) {
				log(e);
			} catch (IOException e) {
				log(e);
			} catch (IllegalArgumentException e) {
				log(e);
			} catch (Exception e) {
				log(e);
			} catch (Throwable e) {
				log(e);
			}
		}
	}

	private static void log(Throwable tipo) {
		System.out.println("Tratador de exce��o de "
				+ tipo.getClass().getName());
	}
}