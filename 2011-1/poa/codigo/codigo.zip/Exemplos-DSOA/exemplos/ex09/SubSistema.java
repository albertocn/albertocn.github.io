package exemplos.ex09;

public class SubSistema {
	
	private String status = null;
	
	public SubSistema() {
		System.out.println("Executando o construtor de SubSistema");
		this.status = "Em Execu��o";
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String s) {
		this.status = s;
	}
}