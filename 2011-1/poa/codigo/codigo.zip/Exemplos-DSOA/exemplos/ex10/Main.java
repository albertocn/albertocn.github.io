package exemplos.ex10;

public class Main {
	
	private void executar() {
		System.out.println("Inic�o testar()");		
		executarAlgo();
		executarAlgoMais();
		System.out.println("Fim testar()");
	}
	
	private void executarAlgo() {
		System.out.println(gerarString(1000, 'A'));		
	}
	
	private void executarAlgoMais() {
		System.out.println(gerarString(3000, 'b'));		
	}
	
	private String gerarString(int n, char c) {
		String s = "";
		for (int i = 0; i < n; i++) {
			s += c;
		}
		return s;		
	}
	
	public static void main(String[] args) {
		
		Main m = new Main();
		
		m.executarAlgo();
		m.executarAlgoMais();
		
		m.executar();
	}

}
