package exemplos.ex02;

/** Ret�ngulo puro */
public class Retangulo {
	
	private int x,y,base,altura;
	
	public Retangulo(int x, int y, int base, int altura) {
		this.x = x;
		this.y = y;
		this.base = base;
		this.altura = altura;
	}	
	public int getX() { return x; }
	public int getY() { return y; }
	public int getBase() { return base; }
	public int getAltura() { return altura; }
	
	public void setX(int x) { this.x = x; }	
	public void setY(int y) { this.y = y; }
	public void setBase(int base) { this.base = base; }
	public void setAltura(int altura) { this.altura = altura; }
	
	public void mover(int offsetX, int offsetY) {
		this.x += offsetX;
		this.y += offsetY;
	}
	
	public double area() {
		System.out.println("Calculando a area");
		return base * altura;
	}

	public static void main(String[] args) {
		Retangulo q = new Retangulo(0,0,100,200);
		q.mover(10, 10);
		q.setX(5);
		q.setY(15);		
		q.setBase(200);
		System.out.println("Area:" + q.area());
		System.out.println("Area:" + q.area());
		q.setAltura(300);
		System.out.println("Area:" + q.area());		
		System.out.println("Area:" + q.area());		
	}	
}
