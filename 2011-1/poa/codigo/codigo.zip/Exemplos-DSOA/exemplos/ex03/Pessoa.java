package exemplos.ex03;

public class Pessoa {
	
	private String nome = null;
	private String cpf = null;
	private String email = null;
	
	public Pessoa(String n, String cpf, String e) {
		this.nome = n;
		this.cpf = cpf;
		this.email = e;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
}