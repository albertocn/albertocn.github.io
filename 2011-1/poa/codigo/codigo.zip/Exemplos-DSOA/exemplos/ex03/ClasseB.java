package exemplos.ex03;

public class ClasseB {

	private int y;

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

}
