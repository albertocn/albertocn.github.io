package exemplos.ex03;

public class ClasseA {

	private long x;

	public long getX() {
		return x;
	}

	public void setX(long x) {
		this.x = x;
	}
}