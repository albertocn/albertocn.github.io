# -*- coding: utf-8 -*-
dados = raw_input()
d = dados.split()
A = float(d[0])
B = float(d[1])
C = float(d[2])

triangulo = A * C / 2
circulo = 3.14159 * C * C
trapezio = ((A + B) * C) / 2
quadrado = B**2
retangulo = A * B

print "TRIANGULO:", '{0:.3f}'.format(triangulo)
print "CIRCULO:", '{0:.3f}'.format(circulo)
print "TRAPEZIO:", '{0:.3f}'.format(trapezio)
print "QUADRADO:", '{0:.3f}'.format(quadrado)

# ERROS REPORTADOS
# Falta de conversao para ponto flutuante apos leitura de String (corrigido na linha 4)
# Impressao de valor com espacos a mais ou a menos nas linhas (corrigido nas linhas 14, 15, 16 e 17)
# Impressao de ponto flutuante sem formatacao (corrigido na linha 14)
# Impressao de ponto flutuante com numero de casas decimais errado (corrigido na linha 15)