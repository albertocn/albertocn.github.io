--Read
do
  local a, i
  a,i ={}, 1
  for i = 1, 3  do
    print("Digite: ")
    a[i] = io.read()
  end
  i= 1
  while i <= 3 do
    print(a[i])
    i = i + 1
  end
end