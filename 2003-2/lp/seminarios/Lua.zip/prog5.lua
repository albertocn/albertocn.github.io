--Controle de fluxo e vari�veis locais

--If

i = 1
if i then
 print("ok")
end
----------ou
i = nil
if i then
 print("oK1")
else
 print("naum ok") 
end
----------ou ainda
i = nil
j = 1
if i then
 print("ok")
elseif j then
  print("ok2")
else
  print("naum ok")
end

--While
i = 0
while i ~=2  do
  print("While Bruno")
  i = i+1
end

--Repeat
i = 0
repeat
 print("Repeat Bruno")
 i = i +1
until i == 2