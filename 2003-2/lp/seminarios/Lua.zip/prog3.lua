--Coer��o
--String para Number
a = "15"
b = 10
print(a+b)