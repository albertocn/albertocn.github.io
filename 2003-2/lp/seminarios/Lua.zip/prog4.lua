--Coer��o
--Number para String
print("Bruno tem ".. 20 .." anos")
