--Tabelas
t = {}
t[1] = 13
t[45] = 56
t["Bruno"] = t[1] + 2
t["Breno"] = t[45]/4
print("t[\"Bruno\"] = "..t["Bruno"])
print("t[\"Breno\"] = "..t.Breno)
u = { nome = "Linguagem Lua", [1] = 3.0}
print("u.nome = "..u.nome)
print("u[1] = "..u[1])
v = {23, 45, -7 ; nome="Linguagem Lua", versao=3.0, [4]=80}
print("v[1] = "..v[1])
print("v[2] = "..v[2])
print("v[3] = "..v[3])
print("v.nome = "..v.nome)
print("v.versao = "..v.versao)
print("v[4] = "..v[4])



