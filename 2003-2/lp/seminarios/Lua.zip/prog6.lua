--Funcoes
function soma (a,b)
  return a+b
end
a = soma(20, 17)
print(a)
