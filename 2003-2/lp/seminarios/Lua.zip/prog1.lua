--exemplo 1
--Tipagem dinamica

a = "Hello World"
print(a)
s = [[Bruno tem 20 anos]]
print(s)
a = 13
print(a)