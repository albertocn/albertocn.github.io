% Exemplos de prolog em LP
progenitor(jo, ze).
progenitor(jo, ana).
progenitor(ze, beth).
progenitor(ze, iris).
progenitor(ana, lipe).
progenitor(iris, gal).
progenitor(lipe, gil).
progenitor(lipe, tel).
feminino(jo).
feminino(ana).
feminino(beth).
feminino(iris).
feminino(gal).
feminino(gil).
masculino(ze).
masculino(lipe).
masculino(tel).
filho(Filho, Pai) :- progenitor(Pai,Filho).
mae(Mae, Filho) :- progenitor(Mae, Filho), feminino(Mae).
avo(Avo, Neto) :- mae(Avo,Pai), progenitor(Pai, Neto).
irma(Irma, X) :- progenitor(Pai, Irma), progenitor(Pai, X), feminino(Irma), Irma \== X.
primo(Primo1, Primo2) :- progenitor(Pai1, Primo1), progenitor(Pai2, Primo2),
                         progenitor(Pai, Pai1),    progenitor(Pai, Pai2),
                         Primo1 \== Primo2,        Pai1 \== Pai2.