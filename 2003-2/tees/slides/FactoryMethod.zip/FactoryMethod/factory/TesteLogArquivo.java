package factory;

/**
 * Classe que demonstra a utiliza��o da classe LogArquivo
 *
 * @author Alberto Costa Neto
 */
public class TesteLogArquivo {

    public TesteLogArquivo(int id) {
        Log l = new LogArquivo();

        for (int i = 1; i <= 10; i++) {
            l.gravar("id:" + id + " i:" + i);
        }
    }

    public static void main(String args[]) {
        new TesteLogArquivo(1);
        new TesteLogArquivo(2);
    }
}