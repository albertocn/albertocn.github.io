package factory;

/**
 * Interface que deve ser implementada por uma classe que permite
 * gravar mensagens de log
 *
 * @author Alberto Costa Neto
 */
public interface Log {

    /**
     * Grava uma mensagem no log
     *
     * @param msg String contendo a mensagem
     */
    public void gravar(String msg);
}