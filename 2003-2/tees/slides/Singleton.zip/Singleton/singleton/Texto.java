package singleton;

/**
 * Classe que representa um texto
 *
 * @author Alberto Costa Neto
 */
public class Texto {

    // Atributo de inst�ncia com o conte�do do texto
    private String txt = "";

    // Atributo de classe que guarda a inst�ncia �nica
    private static Texto textoUnico = null;

    /**
     * O construtor � protegido para impedir que seja
     * chamado por engano
     */
    protected Texto() {}

    /** Prov� acessa � inst�ncia �nica da classe */
    public static synchronized Texto instance() {
        if (textoUnico == null) {
            // Cria a inst�ncia �nica
            textoUnico = new Texto();
        }
        return textoUnico;
    }

    /** Retorna o conte�do atual do texto */
    public synchronized String getTexto() {
        return txt;
	}

    /** Altera o conte�do atual do texto */
    public synchronized void setTexto(String novoTexto) {
        txt = novoTexto;
    }

    /** Retorna uma String com o texto atual */
    public String toString() {
	    return txt;
	}


    // M�todo principal que demonstra a classe Texto
    public static void main(String[] argv) {

       // Obt�m uma inst�ncia �nica do objeto texto
       Texto txt1 = Texto.instance();
       Texto txt2 = Texto.instance();

       // O segundo "set" vai sobrepor o primeiro
       txt1.setTexto("Alberto");
       txt2.setTexto("Costa");

       // Deveriam imprimir a mesma coisa, j� que txt1 e
	   // txt2 referenciam o mesmo objeto
       System.out.println("Objeto txt1: " + txt1);
       System.out.println("Objeto txt2: " + txt2);
   }
}