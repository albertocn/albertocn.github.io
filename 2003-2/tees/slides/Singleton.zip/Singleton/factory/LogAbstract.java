package factory;

import java.util.Date;

import java.io.PrintWriter;

/**
 * Classe que permite gravar mensagens de log
 *
 * @author Alberto Costa Neto
 */
public abstract class LogAbstract implements Log {

    /** PrintWriter para o qual as mensagens ser�o escritas */
    private PrintWriter log = null;


    /**
     * Grava uma mensagem de log na tela
     *
     * @param msg String contendo a mensagem
     */
    public final synchronized void gravar(String msg) {
        char[] mf = format(msg).toCharArray();

        for (int i = 0; i < mf.length; i++) {
            getWriter().print(mf[i]);
            getWriter().flush();
        }

        getWriter().println();
        getWriter().flush();
    }


    /**
     * Cria um PrintWriter que pode ser usado para gravar mensagens. � um
     * Factory Method
     */
    protected abstract PrintWriter criarPrintWriter();


    /**
     * Retorna um PrintWriter que permite grava��o direta no arquivo de log
     */
    private synchronized PrintWriter getWriter() {
        if (log == null) {
            log = criarPrintWriter();
            gravar("Log iniciado" );
        }

        return log;
    }


    // Adiciona a data � mensagem
    private String format(String msg) {
        return (new Date()).toString() + " - " + msg;
    }
}