package decorator;

/**
 * Interface que define a funcionalidade de uma lista de objetos
 *
 * @author Alberto Costa Neto
 */
public interface Lista {

    /**
     * Adiciona o objeto passado na posi��o da lista
     *
     * @param pos Posi��o onde o objeto ser� colocado
     * @param obj Objeto que ser� adicionado � lista
     */
    void inserir(int pos, Object obj);


    /**
     * Retorna o objeto que ocupa a posi��o especificada na lista.
     * Caso n�o haja nenhum objeto na posi��o, retorna null
     *
     * @param pos Posi��o da lista onde se encontra o objeto
     */
    Object pegar(int pos);


    /**
     * Remove e retorna o objeto que ocupa a posi��o especificada na
     * lista. Caso n�o haja nenhum objeto na posi��o, retorna null
     *
     * @param pos Posi��o da lista onde se encontra o objeto
     */
    Object remover(int pos);
}