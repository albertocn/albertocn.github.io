package decorator;

public class TesteLista {

    public Lista lista;

    public TesteLista() {
        lista = createLista();
    }


    public void testar() {
        lista.inserir(1, "A");
        lista.inserir(2, "B");
        lista.pegar(2);
        lista.remover(1);
        lista.remover(2);
        lista.pegar(1);

        lista.inserir(1, "a");
        lista.inserir(2, "b");

        // Adiciona um Decorador dinamicamente
        lista = new ListaNaoModificavel(lista);
        lista.pegar(1);

        try {
            // Gerar� uma exce��o
            lista.remover(1);
            lista.remover(2);
        } catch (RuntimeException re) {}

        lista.pegar(2);
    }



    /**
     * Factory Method que cria uma lista com eventos e sincronizada
     */
    protected Lista createLista() {
        return new ListaComEventos(new ListaSincronizada(new ListaArray()),
                                   new ImprimirEventos());
    }


    public static void main(String args[]) {
        TesteLista tl = new TesteLista();

        tl.testar();
    }
}


/**
 * Imprime a posi��o e o objeto que participou de cada opera��o
 */
class ImprimirEventos implements ReceptorEventosLista {

    public void inseriu(int pos, Object obj) {
        System.out.println("inseriu em (" + pos + ") " + obj);
    }

    public void pegou(int pos, Object obj) {
        System.out.println("pegou em (" + pos + ") " + obj);
    }

    public void removeu(int pos, Object obj) {
        System.out.println("removeu de (" + pos + ") " + obj);
    }
}