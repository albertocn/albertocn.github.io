package decorator;

/**
 * Classe decoradora que adiciona sincroniza��o aos m�todos da Lista
 * passada
 *
 * @author Alberto Costa Neto
 */
public class ListaSincronizada implements Lista {

    private Lista lista;

    public ListaSincronizada(Lista lista) {
        this.lista = lista;
    }

    public void inserir(int pos, Object obj) {
        synchronized (lista) {
            lista.inserir(pos, obj);
        }
    }

    public Object pegar(int pos) {
        synchronized (lista) {
            return lista.pegar(pos);
        }
    }

    public Object remover(int pos) {
        synchronized (lista) {
            return lista.remover(pos);
        }
    }
}