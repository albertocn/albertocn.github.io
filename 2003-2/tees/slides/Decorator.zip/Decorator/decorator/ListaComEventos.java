package decorator;

/**
 * Classe decoradora que adiciona sincroniza��o aos m�todos da Lista
 * passada
 *
 * @author Alberto Costa Neto
 */
public class ListaComEventos implements Lista {

    private Lista lista;

    // Objeto que ser� notificado quando opera��es forem
    // executadas sobre a lista
    private ReceptorEventosLista receptor;

    public ListaComEventos(Lista lista, ReceptorEventosLista receptor) {
        this.lista = lista;
        this.receptor = receptor;
    }

    public void inserir(int pos, Object obj) {
        lista.inserir(pos, obj);
        receptor.inseriu(pos, obj);
    }

    public Object pegar(int pos) {
        Object obj = lista.pegar(pos);
        receptor.pegou(pos, obj);
        return obj;
    }

    public Object remover(int pos) {
        Object obj = lista.remover(pos);
        receptor.removeu(pos, obj);
        return obj;
    }
}