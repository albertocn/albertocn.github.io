package observer;

import java.awt.event.*;
import javax.swing.*;

public class RelogioFrame extends JFrame implements RelogioListener {

    private Relogio relogio;

    private JTextField tfDataHora = new JTextField(14);
    private JCheckBox  cbxRegistrado = new JCheckBox("Registrado", true);


    private RelogioFrame() {}

    public RelogioFrame(Relogio relogio) {
        this.relogio = relogio;

        adicionarComponentes();
	}


    public void atualizar(RelogioEvent re) {
        mudarData(formatarData(re));
    }


    private void mudarData(String novaData) {
        tfDataHora.setText(novaData);
    }


    private String formatarData(RelogioEvent re) {
        StringBuffer sb = new StringBuffer();

        sb.append( re.getDia() );
		sb.append( "/" );
		sb.append( re.getMes() );
		sb.append( "/" );
        sb.append( re.getAno() );
		sb.append( " " );
		sb.append( re.getHora() );
		sb.append( ":" );
        sb.append( re.getMinuto() );
		sb.append( ":" );
		sb.append( re.getSegundo() );

        return sb.toString();
    }


    private void setRegistrado(boolean registrado) {
        if (registrado) {
            relogio.addRelogioListener(this);
        } else {
            relogio.removeRelogioListener(this);
        }
    }

    private void adicionarComponentes() {
        JPanel p = new JPanel();
        p.add(tfDataHora);
        p.add(cbxRegistrado);

        getContentPane().add(p);

        tfDataHora.setEnabled(false);

        cbxRegistrado.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                setRegistrado(cbxRegistrado.isSelected());
            }
        });
    }
}