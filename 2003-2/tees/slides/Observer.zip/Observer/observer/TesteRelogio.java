package observer;

public class TesteRelogio {

    public static void main(String args[]) {

        Relogio relogio = new Relogio(100);

        RelogioFrame rf = new RelogioFrame(relogio);
        rf.pack();
        rf.show();

        relogio.addRelogioListener(new RelogioSaidaPadrao());
        relogio.addRelogioListener(rf);
    }
}
