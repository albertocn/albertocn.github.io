package helloworld;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Date;

import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

public class HelloWorldBean implements SessionBean {

    private final DateFormat df;

    public HelloWorldBean() {
        df = new SimpleDateFormat("HH:mm:ss.SSS");
    }

    // -------------------- Remote -----------------
    public String hello() {
        return "[" + df.format(new Date()) + "] Hello";
    }

    // -------------------- Home -----------------
    public void ejbCreate() {};

    // --------------- Ciclo de Vida -------------
    public void ejbActivate() {};
    public void ejbPassivate() {};
    public void ejbRemove() {};
    public void setSessionContext(SessionContext ctx) {};
}