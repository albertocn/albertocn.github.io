package helloworld.app;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.rmi.PortableRemoteObject;

import helloworld.HelloWorld;
import helloworld.HelloWorldHome;

public class Cliente {

    public Cliente() {}

    public String getMsg() {
        try {
            Context initialContext = getInitialContext();

            // Obt�m uma refer�ncia remota para o objeto que implementa
            // a interface Home e faz o cast
            Object objref = initialContext.lookup("HelloWorld");

            HelloWorldHome home = (HelloWorldHome)
                    PortableRemoteObject.narrow(objref,
                                                HelloWorldHome.class);

            // Utiliza o Home para criar obter uma refer�ncia o
            // Session Bean
            HelloWorld remote = home.create();

            // Chama o m�todo remoto do Session Bean
            String msg = remote.hello();

            // Libera o Session Bean
            remote.remove();

            return msg;

        } catch (Exception ex) {
            ex.printStackTrace();
            return "Ocorreu uma exce��o";
        }
    }

    protected Context getInitialContext() throws NamingException {
      // Especifica as propriedades que indicam a classe que
      // implementa o servi�o JNDI e a URL para o proverdor
      // (espec�fico para cada servidor de aplica��o)
      Properties prop = new Properties();

      prop.setProperty(Context.INITIAL_CONTEXT_FACTORY,
                       "org.jnp.interfaces.NamingContextFactory");

      prop.setProperty( Context.URL_PKG_PREFIXES,
                       "org.jboss.naming:org.jnp.interfaces");

      prop.setProperty(Context.PROVIDER_URL,
                       "localhost" );

      return new InitialContext(prop);
    }

    public static void main(String[] args) {
        Cliente c = new Cliente();
        System.out.println(c.getMsg());
    }
}