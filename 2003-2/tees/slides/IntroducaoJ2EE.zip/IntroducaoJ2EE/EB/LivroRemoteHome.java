package livraria;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.math.*;

public interface LivroRemoteHome extends javax.ejb.EJBHome {
  public LivroRemote create(String id, String titulo, String autor, double preco, double desconto) throws CreateException, RemoteException;
  public Collection findAll() throws FinderException, RemoteException;
  public Collection findByTitulo(String titulo) throws FinderException, RemoteException;
  public LivroRemote findByPrimaryKey(LivroPK pk) throws FinderException, RemoteException;
}