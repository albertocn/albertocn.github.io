package livraria;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.math.*;

public interface LivroRemote extends javax.ejb.EJBObject {
  public void setId(String id) throws RemoteException;
  public String getId() throws RemoteException;
  public void setTitulo(String titulo) throws RemoteException;
  public String getTitulo() throws RemoteException;
  public void setAutor(String autor) throws RemoteException;
  public String getAutor() throws RemoteException;
  public void setPreco(double preco) throws RemoteException;
  public double getPreco() throws RemoteException;
  public void setDesconto(double desconto) throws RemoteException;
  public double getDesconto() throws RemoteException;
  public double getPrecoComDesconto() throws RemoteException;
  public double getValorDoDesconto() throws RemoteException;
}