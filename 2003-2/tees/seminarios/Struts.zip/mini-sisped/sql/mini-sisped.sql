CREATE DATABASE mini_sisped;

USE mini_sisped;

CREATE TABLE Usuario (
       cd_Usuario           int UNSIGNED AUTO_INCREMENT,
       cd_Matricula         char(20) NOT NULL UNIQUE,
       de_Senha             varchar(70) NOT NULL,
       de_Tipo              int NOT NULL,
       de_Nome              char(30) NOT NULL,
       cd_RG                char(15) NOT NULL,
       de_SSP               char(02) NOT NULL,
       PRIMARY KEY (cd_Usuario),
       INDEX(cd_Usuario)
) TYPE=InnoDB;



CREATE TABLE Paciente (
       cd_Paciente          int UNSIGNED AUTO_INCREMENT,
       cd_SUS               char(7) NOT NULL DEFAULT '' UNIQUE,
       de_Nome              char(40) NOT NULL DEFAULT '',
       de_TipoDiabetes      int NOT NULL DEFAULT 1,
       dt_Nascimento        datetime NOT NULL,
       dt_AnoInicioDiabetes char(4) NOT NULL DEFAULT '',
       de_Sexo              char(1) NOT NULL DEFAULT '',
       nu_RG                char(8) NOT NULL DEFAULT '',
       de_SSP               char(2) NOT NULL DEFAULT '',
       de_Profissao         char(60) NOT NULL DEFAULT '',
       de_Endereco          char(60) NOT NULL DEFAULT '',
       de_Bairro            char(20) NOT NULL DEFAULT '',
       nu_Fone              char(8) NOT NULL DEFAULT '',
       de_Cidade            char(25) NOT NULL DEFAULT '',
       de_Estado            char(2) NOT NULL DEFAULT '',
       nu_CEP               char(9) NOT NULL DEFAULT '',
       de_Pais              char(20) NOT NULL DEFAULT '',
       dt_Inclusao          datetime NOT NULL,
       PRIMARY KEY (cd_Paciente),
       INDEX (cd_Paciente)
) TYPE=InnoDB;


INSERT INTO USUARIO(cd_matricula, de_senha, de_tipo, de_nome, cd_rg, de_ssp)
VALUES('adm', 'YWRt', 1, 'Alien', '30895812', 'SE');