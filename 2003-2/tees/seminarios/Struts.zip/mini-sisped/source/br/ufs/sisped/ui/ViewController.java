package br.ufs.sisped.ui;


import java.lang.String;

import java.util.Collection;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Arrays;
import javax.naming.NamingException;

import br.ufs.sisped.facade.query.QueryProcessor;
import br.ufs.sisped.facade.query.QueryProcessorHome;
import br.ufs.sisped.facade.command.CommandProcessor;
import br.ufs.sisped.facade.command.CommandProcessorHome;
import br.ufs.sisped.facade.Argument;
import br.ufs.sisped.facade.Response;

import br.ufs.sisped.util.sql.ResultProcessor;


/** Created on 14 de Fevereiro de 2003, 12:26
 * Classe responsavel pela conversacao com o Session Facade CommandProcessor
 * @author Marcio Carvalho
 */
public class ViewController {

  private static String JNDI_COMMAND_NAME;
  private static String JNDI_QUERY_NAME;
  private static String APP_NAME;

  private static Properties prop;

  private static javax.naming.Context defaultContext = null;

  //Inicializador de Classe
  static {
    init();
  }


  private static void init() {
    try {
      prop = new Properties();
      prop.load( ViewController.class.getResourceAsStream( "ui.properties" ) );
      defaultContext = new javax.naming.InitialContext( prop );

    } catch( Exception e ) {
      e.printStackTrace();
      prop.setProperty( "jndi-command-name", "" );
      prop.setProperty( "jndi-query-name", "" );
      prop.setProperty( "app-name", "" );

    } finally {
      JNDI_COMMAND_NAME = prop.getProperty( "jndi-command-name" );
      JNDI_QUERY_NAME = prop.getProperty( "jndi-query-name" );
      APP_NAME = prop.getProperty( "app-name" );
    }
  }


  /** Creates a new instance of ViewController */
  protected ViewController() {}


  /** Invoca o Session Facade CommandProcessor e solicita a execucao da
   * transacao encapsulada em fields.
   * @param fields Map contendo codigo da transacao eparametros
   * @return Collection
   * @throws Exception Erro de Execucao da transacao
   */
  public static Response execute( Argument arg ) throws java.lang.Throwable {
    String transId = arg.getTransactionId();

    try {
      System.out.println( "[" + APP_NAME + "] Localizando Session Facade..." );

      if (defaultContext == null) init();
      CommandProcessorHome procHome = ( CommandProcessorHome )defaultContext.lookup( JNDI_COMMAND_NAME );

      System.out.println( "[" + APP_NAME + "] Session Facade localizado..." );

      CommandProcessor commProc = procHome.create();

      System.out.println( "[" + APP_NAME + "] Preparando para executar transacao " + transId + " ..." );

      Response ret = commProc.execute( arg );

      if( ret.threwException() ) {
        throw ret.getException();
      }

      System.out.println( "[" + APP_NAME + "] Transacao " + transId + " executada com sucesso...\n" );

      return ret;
    } catch( Throwable ex ) {
      System.out.println( "[" + APP_NAME + "] Erro inesperado ao executar transacao " + transId +
                          ": " + ex.getMessage() + "\n" );
      throw ex;
    }

  }


  /** Executa um comando SQL baseado no codigo do comando informado
   * @param commId Codigo do comando SQL.
   * @param params Array de parametros para o comando
   * @return ResultSet
   * @throws Exception Erro de SQL
   */
  public static java.sql.ResultSet execSQL( java.lang.String commId,
                                            java.lang.Object[] params ) throws Exception {
    try {
      System.out.println( "[" + APP_NAME + "] Localizando Query Session Facade..." );

      if (defaultContext == null) init();
      QueryProcessorHome qprocHome = ( QueryProcessorHome )defaultContext.lookup( JNDI_QUERY_NAME );

      System.out.println( "[" + APP_NAME + "] Query Session Facade localizado..." );

      QueryProcessor qProc = qprocHome.create();

      System.out.println( "[" + APP_NAME + "] Preparando para executar query " +
                          commId + " ..." );

      Collection parametros;
      if( params == null ) {
        parametros = null;
      } else {
        parametros = Arrays.asList( params );
      }

      System.out.println( "[" + APP_NAME + "] Query " + commId + " preparada..." );

      java.sql.ResultSet ret = qProc.execSQL( commId, parametros );

      System.out.println( "[" + APP_NAME + "] Query " + commId + " executada com sucesso...\n" );

      return ret;
    } catch( Exception ex ) {
      System.out.println( "[" + APP_NAME + "] Erro inesperado ao executar Query " + commId +
                          ": " + ex.getMessage() + "\n" );
      throw ex;
    }

  }


  /** Executa um comando SQL baseado no codigo do comando informado
   * @param commId Codigo do comando SQL.
   * @param params Array de parametros ou null se nao necessitar de params.
   * @param processor Objeto responsavel por processar o ResultSet informado.
   * @return Array de Objetos.
   * @throws Exception Erro de SQL.
   */
  public static java.lang.Object[] execSQL( java.lang.String commId,
                                            java.lang.Object[] params,
                                            ResultProcessor processor ) throws  Exception {
    try {
      System.out.println( "[" + APP_NAME + "] Localizando Query Session Facade..." );

      if (defaultContext == null) init();
      QueryProcessorHome qprocHome = ( QueryProcessorHome )defaultContext.lookup( JNDI_QUERY_NAME );

      System.out.println( "[" + APP_NAME + "] Query Session Facade localizado..." );

      QueryProcessor qProc = qprocHome.create();

      System.out.println( "[" + APP_NAME + "] Preparando para executar query " + commId + "..." );

      Collection parametros;
      if( params == null ) {
        parametros = null;
      } else {
        parametros = Arrays.asList( params );
      }

      System.out.println( "[" + APP_NAME + "] Query " + commId + " preparada..." );

      Object[] ret = ( Object[] )qProc.execSQL( commId, parametros, processor ).toArray()[0];

      System.out.println( "[" + APP_NAME + "] Query " + commId + " executada com sucesso...\n" );

      return ret;
    } catch( Exception ex ) {
      System.out.println( "[" + APP_NAME + "] Erro inesperado ao executar query " + commId +
                          ": " + ex.getMessage() + "\n" );
      throw ex;
    }
  }


  /** Executa um comando SQL baseado no codigo do comando informado
   * @param commId Codigo do comando SQL.
   * @param params Array de parametros para o comando
   * @return ResultSet
   * @throws Exception Erro de SQL
   */
  public static java.sql.ResultSet execSQL( java.lang.String commId,
                                            java.lang.String complemento,
                                            java.lang.Object[] params ) throws Exception {
    try {
      System.out.println( "[" + APP_NAME + "] Localizando Query Session Facade..." );

      if (defaultContext == null) init();
      QueryProcessorHome qprocHome = ( QueryProcessorHome )defaultContext.lookup( JNDI_QUERY_NAME );

      System.out.println( "[" + APP_NAME + "] Query Session Facade localizado..." );

      QueryProcessor qProc = qprocHome.create();

      System.out.println( "[" + APP_NAME + "] Preparando para executar query " + commId + " ..." );

      Collection parametros;
      if( params == null ) {
        parametros = null;
      } else {
        parametros = Arrays.asList( params );
      }

      System.out.println( "[" + APP_NAME + "] Query " + commId + " preparada..." );

      java.sql.ResultSet ret = qProc.execSQL( commId, complemento, parametros );

      System.out.println( "[" + APP_NAME + "] Query " + commId + " executada com sucesso...\n" );

      return ret;
    } catch( Exception ex ) {
      System.out.println( "[" + APP_NAME + "] Erro inesperado ao executar Query " + commId +
                          ": " + ex.getMessage() + "\n" );
      throw ex;
    }

  }


  /** Executa um comando SQL baseado no codigo do comando informado
   * @param commId Codigo do comando SQL.
   * @param params Array de parametros para o comando
   * @return ResultSet
   * @throws Exception Erro de SQL
   */
  public static java.sql.ResultSet execSQLStatement( java.lang.String comando,
                                                     java.lang.Object[] params ) throws Exception {
    try {
      System.out.println( "[" + APP_NAME + "] Localizando Query Session Facade..." );

      if (defaultContext == null) init();
      QueryProcessorHome qprocHome = ( QueryProcessorHome )defaultContext.lookup( JNDI_QUERY_NAME );

      System.out.println( "[" + APP_NAME + "] Query Session Facade localizado..." );

      QueryProcessor qProc = qprocHome.create();

      Collection parametros;
      if( params == null ) {
        parametros = null;
      } else {
        parametros = Arrays.asList( params );
      }

      java.sql.ResultSet ret = qProc.execSQLStatement( comando, parametros );

      System.out.println( "[" + APP_NAME + "] Query executada com sucesso...\n" );

      return ret;
    } catch( Exception ex ) {
      System.out.println( "[" + APP_NAME + "] Erro inesperado ao executar Query " + comando +
                          ": " + ex.getMessage() + "\n" );
      throw ex;
    }

  }


  /**
   *
   * @param sqlId
   * @param params
   * @return
   * @throws java.lang.Exception
   */
  public static String getSQL( java.lang.String sqlId, java.lang.Object[] params ) throws Exception {
    try {
      if( defaultContext == null )
        init();

      QueryProcessorHome qprocHome = ( QueryProcessorHome )defaultContext.lookup( JNDI_QUERY_NAME );

      QueryProcessor qProc = qprocHome.create();

      Collection parametros;
      if( params == null ) {
        parametros = null;
      } else {
        parametros = Arrays.asList( params );
      }

      return qProc.getSQL( sqlId, parametros );

    } catch(Exception e) {
      e.printStackTrace();
      return null;
    }

  }



  /** Metodo que prepara o argumento de um comando a partir
   * da String de identificacao do comando e de um Collection
   * de argumentos.
   * @param id Codigo da Transacao
   * @param params Collection de parametros
   * @return Map preparado para a invocacao
   */
  public static Argument prepareCommand( String id, java.util.Collection params ) {
    return new ViewController.FacadeArgument( id, params );
  }


  /** Metodo que prepara o argumento de um comando a partir
   * da String de identificacao do comando e de um Collection
   * de argumentos.
   * @param id Codigo da Transacao
   * @param params Collection de parametros
   * @return Map preparado para a invocacao
   */
  public static Argument prepareCommand( String id, Object[] params ) {
    return new ViewController.FacadeArgument( id, params );
  }


  public static Argument prepareCommand( String id, Object param ) {
    return prepareCommand( id, new Object[] {param} );
  }


  /** Retorna uma referencia ao objeto Context interno.
   * @return Context
   */
  public static javax.naming.Context getContext() {
    return defaultContext;
  }


  private static class FacadeArgument implements Argument {
    private String transId;
    private Object[] params;

    protected FacadeArgument( String id, Collection params ) {
      if( id == null || params == null ) {
        throw new IllegalArgumentException(
            "Os componentes de um Argumento nao podem ser nulos! " );
      }

      this.transId = id;

      this.params = new Object[params.size()];
      java.util.Iterator it = params.iterator();

      for( int i = 0; it.hasNext(); i++ ) {
        this.params[i] = it.next();
      }
    }


    protected FacadeArgument( String id, Object[] params ) {
      if( id == null || params == null ) {
        throw new IllegalArgumentException( "Os componentes de um Argumento nao podem ser nulos! " );
      }

      this.transId = id;
      this.params = params;
    }


    public Object[] getParams() {
      return this.params;
    }


    public String getTransactionId() {
      return this.transId;
    }

  }
}