package br.ufs.sisped.util;


import java.lang.reflect.Method;
import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.Vector;


/** Classe que implementa metodos utilitarios de instrospec��o e chamada a metodos
 * de forma dinamica.
 * @author Marcio Carvalho
 */

public class Methods {

  /** Creates a new instance of Methods */
  protected Methods() {}


  /** Metodo que localiza o metodo "methodSignature" no objeto source.
   *
   * @param source Objeto que contem o metodo a ser buscado
   * @param methodSignature Assinatura do metodo com os tipos dos parametros (com nomes completos. ex: java.lang.Object[]), mas sem os nomes dos parametros.
   * @return Method
   * @throws Exception Quando nao encontra o metodo
   */
  public static Method findMethod( Object source, String methodSignature ) throws
      Exception {
    StringTokenizer st = new StringTokenizer( methodSignature.trim(), "(), " );
    String methodName = st.nextToken();

    return source.getClass().getMethod( methodName, prepareParams( st ) ); //Java reflection
  }


  public static Method findMethod( String className, String methodSignature ) throws
      Exception {
    StringTokenizer st = new StringTokenizer( methodSignature.trim(), "(), " );
    String methodName = st.nextToken();

    return Class.forName( className ).getMethod( methodName, prepareParams( st ) ); //Java Reflection
  }


  private static Class[] prepareParams( StringTokenizer tokens ) throws
      ClassNotFoundException {
    //Array contendo os tipos dos parametros do metodo
    Class[] params = null;

    if( tokens.countTokens() > 0 ) {
      params = new Class[tokens.countTokens()];

      for( int i = 0; i < params.length; i++ ) {
        String type = tokens.nextToken();

        //Array types
        if( type.endsWith( "[]" ) ) {
          type = "[L" + type + ";";

          //Primitive types
        }
        if( type.equals( "int" ) ) {
          params[i] = int.class;
        } else if( type.equals( "float" ) ) {
          params[i] = float.class;
        } else if( type.equals( "double" ) ) {
          params[i] = double.class;
        } else if( type.equals( "long" ) ) {
          params[i] = long.class;
        } else if( type.equals( "char" ) ) {
          params[i] = char.class;
        } else if( type.equals( "boolean" ) ) {
          params[i] = boolean.class;
        } else if( type.equals( "byte" ) ) {
          params[i] = byte.class;
        } else if( type.equals( "short" ) ) {
          params[i] = short.class;

          //Object types
        } else {
          params[i] = Class.forName( type );
        }
      }
    }

    return params;
  }


      /** Metodo que devolve um Collection de objetos java.lang.reflect.Method para um
   * Set de assinaturas de metodos, com exce��o de exceptions que eh uma String contendo
   * as expressoes que nao podem aparecer no nome do metodo separadas por ";".
   *
   * @param source Objeto contendo os metodos
   * @param signatures Conjunto de assinaturas
   * @param exceptions Assinaturas de metodos que nao devem ser executados
   * @return Collection
   * @throws Exception Quando nao encontra algum metodo
   */
  public static Collection findMethods( Object source, Set signatures,
                                        String exceptions ) throws Exception {
    Vector methods = new Vector();

    int size = 0;

    String[] keys = ( String[] )signatures.toArray();
    for( int i = 0; i < keys.length; i++ ) {
      Method m = Methods.findMethod( source, keys[i] );

      if( !contains( m.getName(), exceptions, ";" ) ) {
        methods.addElement( m );
        size++;
      }
    }

    methods.ensureCapacity( size );

    return methods;
  }


  /** Metodo que faz a verificacao de que strings separadas por "delimiters" e
   * contidas em "subexpr" nao esta presentes em "expr".
   *
   * @param expr Expressao completa
   * @param subexpr Subexpressao a ser buscada na expressao
   * @param delimiters Delimitadores
   * @return boolean
   */
  public static boolean contains( String expr, String subexpr,
                                  String delimiters ) {
    StringTokenizer st = new StringTokenizer( subexpr, delimiters );
    String tokens[] = new String[st.countTokens()];
    boolean retorno = false;

    for( int i = 0; !retorno && i < tokens.length; i++ ) {
      tokens[i] = st.nextToken();

      if( expr.indexOf( tokens[i] ) != -1 ) {
        retorno = true;
      }
    }

    return retorno;
  }


  /** Metodo que executa um conjunto de metodos do objeto "source", descobrindo suas
   * assinaturas e seus parametros em "fields". Novamente exceptions representa um conjunto
   * de strings separadas por ";" que nao podem aparecer no nome dos metodos.
   *
   * @param source Objeto contendo o metodo
   * @param fields Map contendo tuplas (assinatura,parametros[])
   * @param exceptions Quando nao encontra algum metodo
   * @throws Exception Quando nao encontra algum metodo
   */
  public static void execScript( Object source, Map fields, String exceptions ) throws
      Exception {
    Method[] methods = ( Method[] )Methods.findMethods( source, fields.keySet(),
        exceptions ).toArray();

    for( int i = 0; i < methods.length; i++ ) {
      Methods.invoke( methods[i], source, fields.get( buildSignature( methods[i] ) ) );
    }
  }


  /**
   * Metodo utilitario para invocacao de metodos ja localizados
   */
  private static Object invoke( Method m, Object source, Object param ) throws
      Exception {
    Object[] arg = null;

    if( param != null && !( param instanceof Object[] ) ) {
      arg = new Object[] {param};

    }
    return m.invoke( source, arg );
  }


  /**
   * Retorna uma String com a assinatura do metodo
   */
  public static String buildSignature( Method m ) {
    StringBuffer key = new StringBuffer( m.getName() + "(" );
    Class[] types = m.getParameterTypes();

    for( int i = 0; i < types.length; i++ ) {
      String type = types[i].getName();

      if( type.startsWith( "[L" ) && type.endsWith( ";" ) ) {
        type = type.substring( 2, type.length() - 1 );

      }
      key.append( type + "," );

    }

    key.setCharAt( key.length() - 1, ')' );

    return key.toString();
  }


  /** Metodo que localiza e invoca o metodo com a assinatura "signature" e parametro "param"
   * no objeto "source".
   *
   * @param source Objeto que contem o metodo
   * @param signature Assinatura do metodo
   * @param param Parametro do metodo
   * @return Object
   * @throws Exception Quando da um erro na execucao do metodo
   */
  public static Object execMethod( Object source, String signature,
                                   Object param ) throws Exception {
    Object[] arg = null;

    if( param != null ) {
      arg = new Object[] {param};

    }
    return Methods.execMethod( source, signature, arg );
  }


  public static Object execMethod( String className, String signature,
                                   Object param ) throws Exception {
    Object[] arg = null;

    if( param != null ) {
      arg = new Object[] {param};

    }
    return Methods.execMethod( className, signature, arg );
  }


  /** Metodo que localiza e invoca o metodo com a assinatura "signature" e parametros "params"
   * no objeto "source".
   *
   * @param source Objeto contendo o metodo
   * @param signature Assinatura do metodo
   * @param params Parametros do metodo
   * @return Object
   * @throws Exception Quando da um erro na execucao do metodo
   */
  public static Object execMethod( Object source, String signature,
                                   Object[] params ) throws Exception {
    Method method = Methods.findMethod( source, signature );

    return method.invoke( source, params );
  }


  public static Object execMethod( String className, String signature,
                                   Object[] params ) throws Exception {
    Method method = Methods.findMethod( className, signature );

    return method.invoke( null, params );
  }


  /*
   * Metodo de Teste
   */
  public static void main( String args[] ) throws Exception {
    Vector v = new Vector( 2 );
    Runnable test = new Runnable() {
      public void run() {
        System.out.println( "teste" );
      }
    };

    v.addElement( test );

    System.out.println( Methods.execMethod( v, "indexOf(java.lang.Object,int)",
                                            new Object[] {test, new Integer( 0 )} ) );

    Method m = findMethod( test, "run()" );
    System.out.println( m.getName() );
  }
}