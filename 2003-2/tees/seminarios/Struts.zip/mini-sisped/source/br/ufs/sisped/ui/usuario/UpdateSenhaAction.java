package br.ufs.sisped.ui.usuario;

import org.apache.struts.action.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import br.ufs.sisped.ui.ViewController;
import br.ufs.sisped.facade.Argument;
import br.ufs.sisped.facade.Response;

/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Marcio Carvalho
 * @version 1.0
 */
public class UpdateSenhaAction extends Action {

  /**
   *
   * @param actionMapping
   * @param actionForm
   * @param httpServletRequest
   * @param httpServletResponse
   * @return
   * @throws ServletException
   */
  public ActionForward perform(ActionMapping actionMapping,
                               ActionForm actionForm,
                               HttpServletRequest httpServletRequest,
                               HttpServletResponse httpServletResponse)
      throws ServletException {

    AlterarSenhaForm form = (AlterarSenhaForm) actionForm;

    try {
      /* Pega a matricula do usuario da sessao */
      String mat = (String) httpServletRequest.getSession().getAttribute("userMatr");

      Argument arg = ViewController.prepareCommand(form.getId(),
                                                   new String[] { mat,
                                                                  form.getTfOldSenha(),
                                                                  form.getTfSenha() });
      Response r = ViewController.execute(arg);

      if (r.getType() != r.TP_ERROR) {
        return actionMapping.findForward("confirm");

      } else {
        httpServletRequest.setAttribute( "mensagem", r.getException().getMessage() );
        return actionMapping.findForward("general-error");
      }

    } catch( Throwable ex ) {
      httpServletRequest.setAttribute( "mensagem", ex.getMessage() );
      return actionMapping.findForward("general-error");
    }

  }
}