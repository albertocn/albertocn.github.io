package br.ufs.sisped.util.timing;


/**
 * Title:        Marcio Utilities
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      UFS
 * @author Marcio Carvalho
 * @version 1.0
 */

import java.util.Vector;
import java.util.Collection;
import java.util.Iterator;


/** Classe que funciona como cron�metro. Possui metodos de marca��o de tempos
 * e c�lculo de estat�sticas. Sua utilidade principal � para testes de performance.
 *
 * Os m�todos principais s�o start() e stop().
 *
     * O m�todo start() pode ser usado depois seguidas vezes, o que vai fazer com que
 * o cron�metro termine uma marca��o e inicie outra. O metodo stop(), ao mesmo tempo
 * que  finaliza uma marcacao, retorna o evento relativo aa mesma.
 */
public class Timer {

  private static int nextTimerId = 1;

  /** Proximo codigo de evento
   */
  private int nextEventId = 1;

  /** Identification of this Timer
   */
  private String id;

  private static synchronized int nextId() {
    return nextTimerId++;
  }


  private synchronized int nextEventId() {
    return nextEventId++;
  }


  /** Construtor que recebe o numero de marcacoes
   * @param times numero de marcacoes
   */
  public Timer() {
    this.id = "timer" + nextId();
  }


      /** M�todo que inicia uma nova marca��o de tempo, independente de o Timer estar
   * no modo ocioso. Ou seja pode ser chamado seguidas vezes.
   * @param desc Descricao da marcacao
   */
  public Event start( String desc ) {
    return new Timer.TimerEvent( desc, System.currentTimeMillis() );
  }


  public Event startNew( Event ev, String desc ) {
    if( !( ev instanceof TimerEvent ) ) {
      throw new IllegalArgumentException( "Tipo inv�lido de evento!" );
    }

    return( ( TimerEvent )ev ).startNew( desc );
  }


  /** Termina, armazena e retorna uma marca��o de tempo.
   * @return Evento representando a ultima marcacao
   */
  public Event stop( Event ev ) {
    if( !( ev instanceof TimerEvent ) ) {
      throw new IllegalArgumentException( "Tipo inv�lido de evento!" );
    }

    return( ( TimerEvent )ev ).stop();
  }


  /**
   * Classe que implementa um Evento
   */
  public final class TimerEvent implements Event {

    private int nextEventId = 1;

    private TimerEvent father = null;
    private String id;
    private String desc;
    private boolean timing;
    private long startTime = 0;
    private long endTime = 0;
    private long duration = 0;
    private Collection data = null;
    private Collection listeners;
    private long totalTime = 0;
    private double averageTime = 0.0;
    private Event bestTime = null;
    private Event worstTime = null;

    private synchronized int nextChildId() {
      return this.nextEventId++;
    }


    /** Construtor padrao desta classe.
     * @param desc Nome do Evento
     * @param duration Duracao do mesmo
     */
    private TimerEvent( String desc, long start ) {
      this.startTime = start;

      this.id = "event" + br.ufs.sisped.util.timing.Timer.this.nextEventId();

      this.timing = true;

      this.desc = desc;
    }


    private TimerEvent( String desc ) {
      this( desc, System.currentTimeMillis() );
    }


    private synchronized TimerEvent startNew( String desc ) {
      if( !timing ) {
        throw new IllegalStateException( "O evento acionado " + this.getId() +
                                         " n�o est� mais em estado ativo!" );
      }

      TimerEvent event = new TimerEvent( desc );
      event.id = this.id + "." + "event" + this.nextChildId();
      event.father = this;

      if( this.data == null ) {
        this.data = new Vector( 5 );
      }

      this.data.add( event );

      return event;
    }


    private synchronized TimerEvent stop() {
      this.endTime = System.currentTimeMillis();
      this.duration = endTime - startTime;
      this.timing = false;

      if( this.father != null ) {
        this.father.notifyDeath( this );
      }

      if( this.data != null ) {
        Iterator it = this.data.iterator();

        while( it.hasNext() ) {
          TimerEvent actual = ( TimerEvent )it.next();
          if( actual.isTiming() ) {
            actual.stop();
          }
        }
      }

      return this;
    }


    /**
     * Utilizado quando um evento filho deseja notificar este objeto sobre seu termino.
     */
    private void notifyDeath( TimerEvent evento ) {
      if( evento == this ) {
        if( evento.father != null ) {
          evento.father.notifyDeath( evento );
        }
      } else {
        this.processTimingEvent( evento );

        if( ( this.bestTime == null ) ||
            ( evento.getDuration() < this.bestTime.getDuration() ) ) {
          this.bestTime = evento;
        }

        if( ( this.worstTime == null ) ||
            ( evento.getDuration() > this.worstTime.getDuration() ) ) {
          this.worstTime = evento;
        }

        this.totalTime += evento.getDuration();
        this.averageTime = ( double )this.totalTime / this.data.size();
      }
    }


    /** Invoca os listeners registrados para processar a ultima marcacao.
     * @param e Ultima marcacao
     */
    private void processTimingEvent( Event e ) {
      if( listeners != null ) {
        Iterator it = listeners.iterator();

        while( it.hasNext() ) {
          ( ( TimingListener )it.next() ).timingProcessed( e );
        }
      }
    }


    /** Retorna os EventListeners registrados
     * @return Iterator de objetos listeners
     */
    public Iterator getTimingListeners() {
      return listeners.iterator();
    }


    /** Adiciona um TimingListeners aa lista atual
     * @param tl Objeto listener
     */
    public void addTimingListener( TimingListener tl ) {
      if( this.listeners == null ) {
        listeners = new Vector( 5 );

      }
      listeners.add( tl );
    }


    public String getId() {
      return this.id;
    }


    public String getDesc() {
      return this.desc;
    }


    public long getDuration() {
      return this.duration;
    }


    public long getDifference( Event other ) {
      return this.getDuration() - other.getDuration();
    }


    public double getSeconds() {
      return( double )this.getDuration() / 1000;
    }


    public boolean isTiming() {
      return this.timing;
    }


    public synchronized double getStandardDeviation() {
      Iterator it = this.getChildren();

      if( it == null ) {
        return 0;
      } else {
        long sum = 0L;

        while( it.hasNext() ) {
          sum +=
              Math.abs( this.getAverage() - ( ( Event )it.next() ).getDuration() );
        }

        return Math.sqrt( ( double )sum / this.getNumberOfChildEvents() );
      }
    }


    /** Retorna todas as marca��es de tempo.
     * @return Iterator com todos os eventos
     */
    public synchronized Iterator getChildren() {
      return( this.data == null ) ? null : this.data.iterator();
    }


    public long getTotalTime() {
      return this.totalTime;
    }


    public double getAverage() {
      return this.averageTime;
    }


    public Event getEventBestTime() {
      return this.bestTime;
    }


    public Event getEventWorstTime() {
      return this.worstTime;
    }


    public long getBestTime() {
      return bestTime.getDuration();
    }


    public long getWorstTime() {
      return worstTime.getDuration();
    }


    public int getNumberOfChildEvents() {
      return( this.data == null ) ? 0 : this.data.size();
    }


    public int compareTo( Object obj ) {
      if( obj instanceof Event ) {
        if( this.getId().equals( ( ( Event )obj ).getId() ) ) {
          return 0;
        } else {
          return this.getId().compareTo( ( ( Event )obj ).getId() );
        }
      } else {
        throw new ClassCastException();
      }
    }


    public boolean equals( Object obj ) {
      return( obj instanceof Event ) ? ( this.getId() == ( ( Event )obj ).getId() ) : false;
    }


    public String toString() {
      return "[Timer: " + br.ufs.sisped.util.timing.Timer.this.id + "] Event: " +
          this.getId() + "- " + this.getDesc() + ": " + this.getDuration() +
          " ms";
    }


    public synchronized void finalize() {
      this.timing = false;
      this.data.clear();
      this.data = null;
      this.father = null;
      this.bestTime = null;
      this.worstTime = null;
    }
  }

}