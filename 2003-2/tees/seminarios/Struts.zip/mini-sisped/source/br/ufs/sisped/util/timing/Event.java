package br.ufs.sisped.util.timing;


/**
 * Title:        Marcio Utilities
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      BANESE
 * @author Marcio Carvalho
 * @version 1.0
 */

import java.io.Serializable;
import java.util.Iterator;


/**
 * A interface utilit�ria Event encapsula uma marca��o.
 */

public interface Event extends Comparable, Serializable {

  public int compareTo( Object obj );


  public String getId();


  public String getDesc();


  public long getDuration();


  public boolean isTiming();


  public long getDifference( Event other );


  public double getSeconds();


  public double getStandardDeviation();


  public Iterator getChildren();


  public long getTotalTime();


  public double getAverage();


  public Event getEventBestTime();


  public Event getEventWorstTime();


  public long getBestTime();


  public long getWorstTime();


  public int getNumberOfChildEvents();


  public Iterator getTimingListeners();


  public void addTimingListener( TimingListener tl );

}