package br.ufs.sisped.util;


import java.util.HashSet;


/**
 *
 * @author  Marcio Ribeiro de Carvalho
 */
public class ThreadFinder {

  private HashSet visitedGroups = null;
  private ThreadGroup mainTG = null;

  /** Creates a new instance of ThreadFinder */
  public ThreadFinder() {
    visitedGroups = new HashSet( 15 );
  }


  /*
   * Inicia a procura
   */
  public Thread find( String name ) {
    ThreadGroup tg = Thread.currentThread().getThreadGroup();

    Thread ret = find( tg, name );

    if( ret != null ) {
      return ret;
    } else {
      return findAgain( mainTG, name );
    }
  }


  /*
   * Procura do grupo atual para cima
   */
  public Thread find( ThreadGroup tg, String name ) {
    if( tg == null ) {
      return null;
    }

    Thread t = visit( tg, name );
    if( t != null ) {
      return t;
    }

    if( "main".equals( tg.getName() ) ) {
      mainTG = tg;

    }
    return find( tg.getParent(), name );
  }


  /*
   * Procura do grupo dado para baixo, sem repetir buscas
   */
  private Thread findAgain( ThreadGroup tg, String name ) {
    if( tg == null ) {
      return null;
    }

    if( ( visitedGroups.contains( tg ) ) == true ) {
      return visitChildren( tg, name );
    } else {
      Thread t = visit( tg, name );
      if( t != null ) {
        return t;
      }

      return visitChildren( tg, name );
    }
  }


  /*
   * Visita as threads de um grupo
   */
  private Thread visit( ThreadGroup tg, String name ) {
    if( tg == null ) {
      return null;
    }

    visitedGroups.add( tg );

    int count = tg.activeCount();
    Thread[] group = new Thread[count];
    tg.enumerate( group );

    for( int i = 0; i < count; i++ ) {
      if( group[i] != null && group[i].getName().equals( name ) ) {
        return group[i];
      }
    }

    return null;
  }


  /*
   * Visita os grupos filhos do grupo dado.
   */
  private Thread visitChildren( ThreadGroup tg, String name ) {
    if( tg == null ) {
      return null;
    }

    int count = tg.activeGroupCount();
    ThreadGroup[] group = new ThreadGroup[count];
    tg.enumerate( group );

    Thread t = null;
    for( int i = 0; t == null && i < count; i++ ) {
      t = findAgain( group[i], name );
    }

    return t;
  }


  public static void main( String args[] ) {
    System.out.println( new ThreadFinder().find( "main" ) );
  }
}