package br.ufs.sisped.facade;


import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Properties;
import java.util.Collections;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.Serializable;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.JDOMException;

import br.ufs.sisped.util.timing.Timer;
import br.ufs.sisped.util.timing.Event;
import br.ufs.sisped.util.ThreadFinder;


/** Classe Thread que de tempos em tempos verifica se o arquivo XML de
 * configuracao foi alterado e em caso positivo o carrega para a memoria.
 * @author Marcio Carvalho
 * @since 1.0
 * @version 1.0
 */
public class ConfigurationLoader extends Thread implements Serializable {

  /**
   * Unica referencia desta classe
   */
  private static ConfigurationLoader singleton;

  /**
   * URL para localiza��o do arquivo XML de configuracoes
   */
  private static String URL;

  /**
   *
   */
  public static String THREAD_NAME;

  /**
   *
   */
  public static String APP_NAME;


  static {
    init();
  }


  /**
   *
   */
  private static void init() {
    System.out.println( "[ConfigurationLoader] Starting Worker-Thread ConfigurationLoader..." );
    Properties p = new Properties();

    try {
      System.out.println( "[ConfigurationLoader] Preparando configura��es iniciais..." );
      p.load( ConfigurationLoader.class.getResourceAsStream( "facade.properties" ) );
      System.out.println( "[ConfigurationLoader] Configura��es iniciais prontas..." );
    } catch( IOException ioe ) {
      System.out.println( "[ConfigurationLoader] Worker-Thread ConfigurationLoader: file facade.properties not found..." );
      p.setProperty( "xml-path", "sisped.xml" );
      p.setProperty( "thread-name", "sisped.facade.ConfigurationLoader" );
      p.setProperty( "app-name", "SISPED" );
      ioe.printStackTrace();
    }

    URL = p.getProperty( "xml-path" );
    THREAD_NAME = p.getProperty( "thread-name" );
    APP_NAME = p.getProperty( "app-name" );

    System.out.println( "[ConfigurationLoader] Construindo instancia singleton..." );

    killOldSingleton();
    singleton = new ConfigurationLoader();
    System.out.println( "[ConfigurationLoader] Instancia singleton construida..." );

    singleton.start();
    System.out.println( "[ConfigurationLoader] Servico ConfigurationLoader startado..." );
  }

  /**
   * Verifica se ja existe um ConfigurationLoader na memoria.
   * Se sim, finaliza-o.
   */
  private static void killOldSingleton() {
    Object obj = new ThreadFinder().find( THREAD_NAME );

    if( obj != null && obj instanceof ConfigurationLoader ) {
      System.out.println(
          "[ConfigurationLoader] Servico ConfigurationLoader antigo localizado..." );
      ConfigurationLoader cl = ( ConfigurationLoader )obj;
      cl.shutdown();
      cl.finalize();
      System.out.println(
          "[ConfigurationLoader] Servico ConfigurationLoader antigo finalizado..." );
      cl = null;
    }
  }


  //Constantes para o controle do funcionamento da Thread
  private static final byte ST_ON = 0;
  private static final byte ST_OFF = 1;
  private static final byte ST_SUSPENDED = 2;

  private static long SLEEP_TIME = 30 * 60 * 1000; //30 min

  //Atributos de Classe
  private Map configuration; //Armazena as configuracoes
  private SAXBuilder parser;
  private byte status = ST_ON; //Status da Thread
  private File xmlFile;
  private long lastModified = 0; //Data da ultima modificacao em milisegundos

  /** Accessor method para a unica instancia desta classe.
   * @return Unica instancia de ConfigurationLoader
   */
  public static ConfigurationLoader getInstance() {
    return ConfigurationLoader.singleton;
  }


  /** Accessor method para a configuracao mantida pelo singleton
   * @return Map de configuracoes.
   */
  public static Map getMap() {
    if (ConfigurationLoader.singleton == null)
      init();

    if (ConfigurationLoader.singleton.configuration == null)
      try {
        singleton.reLoad();
      } catch(Exception ex) {
        ex.printStackTrace();
        return null;
      }

    return ConfigurationLoader.singleton.getConfiguration();
  }


  /**
   *  Construtor protegido pelo fato de a classe ser um singleton
   */
  protected ConfigurationLoader() {
    super( THREAD_NAME );
    this.setPriority( Thread.NORM_PRIORITY - 2 );
    this.setDaemon( true );
    this.configuration = new HashMap();

    try {
      System.out.println( "[ConfigurationLoader] Localizando arquivo " + URL +
                          "..." );
      this.xmlFile = new File( this.processURL( ConfigurationLoader.class.
                                                getResource( URL ).getFile() ) ); //Dando erro no JBoss
      System.out.println( "[ConfigurationLoader] Arquivo " + URL +
                          " localizado..." );

      System.out.println( "[ConfigurationLoader] Configurando Parser XML..." );
      parser = new SAXBuilder();
      parser.setIgnoringElementContentWhitespace( true );
      parser.setValidation( false );
      System.out.println( "[ConfigurationLoader] Parser XML configurado..." );

      this.reLoad();
    } catch( JDOMException jdex ) {
      jdex.printStackTrace();
    } catch( Exception ex ) {
      ex.printStackTrace();
    }
  }


  /**
   * Processa a URL informada para retirar sujeiras vindas do metodo getResource()
   */
  private static String processURL( String url ) {
    StringBuffer sb = new StringBuffer( url );

    for( int i = 0; i < sb.length(); i++ ) {
      if( i > 0 && sb.charAt( i ) == 'C' && sb.charAt( i - 1 ) == 'Q' ) {
        sb.replace( i - 1, i + 1, ":" );
      } else if( i > 0 && sb.charAt( i ) == 'B' && sb.charAt( i - 1 ) == 'Q' ) {
        sb.replace( i - 1, i + 1, "/" );

      }
    }
    return sb.toString();
  }


  /** Metodo principal da classe
   */
  public void run() {
    while( this.status != ST_OFF ) {
      try {
        Thread.sleep( SLEEP_TIME );

        if( status == ST_ON ) {
          System.out.print( "[ConfigurationLoader] Thread acordando e verificando alteracoes na configuracao..." );

          if( this.isFileChanged() ) {
            this.reLoad();
          } else {
            System.out.println( "[ConfigurationLoader] XML inalterado." );
          }
        }
      } catch( InterruptedException ie ) {
        System.out.println( ie.getMessage() );
      } catch( JDOMException jde ) {
        jde.printStackTrace();
      }
    }

    this.finalize();
  }


  /** Recarrega o arquivo XML de configuracoes
   * @throws JDOMException Erro ao carregar a arvore XML
   */
  public void reLoad() throws JDOMException {
    Document doc = null;

    //Carrega configura��es
    System.out.println( "[ConfigurationLoader] Thread carregando configuracoes em server.xml..." );

    try {
      doc = parser.build( ConfigurationLoader.class.getResourceAsStream( URL ) );
    } catch( Exception e ) {
      e.printStackTrace();
      return;
    }

    Timer clock = new Timer();
    Event e1;

    //Realiza as altera��es em this.configuration
    synchronized( this ) {
      e1 = clock.start( "Carregando arquivo XML" );
      this.loadDocument( doc );
      this.lastModified = xmlFile.lastModified();
      clock.stop( e1 );
    }

    System.out.println( "[ConfigurationLoader] Duracao do carregamento das configuracoes: " +
                        e1.getDuration() + " ms" );
    System.gc();
  }


  private boolean isFileChanged() {
    long lm = xmlFile.lastModified();
    return( lm != this.lastModified );
  }


  /** Navega atraves do arquivo extraindo seus elementos e atributos.
   * @param doc Document representando o arquivo XML
   */
  protected void loadDocument( Document doc ) {
    Element root = doc.getRootElement();
    Iterator children = root.getChildren().iterator();

    //Navegando atraves da arvores de elementos
    while( children.hasNext() ) {
      Element current = ( Element )children.next();
      String name = current.getName();

      if( name.equals( "transaction" ) ) {
        String id = current.getAttribute( "id" ).getValue();

        Properties p = new Properties();
        p.setProperty( "method-name",
                       current.getAttribute( "method-name" ).getValue() );
        p.setProperty( "jndi", current.getAttribute( "jndi" ).getValue() );
        p.setProperty( "factory-class",
                       current.getAttribute( "factory-class" ).getValue() );
        p.setProperty( "source-name",
                       current.getAttribute( "source-name" ).getValue() );

        this.configuration.put( id, p );
      }

      if( name.equals( "statement" ) ) {
        String id = current.getAttribute( "id" ).getValue();
        String sql = current.getText();

        this.configuration.put( id, sql );
      }
    }
  }


  /**
   * Torna a Thread suspensa.
   */
  public void pause() {
    synchronized( this ) {
      this.status = ST_SUSPENDED;
    }

    this.interrupt();
  }


  /**
   * Retorna ao estado de execu��o.
   */
  public void restart() {
    synchronized( this ) {
      this.status = ST_ON;
    }

    this.interrupt();
  }


  /**
   * Desliga definitivamente a thread.
   */
  public void shutdown() {
    synchronized( this ) {
      this.status = ST_OFF;
    }

    this.interrupt();
  }


  /** Retorna as configuracoes recem-carregadas
   * @return MapMap contendo as configuracoes
   */
  public Map getConfiguration() {
    return Collections.unmodifiableMap( this.configuration );
  }


  /**
   * Metodo de finaliza��o da Thread
   */
  protected void finalize() {
    System.out.println(
        "[ConfigurationLoader] Finalizando servico ConfigurationLoader..." );

    this.configuration.clear();
    this.parser = null;
    this.xmlFile = null;
  }


  /** Cria uma instancia do Parser
   * @return SAXBuilder
   */
  protected SAXBuilder getParser() {
    return this.parser;
  }


  /** Retorna o status da Thread
   * @return byte
   */
  protected byte getStatus() {
    return this.status;
  }


  /** Retorna uma instancia para o objeto File
   * @return File
   */
  protected File getXMLFile() {
    return this.xmlFile;
  }


  /** Retorna a data da ultima modificacao ao arquivo
   * @return long
   */
  protected long getLastModified() {
    return this.lastModified;
  }


  /**
   */
  public static void main( String args[] ) {
    Map m = ConfigurationLoader.getMap();

    System.out.println( "Transacao 3: " + m.get( "tr3" ) );
  }
}