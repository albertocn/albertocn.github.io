package br.ufs.sisped.ui.usuario;

import org.apache.struts.action.*;
import javax.servlet.http.*;
import javax.servlet.ServletException;
import br.ufs.sisped.data.usuario.UsuarioDAO;
import br.ufs.sisped.ui.ViewController;
import br.ufs.sisped.facade.Argument;
import br.ufs.sisped.facade.Response;


/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Marcio Carvalho
 * @version 1.0
 */
public class CreateUsuarioAction extends Action {

  public ActionForward perform(ActionMapping actionMapping,
                               ActionForm actionForm,
                               HttpServletRequest httpServletRequest,
                               HttpServletResponse httpServletResponse)
  throws ServletException {

    UsuarioForm form = (UsuarioForm) actionForm;

    try {
      UsuarioDAO user = new UsuarioDAO( Long.parseLong( form.getTfCodigo() ),
                                        form.getTfMatricula(),
                                        form.getTfSenha(),
                                        Integer.parseInt( form.getSlTipo() ),
                                        form.getTfNome(),
                                        form.getTfRG(),
                                        form.getSlSSP() );

      /* Envia os dados para o servidor */
      Argument arg = ViewController.prepareCommand( form.getId(), user );
      Response r = ViewController.execute( arg );

      /* Trata os resultados do servidor */
      if( r.getType() != r.TP_ERROR ) {
        UsuarioDAO ret = ( UsuarioDAO )r.getValue();
        form.setTfCodigo(ret.getCodigo().toString());

        httpServletRequest.setAttribute( "usuarioForm", form );

        return actionMapping.findForward("confirm");

      } else {
        httpServletRequest.setAttribute( "mensagem", r.getException().getMessage() );
        return actionMapping.findForward("general-error");
      }

    } catch( Throwable ex ) {
      httpServletRequest.setAttribute( "mensagem", ex.getMessage() );
      return actionMapping.findForward("general-error");
    }
  }

}