package br.ufs.sisped.util.timing;


/**
 * Title:        Marcio Utilities
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      BANESE
 * @author Marcio Carvalho
 * @version 1.0
 */

import java.util.EventListener;


/** Interface que deve ser implementada por toda classe que deseja processar os eventos de marca��o da classe Timer.
 */
public interface TimingListener extends EventListener {

  /** Metodo invocado pelo Timer quando uma marcacao for realizada.
   * @param e Marca��o
   */
  public void timingProcessed( Event e );

}