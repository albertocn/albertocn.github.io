/*
 * ItemArea.java
 *
 * Created on 25 de Abril de 2003, 13:04
 */

package br.ufs.sisped.data;


/**
 *
 * @author  00113006
 */
public interface ItemArea {

  //Codigo da area do sistema
  public static final int CD_AREA = 1;

}
