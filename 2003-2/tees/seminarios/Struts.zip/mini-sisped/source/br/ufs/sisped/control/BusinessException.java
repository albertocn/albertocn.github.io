package br.ufs.sisped.control;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Marcio Carvalho
 * @version 1.0
 */

public class BusinessException extends Exception implements java.io.Serializable {

  public BusinessException(String msg) {
    super(msg);
  }

}