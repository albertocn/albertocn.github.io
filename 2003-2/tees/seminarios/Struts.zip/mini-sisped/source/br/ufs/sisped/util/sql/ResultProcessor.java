/*
 * ResultProcessor.java
 *
 * Created on 28 de Mar�o de 2003, 13:42
 */

package br.ufs.sisped.util.sql;


import java.sql.SQLException;


/**
 *
 * @author  Marcio Carvalho
 */
public interface ResultProcessor extends java.io.Serializable {

  public Object[] processResult( java.sql.ResultSet rs ) throws SQLException;

}