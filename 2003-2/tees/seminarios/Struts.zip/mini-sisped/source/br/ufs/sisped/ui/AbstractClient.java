package br.ufs.sisped.ui;

import javax.servlet.http.HttpServletRequest; //request variable
import javax.servlet.jsp.PageContext; //pageContext variable
import javax.servlet.http.HttpSession; //session variable
import javax.servlet.ServletContext; //application variable


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author not attributable
 * @version 1.0
 */
public abstract class AbstractClient {

  //Componentes de uma requisicao HTML
  protected PageContext pageContext = null;
  protected ServletContext application = null;
  protected HttpSession session = null;
  protected HttpServletRequest request = null;


  /**
   *
   * @param page
   * @param app
   * @param session
   * @param request
   */
  public AbstractClient(PageContext page, ServletContext app,
                        HttpSession session, HttpServletRequest request ) {
    this.application = app;
    this.pageContext = page;
    this.session = session;
    this.request = request;
  }


  //Metodos de manipulacao de uma classe Client
  public abstract void inserir() throws Throwable;
  public abstract void excluir() throws Throwable;
  public abstract void exibir() throws Throwable;
  public abstract void alterar() throws Throwable;


  //Metodos de alteracao de Contexto
  public void setPageContext( PageContext page ) {
    this.pageContext = page;
  }


  public void setServletContext( ServletContext app ) {
    this.application = app;
  }


  public void setHttpSession( HttpSession session ) {
    this.session = session;
  }


  public void setRequest( HttpServletRequest request ) {
    this.request = request;
  }
}