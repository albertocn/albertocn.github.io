package br.ufs.sisped.facade.query;


import javax.ejb.*;

import java.util.Map;
import java.util.Properties;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.regex.Pattern;
import java.util.regex.Matcher;

import java.io.IOException;

import java.sql.*;
import javax.sql.DataSource;
import sun.jdbc.rowset.CachedRowSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import br.ufs.sisped.util.timing.Timer;
import br.ufs.sisped.util.timing.Event;
import br.ufs.sisped.util.sql.ResultProcessor;
import br.ufs.sisped.facade.ConfigurationLoader;


/** Created 11/03/2003 15:07:44
 * Classe Session Bean que fornece um meio unico de executar
 * comandos SQL.
 * @author Marcio Carvalho
 * @version 1.0
 */
public class QueryProcessorBean implements javax.ejb.SessionBean,
    br.ufs.sisped.data.ItemArea {

  private static final String APP_NAME = ConfigurationLoader.APP_NAME;

  private static final String DATASOURCE_JNDI;

  static {
    Properties p = new Properties();

    try {
      p.load( QueryProcessorBean.class.getResourceAsStream( "query.properties" ) );
    } catch( IOException ioe ) {
      System.out.println( "[" + APP_NAME +
                          "] file facade.properties not found..." );
      p.setProperty( "xml-path", "java:/MySQLSisped" );
      ioe.printStackTrace();
    }

    DATASOURCE_JNDI = p.getProperty( "query-datasource-jndi-name" );
  }


  private javax.ejb.SessionContext context;
  private static DataSource ds = getDataSource();
  private Connection conn;


  /**
   * M�todo que obt�m um instancia de um DataSource e o retorna.
   */
  private static DataSource getDataSource() {
    try {
      Context ctx = new InitialContext();
      DataSource ds = ( DataSource )ctx.lookup( DATASOURCE_JNDI );

      return ds;

    } catch( NamingException ne ) {
      System.out.println( "[" + APP_NAME +
                          "] DataSource para o banco de dados n�o carregado..." );
      ne.printStackTrace();
      return null;
    }
  }


  /** See section 7.10.3 of the EJB 2.0 specification
   * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
   * @param aContext See section 7.10.3 of the EJB 2.0 specification
   */
  public void setSessionContext(javax.ejb.SessionContext aContext) {
    context = aContext;
  }


  /** See section 7.10.3 of the EJB 2.0 specification
   * @see javax.ejb.SessionBean#ejbActivate()
   */
  public void ejbActivate() {

  }


  /** See section 7.10.3 of the EJB 2.0 specification
   * @see javax.ejb.SessionBean#ejbPassivate()
   */
  public void ejbPassivate() {

  }


  /** See section 7.10.3 of the EJB 2.0 specification
   * @see javax.ejb.SessionBean#ejbRemove()
   */
  public void ejbRemove() {

  }


  /**
   * See section 7.10.3 of the EJB 2.0 specification
   */
  public void ejbCreate() {

  }


  /** Metodo para executar comandos de alteracao no banco de dados.
   * @param commId Identificador do Comando SQL contido no arquivo server.xml
   * @param params Parametros para serem inseridos no comando.
   * @throws SQLException Erro de SQL
   * @return Numero de linhas afetadas
   */
  public java.lang.Integer execCommand(java.lang.String commId, java.util.Collection params) throws java.sql.SQLException {
    try {
      Map m = ConfigurationLoader.getMap();

      String sql = ( String )m.get( commId );

      return this.execCommandStatement( sql, params );
    } catch( Exception e ) {
      e.printStackTrace();
      if( e instanceof java.sql.SQLException ) {
        throw( java.sql.SQLException )e;
      }
      return null;
    }
  }


  /** Executa um comando DML no servidor de banco de dados.
   * @param comm Comando SQL.
   * @param params Parametros para serem inseridos no comando.
   * @throws SQLException Qualquer erro de SQL
   * @return Numero de linhas afetadas
   */
  public java.lang.Integer execCommandStatement(java.lang.String comm, java.util.Collection params) throws java.sql.SQLException {
    Connection conn = null;

    try {
      conn = ds.getConnection();

      return new Integer( this.doExecuteCommand( comm, params, conn ) );
    } catch( Exception e ) {
      e.printStackTrace();
      if( e instanceof java.sql.SQLException ) {
        throw( java.sql.SQLException )e;
      }
      return null;
    } finally {
      conn.close();
    }
  }


  /** Metodo que executa uma consulta no banco de dados, devolvendo o
   * ResultSet correspondente.
   * @param commId Identificador da consulta SQL contida no arquivo server.xml
   * @param params Parametros a serem inseridos na consulta SQL
   * @return java.sql.ResultSet
   * @throws SQLException Qualquer erro de SQL
   */
  public java.sql.ResultSet execSQL(java.lang.String commId, java.util.Collection params) throws java.sql.SQLException {
    try {
      Map m = ConfigurationLoader.getMap();

      String sql = ( String )m.get( commId );

      CachedRowSet crs = new CachedRowSet();

      crs.populate( this.execSQLStatement( sql, params ) );

      return crs;
    } catch( Exception e ) {
      e.printStackTrace();
      if( e instanceof java.sql.SQLException ) {
        throw( java.sql.SQLException )e;
      }
      return null;
    }
  }


  /** Executa uma consulta SQL no servidor de banco de dados.
   * @param comm Comando SQL.
   * @param params Parametros para serem inseridos no comando.
   * @return java.sql.ResultSet
   * @throws SQLException Qualquer erro de SQL
   */
  public java.sql.ResultSet execSQLStatement(java.lang.String comm, java.util.Collection params) throws java.sql.SQLException {
    Connection conn = null;

    try {
      conn = ds.getConnection();

      CachedRowSet crs = new CachedRowSet();

      crs.populate( this.doExecuteSQL( comm, params, conn ) );

      return crs;

    } catch( Exception e ) {
      e.printStackTrace();
      if( e instanceof java.sql.SQLException ) {
        throw( java.sql.SQLException )e;
      }
      return null;
    } finally {
      conn.close();
    }
  }


  /** Metodo que executa uma consulta no banco de dados, devolvendo um
   * array de Object gerado pelo ResultProcessor informado.
   * @param commId identificacao do comando SQL
   * @param params Parametros do comando
   * @param processor Objeto responsavel por processar o ResultSet gerado
   * @return Array de Objetos gerado pelo ResultProcessor
   * @throws SQLException Qualquer erro SQL
   */
  public java.util.Collection execSQL(java.lang.String commId, java.util.Collection params, ResultProcessor processor) throws java.sql.SQLException {

    return Arrays.asList( processor.processResult( this.execSQL( commId, params ) ) );
  }


  public ResultSet execSQL(java.lang.String stId, java.lang.String complement, java.util.Collection params) throws java.sql.SQLException {

    try {
      Map m = ConfigurationLoader.getMap();

      String sql = ( ( String )m.get( stId ) ) + complement;

      CachedRowSet crs = new CachedRowSet();

      crs.populate( this.execSQLStatement( sql, params ) );

      return crs;

    } catch( Exception e ) {
      e.printStackTrace();
      if( e instanceof java.sql.SQLException ) {
        throw( java.sql.SQLException )e;
      }
      return null;
    }
  }


  public Collection execSQL(java.lang.String stId, java.lang.String complemento, java.util.Collection params, br.ufs.sisped.util.sql.ResultProcessor proc) throws java.sql.SQLException {

    return Arrays.asList( proc.processResult( this.execSQL( stId, complemento,
        params ) ) );
  }


  /** Metodo que executa uma consulta no banco de dados, devolvendo um
   * array de Object gerado pelo ResultProcessor informado.
   * @param comm Comando SQL
   * @param params Parametros do comando SQL
   * @param processor Objeto responsavel por processar o ResultSet e gerar um array de Objetos
   * @return Array de objetos gerado pelo ResultProcessor
   * @throws SQLException Qualquer erro SQL
   */
  public java.util.Collection execSQLStatement(java.lang.String comm, java.util.Collection params, ResultProcessor processor) throws java.sql.SQLException {
    try {

      ArrayList array = new ArrayList( 1 );
      array.add( processor.processResult( this.execSQLStatement( comm, params ) ) );
      return array;

    } catch( Exception e ) {
      e.printStackTrace();
      if( e instanceof java.sql.SQLException ) {
        throw( java.sql.SQLException )e;
      }
      return null;
    }
  }


  /** Executa um conjunto de Comandos SQL e devolve o numero de linhas
   * afetadas no total.
   * @param commIds Array de codigos de comandos SQL
   * @param params Array de Array de parametros.
   * @return Numero de linhas afetadas.
   * @throws SQLException Qualquer erro SQL
   */
  public java.lang.Integer execTransaction(java.lang.String[] commIds, java.util.Collection params) throws java.sql.SQLException {
    try {
      String[] comms = new String[commIds.length];

      Map m = ConfigurationLoader.getMap();
      for( int i = 0; i < commIds.length; i++ ) {
        comms[i] = ( String )m.get( commIds[i] );

      }
      return this.execTransactionStatements( comms, params );
    } catch( Exception e ) {
      e.printStackTrace();
      if( e instanceof java.sql.SQLException ) {
        throw( java.sql.SQLException )e;
      }
      return null;
    }
  }


  /** Executa um conjunto de Comandos SQL e devolve o numero de linhas
   * afetadas no total.
   * @param comms Array de Comandos SQL
   * @param params Array de Arrays de parametros
   * @return Numero de linhas afetadas no total
   * @throws SQLException Erro SQL
   */
  public java.lang.Integer execTransactionStatements(java.lang.String[] comms, java.util.Collection params) throws java.sql.SQLException {
    Connection conn = ds.getConnection();
    Timer clock = new Timer();
    Event e1;
    Object[] args = ( Object[] )params.toArray()[0];

    try {

      int rows = 0;
      e1 = clock.start( "Iniciando Transacao SQL" );
      for( int i = 0; i < comms.length; i++ ) {
        ArrayList coll = new ArrayList( 1 );
        coll.add( args[i] );
        rows += this.doExecuteCommand( comms[i], coll, conn );
      }

      System.out.println( "[" + APP_NAME + "] Transacao SQl finalizada: " +
                          clock.stop( e1 ).getDuration() + " ms" );

      return new Integer( rows );

    } catch( Exception e ) {
      e.printStackTrace();
      if( e instanceof java.sql.SQLException ) {
        throw( java.sql.SQLException )e;
      }
      return null;
    } finally {
      conn.close();
    }
  }


  /** Metodo utilit�rio que faz a execucao propriamente dita de um comando SQL.
   * @param comm Comando SQL
   * @param params Array de parametros
   * @param conn Conexao com o BD
   * @return Numero de Linhas afetadas
   * @throws SQLException Erro SQL
   */
  protected int doExecuteCommand(java.lang.String comm, Collection params, Connection conn) throws java.sql.SQLException {
    PreparedStatement ps = null;

    try {
      Timer clock = new Timer();
      Event e1;
      ps = conn.prepareStatement( buildStatement( comm, params ) );

      e1 = clock.start( "Executando consulta SQL" );

      int rows = ps.executeUpdate();
      System.out.println( "[" + APP_NAME +
                          "] Comando SQL executado com sucesso: " +
                          comm.substring( 0, 20 ) + "..." );
      System.out.println( "[" + APP_NAME +
                          "] Tempo de Execu��o de consulta SQL: " +
                          clock.stop( e1 ).getDuration() + " ms" );
      System.out.println( "[" + APP_NAME +
                          "] _______________________________________" );

      return rows;

    } catch( Exception e ) {
      e.printStackTrace();
      if( e instanceof java.sql.SQLException ) {
        throw( java.sql.SQLException )e;
      }
      return -1;
    } finally {
      if( ps != null ) {
        ps.close();
      }
    }
  }


      /** Metodo utilit�rio que faz a execucao propriamente dita de uma consulta SQL.
   * @param comm Consulta SQL
   * @param params Array de Parametros
   * @param conn Conexao com o BD
   * @return Resultado da consulta
   * @throws SQLException Erro SQL
   */
  protected java.sql.ResultSet doExecuteSQL(java.lang.String comm, java.util.Collection params, Connection conn) throws java.sql.SQLException {
    PreparedStatement ps = null;

    try {
      Timer clock = new Timer();
      Event e1;

      ps = conn.prepareStatement( buildStatement( comm, params ) );

      e1 = clock.start( "Executando consulta SQL" );
      ResultSet rs = ps.executeQuery();
      CachedRowSet crs = new CachedRowSet();
      crs.populate( rs );

      System.out.println( "[" + APP_NAME +
                          "] Comando SQL executado com sucesso " );
      System.out.println( "[" + APP_NAME +
                          "] Tempo de Execu��o de consulta SQL: " +
                          clock.stop( e1 ).getDuration() + " ms" );
      System.out.println( "[" + APP_NAME +
                          "] _______________________________________" );

      return crs;

    } catch( Exception e ) {
      e.printStackTrace();
      if( e instanceof java.sql.SQLException ) {
        throw( java.sql.SQLException )e;
      }
      return null;
    } finally {
      if( ps != null ) {
        ps.close();
      }
    }
  }


  /** Prepara os valores dos parametros no objeto PreparedStatement informado.
   * @param st PreparedStatement criado anteriormente
   * @param params Array de parametros para ser utilizado na montagem do comando SQL
   * @throws SQLException Erro SQL
   */
  private String buildStatement(String sql, java.util.Collection params) throws Exception {
    if( params != null ) {
      Iterator it = params.iterator();
      for( int i = 1; it.hasNext(); i++ ) {
        Object obj = it.next();

        if( obj == null ) {
          sql = Pattern.compile( "\\?" + i ).matcher( sql ).replaceAll( "NULL" );
        } else {
          sql = Pattern.compile( "\\?" +
                i ).matcher( sql ).replaceAll( obj.toString() );
        }
      }
    }

    return sql;
  }



  /**
   * Apenas consulta o comando SQL no Banco de Dados
   *
   * @param id
   * @param params
   * @return
   */
  public String getSQL(String id, java.util.Collection params) {
    try {
      Map m = ConfigurationLoader.getMap();

      String sql = this.buildStatement( ( String )m.get( id ), params );

      return sql;
    } catch (Exception e) {
      e.printStackTrace();
      return null;
    }
  }

}