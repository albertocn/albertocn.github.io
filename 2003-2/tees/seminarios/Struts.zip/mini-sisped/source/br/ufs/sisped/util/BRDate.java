/*
 * BRDateFormat.java
 *
 * Created on 28 de Junho de 2003, 13:50
 */

package br.ufs.sisped.util;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;


/**
 *
 * @author  Marcio Carvalho
 */
public class BRDate extends java.util.Date {

  private static SimpleDateFormat timeParser =
      new SimpleDateFormat("h:mm:ss a");

  private static SimpleDateFormat dateParser =
      new SimpleDateFormat("dd/MM/yyyy");

  /** Creates a new instance of BRDateFormat */
  public BRDate() {
    super();
  }


  public BRDate( String date ) throws java.text.ParseException {
    super( parseString( date ).getTime() );
  }


  public BRDate( String date, String mask ) throws java.text.ParseException {
    super( new SimpleDateFormat( mask ).parse( date ).getTime() );
  }


  public BRDate( java.util.Date date ) {
    super( date.getTime() );
  }


  private static String formatDate( java.util.Date date ) {
    StringBuffer ret = new StringBuffer( 20 );

    Calendar calendar = new GregorianCalendar();
    calendar.setTime( date );

    ret.append( diaSemana( calendar.get( Calendar.DAY_OF_WEEK ) ) + ", " );
    ret.append( calendar.get( Calendar.DAY_OF_MONTH ) + " de " );
    ret.append( mes( calendar.get( Calendar.MONTH ) ) + " de " );
    ret.append( calendar.get( Calendar.YEAR ) + "" );

    return ret.toString();
  }


  private static String diaSemana( int dia ) {
    switch( dia ) {
      case Calendar.SUNDAY:
        return "domingo";
      case Calendar.MONDAY:
        return "segunda-feira";
      case Calendar.TUESDAY:
        return "ter�a-feira";
      case Calendar.WEDNESDAY:
        return "quarta-feira";
      case Calendar.THURSDAY:
        return "quinta-feira";
      case Calendar.FRIDAY:
        return "sexta-feira";
      case Calendar.SATURDAY:
        return "s�bado";
      default:
        return "";
    }
  }


  private static String mes( int mes ) {
    switch( mes ) {
      case Calendar.JANUARY:
        return "janeiro";
      case Calendar.FEBRUARY:
        return "fevereiro";
      case Calendar.MARCH:
        return "mar�o";
      case Calendar.APRIL:
        return "abril";
      case Calendar.MAY:
        return "maio";
      case Calendar.JUNE:
        return "junho";
      case Calendar.JULY:
        return "julho";
      case Calendar.AUGUST:
        return "agosto";
      case Calendar.SEPTEMBER:
        return "setembro";
      case Calendar.OCTOBER:
        return "outubro";
      case Calendar.NOVEMBER:
        return "novembro";
      case Calendar.DECEMBER:
        return "dezembro";
      default:
        return "";
    }
  }


  private static String formatTime( java.util.Date date ) {
    return timeParser.format( date );
  }


  private static java.util.Date parseString( String data ) throws java.text.
      ParseException {
    return dateParser.parse( data );
  }


  public String toString() {
    return this.toDateText() + " " + this.toHour();
  }


  public String toDate() {
    return dateParser.format( this );
  }


  public String toDate( String mask ) {
    return new SimpleDateFormat( mask ).format( this );
  }


  public String toDateText() {
    return formatDate( this );
  }


  public String toHour() {
    return formatTime( this );
  }


  public long diffDays(Date other) {
    Calendar cal1 = Calendar.getInstance();
    Calendar cal2 = Calendar.getInstance();

    cal1.setTime(this);
    cal2.setTime(other);

    long time1 = this.getTime() + cal1.get(Calendar.ZONE_OFFSET) + cal1.get(Calendar.DST_OFFSET);
    long time2 = other.getTime() + cal2.get(Calendar.ZONE_OFFSET) + cal2.get(Calendar.DST_OFFSET);
    long days1 = time1 / (1000 * 60 * 60 * 24);
    long days2 = time2 / (1000 * 60 * 60 * 24);

    return days1 - days2;
  }


  public long diffMonths(Date other) {
    return this.diffDays(other) / 30;
  }


  public int diffYears(Date other) {
    return (int) ( this.diffDays(other) / 365 );
  }


  public static void main( String args[] ) throws Exception {
    BRDate hoje = new BRDate();
    BRDate ontem = new BRDate("11/02/1980");

    System.out.println( hoje.diffYears(ontem) );
  }
}