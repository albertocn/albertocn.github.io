/*
 * Argument.java
 *
 * Created on 17 de Abril de 2003, 11:22
 */

package br.ufs.sisped.facade;


/**
 * Interface que representa
 *
 * @author  Marcio Carvalho
 */
public interface Argument extends java.io.Serializable {

  public String getTransactionId();


  public Object[] getParams();
}