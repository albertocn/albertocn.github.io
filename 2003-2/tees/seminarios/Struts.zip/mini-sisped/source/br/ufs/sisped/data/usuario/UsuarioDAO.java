package br.ufs.sisped.data.usuario;


/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Marcio Carvalho
 * @version 1.0
 */
public class UsuarioDAO implements java.io.Serializable {

  /*
   * Constantes contendo os tipos de Usuario
   */
  public static final int TP_ADMINISTRADOR = 1;
  public static final int TP_USUARIO = 2;


  /*
   * Fields of Usuario
   */
  private long codigo;
  private String matricula;
  private String senha;
  private int tipo;
  private String nome;
  private String rg;
  private String ssp;


  public void validate() throws Exception {

    if (matricula == null || "".equals(matricula)) {
      throw new Exception("� preciso informar uma matr�cula v�lida.");
    }

    if (senha == null && "".equals(senha)) {
      throw new Exception("� preciso informar uma senha v�lida.");
    }

    if (tipo != 1 && tipo != 2) {
      throw new Exception("� preciso informar um tipo v�lido de usu�rio.");
    }

    if (nome == null && "".equals(nome)) {
      throw new Exception("� preciso informar um nome v�lido para o usu�rio.");
    }

    if (rg == null && "".equals(rg)) {
      throw new Exception("� preciso informar um RG v�lido para o usu�rio.");
    }

    if (ssp == null && "".equals(ssp)) {
      throw new Exception("� preciso informar um SSP v�lido para o RG do usu�rio.");
    }

  }


  public UsuarioDAO() {}


  public UsuarioDAO( long codigo,
                     String matricula,
                     String senha,
                     int tipo,
                     String nome,
                     String rg,
                     String ssp ) throws Exception {
    this.codigo = codigo;
    this.matricula = matricula;
    this.senha = senha;
    this.tipo = tipo;
    this.nome = nome;
    this.rg = rg;
    this.ssp = ssp;

    validate();
  }


  public UsuarioDAO( LocalUsuario lu ) {
    this.codigo = lu.getCdUsuario().longValue();
    this.matricula = lu.getCdMatricula();
    this.senha = lu.getDeSenha();
    this.tipo = lu.getDeTipo().intValue();
    this.nome = lu.getDeNome();
    this.rg = lu.getCdRG();
    this.ssp = lu.getDeSSP();
  }


  public Long getCodigo() {
    return new Long( codigo );
  }


  public void setCodigo(Long codigo) {
    this.codigo = codigo.longValue();
  }


  public String getMatricula() {
    return matricula;
  }


  public void setMatricula(String matricula) {
    this.matricula = matricula;
  }


  public String getSenha() {
    return senha;
  }


  public void setSenha(String senha) {
    this.senha = senha;
  }


  public Integer getTipo() {
    return new Integer( tipo );
  }


  public void getTipo(Integer tipo) {
    this.tipo = tipo.intValue();
  }


  public String getNome() {
    return nome;
  }


  public void setNome(String nome) {
    this.nome = nome;
  }


  public String getRg() {
    return rg;
  }


  public void setRg(String rg) {
    this.rg = rg;
  }


  public String getSsp() {
    return ssp;
  }


  public void setSsp(String ssp) {
    this.ssp = ssp;
  }

}