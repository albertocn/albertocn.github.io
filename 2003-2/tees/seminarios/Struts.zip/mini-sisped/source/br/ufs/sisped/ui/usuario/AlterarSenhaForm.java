package br.ufs.sisped.ui.usuario;

import org.apache.struts.action.*;
import javax.servlet.http.*;


/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Marcio Carvalho
 * @version 1.0
 */
public class AlterarSenhaForm extends ActionForm {
  private String id;
  private String tfConfirmacao;
  private String tfOldSenha;
  private String tfSenha;


  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }


  public String getTfConfirmacao() {
    return tfConfirmacao;
  }


  public void setTfConfirmacao(String tfConfirmacao) {
    this.tfConfirmacao = tfConfirmacao;
  }


  public String getTfOldSenha() {
    return tfOldSenha;
  }


  public void setTfOldSenha(String tfOldSenha) {
    this.tfOldSenha = tfOldSenha;
  }


  public String getTfSenha() {
    return tfSenha;
  }


  public void setTfSenha(String tfSenha) {
    this.tfSenha = tfSenha;
  }


  public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest) {
    ActionErrors ae = new ActionErrors();

    if (tfOldSenha == null) {
      ae.add("senha", new ActionError("alterar_senha.error.invalid.senha"));
    }

    if (!tfSenha.equals(tfConfirmacao)) {
      ae.add("confirmacao", new ActionError("alterar_senha.error.invalid.confirmacao"));
    }

    return ae;
  }


  public void reset(ActionMapping actionMapping, HttpServletRequest httpServletRequest) {
    id = null;
    tfConfirmacao = null;
    tfOldSenha = null;
    tfSenha = null;
  }

}