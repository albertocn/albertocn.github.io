package br.ufs.sisped.facade;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2003
 * Company:
 * @author
 * @version 1.0
 */

public class FacadeResponse implements Response {

  private byte type;
  private Object response;
  private Throwable exception;

  /**
   *
   */
  public FacadeResponse() {
    this.response = null;
    this.exception = null;
    type = TP_NULL;
  }


  /**
   *
   * @param t
   */
  public FacadeResponse( Throwable t ) {
    this.response = null;
    this.exception = t;
    type = TP_NULL;
  }


  /**
   *
   * @param response
   */
  public FacadeResponse( Object response ) {
    this.response = response;
    this.exception = null;
    this.type = ( response instanceof Object[] ) ? TP_ARRAY : TP_SINGLETON;
  }


  /**
   *
   * @param response
   */
  public FacadeResponse( Object[] response ) {
    this.response = response;
    this.exception = null;
    this.type = TP_ARRAY;
  }


  /**
   *
   * @param t
   */
  public void setException( Throwable t ) {
    this.exception = t;
  }


  /**
   *
   * @return
   */
  public byte getType() {
    if( threwException() ) {
      return TP_ERROR;
    }

    return type;
  }


  /**
   *
   * @return
   * @throws java.lang.Throwable
   */
  public Object getValue() throws Throwable {
    if( this.exception != null ) {
      throw this.exception;
    }

    return response;
  }


  /**
   *
   * @return
   * @throws java.lang.Throwable
   */
  public Object[] getValues() throws Throwable {
    if( this.exception != null ) {
      throw this.exception;
    }

    try {
      return( Object[] )response;
    } catch( ClassCastException cce ) {
      throw new IllegalStateException( "Tipo de retorno inv�lido!" );
    }
  }


  /**
   *
   * @return
   */
  public Throwable getException() {
    return this.exception;
  }


  /**
   *
   * @return
   */
  public boolean isNull() {
    return( type == this.TP_NULL );
  }


  /**
   *
   * @return
   */
  public boolean threwException() {
    return( exception != null );
  }
}