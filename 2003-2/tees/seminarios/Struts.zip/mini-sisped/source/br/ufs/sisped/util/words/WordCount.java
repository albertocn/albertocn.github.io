package br.ufs.sisped.util.words;


/**
 *
 * <p>Title: Top. Esp. Em Ling. de Programacao (10 de outubro de 2003)</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author Marcio Carvalho - 00113006
 * @version 1.0
 */
public class WordCount implements Comparable {
  private String word;
  private long count;

  /**
   * Construtor Padrao
   * @param word palavra
   * @param count numero inicial de ocorrencias
   */
  public WordCount(String word, long count) {
    this.word = word;
    this.count = count;
  }


  /**
   * Ao comparar uma palavra informada com as existentes, atualiza
   * o contador da palavra igual, se existir.
   *
   * @param o outra Tupla
   * @return
   */
  public int compareTo(Object o) {
    if (!(o instanceof WordCount))
      throw new IllegalArgumentException("A instancia passada deve ser do tipo Tupla");

    String other = ((WordCount)o).word;
    int comparacao = this.word.compareTo(other);

    if (comparacao == 0) //Ja existe uma ocorrencia
      ((WordCount)o).count++;

    return comparacao;
  }


  public boolean equals(Object o ) {
    int comparacao = this.compareTo(o);
    return (comparacao == 0);
  }
}