package br.ufs.sisped.control.usuario;


import javax.ejb.*;

import br.ufs.sisped.control.BusinessException;

import java.util.Collection;
import java.util.Collections;

import javax.naming.InitialContext;
import javax.naming.Context;

import br.ufs.sisped.util.Methods;
import br.ufs.sisped.util.crypto.Base64;

import br.ufs.sisped.data.usuario.*;

import br.ufs.sisped.facade.FacadeResponse;
import br.ufs.sisped.facade.Response;

import br.ufs.sisped.facade.query.*;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.io.FileWriter;
import java.io.BufferedWriter;



/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Marcio Carvalho
 * @version 1.0
 */
public class CadastrarUsuarioBean implements javax.ejb.SessionBean {
  private static final String JNDI_USUARIO = "sisped/data/usuario/UsuarioEJB";
  private static final String JNDI_POSTO_DE_SAUDE = "sisped/data/paciente/PostoDeSaudeEJB";


  private javax.ejb.SessionContext context;

  /**
   * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
   */
  public void setSessionContext(javax.ejb.SessionContext aContext) {
    context = aContext;
  }


  /**
   * @see javax.ejb.SessionBean#ejbActivate()
   */
  public void ejbActivate() {

  }


  /**
   * @see javax.ejb.SessionBean#ejbPassivate()
   */
  public void ejbPassivate() {

  }


  /**
   * @see javax.ejb.SessionBean#ejbRemove()
   */
  public void ejbRemove() {

  }


  /**
   * See section 7.10.3 of the EJB 2.0 specification
   */
  public void ejbCreate() {

  }


  /** Insere um usuario no banco de dados
   * @param usuario Objeto DAO contendo todos os dados do usuario
   * @return int
   */
  public br.ufs.sisped.facade.Response createUsuario(br.ufs.sisped.data.usuario.UsuarioDAO usuario) {
    System.out.println( "[CadastrarUsuarioBean] Metodo createUsuario invocado..." );

    try {
      Context ctx = new InitialContext();

      LocalUsuarioHome uHome = ( LocalUsuarioHome )ctx.lookup( JNDI_USUARIO );
      LocalUsuario local = uHome.create( usuario );

      return new FacadeResponse( new UsuarioDAO( local ) );
    } catch( Exception e ) {
      e.printStackTrace();
      return new FacadeResponse( new Exception("N�o foi poss�vel inserir o usu�rio informado. Provavelmente a matr�cula informada est� duplicada.") );
    }
  }


  /** Retorna o usuario referente ao codigo informado.
   * @param codigo Codigo do Usuario
   * @return int
   */
  public br.ufs.sisped.facade.Response getUsuario(java.lang.Long codigo) {
    System.out.println( "[CadastrarUsuarioBean] Metodo getUsuario invocado..." );

    try {
      Context ctx = new InitialContext();
      LocalUsuarioHome usHome = ( LocalUsuarioHome )ctx.lookup( JNDI_USUARIO );

      LocalUsuario local = usHome.findByPrimaryKey( codigo );

      return new FacadeResponse( new UsuarioDAO( local ) );
    } catch( Exception e ) {
      e.printStackTrace();
      return new FacadeResponse( new Exception( "C�digo inexistente." ) );
    }
  }


  /** Altera os campos de usuario
   * @param fields Objeto Map contendo as modificacoes a serem feitas
   */
  public br.ufs.sisped.facade.Response setUsuario(br.ufs.sisped.data.usuario.UsuarioDAO user) {
    System.out.println( "[CadastrarUsuarioBean] Metodo setUsuario invocado..." );

    try {
      Context ctx = new InitialContext();

      LocalUsuarioHome usHome = ( LocalUsuarioHome )ctx.lookup( JNDI_USUARIO );
      LocalUsuario local = usHome.findByPrimaryKey( user.getCodigo() );

      local.setCdMatricula( user.getMatricula() );

      if( !( local.getDeSenha().trim().equals( user.getSenha().trim() ) ) ) {
        local.setDeSenha( Base64.encodeString( user.getSenha() ) );
      }

      if ( user.getCodigo().longValue() != 1 )
        local.setDeTipo( user.getTipo() );

      local.setDeNome( user.getNome() );
      local.setCdRG( user.getRg() );
      local.setDeSSP( user.getSsp() );

      return new FacadeResponse( user );
    } catch( Exception e ) {
      e.printStackTrace();
      return new FacadeResponse( new Exception( "N�o foi poss�vel alterar os dados do usu�rio informado. Provavelmente a matr�cula informada est� duplicada." ) );
    }
  }


  /**
   * Remove um usuario do banco de dados.
   * @param codigo Codigo do Usuario
   */
  public br.ufs.sisped.facade.Response removeUsuario(java.lang.Long codigo) {
    System.out.println("[CadastrarUsuarioBean] Metodo removeUsuario invocado..." );

    try {
      Context ctx = new InitialContext();
      LocalUsuarioHome usHome = ( LocalUsuarioHome )ctx.lookup( JNDI_USUARIO );
      LocalUsuario local = usHome.findByPrimaryKey( codigo );

      if (local.getCdUsuario().longValue() != 1)
        local.remove();
      else
        throw new BusinessException("O usu�rio administrador do sistema n�o pode ser removido do banco de dados.");

      return new FacadeResponse( ( Object )null );

    } catch( BusinessException be ) {
      return new FacadeResponse( be );

    } catch( Exception e ) {
      e.printStackTrace();
      return new FacadeResponse( new Exception( "N�o foi poss�vel remover o usu�rio informado." ) );
    }
  }


  /** Autentica o login e senha informados.
   * @param matricula Matricula do usuario
   * @param senha Senha do usuario
   * @return Integer
   */
  public br.ufs.sisped.facade.Response autenticarUsuario(java.lang.String matricula, java.lang.String senha) {
    System.out.println( "[CadastrarUsuarioBean] Metodo autenticarUsuario invocado..." );

    try {
      Context ctx = new InitialContext();
      LocalUsuarioHome usHome = ( LocalUsuarioHome )ctx.lookup( JNDI_USUARIO );

      LocalUsuario user = ( LocalUsuario )usHome.findByLogin( matricula,
                                                              Base64.encodeString( senha ) );
      System.out.println( "[CadastrarUsuarioBean] Usuario localizado..." );


      return new FacadeResponse( new UsuarioDAO( user ) );

    } catch( Exception e ) {
      e.printStackTrace();
      return new FacadeResponse( new Exception( "Usu�rio e/ou Senha inv�lidos!" ) );
    }
  }


  public br.ufs.sisped.facade.Response alterarSenha(java.lang.String matr, java.lang.String oldPass, java.lang.String newPass) {
    System.out.println( "[CadastrarUsuarioBean] Metodo autenticarUsuario invocado..." );

    try {
      Context ctx = new InitialContext();
      LocalUsuarioHome usHome = ( LocalUsuarioHome )ctx.lookup( JNDI_USUARIO );

      LocalUsuario user = ( LocalUsuario )usHome.findByLogin( matr, Base64.encodeString( oldPass ) );
      user.setDeSenha( Base64.encodeString( newPass ) );

      return new FacadeResponse( ( Object )null );

    } catch( Exception e ) {
      e.printStackTrace();
      return new FacadeResponse( new Exception("Senha inv�lida! Informe corretamente sua senha atual.") );
    }
  }

  /**
   * Metodo de criacao de backups de tabelas
   * Utilizado apenas em condicoes especiais
   *
   * @throws java.lang.Exception
   */
  private void createBackup(String sql) throws Exception {
    Context ctx = new InitialContext();
    LocalQueryProcessorHome qHome = ( LocalQueryProcessorHome )ctx.lookup( "sisped/facade/LocalQueryProcessor" );
    LocalQueryProcessor qProc = qHome.create();

    ResultSet rs = qProc.execSQLStatement( sql, null );
    ResultSetMetaData rsm = rs.getMetaData();
    BufferedWriter fw = new BufferedWriter(new FileWriter( "c:\\backup-sisped.sql" ));

    for (int i = 1 ; i <= rsm.getColumnCount() ; i++)
      fw.write(rsm.getColumnName(i) + "\t\t");
    fw.write("\n\r");

    StringBuffer linha = new StringBuffer();
    while( rs.next() ) {
      for (int i = 1 ; i <= rsm.getColumnCount() ; i++)
        linha.append(rs.getString(i) + "\t");

      fw.write( linha.toString() + "\n\r" );
      fw.flush();
      linha.setLength(0);
    }

    fw.close();
  }

}