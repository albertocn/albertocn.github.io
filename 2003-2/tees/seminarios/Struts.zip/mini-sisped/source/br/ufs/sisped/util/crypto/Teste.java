package br.ufs.sisped.util.crypto;


import java.security.MessageDigest;


public class Teste {
  public static void main( String[] args ) throws Exception {

    //doIt( "senha1234" );
    //doIt( "senha4321" );
    //doIt( "Limiar2004" );
    //doIt( "senha" );
    //doIt( "adm" );
    //doIt( "senha_De_Tamanho_Razoavel" );

    System.out.println( Base64.encodeString( "adm" ) );
  }

  /*private static void doIt(String s) throws Exception
     {
    // obtem uma instancia da classe que far� a codifica�ao do texto
    // SHA � o algoritmo que ser� usado. mais detalhes vide API.
    MessageDigest md = MessageDigest.getInstance("SHA");
    md.update( s.getBytes() );
    String stringEncriptada = Base64.encodeBytes( md.digest() );
    System.out.println( stringEncriptada );
     }
   */
}