package br.ufs.sisped.util;


import java.util.Iterator;
import br.ufs.sisped.util.crypto.Base64;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.*;


public class JSPTest {

  public static void test() {
    try {
      Pattern p = Pattern.compile( "TATA[TA]T[TA][ACTG]{10,30}TAG" );
      String str = "TATAATTAAGAAATCGATAGAAAAAATTTTTCCCCTAG";

      Matcher m = p.matcher( str );

      for( int i = 1; m.find(); i++ ) {
        System.out.println( "grupo " + i + ": " + m.group() );

      }
      System.out.println( "end" );
    } catch( Exception e ) {
      e.printStackTrace();
    }
  }


  private static String prepareParams( String sql, java.util.Collection params ) {

    if( params != null ) {
      Iterator it = params.iterator();
      for( int i = 1; it.hasNext(); i++ ) {
        Object obj = it.next();

        if( obj == null ) {
          sql = Pattern.compile( "\\?" + i ).matcher( sql ).replaceAll( "NULL" );
        } else {
          sql = Pattern.compile( "\\?" +
                i ).matcher( sql ).replaceAll( obj.toString() );
        }
      }
    }

    return sql;
  }


  public static void main( String[] args ) {

  }

}