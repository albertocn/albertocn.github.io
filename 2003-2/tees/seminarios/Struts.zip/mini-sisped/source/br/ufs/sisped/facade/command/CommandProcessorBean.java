package br.ufs.sisped.facade.command;


import javax.ejb.*;

import java.lang.reflect.Method;

import javax.naming.InitialContext;
import javax.naming.Context;
import javax.rmi.PortableRemoteObject;
import java.rmi.RemoteException;

import java.util.Map;
import java.util.Properties;

import br.ufs.sisped.util.Methods;
import br.ufs.sisped.util.timing.Timer;
import br.ufs.sisped.util.timing.Event;

import br.ufs.sisped.facade.ConfigurationLoader;
import br.ufs.sisped.facade.FacadeResponse;
import br.ufs.sisped.facade.Response;


/** Created 11/02/2003 12:16:39
 * Session Facade com a responsabilidade de centralizar os pedidos do cliente
 * e  acessar os demais servicos disponibilizados pelo SiSPED
 * @author Marcio Carvalho
 * @version 1.0
 */
public class CommandProcessorBean implements javax.ejb.SessionBean {

  private static final String APP_NAME = ConfigurationLoader.APP_NAME;

  private javax.ejb.SessionContext context;

  /**
   * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
   */
  public void setSessionContext(javax.ejb.SessionContext aContext) {
    this.context = aContext;
  }


  /**
   * @see javax.ejb.SessionBean#ejbActivate()
   */
  public void ejbActivate() {}


  /**
   * @see javax.ejb.SessionBean#ejbPassivate()
   */
  public void ejbPassivate() {}


  /**
   * @see javax.ejb.SessionBean#ejbRemove()
   */
  public void ejbRemove() {}


  /**
   * See section 7.10.3 of the EJB 2.0 specification
   */
  public void ejbCreate() {}


  /** Metodo do principal deste SessionFacade.
   * Executa metodos definidos nos SessionBeans de controle e
   * registrados no arquivo server.xml
       * @param fields Objeto Map contendo uma tupla (codigo da transacao,parametros[])
   * @return Collection de um ou mais objetos de retorno do metodo invocado.
   * Se o retorno for void, esse Collection vira null
   */
  public br.ufs.sisped.facade.Response execute(br.ufs.sisped.facade.Argument arg) {
    try {
      Timer clock = new Timer(); // Cronometro
      Event mainEvent = clock.start( "Main" );

      Event e1 = clock.startNew( mainEvent, "Localizando Transa��o..." );
      System.out.println( "[" + APP_NAME + "] Localizando Transa��o..." );

      String id = arg.getTransactionId(); //Identificador da transacao
      Object[] params = arg.getParams(); //Array contendo os argumentos do metodo

      //Configuracoes extraidas do arquivo server.xml
      Properties transaction = ( Properties )ConfigurationLoader.getMap().get( id );

      if( transaction == null ) {
        throw new Exception( "[" + APP_NAME + "] Transa��o n�o definida ou temporariamente indispon�vel: " + id );
      }

      System.out.println( "[" + APP_NAME + "] Transacao localizada: " + clock.stop( e1 ).getDuration() + " ms" );

      Event e2 = clock.startNew( mainEvent, "Preparando Transa��o..." );
      System.out.println( "[" + APP_NAME + "] Preparando Transa��o..." );

      String jndi = transaction.getProperty( "jndi" );
      String signature = transaction.getProperty( "method-name" ); //Nome do metodo mais parametros
      String factory = transaction.getProperty( "factory-class" ); //Classe Home
      String className = transaction.getProperty( "source-name" ); //Classe que declarou o metodo

      System.out.println( "[" + APP_NAME + "] Transacao: " + id );
      System.out.println( "[" + APP_NAME + "] Classe Factory: " + factory );
      System.out.println( "[" + APP_NAME + "] Classe Source: " + className );
      System.out.println( "[" + APP_NAME + "] Nome da transacao: " + signature );

      //Localizando Classe Factory
      Context ctx = new InitialContext();
      Object home = ctx.lookup( jndi );
      Object source = null;

      //Se a classe que declara o metodo eh o proprio factory
      if( className.equals( factory ) ) {
        source = home;
      } else {
        source = Methods.execMethod( home, "create()", null );

      }
      System.out.println( "[" + APP_NAME + "] Transacao preparada: " + clock.stop( e2 ).getDuration() + " ms" );

      Method method = Methods.findMethod( source, signature );

      System.out.println( "[" + APP_NAME + "] Executando transacao..." );
      Event e3 = clock.startNew( mainEvent, "Executando transacao..." );
      Object retorno = method.invoke( source, params );

      System.out.println( "[" + APP_NAME + "] Transacao " + id + " executada com sucesso: " + clock.stop( e3 ).getDuration() + " ms" );
      System.out.println( "[" + APP_NAME + "] Tempo total da transacao " + id + ": " + clock.stop( mainEvent ).getTotalTime() + " ms" );
      System.out.println( "______________________________________________________" );

      return( Response )retorno;

    } catch( Exception e ) {
      System.out.println( e.getMessage() );
      e.printStackTrace();
      return new FacadeResponse( e );
    }
  }
}