package br.ufs.sisped.util.timing;


/**
 * Title:        Marcio Utilities
 * Description:
 * Copyright:    Copyright (c) 2001
 * Company:      BANESE
 * @author Marcio Carvalho
 * @version 1.0
 */

public class Tester {

  public static void main( String args[] ) {
    Timer clock = new Timer();

    Event evento = clock.start( "Evento Principal" );

    Event e1 = clock.startNew( evento, "Teste 1" );
    for( int i = 0; i < 10000000; i++ ) {
      ;
    }
    System.out.println( clock.stop( e1 ) );

    Event e2 = clock.startNew( evento, "Teste 2" );
    for( int i = 0; i < 10000000; i++ ) {
      ;
    }

    Event e3 = clock.startNew( evento, "Teste 3" );
    for( int i = 0; i < 10000000; i++ ) {
      ;
    }
    System.out.println( clock.stop( e3 ) );

    Event e4 = clock.startNew( evento, "Teste 4" );
    for( int i = 0; i < 100000099; i++ ) {
      ;
    }
    System.out.println( clock.stop( e4 ) );
    System.out.println( "Standard Deviation: " + evento.getStandardDeviation() );

    Event e5 = clock.startNew( evento, "Teste 5" );
    for( int i = 0; i < 100000000; i++ ) {
      ;
    }
    System.out.println( clock.stop( e5 ) );
    System.out.println( "Standard Deviation: " + evento.getStandardDeviation() );
    System.out.println( "Average time: " + evento.getAverage() );

    Event e6 = clock.startNew( evento, "Teste 6" );
    for( int i = 0; i < 10000000; i++ ) {
      ;
    }
    System.out.println( clock.stop( e6 ) );

    Event e7 = clock.startNew( evento, "Teste 7" );
    for( int i = 0; i < 100000000; i++ ) {
      ;
    }
    System.out.println( clock.stop( e7 ) );

    Event e8 = clock.startNew( evento, "Teste 8" );
    for( int i = 0; i < 100000000; i++ ) {
      ;
    }
    System.out.println( clock.stop( e8 ) );

    System.out.println( clock.stop( evento ) );

    System.out.println( evento.getEventBestTime() );
    System.out.println( evento.getEventWorstTime() );
    System.out.println( "Average time: " + evento.getAverage() );
    System.out.println( "Standard Deviation: " + evento.getStandardDeviation() );
    System.out.println( "Total time: " + evento.getTotalTime() );
    System.out.println( "Numero de marcacoes: " + evento.getNumberOfChildEvents() );
  }
}