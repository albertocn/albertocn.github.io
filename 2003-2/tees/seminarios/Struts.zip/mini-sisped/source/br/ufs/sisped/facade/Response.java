package br.ufs.sisped.facade;


import java.io.Serializable;


/**
 * Title:
 * Description:
 * Copyright:    Copyright (c) 2003
 * Company:
 * @author
 * @version 1.0
 */

public interface Response extends Serializable {
  public static final byte TP_NULL = 0;
  public static final byte TP_ARRAY = 1;
  public static final byte TP_SINGLETON = 2;
  public static final byte TP_ERROR = 3;

  public byte getType();


  public Object getValue() throws Throwable;


  public Object[] getValues() throws Throwable;


  public Throwable getException();


  public boolean isNull();


  public boolean threwException();
}