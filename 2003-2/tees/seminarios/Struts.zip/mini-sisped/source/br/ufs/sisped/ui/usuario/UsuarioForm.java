package br.ufs.sisped.ui.usuario;

import org.apache.struts.action.*;
import javax.servlet.http.*;


/**
 *
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: UFS</p>
 * @author Marcio Carvalho
 * @version 1.0
 */
public class UsuarioForm extends ActionForm {

  private String id;
  private String tfCodigo;
  private String tfConfirmacao;
  private String tfMatricula;
  private String tfNome;
  private String tfRG;
  private String slSSP;
  private String tfSenha;
  private String slTipo;


  public String getId() {
    return id;
  }


  public void setId(String id) {
    this.id = id;
  }


  public String getTfCodigo() {
    return tfCodigo;
  }


  public void setTfCodigo(String cod) {
    this.tfCodigo = cod;
  }


  public String getTfConfirmacao() {
    return tfConfirmacao;
  }


  public void setTfConfirmacao(String tfConfirmacao) {
    this.tfConfirmacao = tfConfirmacao;
  }


  public String getTfMatricula() {
    return tfMatricula;
  }


  public void setTfMatricula(String tfMatricula) {
    this.tfMatricula = tfMatricula;
  }


  public String getTfNome() {
    return tfNome;
  }


  public void setTfNome(String tfNome) {
    this.tfNome = tfNome;
  }


  public String getTfRG() {
    return tfRG;
  }


  public void setTfRG(String tfRG) {
    this.tfRG = tfRG;
  }


  public String getSlSSP() {
    return slSSP;
  }


  public void setSlSSP(String slSSP) {
    this.slSSP = slSSP;
  }


  public String getTfSenha() {
    return tfSenha;
  }


  public void setTfSenha(String tfSenha) {
    this.tfSenha = tfSenha;
  }


  public String getSlTipo() {
    return slTipo;
  }


  public void setSlTipo(String slTipo) {
    this.slTipo = slTipo;
  }


  /**
   *
   * @param actionMapping
   * @param httpServletRequest
   * @return
   */
  public ActionErrors validate(ActionMapping actionMapping, HttpServletRequest httpServletRequest) {
    ActionErrors ae = new ActionErrors();

    if (tfMatricula == null || "".equals(tfMatricula)) {
      ae.add("matricula", new ActionError("usuario.error.invalid.matricula"));
    }

    if (tfSenha == null && "".equals(tfSenha)) {
      ae.add("senha", new ActionError("usuario.error.invalid.senha"));
    }

    if (!tfSenha.equals(tfConfirmacao)) {
      ae.add("confirmacao", new ActionError("usuario.error.invalid.confirmacao"));
    }

    if (!"1".equals(slTipo) && !"2".equals(slTipo)) {
      ae.add("tipo", new ActionError("usuario.error.invalid.tipo_usuario"));
    }

    if (tfNome == null && "".equals(tfNome)) {
      ae.add("nome", new ActionError("usuario.error.invalid.nome"));
    }

    if (tfRG == null && "".equals(tfRG)) {
      ae.add("rg", new ActionError("usuario.error.invalid.rg"));
    }

    if (slSSP == null && "".equals(slSSP)) {
      ae.add("rg", new ActionError("usuario.error.invalid.ssp"));
    }

    return ae;
  }


  /**
   *
   * @param actionMapping
   * @param httpServletRequest
   */
  public void reset(ActionMapping actionMapping, HttpServletRequest httpServletRequest) {
    id = null;
    tfConfirmacao = null;
    tfMatricula = null;
    tfNome = null;
    tfRG = null;
    slSSP = null;
    tfSenha = null;
    slTipo = null;
  }

}