// JavaScript Document
// Created by Thiago Silva
// Date: 01-04-2003

//---------------------------------------------------------------------------------------
function MM_reloadPage(init) {  //reloads the window if Nav4 resized
  if (init==true) with (navigator) {if ((appName=="Netscape")&&(parseInt(appVersion)==4)) {
    document.MM_pgW=innerWidth; document.MM_pgH=innerHeight; onresize=MM_reloadPage; }}
  else if (innerWidth != document.MM_pgW || innerHeight!=document.MM_pgH) location.reload();
}

MM_reloadPage(true);

//---------------------------------------------------------------------------------------

function MM_findObj(n, d) { 
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_showHideLayers() {
  var i, p, v, obj, args = MM_showHideLayers.arguments;
  for (i = 0 ; i < (args.length-2) ; i += 3) 
    if ((obj = MM_findObj(args[i])) != null) { 
	  v=args[i+2];
      if (obj.style) { obj=obj.style; v=(v=='show')?'visible':(v=='hide')?'hidden':v; }
      obj.visibility=v; 
	}
}

//---------------------------------------------------------------------------------------

function hideAll() { // esconde todas as camadas-submenus
  MM_showHideLayers('ContPac','','hide');
  MM_showHideLayers('ContQuest','','hide');
  MM_showHideLayers('ContLaudos','','hide');
  MM_showHideLayers('Estatistica','','hide');
  MM_showHideLayers('ContUsuario','','hide');
  MM_showHideLayers('ContPosto','','hide');
}

//--> alterando cores no menu

function markMenu(o) {
  o.style.backgroundColor='#ff8800' 
} 
function unmarkMenu(o) {
  o.style.backgroundColor='#003366' 
}

//-------------------------------------------------------------------------------------