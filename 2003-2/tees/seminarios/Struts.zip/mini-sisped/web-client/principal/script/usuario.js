//----Validacao do formulario

function validarFormUsuario() {
  var validity = true; // assume valid

  if (validity && isNULL(document.frmUsuario.tfMatricula.value) != 0) {
    validity = false;
	  alert('O campo Matr�cula � obrigat�rio, n�o pode ficar vazio.');
	  document.frmUsuario.tfMatricula.focus();
  }

  if (validity && isNULL(document.frmUsuario.tfPostoSaude.value) != 0) {
    validity = false;
	  alert('O campo Posto de Sa�de � obrigat�rio, n�o pode ficar vazio.');
	  document.frmUsuario.tfPostoSaude.focus();
  }


  if (validity && isNULL(document.frmUsuario.tfSenha.value) != 0) {
    validity = false;
	  alert('O campo Senha � obrigat�rio, n�o pode ficar vazio.');
	  document.frmUsuario.tfSenha.focus();
  }

  if (validity && isNULL(document.frmUsuario.tfConfirmacao.value) != 0) {
    validity = false;
	  alert('O campo Confirma��o � obrigat�rio, n�o pode ficar vazio.');
	  document.frmUsuario.tfConfirmacao.focus();
  }

  if (validity && isNULL(document.frmUsuario.tfNome.value) != 0) {
    validity = false;
	  alert('O campo Nome � obrigat�rio, n�o pode ficar vazio.');
  	document.frmUsuario.tfNome.focus();
  }

  if (validity && isNULL(document.frmUsuario.tfRG.value) != 0) {
    validity = false;
	  alert('O campo RG � obrigat�rio, n�o pode ficar vazio.');
	  document.frmUsuario.tfRG.focus();
  }

  if (validity && !isNUMB(limpar(document.frmUsuario.tfRG.value))) {
    validity = false;
	  alert('O campo RG deve ser preenchido apenas com n�meros.');
	  document.frmUsuario.tfRG.focus();
  }


  if (validity && !checkPasswd()) {
    validity = false;
    alert ("A senha informada e a confirma��o n�o correspondem. Por favor digite novamente.");
	  document.frmUsuario.tfSenha.focus();
  }

  return validity;
}


function callPosto() {
  return window.open("../posto/listPosto.jsp", "", "HEIGHT=400,WIDTH=600,STATUS=yes,TOOLBAR=no,MENUBAR=no,LOCATION=no");
}


function validarFormSenha() {
  var validity = true; // assume valid

  if (validity && isNULL(document.frmUsuario.tfSenha.value) != 0) {
    validity = false;
	  alert('O campo Senha � obrigat�rio, n�o pode ficar vazio.');
	  document.frmUsuario.tfSenha.focus();
  }

  if (validity && isNULL(document.frmUsuario.tfOldSenha.value) != 0) {
    validity = false;
	  alert('O campo Senha Atual � obrigat�rio, n�o pode ficar vazio.');
	  document.frmUsuario.tfOldSenha.focus();
  }

  if (validity && !checkPasswd()) {
    validity = false;
    alert ("A senha informada e a confirma��o n�o correspondem. Por favor digite novamente.");
	  document.frmUsuario.tfSenha.focus();
  }

  if (validity && isNULL(document.frmUsuario.tfConfirmacao.value) != 0) {
    validity = false;
	  alert('O campo Confirma��o � obrigat�rio, n�o pode ficar vazio.');
	  document.frmUsuario.tfConfirmacao.focus();
  }

  return validity;
}


function validarConsulta() {
  if (isNULL(document.frmList.tfValue.value) != 0) {
    alert("� preciso informar um valor para a busca.");
	  document.frmList.tfValue.focus();
    return false;
  } else return true;
}


function confirmaExclusao() {
  if (confirm('Deseja realmente excluir o usu�rio atual? Se sim, clique em OK, se n�o, clique em Cancelar.'))
    return true;
  else return false;
}


function isNULL(c)	{
	// Fun��o para verifi��o se o valor � vazio ou s� contenha espa�os
  if(c == "") {
    return(1);			// retorna 1 (true) se for vazio
  }	else {
    var pos = 0;
	  while(c.charAt(pos) == " ")	{
      if(pos == c.length-1)	{
        return(1);			// retorna 1 (true) se apenas tiver espa�os em branco
	  }
	  pos++;
	}
	  return(0);			// retorna 0 (false) se for um valor n�o vazio (ou n�o nulo)
  }
}


function isNUMB(c) {
// Fun��o para verifica��o de um valor num�rico v�lido
  if((pos = c.indexOf("-")) != -1) {
	  c = c.substring(0, pos) + "." + c.substring(pos + 1);
  }

  if((parseFloat(c) / c != 1)) {
    if(parseFloat(c) * c == 0) {
	    return(1);
    } else {
      return(0);			// retorna 0 (false) se n�o for um valor num�rico v�lido
    }
  }	else {
	  return(1);			// retorna 1 (true) se for um valor num�rico v�lido
  }
}


function checkPasswd() {
  var pw1 = document.frmUsuario.tfSenha.value;
  var pw2 = document.frmUsuario.tfConfirmacao.value;

  if (pw1 != pw2)
    return false;
  else return true;
}


function limpar(c) {
  // Fun��o que retorna como resultado um valor sem s�mbolos auxiliares, como a barra
  var pos;
  var s = new Array();			// define uma matriz com os s�mbolos que ser�o eliminados
  s[0] = "-"; s[1] = "/"; s[2] = ","; s[3] = "."; s[4] = "("; s[5] = ")"; s[6] = " ";

  for(var x = 0; x < s.length ; x++) {
	  while((pos=c.indexOf(s[x])) != -1) {
      c = c.substring(0, pos) + c.substring(pos+1);
	  }
  }

  return(c);			// retorna o valor sem os s�mbolos
}