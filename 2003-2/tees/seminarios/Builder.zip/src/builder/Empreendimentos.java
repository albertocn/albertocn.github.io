package builder;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.Vector;


public class Empreendimentos extends JFrame{

  private List ListaEstocagem;
  private JPanel choicePanel;
  private Vector Companhia;
  private Vector Investimentos;
  private Vector Contratos;
  private MultiChoice mchoice;
  private ChoiceBuilder cfact; //O Builder

  public Empreendimentos(){
    super("Investimentos");
    setGUI();
    buildStockLists();
    cfact = new ChoiceBuilder();
  }
//----------------------------------
  private void setGUI(){
    getContentPane().setLayout(new BorderLayout());
    JPanel p = new JPanel();
    getContentPane().add("Center", p);
    p.setLayout(new GridLayout(1, 2));
    ListaEstocagem = new List(10);
    ListaEstocagem.addActionListener(new ActionListener (){
         public void actionPerformed(ActionEvent e) {
           stockList_Click();
         }
    });
    p.add(ListaEstocagem);
    ListaEstocagem.add("Estocagem");
    ListaEstocagem.add("Contratos");
    ListaEstocagem.add("Companhia de Investimentos");

    JPanel p1 = new JPanel();
    p1.setBackground(Color.lightGray);
    getContentPane().add("South", p1);

    choicePanel = new JPanel();
    choicePanel.setBackground(Color.lightGray);
    p.add(choicePanel);
    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent evt){
        System.exit(0);
      }
    });
    setBounds(100, 100, 400, 250);
    setVisible(true);
    }

    private void buildStockLists() {

      Investimentos = new Vector();
      Investimentos.addElement("GBarbosa");
      Investimentos.addElement("Serigy");
      Investimentos.addElement("Bom Pre�o");
      Investimentos.addElement("Prado Vasconcelos");

      Contratos = new Vector();
      Contratos.addElement("Moinho Sergipe");
      Contratos.addElement("Petrobras");
      Contratos.addElement("Nitrofertil");

      Companhia = new Vector();
      Companhia.addElement("Bradesco Seguros");
      Companhia.addElement("Ita� Seguros");
      Companhia.addElement("Ouro Cap");
      Companhia.addElement("caixa Universit�rio");

    }

    private void stockList_Click() {

     Vector v = null;
     int index = ListaEstocagem.getSelectedIndex();
     choicePanel.removeAll();
     /**
      * Remove o previo painel UI deste que troca entre 3 diferentes vetores
      * e passa um seleciona por voc� para o padrao Builder
      */
     switch(index) {
       case 0:
         v = Investimentos; break;
       case 1:
         v = Contratos; break;
       case 2:
         v = Companhia;
       }
       mchoice = cfact.getChoiceUI(v); //pega um dos UIs
       choicePanel.add(mchoice.getUI()); //insere no painel direito
       choicePanel.validate(); //refaz e exibe

    }


}