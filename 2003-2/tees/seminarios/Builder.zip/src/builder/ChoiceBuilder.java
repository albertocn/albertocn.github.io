package builder;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.util.Vector;

public class ChoiceBuilder {

  private MultiChoice ui;

  /**
   * Esta classe retorna o painel cantendo um conjunto de paineis escolhidos
   * por um de varios m�todos UI.
   * @param choices
   * @return
   */

  public MultiChoice getChoiceUI(Vector choices){
    if(choices.size() <= 3){
      ui = new CheckBoxChoice(choices);
    }
    else {
      ui = new ListboxChoice(choices);
    }
    return ui;
  }

}
