package builder;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class ChoiceFrame{
  public ChoiceFrame() {
    Empreendimentos empreendimentos = new Empreendimentos();
    empreendimentos.show();
  }

  public static void main(String[] args) {
    new ChoiceFrame();
  }

}