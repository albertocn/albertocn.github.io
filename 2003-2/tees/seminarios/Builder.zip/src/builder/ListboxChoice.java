package builder;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import javax.swing.JPanel;
import java.util.Vector;
import java.awt.List;

public class ListboxChoice extends MultiChoice{

  private List list;

  public ListboxChoice(Vector choices){
    super(choices);
  }

  public JPanel getUI(){
    /**
     * Cria um panel contendo um listbox
     */
    JPanel p = new JPanel();
    list = new List(choices.size());
    list.setMultipleMode(true);
    p.add(list);
    /**
     * Adiciona Investimentos no listbox
     */
    for (int i = 0; i < choices.size(); i++){
      list.addItem( (String) choices.elementAt(i));
    }
    return p; //retorno do painel
  }

  public String[] getSelected(){
    int count = 0;
    for (int i=0; i < list.getItemCount(); i++ ){
      if (list.isIndexSelected(i))
        count++;
    }
    /**
     * Cria um array de string grande o bastante para os selecionados
     */
    String[] slist = new String[count];
    /**
     * Copia a lista de elementos dentro do array de strings
     */
    int j = 0;
    for (int i=0; i < list.getItemCount(); i++ ){
      if (list.isIndexSelected(i)){
        slist[j++] = list.getItem(i);
      }
    }
    return(slist);
  }

  public void clearAll(){
    //N�o fazer nada
  }
}