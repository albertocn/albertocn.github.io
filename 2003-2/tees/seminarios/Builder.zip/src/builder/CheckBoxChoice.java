package builder;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import java.awt.GridLayout;
import javax.swing.JPanel;
import javax.swing.JCheckBox;
import javax.swing.JTextArea;
import java.util.Vector;
import java.awt.List;

public class CheckBoxChoice extends MultiChoice{

  private int count;
  private JPanel p;
  private List list;

  public CheckBoxChoice(Vector choices){
    super(choices);
    count = 0;
    p = new JPanel();
  }

  public JPanel getUI(){
    String s;
    /**
     * Cria um grid layout de 1 coluna e n linhas
     */
    p.setLayout(new GridLayout(choices.size(), 1));
    /**
     * e adiciona um check box nele
     */
    for (int i = 0; i < choices.size(); i++){
      s = (String)choices.elementAt(i);
      p.add(new JCheckBox(s));
      count++;
    }
    return p;
  }

  public String[] getSelected(){
    int count = 0;
    for (int i=0; i < list.getItemCount(); i++ ){
      if (list.isIndexSelected(i))
        count++;
    }
    /**
     * Cria uma array string muito grande para oa selecionados
     */
    String[] slist = new String[count];
    /**
     * copia uma lista de elementos dentro do array string
     */
    int j = 0;
    for (int i = 0; i < list.getItemCount(); i++ ){
      if (list.isIndexSelected(i)){
        slist[j++] = list.getItem(i);
      }
    }
    return(slist);
  }

  public void clearAll(){
    /**
     * N�o fazer nada
     */
  }
}