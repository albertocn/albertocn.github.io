package builder;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import javax.swing.JPanel;
import java.util.Vector;

//Representa o participante Builder

public abstract class MultiChoice {
  //Esta � a classe base abstrata
  //que os paineis listbox e checkbox
  //sao derivados
  Vector choices; //array de nomes
  //--------------------------------------------
  public MultiChoice(Vector choiceList){
    choices = choiceList; //save list
  }
  //retorna o painel de componentes
  abstract public JPanel getUI();
  //pega a lista de itens
  abstract public String[] getSelected();
  //Limpa sele�oes
  abstract public void clearAll();
}