package fmttitulo;

class Contexto
{
   private Formatador formatador;

   public Contexto(Formatador formatador){
     this.formatador = formatador;
   }

   public String[] formatTitulo(String[] titulos)
   {
       String[] formatado = new String[titulos.length];
       for (int i = 0; i < titulos.length; i++)
       {
           formatado[i] = formatador.formatTitulo(titulos[i]);
           System.out.println("Antes de Formatar: " + titulos[i]);
           System.out.println("Ap�s Formata��o:  " + formatado[i]);
           System.out.println("--------------------------------------------------");
       }
       return formatado;
   }
}
