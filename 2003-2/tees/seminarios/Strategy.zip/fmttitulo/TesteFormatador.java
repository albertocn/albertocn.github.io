package fmttitulo;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.IOException;
import java.lang.StringIndexOutOfBoundsException;

class TesteFormatador {

   public static void main(String[] args){
     String titulos[] = new String[10];
     titulos[0] = "Revela��es * 11h30F - 14h - 16h30 - 19h - 21h30 - 00h20C";
     titulos[1] = "Xuxa Abracadabra * 12h20F - 14h40 - 16h50";
     titulos[2] = "O Sorriso de Monalisa * 12h20F - 14h40 - 16h50";
     titulos[3] = "O Senhor dos An�is * 21h40";
     titulos[4] = "Um Show de Ver�o * 11h10F - 13h20 - 15h40 - 18h20";
     titulos[5] = "Doze � Demais * 17h20";
     titulos[6] = "Mans�o Mal Assombrada * 13h - 15h10";
     titulos[7] = "Adeus Lenin * 19h30 - 22h10";
     titulos[8] = "Sexo, Amor e Trai��o * 19h40 - 21h50 - 00h10C";
     titulos[9] = "O �ltimo Samurai * 13h50 - 17h10 - 20h30 - 23h40C";

     try{
        BufferedReader br = new BufferedReader( new InputStreamReader( System.in ) );
        System.out.print("Digite Codigo da Strategy de formata��o:\n"+
                         "1 - HoraFormat \n" + "2 - SessoesFormat\n" +
                         "3 - LowerCaseFormat\n" + "4 - CapsLockFormat \n\n C�digo: ");
        String s = br.readLine();
        Contexto contexto;
        switch (s.charAt(0)){
           case '1' : contexto = new Contexto(new HoraFormat()); break;
           case '2' : contexto = new Contexto(new SessoesFormat()); break;
           case '3' : contexto = new Contexto(new LowerCaseFormat()); break;
           case '4' : contexto = new Contexto(new CapsLockFormat()); break;
           default  : contexto = new Contexto(new HoraFormat());
       }
       String[] formatado = contexto.formatTitulo(titulos);
     }
     catch (IOException e) {
     }
     catch (StringIndexOutOfBoundsException er){
       System.out.println("N�o escolheu nenhuma Strategy!");
     }
   }
}
