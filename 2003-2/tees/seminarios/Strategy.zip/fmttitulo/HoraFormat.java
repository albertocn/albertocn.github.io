package fmttitulo;

public class HoraFormat extends Formatador{
  public String formatTitulo(String titulo) {
    int indice = titulo.indexOf('*') ;
    String filme = titulo.substring(0,indice - 1 );
    String horario = titulo.substring((indice + 1), (titulo.length()));
    return (filme + " * " + horario.replace('h', ':'));

  }
}
