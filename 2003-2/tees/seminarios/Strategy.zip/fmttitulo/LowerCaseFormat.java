package fmttitulo;

class LowerCaseFormat extends Formatador{
  public String formatTitulo(String titulo){
      return titulo.toLowerCase();
  }

}