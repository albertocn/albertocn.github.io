package fmttitulo;


public abstract class Formatador
{
   public abstract String formatTitulo(String titulo);
}
