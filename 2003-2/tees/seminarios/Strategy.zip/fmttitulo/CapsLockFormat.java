package fmttitulo;

public class CapsLockFormat extends Formatador{
   public String formatTitulo(String titulo){
       return titulo.toUpperCase();
   }
}
