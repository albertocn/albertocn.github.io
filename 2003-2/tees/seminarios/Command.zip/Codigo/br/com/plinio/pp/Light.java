package br.com.plinio.pp;

// Receiver
// Um Objeto que representar� uma LUZ que tem fun��es de ligar e desligar
public class Light {

	// Uma fun��o qualquer no objeto que tem um comportamento de UP
	public void turnOn() {
		System.out.println("Light is on ");
	}

	//	Uma fun��o qualquer no objeto que tem um comportamento de DOWN
	public void turnOff() {
		System.out.println("Light is off");
	}
}
