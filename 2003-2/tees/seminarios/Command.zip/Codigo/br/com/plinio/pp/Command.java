package br.com.plinio.pp;
/**
 * @author plinio
 */
public interface Command {
	
		public abstract void execute ( );
		
}