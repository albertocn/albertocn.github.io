package br.com.plinio.pp;

// Receiver
// Um Objeto que representar� uma LUZ que tem fun��es de ligar e desligar
public class Fan {

	//	Uma fun��o qualquer no objeto que tem um comportamento de UP
	public void startRotate() {
		System.out.println("Fan is rotating");
	}

	//	Uma fun��o qualquer no objeto que tem um comportamento de DOWN
	public void stopRotate() {
		System.out.println("Fan is not rotating");
	}
}
