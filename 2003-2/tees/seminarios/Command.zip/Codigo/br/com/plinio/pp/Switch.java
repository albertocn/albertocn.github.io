package br.com.plinio.pp;

// Funciona como um Invoker
public class Switch {
	
	private Command UpCommand, DownCommand;

	// Construtor que receber� a implementa��o dos Executes
	public Switch(Command Up, Command Down) {
		UpCommand = Up;    // Um Command implementado 
		DownCommand = Down;
	}

	public void flipUp() { // Metodo que chamar� a implementa��o do Execute para esta Chamada 
		UpCommand.execute();

	}

	public void flipDown() { // Metodo que chamar� a implementa��o do Execute para esta Chamada
		DownCommand.execute();
	}
	
}
