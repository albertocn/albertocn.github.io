package br.com.plinio.pp;

/**
 * @author Plinio Santos Bomfim
 *
 */

public class CommandTeste {
	public static void main(String[] args) {
		
		Light testLight = new Light(); // Criou um objeto que simular� uma l�mpada que liga e desliga
		
		LightOnCommand testLOC = new LightOnCommand(testLight); // Instancia uma implementa��o de um execute
		LightOffCommand testLFC = new LightOffCommand(testLight); // Instancia uma implementa��o de um execute
		
		Switch lightSwitch = new Switch(testLOC, testLFC); // Instancia uma Switch definido a implementa��o que vai usar
		
		lightSwitch.flipUp(); // Utiliza as fun��es padr�o sem se importar com a forma de executar
		lightSwitch.flipDown();
		lightSwitch.flipUp();
		
		Fan testFan = new Fan();
		
		FanOnCommand foc = new FanOnCommand(testFan);
		FanOffCommand ffc = new FanOffCommand(testFan);
		
		Switch fanSwitch = new Switch(foc, ffc);
		
		fanSwitch.flipUp();
		fanSwitch.flipDown();
	}
}
