package br.com.plinio.pp;

public class LightOnCommand implements Command {
	
	private Light myLight;

	// Construtor que inicia luz ligada
	public LightOnCommand(Light L) {
		myLight = L;
	}
	
	// Implementa��o do Execute da Interface Command
	public void execute() {
		myLight.turnOn();
	}
}
