package br.com.plinio.pp;

public class LightOffCommand implements Command {

	private Light myLight;

	//	Construtor que inicia luz desligada
	public LightOffCommand(Light L) {
		myLight = L;
	}
	
	//	Implementa��o do Execute da Interface Command
	public void execute() {
		myLight.turnOff();
	}
}