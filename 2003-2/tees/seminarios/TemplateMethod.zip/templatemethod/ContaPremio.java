package templatemethod;

/**
 * Classe concreta que implementa o m�todo abstrato de c�lculo de Juros e redefine
 * o m�todo gancho de c�lculo de taxas
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */

public class ContaPremio extends Conta {

  /**
   * Construtor padr�o que invoca o da superclasse
   */
  public ContaPremio(String cliente, double saldo, int anoAbertura) {
    super(cliente, saldo, anoAbertura);
  }

  /**
   * Calcula o juros de acordo com o ano de abertura, para contas abertas antes
   * de 1950 o juros � de 50%, para contas abertas entre 1950 e 1989 o juros �
   * de 30% e para contas abertas entre 1990 e 2000 o juros � de 10%.
   */
  public double DoCalculoJuros() {
    double juros = 0;
    if (getAnoAbertura() < 1950) //Reajuste de 50%
      juros = 0.5;
    else
    if (getAnoAbertura() >= 1950 && getAnoAbertura() < 1990) //Reajuste de 30%
      juros = 0.3;
    else
    if (getAnoAbertura() >= 1990 && getAnoAbertura() < 2000) //Reajuste de 10%
      juros = 0.1;
    return juros;
  }

  /**
     * Calcula da taxa de manuten��o da conta de acordo com o ano de abertura,
     * para contas abertas antes de 1950 a taxa � de 10%, para contas abertas
     * entre 1950 e 1989 a taxa � de 5% e para contas abertas entre 1990 e 2000
     * a taxa � de 1%.
     */
  public double DoCalculaTaxa() {
    double taxa = 0;
    if (getAnoAbertura() < 1950) //Taxa de 10%
      taxa = 0.1;
    else
    if (getAnoAbertura() >= 1950 && getAnoAbertura() < 1990) //Taxa de 5%
      taxa = 0.05;
    else
    if (getAnoAbertura() >= 1990 && getAnoAbertura() < 2000) //Taxa de 1%
      taxa = 0.01;
    return taxa;
  }

}