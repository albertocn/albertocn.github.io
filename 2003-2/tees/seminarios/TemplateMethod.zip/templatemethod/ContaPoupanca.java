package templatemethod;

/**
 * Classe concreta que implementa o m�todo abstrato de c�lculo de Juros
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */

public class ContaPoupanca extends Conta{

  public ContaPoupanca(String cliente, double saldo, int anoAbertura) {
    super(cliente, saldo, anoAbertura);
  }

  /**
   * C�lculo de Juros fixos para qualquer conta
   *
   */
  public double DoCalculoJuros() {
    return 0.02;                   //Juros fixo da poupanca
  }
}