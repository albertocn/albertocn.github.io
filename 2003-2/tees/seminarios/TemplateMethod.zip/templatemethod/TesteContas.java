package templatemethod;

/**
 * Classe que testa as reajustes e cobrancas de taxas nas classes conta
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */

public class TesteContas {
  Conta contas[] = new Conta[6];

  public TesteContas() {
    contas[0] = new ContaPoupanca("Sr. Alberto", 1000.00, 1940);
    contas[1] = new ContaPoupanca("D. Maria   ", 2000.00, 1970);
    contas[2] = new ContaPoupanca("Marcos     " ,3000.00, 1990);


    contas[3] = new ContaPremio("Sr. Alberto", 1000.00, 1940);
    contas[4] = new ContaPremio("D. Maria   ", 2000.00, 1970);
    contas[5] = new ContaPremio("Marcos     " ,3000.00, 1990);

    for (int i = 0; i < contas.length; i++) {
      System.out.println(contas[i]);
    }

    //Faz o reajuste das contas de poupanca
    System.out.println("\nREAJUSTE DE CONTAS POUPANCA");
    for (int i = 0; i < 3; i++) {
      contas[i].reajustarConta();
      System.out.println(contas[i]);
    }

    //Fas o reajuste das contas premio
    System.out.println("\nREAJUSTE DE CONTAS PREMIO");
    for (int i = 3; i < 6; i++) {
      contas[i].reajustarConta();
      System.out.println(contas[i]);
    }

    //Faz a cobran�a de taxa das contas de poupanca
    System.out.println("\nCOBRANCA DE TAXAS DE CONTAS POUPANCA");
    for (int i = 0; i < 3; i++) {
      contas[i].cobrarTaxas();
      System.out.println(contas[i]);
    }

    //Faz a cobran�a de taxa das contas premio
    System.out.println("\nCOBRANCA DE TAXAS DE CONTAS PREMIO");
    for (int i = 3; i < 6; i++) {
      contas[i].cobrarTaxas();
      System.out.println(contas[i]);
    }

  }

  public static void main(String[] args) {
    TesteContas testeContas1 = new TesteContas();
  }
}