package templatemethod;

/**
 * Classe abstrata que define o m�todo template
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */

public abstract class Conta {

  private double saldo;
  private String cliente;
  private int anoAbertura;

  /**
   * Construtor padr�o
   * @param cliente � o nome do cliente
   * @param saldo � o valor que o cliente possui na conta
   * @param anoAbertura � o ano que o cliente abriu a conta no banco
   */
  public Conta(String cliente, double saldo, int anoAbertura) {
    this.cliente = cliente;
    this.saldo = saldo;
    this.anoAbertura   = anoAbertura;
  }

  //M�todos GET
  public double getSaldo() { return saldo; }
  public String getCliente() { return cliente; }
  public int getAnoAbertura() { return anoAbertura; }

  /**
   * Modifica o saldo da conta
   */
  public void setSaldo(double novoSaldo) { saldo = novoSaldo; }

  /**
   * M�todo abstrato que deve ser implementado pelas subclasse e retorna o valor
   * do juros que ser� aplicado quando um reajuste de contas for realizado.
   */
  public abstract double DoCalculoJuros();


  /**
   * M�todo gancho que pode ser redefinido pelas suas sublclasses se necess�rio
   */
  public double DoCalculaTaxa(){
    return 0;
  }


  /**
   * M�todo Template que invoca opera��es primitivas da classe e opera��es
   * abstratas que devem ser redefinidas pelas subclasses.
   */
  public final void reajustarConta(){
    double novoSaldo = getSaldo() + ( getSaldo() * DoCalculoJuros() );
    setSaldo( novoSaldo );
  }

  /**
   * M�todo Template que invoca opera��es primitivas da classe e opera��es
   * gancho que podem ser redefinidas pelas subclasses.
   */
  public final void cobrarTaxas(){
    double novoSaldo = getSaldo() - ( getSaldo() * DoCalculaTaxa() );
    setSaldo( novoSaldo );
  }

  public String toString() {
    return "Cliente: "+getCliente() + "  " +
           "Ano Abertura: "+ getAnoAbertura() +"  "+
           "Saldo: " + getSaldo();
  }
}