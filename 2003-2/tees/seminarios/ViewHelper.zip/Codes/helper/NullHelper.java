package br.ufs.periodont.ui.helper;

import javax.servlet.http.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class NullHelper extends Helper {

  public static NullHelper getInstance() {
    return instance;
  }

  private static NullHelper instance = new NullHelper();


  private NullHelper() {}

  public void processar(HttpServletRequest request) throws Throwable {
    //n�o faz nada
  }

}