package br.ufs.periodont.ui.helper;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

import br.ufs.periodont.ui.ViewController;
import br.ufs.periodont.data.paciente.PacienteDAO;
import br.ufs.periodont.data.cor.CorDAO;
import br.ufs.periodont.data.NivelInstrucao.NivelInstrucaoDAO;
import br.ufs.periodont.data.estadoCivil.EstadoCivilDAO;
import br.ufs.periodont.facade.Argument;
import br.ufs.periodont.facade.Response;


public class ProcessaInserirPaciente {

  public static final int PARAMCOR = 0;
  public static final int PARAMESTCIVIL = 1;
  public static final int PARAMNIVEL = 2;

  public ProcessaInserirPaciente() {
  }

  public static Object[] retornaLista ( int param ) throws Throwable {


    Object[] params = new Object[] {new Integer(param)};

    try {
      Argument arg = ViewController.prepareCommand("tr28", params);
      Response r = ViewController.execute(arg);
      if (r.getType() != r.TP_ERROR) {
        switch (param) {
            case PARAMCOR :      return (CorDAO[]) r.getValues();
            case PARAMESTCIVIL : return (EstadoCivilDAO[]) r.getValues();
            case PARAMNIVEL :    return (NivelInstrucaoDAO[]) r.getValues();
            default :            return null;
        }
      }else throw r.getException();
    } catch(Exception ex) {
      System.out.println("[PERIODONT - AltRemPaciente.jsp] : Erro na pagina");
      //application.log("Erro na pagina AltRemPaciente.jsp", ex);
      throw ex;
    }

  }

}