package br.ufs.periodont.ui.helper;

import javax.servlet.http.*;
import java.sql.Timestamp;
import br.ufs.periodont.data.paciente.PacienteDAO;
import br.ufs.periodont.util.BRDate;

import br.ufs.periodont.ui.pacientes.Pacientes;


/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class CadastrarPacienteHelper extends Helper {

  private static final String PARAMCOR = "vCor";
  private static final String PARAMESTADOCIVIL = "vEstadoCivil";
  private static final String PARAMNIVELINSTRUCAO = "vNivelInstrucao";
  private static final String PARAMCODPAI = "vCodPai";
  private static final String PARAMCODMAE = "vCodMae";
  private static final String PARAMNOME = "vNome";
  private static final String PARAMSEXO = "vSexo";
  private static final String PARAMNASCIMENTO = "vNascimento";
  private static final String PARAMNATURALIDADE = "vNaturalidade";
  private static final String PARAMNACIONALIDADE = "vNacionalidade";
  private static final String PARAMIDENTIDADE = "vIdentidade";
  private static final String PARAMCPF = "vCPF";
  private static final String PARAMPROFISSAO = "vProfissao";
  private static final String PARAMNOMEPAI = "vNomePai";
  private static final String PARAMNOMEMAE = "vNomeMae";
  private static final String PARAMEMAIL = "vEmail";

  private static final String ATTPACIENTE = "pacienteObj";

  public CadastrarPacienteHelper() {}

  public void processar(HttpServletRequest request) throws Throwable {
    long codCor;
    long codEstCiv;
    long codNivInst;
    long codCodPai;
    long codCodMae;
    codCor = (request.getParameter(PARAMCOR).equals("null"))? -1 : Long.parseLong(request.getParameter(PARAMCOR),10);
    codEstCiv = (request.getParameter(PARAMESTADOCIVIL).equals("null"))? -1 : Long.parseLong(request.getParameter(PARAMESTADOCIVIL),10);
    codNivInst = (request.getParameter(PARAMNIVELINSTRUCAO).equals("null"))? -1 : Long.parseLong(request.getParameter(PARAMNIVELINSTRUCAO),10);
    codCodPai = (request.getParameter(PARAMCODPAI).equals(""))? -1 : Long.parseLong(request.getParameter(PARAMCODPAI),10);
    codCodMae = (request.getParameter(PARAMCODMAE).equals(""))? -1 : Long.parseLong(request.getParameter(PARAMCODMAE),10);
    PacienteDAO newPaciente = new PacienteDAO( -1,
                                              request.getParameter(PARAMNOME),
                                              new Timestamp( (new BRDate(request.getParameter(PARAMNASCIMENTO))).getTime()),
                                              request.getParameter(PARAMSEXO),
                                              codCor,
                                              codEstCiv,
                                              codNivInst,
                                              request.getParameter(PARAMNATURALIDADE),
                                              request.getParameter(PARAMNACIONALIDADE),
                                              request.getParameter(PARAMIDENTIDADE),
                                              request.getParameter(PARAMCPF),
                                              request.getParameter(PARAMPROFISSAO),
                                              codCodPai,
                                              request.getParameter(PARAMNOMEPAI),
                                              codCodMae,
                                              request.getParameter(PARAMNOMEMAE),
                                              request.getParameter(PARAMEMAIL),
                                              -1,
                                              null);
   PacienteDAO paciente = Pacientes.insertPaciente(newPaciente);
   HttpSession session = request.getSession();
   session.setAttribute(ATTPACIENTE, paciente);


  }

}