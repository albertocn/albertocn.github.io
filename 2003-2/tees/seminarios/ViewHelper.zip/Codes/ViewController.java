package br.ufs.periodont.ui;



import java.lang.String;



import java.util.Collection;

import java.util.ArrayList;

import java.util.Properties;

import java.util.Arrays;

import javax.naming.NamingException;



import br.ufs.periodont.facade.QueryProcessor;

import br.ufs.periodont.facade.QueryProcessorHome;

import br.ufs.periodont.facade.CommandProcessor;

import br.ufs.periodont.facade.CommandProcessorHome;

import br.ufs.periodont.facade.Argument;

import br.ufs.periodont.facade.Response;

import br.ufs.periodont.facade.FacadeResponse;



import br.ufs.periodont.util.sql.ResultProcessor;





/** Created on 14 de Fevereiro de 2003, 12:26

 * Classe responsavel pela conversacao com o Session Facade CommandProcessor

 * @author Marcio Carvalho

 */

public class ViewController {



  private static final String JNDI_COMMAND_NAME;

  private static final String JNDI_QUERY_NAME;



  private static javax.naming.Context ctx = null;



  //Inicializador de Classe

  static {

    Properties p = new Properties();



    try {

      p.load(ViewController.class.getResourceAsStream("ui.properties"));

      ctx = new javax.naming.InitialContext(p);

    } catch(Exception e) {

      System.out.println("[PERIODONT - ViewController] Carregando propriedades padroes..");

      e.printStackTrace();

      p.setProperty("jndi-command-name", "periodont/facade/CommandProcessor");

      p.setProperty("jndi-query-name", "periodont/facade/QueryProcessor");

    } finally {

      JNDI_COMMAND_NAME = p.getProperty("jndi-command-name");

      JNDI_QUERY_NAME = p.getProperty("jndi-query-name");

    }

  }





  /** Creates a new instance of ViewController */

  protected ViewController() {}





  /** Invoca o Session Facade CommandProcessor e solicita a execucao da

   * transacao encapsulada em fields.

   * @param fields Map contendo codigo da transacao eparametros

   * @return Collection

   * @throws Exception Erro de Execucao da transacao

   */

  public static Response execute(Argument arg) throws java.lang.Throwable {

    String transId = arg.getTransactionId();



    try {

      System.out.println("[PERIODONT - ViewController] Localizando Session Facade...");



      CommandProcessorHome procHome = (CommandProcessorHome) ctx.lookup(JNDI_COMMAND_NAME);



      System.out.println("[PERIODONT - ViewController] Session Facade localizado...");



      CommandProcessor commProc = procHome.create();



      System.out.println("[PERIODONT - ViewController] Preparando para executar transacao " + transId + " ...");



      Response ret = commProc.execute(arg);



      if (ret.threwException())

        throw ret.getException();



      System.out.println("[PERIODONT - ViewController] Transacao " + transId + " executada com sucesso...\n");



      return ret;

    } catch(Throwable ex) {

      System.out.println("[PERIODONT - ViewController] Erro inesperado ao executar transacao " + transId + ": " + ex.getMessage() + "\n");

      throw ex;

    }



  }





  /** Executa um comando SQL baseado no codigo do comando informado

   * @param commId Codigo do comando SQL.

   * @param params Array de parametros para o comando

   * @return ResultSet

   * @throws Exception Erro de SQL

   */

  public static java.sql.ResultSet execSQL(java.lang.String commId, java.lang.Object[] params) throws Exception {

    try {

      System.out.println("[PERIODONT - ViewController] Localizando Query Session Facade...");



      QueryProcessorHome qprocHome = (QueryProcessorHome)ctx.lookup(JNDI_QUERY_NAME);



      System.out.println("[PERIODONT - ViewController] Query Session Facade localizado...");



      QueryProcessor qProc = qprocHome.create();



      System.out.println("[PERIODONT - ViewController] Preparando para executar query " + commId + " ...");



      Collection parametros;

      if (params == null)

        parametros = null;

      else

        parametros = Arrays.asList(params);



      System.out.println("[PERIODONT - ViewController] Query " + commId + " preparada...");



      java.sql.ResultSet ret = qProc.execSQL(commId, parametros);



      System.out.println("[PERIODONT - ViewController] Query " + commId + " executada com sucesso...\n");



      return ret;

    } catch(Exception ex) {

      System.out.println("[PERIODONT - ViewController] Erro inesperado ao executar Query " + commId + ": " + ex.getMessage() + "\n");

      throw ex;

    }



  }





  /** Executa um comando SQL baseado no codigo do comando informado

   * @param commId Codigo do comando SQL.

   * @param params Array de parametros ou null se nao necessitar de params.

   * @param processor Objeto responsavel por processar o ResultSet informado.

   * @return Array de Objetos.

   * @throws Exception Erro de SQL.

   */

  public static java.lang.Object[] execSQL(java.lang.String commId, java.lang.Object[] params, ResultProcessor processor) throws Exception {

    try {

      System.out.println("[PERIODONT - ViewController] Localizando Query Session Facade...");



      QueryProcessorHome qprocHome = (QueryProcessorHome)ctx.lookup(JNDI_QUERY_NAME);



      System.out.println("[PERIODONT - ViewController] Query Session Facade localizado...");



      QueryProcessor qProc = qprocHome.create();



      System.out.println("[PERIODONT - ViewController] Preparando para executar query " + commId + "...");



      Collection parametros;

      if (params == null)

        parametros = null;

      else

        parametros = Arrays.asList(params);



      System.out.println("[PERIODONT - ViewController] Query " + commId + " preparada...");



      Object[] ret = (Object[]) qProc.execSQL(commId, parametros, processor).toArray()[0];



      System.out.println("[PERIODONT - ViewController] Query " + commId + " executada com sucesso...\n");



      return ret;

    } catch(Exception ex) {

      System.out.println("[PERIODONT - ViewController] Erro inesperado ao executar query " + commId + ": " + ex.getMessage() + "\n");

      throw ex;

    }

  }







  /** Executa um comando SQL baseado no codigo do comando informado

   * @param commId Codigo do comando SQL.

   * @param params Array de parametros para o comando

   * @return ResultSet

   * @throws Exception Erro de SQL

   */

  public static java.sql.ResultSet execSQL(java.lang.String commId,

                                           java.lang.String complemento,

                                           java.lang.Object[] params) throws Exception {

    try {

      System.out.println("[PERIODONT - ViewController] Localizando Query Session Facade...");



      QueryProcessorHome qprocHome = (QueryProcessorHome)ctx.lookup(JNDI_QUERY_NAME);



      System.out.println("[PERIODONT - ViewController] Query Session Facade localizado...");



      QueryProcessor qProc = qprocHome.create();



      System.out.println("[PERIODONT - ViewController] Preparando para executar query " + commId + " ...");



      Collection parametros;

      if (params == null)

        parametros = null;

      else

        parametros = Arrays.asList(params);



      System.out.println("[PERIODONT - ViewController] Query " + commId + " preparada...");



      java.sql.ResultSet ret = qProc.execSQL(commId, complemento, parametros);



      System.out.println("[PERIODONT - ViewController] Query " + commId + " executada com sucesso...\n");



      return ret;

    } catch(Exception ex) {

      System.out.println("[PERIODONT - ViewController] Erro inesperado ao executar Query " + commId + ": " + ex.getMessage() + "\n");

      throw ex;

    }



  }







  /** Executa um comando SQL baseado no codigo do comando informado

   * @param commId Codigo do comando SQL.

   * @param params Array de parametros para o comando

   * @return ResultSet

   * @throws Exception Erro de SQL

   */

  public static java.sql.ResultSet execSQLStatement(java.lang.String comando,

                                                    java.lang.Object[] params) throws Exception {

    try {

      System.out.println("[PERIODONT - ViewController] Localizando Query Session Facade...");



      QueryProcessorHome qprocHome = (QueryProcessorHome)ctx.lookup(JNDI_QUERY_NAME);



      System.out.println("[PERIODONT - ViewController] Query Session Facade localizado...");



      QueryProcessor qProc = qprocHome.create();



      Collection parametros;

      if (params == null)

        parametros = null;

      else

        parametros = Arrays.asList(params);



      java.sql.ResultSet ret = qProc.execSQLStatement(comando, parametros);



      System.out.println("[PERIODONT - ViewController] Query executada com sucesso...\n");



      return ret;

    } catch(Exception ex) {

      System.out.println("[PERIODONT - ViewController] Erro inesperado ao executar Query " + comando + ": " + ex.getMessage() + "\n");

      throw ex;

    }



  }







  /** Metodo que prepara o argumento de um comando a partir

   * da String de identificacao do comando e de um Collection

   * de argumentos.

   * @param id Codigo da Transacao

   * @param params Collection de parametros

   * @return Map preparado para a invocacao

   */

  public static Argument prepareCommand(String id, java.util.Collection params) {

    return new ViewController.FacadeArgument(id, params);

  }





  /** Metodo que prepara o argumento de um comando a partir

   * da String de identificacao do comando e de um Collection

   * de argumentos.

   * @param id Codigo da Transacao

   * @param params Collection de parametros

   * @return Map preparado para a invocacao

   */

  public static Argument prepareCommand(String id, Object[] params) {

    return new ViewController.FacadeArgument(id, params);

  }





  public static Argument prepareCommand(String id, Object param) {

    return prepareCommand( id, new Object[] {param} );

  }





  /** Retorna uma referencia ao objeto Context interno.

   * @return Context

   */

  public static javax.naming.Context getContext() {

    return ctx;

  }





  private static class FacadeArgument implements Argument {

    private String transId;

    private Object[] params;



    protected FacadeArgument(String id, Collection params) {

      if (id == null || params == null)

        throw new IllegalArgumentException("Os componentes de um Argumento nao podem ser nulos! ");



      this.transId = id;



      this.params = new Object[params.size()];

      java.util.Iterator it = params.iterator();



      for(int i = 0 ; it.hasNext() ; i++)

        this.params[i] = it.next();

    }





    protected FacadeArgument(String id, Object[] params) {

      if (id == null || params == null)

        throw new IllegalArgumentException("Os componentes de um Argumento nao podem ser nulos! ");



      this.transId = id;

      this.params = params;

    }





    public Object[] getParams() {

      return this.params;

    }





    public String getTransactionId() {

      return this.transId;

    }



  }

}