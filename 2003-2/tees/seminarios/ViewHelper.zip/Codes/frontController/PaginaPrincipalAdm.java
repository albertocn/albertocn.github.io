package br.ufs.periodont.ui.frontController;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * Dispatcher para a categoria de usu�rio "Administrador"
 */
public class PaginaPrincipalAdm extends PaginaPrincipal {

   /**
    * URLs (relativas) das partes das molduras.
    */
    private static final String MOLDURAINICIO = "/moldura/administrador/InicioMolduraAdministrador.jsp";
    private static final String MOLDURAFIM = "/moldura/administrador/FinalMolduraAdministrador.jsp";

    /**
     * Retorna a URL da p�gina inicial do administrador
     */
    public String getPaginaInicial() {
      return "PaginaInicialAdm.jsp";
    }

    /**
     * No exemplo, o administrador n�o tem permiss�o de acesso ao cadastro de pacientes
     */
    public void verificarPermissao(HttpServletRequest req) throws UnauthorizedException {
      if (req.getParameter(Main.ATTACTION).equals("cadastroPaciente"))
        throw new UnauthorizedException();
    }

    /**
     * Configura a moldura do administrador
     */
    public void setMoldura(HttpServletRequest req) {
      req.setAttribute(Main.PARAMMOLDURAINICIO,MOLDURAINICIO);
      req.setAttribute(Main.PARAMMOLDURAFIM, MOLDURAFIM);
    }

  }
