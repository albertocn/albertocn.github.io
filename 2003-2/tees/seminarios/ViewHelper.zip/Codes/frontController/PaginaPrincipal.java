package br.ufs.periodont.ui.frontController;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;


//Classe de servi�os referentes a Usuarios
import br.ufs.periodont.ui.usuarios.Usuarios;
//Objeto DATA ACESS OBJECT do Usuario (contem os dados de um Usuario)
import br.ufs.periodont.data.usuario.UsuarioDAO;



/**
 * Classe abstrata que representa o Dispatcher
 * e � estendida para cada categoria de usuario
 */
public abstract class PaginaPrincipal {

  /**
   * Garante que a instancia��o dos disptachers ser� controlada
   * Para que cada usu�rio tenha um dispatcher correspondente correto
   */
  protected PaginaPrincipal() {}

  /**
   * Tabela associativa de identificadores a recursos
   * Poderia ser um XML
   */
  public final static Map mapa = new HashMap();

  static {
    //Inicializa��o da tabela de recursos
    //Poderia ser a carga de um XML
    mapa.put("cadastroUsuario","/usuarios/InserirUsuario.jsp");
    mapa.put("cadastrarPaciente","confirm.jsp");
    mapa.put("cadastroPaciente","/pacientes/InserirPaciente.jsp");
    mapa.put("visualizacaoEstatistica","/estatisticas/Estatisticas.jsp");
    mapa.put("encerrar","Encerrar.jsp");
    mapa.put("confirmar","confirm.jsp");
  }

  /**
   * M�todo que devolve um objeto Dispatcher correspondente a cada tipo de Usu�rio
   */
  public static PaginaPrincipal getPaginaPrincipal(int tipoUsuario) {
    //Tipo do usu�rio � passado como parametro para esse "factory method"
    switch (tipoUsuario) {
      case UsuarioDAO.TP_ADMINISTRADOR:
        return new PaginaPrincipalAdm();
      case UsuarioDAO.TP_ATENDENTE:
        return new PaginaPrincipalAtendente();
      case UsuarioDAO.TP_DENTISTA:
        return new PaginaPrincipalDentista();
      default:
        return null;
    }
  }

  /**
   * Coloca os par�metros referentes � moldura da p�gina na requisi��o
   */
  public abstract void setMoldura(HttpServletRequest req);

  /**
   *  Retorna a URL da p�gina inicial deste dispatcher (categoria de usu�rio)
   */
  public abstract String getPaginaInicial();

  /**
   * Verifica a permissao de processamento da requisi��o. Cada subclasse
   * conhece sua categoria de usu�rios e, portanto, suas permiss�es.
   */
  public abstract void verificarPermissao(HttpServletRequest req) throws UnauthorizedException;


  /**
   * Template method que implementa o "encaminhamento" do dispatcher a um recurso
   * Os m�todos presentes no corpo s�o usados para que as subclasses dispatcher
   * concretas tomem decis�es a respeito do processamento da requisi��o.
   */
  public final void dispatch(HttpServletRequest req, HttpServletResponse res)
      throws UnauthorizedException, IOException, ServletException {
    setMoldura(req);
    String acao = "";
    String destino = "";

    //Caso haja uma acao associada, o dispatcher determina a permiss�o de execu�ao
    if (req.getParameter(Main.ATTACTION) != null) {
      verificarPermissao(req);
      //Captura a a��o associada e mapeia em um recurso "destino"
      acao = (String) req.getParameter(Main.ATTACTION);
      destino = (String) mapa.get(acao);
      //Caso n�o haja destino definido, encaminha � p�gina principal
      if (destino == null) {
        destino = getPaginaInicial();
      }
    } else
      destino = getPaginaInicial();

    //Informa o destino ao m�todo de montagem efetiva da p�gina
    montarPagina(destino,req,res);
  }


  private void montarPagina(String destino, HttpServletRequest req, HttpServletResponse res) throws
  ServletException, IOException {
    //Captura os atributos colocados pelas subclasses
    incluir((String) req.getAttribute(Main.PARAMMOLDURAINICIO), req, res);
    incluir(destino, req, res);
    incluir((String) req.getAttribute(Main.PARAMMOLDURAFIM), req, res);
  }

  /**
   * Obt�m um RequestDispatcher e inclui o conte�do de uma URL passada
   */
  private void incluir(String target, HttpServletRequest req, HttpServletResponse res)
      throws ServletException, IOException {
    RequestDispatcher rd = req.getRequestDispatcher(target);
    rd.include(req, res);
  }

}