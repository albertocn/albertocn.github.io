package br.ufs.periodont.ui.interceptingFilter;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import br.ufs.periodont.ui.frontController.Main;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class EncerramentoFilter extends HttpServlet implements Filter {
  private FilterConfig filterConfig;
  //Handle the passed-in FilterConfig
  public void init(FilterConfig filterConfig) {
    this.filterConfig = filterConfig;
  }
  //Process the request/response pair
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) {
    HttpServletRequest req = (HttpServletRequest) request;
    HttpServletResponse res = (HttpServletResponse) response;
    try {
      if (req.getParameter(Main.ATTACTION)!=null) {
        if (req.getParameter(Main.ATTACTION).equals("encerrar"))
          encerrar(req, res);
        else
          filterChain.doFilter(request, response);
      } else
        filterChain.doFilter(request, response);

    }
    catch(ServletException sx) {
      filterConfig.getServletContext().log(sx.getMessage());
    }
    catch(IOException iox) {
      filterConfig.getServletContext().log(iox.getMessage());
    }
  }

  private void encerrar(HttpServletRequest req, HttpServletResponse res) {
     String url = "Encerrar.jsp";
     System.out.println("Encerrando atraves da URL: "+url);
     RequestDispatcher rd = req.getRequestDispatcher(url);
     try {
       rd.forward(req, res);
     } catch (Throwable t) {
       try {
         PrintWriter out = new PrintWriter(res.getOutputStream());
         out.println("Erro ao redirecionar para a p�gina de logon.");
         out.println("Contate o administrador do sistema.");
       } catch (IOException ioe) {}
     }
  }

  //Clean up resources
  public void destroy() {
  }
}