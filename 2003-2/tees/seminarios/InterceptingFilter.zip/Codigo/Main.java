package br.ufs.periodont.ui.frontController;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

//Classe de servi�os referentes a Usuarios
import br.ufs.periodont.ui.usuarios.Usuarios;
//Objeto DATA ACESS OBJECT do Usuario (contem os dados de um Usuario)
import br.ufs.periodont.data.usuario.UsuarioDAO;
import br.ufs.periodont.ui.helper.Helper;
import br.ufs.periodont.ui.helper.ProcessaInserirPaciente;
import br.ufs.periodont.data.cor.CorDAO;
import br.ufs.periodont.data.NivelInstrucao.NivelInstrucaoDAO;
import br.ufs.periodont.data.estadoCivil.EstadoCivilDAO;
import java.sql.Timestamp;


/**Servlet que implementa a funcionalidade de Front Controller
 */
public class Main extends HttpServlet {

  /**
   * Constantes que representam os nomes de certos parametros e atributos
   * importantes das requisicoes
   */
  public static final String ATTDISPATCHER = "dispatcher";
  public static final String ATTLOGIN = "vLogin";
  public static final String ATTSENHA = "vSenha";
  public static final String ATTUSER = "user";
  public static final String ATTACTION = "acao";

  public static final String ATTCOR = "cor";
  public static final String ATTESTCIVIL = "estadoCivil";
  public static final String ATTNIVEL = "nivel";

  /**
   * Constantes usadas no encerramento de sess�o.
   */
  public static final String ACTENCERRAR = "encerrar";
  public static final String PAGENCERRAR = "Encerrar.jsp";

  /**
   * Parametros associados a moldura
   */
  public static final String PARAMMOLDURAINICIO = "molduraInicio";
  public static final String PARAMMOLDURAFIM = "molduraFim";

  private static final String CONTENT_TYPE = "text/html";

  //Initialize global variables
  public void init() throws ServletException {
  }

  /**
   * O get � redirecionado para o post imediatamente.
   */
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request, response);
  }

  /**
   * Efetivamente processa as requisi��es HTTP.
   */
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   //Obtendo a stream de sa�da do browser
    PrintWriter out = response.getWriter();

    try {

      if (getDispatcher(request) == null) {  //C�digo para deixar passar sem autentica�ao
        UsuarioDAO ud = new UsuarioDAO(1,"aa","aa","bwbwfqwfb",new Timestamp(System.currentTimeMillis())
        ,"M",1,"5456456","99999999999","a","a",1,2);
        request.getSession().setAttribute(Main.ATTUSER,ud);
        PaginaPrincipal p = PaginaPrincipal.getPaginaPrincipal(2);
        request.getSession().setAttribute(Main.ATTDISPATCHER,p);
      }

      System.out.println("Chamando o Helper...");
      Helper helper = getHelper(request);
      System.out.println("Classe do Helper: " + helper.getClass());
      helper.processar(request);

      //Coloca na se��o objeto contendo lista com valores apresentado no selectBox (cor, estado civil e nivel)
      setListaConteudoSelectBox(request);

      //A requisi��o � ent�o encaminhada ao dispatcher deste usu�rio.
      getDispatcher(request).dispatch(request, response);


      //Ponto central de tratamento de erros.
    } catch (UnauthorizedException ue) {
      out.println("403 - FORBIDDEN ");
      out.println("VOCE N�O EST� AUTORIZADO A VER ESSE CONTE�DO.");
    } catch (Throwable t) {
      out.println(" Um erro foi capturado na execu��o da sua requisi��o.");
      out.println("Erro:");
      out.println(t.toString());
      out.println("Causa: "+t.getCause());
      t.printStackTrace(out);
      t.printStackTrace();
    }

  }

  private Helper getHelper(HttpServletRequest req) {
      return Helper.getHelper(req);
  }

  /**
   * Pr�-processamento feito pelo Front Controller para deteminar se o usu�rio
   * solicitou um encerramento de sess�o.
   */
  private void verificarEncerramento(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException {
    if (req.getParameter(ATTACTION) !=  null)
      //Caso a acao seja encerrar, encaminha para a p�gina de encerramento
      if (req.getParameter(ATTACTION).equals(ACTENCERRAR)) {
        RequestDispatcher rd = req.getRequestDispatcher(PAGENCERRAR);
        rd.forward(req, res);
      }
  }

  //Poderia ser usado para liberar recursos
  public void destroy() {}

  /**
   * Retorna o objeto de sessao Dispatcher do usuario que enviou a
   * requisicao req
   */
  private PaginaPrincipal getDispatcher(HttpServletRequest req) {
    return (PaginaPrincipal) req.getSession().getAttribute(ATTDISPATCHER);
  }

  private void setListaConteudoSelectBox(HttpServletRequest req) throws Throwable {
    ProcessaInserirPaciente pip = new ProcessaInserirPaciente();

    req.getSession().setAttribute( ATTCOR, pip.retornaLista(pip.PARAMCOR) );
    req.getSession().setAttribute( ATTESTCIVIL, pip.retornaLista(pip.PARAMESTCIVIL) );
    req.getSession().setAttribute( ATTNIVEL, pip.retornaLista(pip.PARAMNIVEL) );
  }

}



