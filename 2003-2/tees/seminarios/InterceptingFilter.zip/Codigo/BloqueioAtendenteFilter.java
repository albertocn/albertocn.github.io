package br.ufs.periodont.ui.interceptingFilter;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import br.ufs.periodont.ui.frontController.Main;
import br.ufs.periodont.data.usuario.UsuarioDAO;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class BloqueioAtendenteFilter extends HttpServlet implements Filter {

  private static String paginas = "cadastroUsuario|consultaUsuario|cadastrarUsuario";

  private FilterConfig filterConfig;
  //Handle the passed-in FilterConfig
  public void init(FilterConfig filterConfig) {
    this.filterConfig = filterConfig;
  }
  //Process the request/response pair
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) {
    try {
      HttpServletRequest req = (HttpServletRequest) request;
      HttpServletResponse res = (HttpServletResponse) response;
      String acao = (String) request.getParameter(Main.ATTACTION);
      if (acao == null)
        acao = "";
      if (acao.equals("cadastroPaciente")) {
        if ( ( (UsuarioDAO) req.getSession().getAttribute(Main.ATTUSER)).
            gettipo().intValue()  == UsuarioDAO.TP_ADMINISTRADOR)
          bloquear(req, res);
        else
          filterChain.doFilter(req, res);
      }
      else
        filterChain.doFilter(req, res);
    }
    catch(ServletException sx) {
      filterConfig.getServletContext().log(sx.getMessage());
    }
    catch(IOException iox) {
      filterConfig.getServletContext().log(iox.getMessage());
    }
  }

  private void bloquear(HttpServletRequest req, HttpServletResponse res) {
    RequestDispatcher rd = req.getRequestDispatcher("Forbidden.jsp");
    try {
      rd.forward(req, res);
    } catch (Throwable t) {
      try {
        PrintWriter out = new PrintWriter(res.getOutputStream());
        out.println("Erro ao redirecionar para a p�gina de logon.");
        out.println("Contate o administrador do sistema.");
      } catch (IOException ioe) {}
    }
  }

  //Clean up resources
  public void destroy() {
  }
}