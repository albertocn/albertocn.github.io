package br.ufs.periodont.ui.interceptingFilter;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import br.ufs.periodont.ui.frontController.Main;
import br.ufs.periodont.data.usuario.UsuarioDAO;
import br.ufs.periodont.ui.frontController.PaginaPrincipal;
import br.ufs.periodont.ui.usuarios.Usuarios;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public class AutenticacaoFilter extends HttpServlet implements Filter {

  public static final String ATTMENSAGEM = "mensagem";
  public static final String LOGON = "index.jsp";

  private FilterConfig filterConfig;
  //Handle the passed-in FilterConfig
  public void init(FilterConfig filterConfig) {
    this.filterConfig = filterConfig;
  }
  //Process the request/response pair
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) {
    try {
      HttpServletRequest req = (HttpServletRequest) request;
      HttpServletResponse res = (HttpServletResponse) response;

      if (!usuarioAutenticado(req)) {
        if (autenticarUsuario(req,res))
          filterChain.doFilter(request, response);
      } else
        filterChain.doFilter(request, response);
    }
    catch(ServletException sx) {
      filterConfig.getServletContext().log(sx.getMessage());
    }
    catch(IOException iox) {
      filterConfig.getServletContext().log(iox.getMessage());
    }
  }

  private boolean usuarioAutenticado(HttpServletRequest req) {
    HttpSession session = req.getSession();
    //Se o atributo de sess�o que representa o usu�rio � n�o-nulo, ele
    //est� autenticado
    return (session.getAttribute(Main.ATTUSER) != null);
  }

  /**
  * Tenta autenticar um usuario que enviou a Requisicao req.
  * @param req - Requisicao HTTP
  * @param res - Resposta HTTP
  * @throws ServletException - lan�ada quando h� uma falha durante a autentica��o
  */
 private boolean autenticarUsuario(HttpServletRequest req, HttpServletResponse res) throws ServletException {
   try {
     //S�o verificados os parametros login e senha
     String login = (String) req.getParameter(Main.ATTLOGIN);
     String senha = (String) req.getParameter(Main.ATTSENHA);
     if ((login == null)||(senha==null))
       throw new Exception();

     //Chamada a uma classe biblioteca de m�todos referente a usuarios
     UsuarioDAO usuario = Usuarios.autenticarUsuario(login, senha);
     //O objeto que representa o usu�rio � inclu�do na sess�o
     req.getSession().setAttribute(Main.ATTUSER,usuario);

     //Um Dispatcher referente ao tipo do usu�rio � criado e setado na sess�o
     PaginaPrincipal p = PaginaPrincipal.getPaginaPrincipal(usuario.gettipo().intValue());
     req.getSession().setAttribute(Main.ATTDISPATCHER,p);
     return true;
   } catch (Throwable e) {
     req.setAttribute("caminho",getCaminhoToRoot("", req));
     req.setAttribute(ATTMENSAGEM, "Voc� deve efetuar logon para obter acesso ao sistema!");
     RequestDispatcher rd = req.getRequestDispatcher(getCaminhoToRoot(LOGON, req));
     try {
       rd.forward(req, res);
     } catch (Throwable t) {
       t.printStackTrace();
       try {
         PrintWriter out = new PrintWriter(res.getOutputStream());
         out.println("Erro ao redirecionar para a p�gina de logon.");
         out.println("Contate o administrador do sistema.");
       } catch (IOException ioe) {}
     }
     return false;
   }
 }

 public static String getCaminhoToRoot(String urlFromRoot, HttpServletRequest req) {
   String caminho = "";
   String profundidade = req.getContextPath();
   while (profundidade.charAt(0)=='/') { //determinando caminho at� index.jsp
     caminho += "../";
     profundidade = profundidade.substring(1);
     if (profundidade.indexOf('/') > 0)
       profundidade = profundidade.substring(profundidade.indexOf('/'));
   }
   return caminho+urlFromRoot;
 }


  //Clean up resources
  public void destroy() {
  }
}