package br.ufs.periodont.ui.frontController;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * Dispatcher para a categoria de usu�rio "Atendente"
 */
public class PaginaPrincipalAtendente extends PaginaPrincipal {

    /**
     * Retorna a URL da p�gina inicial do administrador
     */
    public String getPaginaInicial() {
      return "PaginaInicialAtendente.jsp";
    }

    /**
     * No exemplo, o atendente n�o tem permiss�o de acesso ao cadastro de usu�rios
     */
    public void verificarPermissao(HttpServletRequest req) throws UnauthorizedException {
      if (req.getParameter(Main.ATTACTION).equals("cadastroUsuario"))
        throw new UnauthorizedException();
    }

  }