package br.ufs.periodont.ui.frontController;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * Dispatcher para a categoria de usu�rio "Administrador"
 */
public class PaginaPrincipalAdm extends PaginaPrincipal {

    /**
     * Retorna a URL da p�gina inicial do administrador
     */
    public String getPaginaInicial() {
      return "PaginaInicialAdm.jsp";
    }

    /**
     * No exemplo, o administrador n�o tem permiss�o de acesso ao cadastro de pacientes
     */
    public void verificarPermissao(HttpServletRequest req) throws UnauthorizedException {
      if (req.getParameter(Main.ATTACTION).equals("cadastroPaciente"))
        throw new UnauthorizedException();
    }

  }
