/**
 * Classe que implementa o viewManager, usando um Singleton
 */
package br.ufs.periodont.ui.compositeView;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.Map;
import java.util.HashMap;

import br.ufs.periodont.ui.frontController.Main;
import br.ufs.periodont.data.usuario.UsuarioDAO;

public class viewManager {

  private static final String PARAMPRINCIPAL = "/moldura/template.jsp";
  private static final String PARAMFIMMOLDURA = "/moldura/FinalMoldura.jsp";

  /**
   * Mant�m Inst�ncia �nica
   */
  private static viewManager vm = null;

  public final static Map mapa = new HashMap();

  static {
    //Inicializa��o da tabela de recursos
    //Poderia ser a carga de um XML
    mapa.put("leftbarAdministrador","/moldura/leftbarAdministrador.jsp");
    mapa.put("leftbarDentista","/moldura/leftbarDentista.jsp");
    mapa.put("leftbarAtendente","/moldura/leftbarAtendente.jsp");
    mapa.put("logo","/moldura/logo.jsp");
    mapa.put("topbarAdministrador","/moldura/topbarAdministrador.jsp");
    mapa.put("topbarDentista","/moldura/topbarDentista.jsp");
    mapa.put("topbarAtendente","/moldura/topbarAtendente.jsp");
    mapa.put("topbarIdent","/moldura/topbarIdent.jsp");
  }
  
  /**
   * Construtor protegido
   */
  protected viewManager() {}

  /**
   * Retorna inst�ncia �nica
   */
  public static viewManager getManager() {
    if (vm == null)
      vm = new viewManager();
    return vm;
  }

  public void montarPagina(String destino, HttpServletRequest req, HttpServletResponse res) throws
   ServletException, IOException {
     //Captura os atributos colocados pelas subclasses
     incluir(PARAMPRINCIPAL, req, res);
     incluir(destino, req, res);
     incluir(PARAMFIMMOLDURA, req, res);
   }

   /**
    * Obt�m um RequestDispatcher e inclui o conte�do de uma URL passada
    */
   public void incluir(String target, HttpServletRequest req, HttpServletResponse res)
       throws ServletException, IOException {
     RequestDispatcher rd = req.getRequestDispatcher(target);
     rd.include(req, res);
   }

  /**
    * Retorna a URL da p�gina passada como par�metro
    */ 
   public String getPage(String name) {
     return (String)mapa.get(name);
   }

  /**
    * Retorna a URL da p�gina passada, a partir do tipo de usu�rio
    */ 
   public String getPageUsuario(String name, String tipo) {
     return (String)mapa.get(name + tipo);
   }

}