package editordetexto;


import java.io.IOException;
import javax.swing.*;
import java.io.File;

class StEditorAberto implements StEditor{
  public void StEditorAberto(){
    System.out.print("Entrou no estado >>Aberto<< \n");
  }

  public void abrir(StControl controle, String nome){
     JOptionPane.showMessageDialog(null, " N�o � poss�vel: H� outro arquivo aberto. ",
                                   " StEditorAberto - Erro ", JOptionPane.OK_OPTION);
  }

  public void salvar(StControl controle){
    System.out.print("O arquivo nao foi modificado, N�o precisa Salvar\n");
    //N�o far� nada o arquivo nao foi modificado portanto nao precisa ser salvo!!!
  }

  public void fechar(StControl controle){
    try{
      controle.fecharStreamSaida();
    }
    catch (Exception e){
      System.out.print("Falha ao tentar fechar o arquivo...\n");
    }
    finally {
      controle.setTxArea("");
      controle.setStEditor(new StEditorEsperando());
    }
  }


}