package editordetexto;

import java.io.IOException;
import javax.swing.*;

class StEditorEsperando implements StEditor {
  public void abrir( StControl controle, String nome){
    System.out.print("Entrou no abrir de esperando\n");
    try{
      controle.setTxArea(controle.lerInput(nome));
      System.out.print("Acabou de ler o arquivo e copiar para o text area \n");
      //S� modifica o estado se conseguir abrir r ler o arquivo
      controle.setStEditor(new StEditorAberto());
    }
    catch(Exception e){
      JOptionPane.showMessageDialog(null, " N�o � poss�vel abrir o arquivo: '\n' "+
                                    "Permanecer� no estado StEditorEsperando", " StEditorEsperando - Erro "
                                    , JOptionPane.OK_OPTION);
     //  N�o precisa mudar o estado - Permanecer� "Esperando" caso nao consiga abrir o arquivo
    }
  }

  public void salvar(StControl controle){
    JOptionPane.showMessageDialog(null, " N�o � poss�vel SALVAR: N�o h� arquivo aberto ",
                                  " StEditorEsperando - Erro ", JOptionPane.OK_OPTION);
  }

  public void fechar(StControl controle){
    JOptionPane.showMessageDialog(null, " N�o h� arquivo aberto ", "StEditorEsperando - Erro",
                                  JOptionPane.OK_OPTION);
  }

}