package editordetexto;

import java.io.*;
import javax.swing.*;

class StControl {
  // Mantem instancia para estado do Editor
  private StEditor stEditor;
  private String nmArquivo;
  private JTextArea txArea;
  private Writer w;
  private BufferedWriter buffer;
  private Boolean mov;

  public StControl(JTextArea txArea){
    this.txArea = txArea;
    setStEditor(new StEditorEsperando());  //set para estado inicial padr�o;
  }

  public void abrir( String nome){
    this.nmArquivo = nome;
    stEditor.abrir(this, nome);
  }

  public void salvar(){
    stEditor.salvar(this);
  }

  public void fechar(){
    stEditor.fechar(this);
  }

  public void setStEditor(StEditor novoState){
    System.out.println("setStEditor chamado!!!\n");
    stEditor = novoState;
  }

  public void setTxArea(String texto){
    txArea.setText(texto);
  }

  public String getTxArea(){
    return txArea.getText();
  }

  /* M�todo chamado quando digita h� modifica��o no conteudo do textArea*/
  public void textModificado(){
    if (stEditor instanceof StEditorAberto){
      System.out.println("Texto foi modificado");
      /* Verifica se est� no estado Aberto, se sim modifica para Editando */
      setStEditor(new StEditorEditando());
    }
  }

  public String lerInput(String nmArquivo) throws IOException {
    this.nmArquivo = nmArquivo;

       // Cria uma InputStream para o arquivo especificado
       InputStream is = new FileInputStream(nmArquivo);
       return lerString(is);
   }

   private String lerString(InputStream is) throws IOException {
       ByteArrayOutputStream baos = new ByteArrayOutputStream();
       int i;
       while ((i = is.read()) != -1) {
         baos.write((byte) i);
       }
       return baos.toString();
   }


  public BufferedWriter criarOutPut(String conteudoTxt) throws IOException{
    w = new FileWriter(nmArquivo);
    buffer = new BufferedWriter(w);
    buffer.write(conteudoTxt);
    buffer.flush();
    return buffer;
  }

  public void fecharStreamSaida() throws Exception {
    w.close();
    buffer.close();
  }


}