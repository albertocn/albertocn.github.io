package editordetexto;

public interface StEditor {
  public void abrir(StControl controle, String nome);
  public void salvar(StControl controle);
  public void fechar(StControl controle);

}