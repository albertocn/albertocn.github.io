package editordetexto;

import java.io.IOException;
import javax.swing.*;

class StEditorEditando implements StEditor {
  public void abrir(StControl controle, String nome){
    JOptionPane.showMessageDialog(null, " N�o � poss�vel Abrir: Est� editando um arquivo ",
                                   " StEditorEditando - Erro ", JOptionPane.OK_OPTION);
  }

  public void salvar(StControl controle){
    try{
      JOptionPane.showMessageDialog(null, " Arquivo foi salvo - mudar para estado StEditorAberto ",
                                   " StEditorEditando - alerta ", JOptionPane.OK_OPTION);

      controle.criarOutPut(controle.getTxArea());
      controle.setStEditor(new StEditorAberto());
    }catch (Exception e){
      /* Falha ao tentar salvar*/
      System.out.print("Falha ao tentar salvar o arquivo\n");
      try{
        controle.fecharStreamSaida();
      }
      catch (Exception ex){}
      controle.setStEditor(new StEditorEsperando());
    }
  }

  public void fechar(StControl controle){
      controle = controle;
      try{
         controle.fecharStreamSaida();
      }
      catch (Exception e){System.out.print("Falha ao tentar fechar o arquivo\n");}
      finally {
        controle.setTxArea("");
        controle.setStEditor(new StEditorEsperando());
      }
  }

}