package editordetexto;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.*;
import javax.swing.*;

public class FrmText extends JFrame {
  private JPanel pBotao = new JPanel();
  private StControl control;
  private JPanel pAbrir = new JPanel();
  private JTextArea txArea = new JTextArea( 20, 80 );
  private JTextField tfArquivo = new JTextField(50);
  private JButton btSalvar = new JButton();
  private JButton btAbrir = new JButton();
  private JButton btFechar = new JButton();

  public FrmText() {
    super( "Editor legal pra caramba!!!" );
    control = new StControl(txArea);
    Container contentPane = getContentPane();
    contentPane.setLayout( new BorderLayout() );
    JScrollPane spTextArea = new JScrollPane(txArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    contentPane.add(spTextArea, new BorderLayout().CENTER);
    contentPane.add(pBotao, new BorderLayout().NORTH);
    pAbrir.add(BorderLayout.WEST, tfArquivo);
    pAbrir.add(BorderLayout.EAST, btAbrir);
    pBotao.add( BorderLayout.WEST, pAbrir );
    pBotao.add( BorderLayout.EAST, btSalvar );
    pBotao.add( BorderLayout.CENTER, btFechar );
    btSalvar.setText("Salvar");
    btAbrir.setText("Abrir");
    btFechar.setText("Fechar");
    btAbrir.addActionListener( new AbrirListener() );
    btFechar.addActionListener( new FecharListener() );
    btSalvar.addActionListener( new SalvarListener() );
    txArea.addKeyListener(new KeyAdapter() {
      public void keyPressed(KeyEvent e){
        System.out.println("ENTROU NO KEY EVENT");
        control.textModificado();
      };
    } );

    pack();
    show();
  }

  private class AbrirListener implements ActionListener {
     public void actionPerformed( ActionEvent e ) {
       System.out.print("Clicou no botao abrir\n");
       control.abrir(tfArquivo.getText());
     }
  }

  private class FecharListener implements ActionListener {
   public void actionPerformed( ActionEvent e ) {
     System.out.print("Clicou no botao fechar\n");
     control.fechar();
   }
  }

  private class SalvarListener implements ActionListener {
   public void actionPerformed( ActionEvent e ) {
     System.out.print("Clicou no botao salvar\n");
     control.salvar();
   }
  }

 /*void conteudo_inputMethodTextChanged(InputMethodEvent e) {

   System.out.println("ARQUIVO FOI MODIFICADO");
 }*/

  public static void main( String args[] ) {
    FrmText application = new FrmText();
    application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }
}
