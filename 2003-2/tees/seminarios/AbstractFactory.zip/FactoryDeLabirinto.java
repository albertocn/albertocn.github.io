package abstracty;

/**
 * <p>Title: Fabrica de Labirinto </p>
 * <p>Description: Retorna a instancia adequada da Fabrica e cria labirintos normais </p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public class FactoryDeLabirinto implements FactoryDeLabirintoIF {
  //Usando o Padrao Singleton temos uma unica instancia de uma Fabrica de Labirintos
  private static FactoryDeLabirintoIF inst�ncia�nica = null;

  //Retorna a instancia da Fabrica de Labirintos definida na string Tipo
  public static FactoryDeLabirintoIF getInstance(String tipo) {
    if(inst�ncia�nica == null) {
      if(tipo.equals("perigoso")) {
        inst�ncia�nica = new FactoryDeLabirintoPerigoso();
      } else {
        inst�ncia�nica = new FactoryDeLabirinto();
      }
    }
    return inst�ncia�nica;
  }

  // Factory Methods
  // Tem default para as Factory Methods
  public LabirintoIF criaLabirinto() {
    return new Labirinto();
  }

  public SalaIF criaSala(int n�meroDaSala) {
    return new Sala(n�meroDaSala);
  }

  public ParedeIF criaParede() {
    return new Parede();
  }

  public PortaIF criaPorta(SalaIF sala1, SalaIF sala2) {
    return new Porta(sala1, sala2);
  }
}