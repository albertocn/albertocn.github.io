package abstracty;

/**
 * <p>Title: Jogo </p>
 * <p>Description: Monta Labirinto usando uma fabrica </p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public class Jogo {
    public LabirintoIF montaLabirinto(FactoryDeLabirintoIF factory) {
    // Sao criadas as salas, porta e o Labirinto
    LabirintoIF umLabirinto = factory.criaLabirinto();
    SalaIF sala1 = factory.criaSala(1);
    SalaIF sala2 = factory.criaSala(2);
    PortaIF aPorta = factory.criaPorta(sala1, sala2);

    // As salas s�o adicionadas no labirinto e suas coneccoes sao estabelecidas

    umLabirinto.adicionaSala(sala1);
    umLabirinto.adicionaSala(sala2);

    sala1.setVizinho(1, factory.criaParede());
    sala1.setVizinho(3, aPorta);
    sala1.setVizinho(2, factory.criaParede());
    sala1.setVizinho(4, factory.criaParede());

    sala2.setVizinho(1, factory.criaParede());
    sala2.setVizinho(3, factory.criaParede());
    sala2.setVizinho(2, factory.criaParede());
    sala2.setVizinho(4, aPorta);

    return umLabirinto;
  }
}