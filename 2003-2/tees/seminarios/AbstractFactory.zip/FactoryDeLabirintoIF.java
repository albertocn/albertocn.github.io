package abstracty;

/**
 * <p>Title: Interface da Fabrica de Labirintos </p>
 * <p>Description: Define a interface da Fabrica de Labirintos </p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public interface FactoryDeLabirintoIF {
  public LabirintoIF criaLabirinto();
  public SalaIF criaSala(int n�meroDaSala);
  public ParedeIF criaParede();
  public PortaIF criaPorta(SalaIF sala1, SalaIF sala2);
}
