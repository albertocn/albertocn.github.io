package abstracty;

/**
 * <p>Title: Testar Labirinto </p>
 * <p>Description: Simula a cria��o de Labirintos </p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public class TestaLabirinto {
  public static void main(String args[]) {
    Jogo umJogo = new Jogo();
    //Factory e a instancia unica de uma Fabrica de Labirintos Perigosos
    FactoryDeLabirintoIF factory = FactoryDeLabirinto.getInstance("perigoso");
    //Cria um um jogo com um Labirinto Perigoso
    umJogo.montaLabirinto(factory);
  }
}