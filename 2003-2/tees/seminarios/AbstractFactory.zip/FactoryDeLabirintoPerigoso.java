package abstracty;

/**
 * <p>Title: Fabrica de Labirintos Perigosos </p>
 * <p>Description: Cria Labirintos Perigosos </p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public class FactoryDeLabirintoPerigoso extends FactoryDeLabirinto {
  //Cria Paredes com bombas
  public ParedeIF criaParede() {
    return new ParedeComBomba();
  }
  //Cria Salas Perigosas
  public SalaIF criaSala(int numeroDaSala) {
    return new SalaPerigosa(numeroDaSala);
  }
}
