// Apresenta��o da Disciplina T�picos Especiais em Engenharia de Software
// Professor Alberto Costa Neto
// Aluna: Sueane Bomfim
// 09/02/2003

package mediator;

//interface a ser implementada pelo Mediador

public interface Diretor {
  void notificar ( Objeto obj );
}
