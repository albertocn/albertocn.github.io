// Apresenta��o da Disciplina T�picos Especiais em Engenharia de Software
// Professor Alberto Costa Neto
// Aluna: Sueane Bomfim
// 09/02/2003

package mediator;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;


public class TesteMediator
{
  public static void main ( String[] args )
  {
    JFrame frame = new JFrame ( "Abrir Arquivo" );

    frame.setBounds(50,50,470,510);
    frame.setVisible ( true );

    // Instanciacao do ConcreteMediator
    Janela listas = new Janela(frame, "Abrir Arquivo", true);
    frame.getContentPane().add ( listas.painel );
    frame.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
    frame.setVisible ( true );
  }
}