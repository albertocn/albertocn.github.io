// Apresenta��o da Disciplina T�picos Especiais em Engenharia de Software
// Professor Alberto Costa Neto
// Aluna: Sueane Bomfim
// 09/02/2003

//Classe mediadora onde est� inserida a intercomunica��o entre os objetos

package mediator;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.border.*;
import com.borland.jbcl.layout.*;
import java.util.*;
import java.io.*;


public class Janela extends JDialog implements Diretor, ListSelectionListener
{
  public  JPanel painel = new JPanel();
  private XYLayout layout = new XYLayout();
  //objetos controlados pelo mediator
  public  CaixadeTexto caixaTexto;
  public  AreadeTexto areadeTexto;
  public  ListBox lstArqs;
  public  Botao abrir;

  public Janela ( Frame frame, String title, boolean modal )
  {
    super ( frame, title, modal );
    try
    { criarComponentes();
      pack();   }
    catch( Exception ex )
    { ex.printStackTrace(); }
  }

  public Janela()
  {  this( null, "", false );   }


  void criarComponentes() throws Exception
  {
    Container ctn = getContentPane();
    painel.setLayout ( layout );

    abrir = new Botao ( this );
    abrir.botao.setActionCommand ( abrir.mostrar );
    abrir.botao.addActionListener (new BotaoAcionado () );

    caixaTexto = new CaixadeTexto ( this );
    caixaTexto.InserirCaixaDeTexto ( "" );
    caixaTexto.caixa.setBorder ( BorderFactory.createLineBorder ( Color.black ) );
    //inserindo os arquivos dentro do listBox
    lstArqs = new ListBox ( this );
    lstArqs.inserirLista ( obterArquivos() );
    lstArqs.lista.setSelectionMode ( ListSelectionModel.SINGLE_SELECTION );
    lstArqs.lista.setBorder ( BorderFactory.createLineBorder ( Color.black ) );
    lstArqs.lista.addListSelectionListener ( this );
    JScrollPane spLista = new JScrollPane(lstArqs.lista,
                                           JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                                           JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

    areadeTexto = new AreadeTexto ( this , 5 , 180 );
    JScrollPane spTextArea = new JScrollPane(areadeTexto.conteudo,
                                              JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                                              JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

    painel.add ( new JLabel("Arquivo:") , new XYConstraints ( 8, 5, 160, 25 ) );
    painel.add ( caixaTexto.caixa, new XYConstraints ( 5, 30, 270, 25 ) );
    painel.add ( abrir.botao, new XYConstraints ( 280, 30, 170, 25 ) );
    painel.add ( spLista, new XYConstraints ( 5, 70, 450 , 100 ) );
    painel.add ( spTextArea, new XYConstraints ( 5, 180, 450 , 290 ) );

    this.getContentPane().add ( painel );
  }

  // acionado quando houver alteracao do estado do botao
  class BotaoAcionado implements ActionListener
  {
    public void actionPerformed ( ActionEvent e )
    {
      if (!(caixaTexto.caixa.getText().equals("")))
      { abrir.mudar();
        return;        }
    }
  }

  // Este metodo eh declarado na Interface ListSelectionListener
  // acionado quando a selecao � alterada no ListBox
  public void valueChanged ( ListSelectionEvent e )
  {
    lstArqs.mudar();
  }

  private Vector obterArquivos() {
    Vector arqs = new Vector();
    File dir = new File("arquivos\\");
    File[] conteudoDir = dir.listFiles();
    for (int i = 0; i < conteudoDir.length; i++) {
      if (conteudoDir[i].isFile()) {
        arqs.add("arquivos\\" + conteudoDir[i].getName());
      }
    }
    return arqs;
  }

  void atualizarTextArea(  ) {
    try {
      File f = new File ( lstArqs.lista.getSelectedValue().toString() );
      Reader reader = new InputStreamReader( new FileInputStream( f ) );
      areadeTexto.conteudo.read( reader, null );
    } catch (IOException e) {
      areadeTexto.conteudo.setText( e.getMessage() );
    }
  }

// Este metodo esta declarado na Interface Diretor ( Mediator )
// Concentra as informa��es a respeito das intera��es entre os objetos que esse
// mediator controla.
// Quando algum objeto eh alterado ele envia uma informa��o para a sua
// SuperClasse (classe Objeto) e esta chama o metodo notificar passando como
// argumento a referencia ao objeto originador do evento.
 public void notificar( Objeto obj )
 {
   if ( obj instanceof ListBox )
   {
     if (!( lstArqs.lista.getSelectedIndex( ) == -1 ))
     {
       //Selecao, atualiza a Caixa de Texto
       abrir.botao.setEnabled ( true );
       String name = lstArqs.lista.getSelectedValue().toString();
       caixaTexto.caixa.setText ( name );
     }
   }
   else if ( obj instanceof Botao )
          atualizarTextArea(  );
 }
}
