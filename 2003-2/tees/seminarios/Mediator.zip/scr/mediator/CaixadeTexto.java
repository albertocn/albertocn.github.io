// Apresenta��o da Disciplina T�picos Especiais em Engenharia de Software
// Professor Alberto Costa Neto
// Aluna: Sueane Bomfim
// 09/02/2003

//Classe Colleague - um dos objetos que tem
//o comportamento administrado pelo Mediator


package  mediator;

import javax.swing.JTextField;

public class CaixadeTexto extends JTextField implements Objeto
{
  Diretor diretor;
  public JTextField caixa;

  public CaixadeTexto ( Diretor diretor )
  {
    super();
    this.diretor = diretor;
  }

  // Metodo da interface Objeto implementado
  public void mudar()
  {
    diretor.notificar ( this );
  }

  public void InserirCaixaDeTexto ( String texto )
  {
    this.caixa = new JTextField ();
    this.caixa.setText ( texto );
  }

}
