// Apresenta��o da Disciplina T�picos Especiais em Engenharia de Software
// Professor Alberto Costa Neto
// Aluna: Sueane Bomfim
// 09/02/2003

//Classe Colleague - um dos objetos que tem
//o comportamento administrado pelo Mediator


package mediator;

import javax.swing.JList;
import java.util.*;

public class ListBox extends JList implements Objeto
{
  Diretor diretor;
  public JList lista = new JList();

  public ListBox ( Diretor diretor )
  {
    super();
    this.diretor = diretor;
  }

  // Metodo da interface Objeto implementado
  public void mudar()
  {
    diretor.notificar ( this );
  }

  public JList inserirLista( Vector elemento )
  {
    lista = new JList( elemento );
    return lista;
  }

}
