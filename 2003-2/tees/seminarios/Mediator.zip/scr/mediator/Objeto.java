// Apresenta��o da Disciplina T�picos Especiais em Engenharia de Software
// Professor Alberto Costa Neto
// Aluna: Sueane Bomfim
// 09/02/2003

//Interface Colleague - interface para os objetos que ser�o
//administrados pelo Mediator


package mediator;

public interface Objeto
{
  void mudar();
}