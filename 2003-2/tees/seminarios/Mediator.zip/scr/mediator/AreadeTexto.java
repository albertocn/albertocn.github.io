// Apresenta��o da Disciplina T�picos Especiais em Engenharia de Software
// Professor Alberto Costa Neto
// Aluna: Sueane Bomfim
// 09/02/2003

//Classe Colleague - um dos objetos que tem
//o comportamento administrado pelo Mediator

package  mediator;

import javax.swing.*;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import javax.swing.event.ListSelectionEvent;
import java.io.File;
import java.io.IOException;
import javax.swing.event.ListSelectionListener;


public class AreadeTexto extends JTextArea implements Objeto {

  Diretor diretor;
  JTextArea conteudo;

  public AreadeTexto ( Diretor diretor , int lin, int col )
  {
    super();
    conteudo = new JTextArea( lin, col );
    this.diretor = diretor;
  }

  // Metodo da interface Objeto implementado
  public void mudar()
  {
    diretor.notificar ( this );
  }



}