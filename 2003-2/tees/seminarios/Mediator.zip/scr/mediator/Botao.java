// Apresenta��o da Disciplina T�picos Especiais em Engenharia de Software
// Professor Alberto Costa Neto
// Aluna: Sueane Bomfim
// 09/02/2003

//Classe Colleague - um dos objetos que tem
//o comportamento administrado pelo Mediator


package  mediator;

import javax.swing.JButton;

public class Botao extends JButton implements Objeto
{
  Diretor diretor;
  public JButton botao;
  public String mostrar = new String ( "Abrir Arquivo" );

  public Botao ( Diretor diretor )
  {
    super();
    botao = new JButton ( mostrar );
    botao.setEnabled ( false );
    this.diretor = diretor;
  }

  // Metodo da interface Objeto implementado
  public void mudar()
  {
    diretor.notificar( this );
  }

}