package proxy;

import java.awt.*;
import java.awt.event.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.Reader;
import java.io.LineNumberReader;
import java.io.InputStreamReader;
import java.io.IOException;

import javax.swing.*;

/**
 * <p>Title: Sistema para Auxiliar a pesquisa de Fiter�picos baseado na Quimiotaxonomia</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Interface extends JFrame{

   private Arquivo arqProxy;
   private Arquivo arqReal;
   private Arquivo arqRemoto;
   private String metodo = "REAL";


   //Crai��o dos Componentes que ser�o utilizados no Frame
   private JLabel lblMatriz = new JLabel("Nome do Arquivo");
   private JTextField arquivoField = new JTextField(20);

   private JRadioButton rbMetodo1 = new JRadioButton("Real", true);
   private JRadioButton rbMetodo2 = new JRadioButton("Proxy");
   private JRadioButton rbMetodo3 = new JRadioButton("Remoto");
   private ButtonGroup bgMetodo   = new ButtonGroup();

   private JLabel lblResultados = new JLabel("RESULTADOS");
   private JTextArea resultados = new JTextArea( 20, 60 );
   private JButton btnAgrupar = new JButton("Dados do Arquivo");
   private JButton btnConteudo = new JButton("Conteudo Arquivo");


   public Interface() {
    Container cp = getContentPane();

    // Cria um GridLayout com um n�mero n�o especificado de linhas,
    // com 2 colunas, que mant�m uma dist�ncia horizontal de 5 pixels
    // e uma dist�ncia vertical de 10 pixels entre os componentes
    cp.setLayout(new BorderLayout());
    // Adiciona os bot�es ao grupo
    bgMetodo.add( rbMetodo1 );
    bgMetodo.add( rbMetodo2 );
    bgMetodo.add( rbMetodo3 );

    JPanel cima = new JPanel(new BorderLayout());
    JPanel pn0  = new JPanel(new FlowLayout());
    pn0.add ( lblMatriz );
    pn0.add( arquivoField );
    cima.add (  BorderLayout.NORTH, pn0 );

    JPanel pn1  = new JPanel(new FlowLayout());
    pn1.add( rbMetodo1 );
    pn1.add( rbMetodo2 );
    pn1.add( rbMetodo3 );

    JPanel grid  = new JPanel(new BorderLayout());
    grid.add( BorderLayout.NORTH, pn1 );
  //  grid.add( BorderLayout.SOUTH, pn2 );
    cima.add( BorderLayout.CENTER, grid);

    cima.add( BorderLayout.SOUTH, lblResultados );

    cp.add( BorderLayout.NORTH, cima );
    JPanel pn3  = new JPanel(new FlowLayout());
    JScrollPane spTextArea = new JScrollPane(resultados,
                                             JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

    pn3.add( spTextArea );
    cp.add( BorderLayout.CENTER, pn3 ) ;

    JPanel pn4  = new JPanel(new FlowLayout());
    pn4.add( btnAgrupar );
    pn4.add( btnConteudo );
    cp.add( BorderLayout.SOUTH, pn4  ) ;

    RadioListenerMetodo listenerMetodo = new RadioListenerMetodo();
    rbMetodo1.addActionListener( listenerMetodo );
    rbMetodo2.addActionListener( listenerMetodo );
    rbMetodo3.addActionListener( listenerMetodo );


    btnAgrupar.addActionListener( new BotaoListener() );

    btnConteudo.addActionListener( new BotaoConteudoListener() );

   }



   private class RadioListenerMetodo implements ActionListener {
     public void actionPerformed(ActionEvent e) {
       if (rbMetodo1.isSelected()) {
         metodo = "REAL";
       } else if (rbMetodo2.isSelected()) {
         metodo = "PROXY";
       } else if (rbMetodo3.isSelected()) {
        metodo = "REMOTO";
       }
     }
   }


   private class BotaoListener implements ActionListener {
     public void actionPerformed( ActionEvent e ) {
       String nomeArquivo = "" + arquivoField.getText();
       Arquivo arquivo = null;

       if ( nomeArquivo != "" ) {

         //verifica qual m�todo ser� utilizado
         try {
            if (metodo.equals("REAL") ) {
              arquivo = (arqReal == null)? new ArquivoReal( nomeArquivo ) : arqReal;
              arqReal = arquivo;
            } else if (metodo.equals("PROXY") ) {
              arquivo = (arqProxy == null)? new ArquivoProxy( nomeArquivo ) : arqProxy;
              arqProxy = arquivo;
            } else if (metodo.equals("REMOTO") ) {
              arquivo = (arqRemoto == null)? new ArquivoRemoto( nomeArquivo ) : arqRemoto;
              arqRemoto = arquivo;
            }

            resultados.setText("Fonte dos Dados: " + arquivo.getFonte()+"\n"+
                               "Nome do Arquivo: "+ arquivo.getNome()+"\n"+
                               "Tamanho do Arquivo: "+arquivo.getTamanho());

         } catch (Exception erro) {
           erro.printStackTrace();
           JOptionPane.showMessageDialog(null, "Erro nos dados informados!",
                                           "Erro", JOptionPane.ERROR_MESSAGE);
         }

       } else
         JOptionPane.showMessageDialog(null, "Digite o nome do arquivo!",                                         "Erro", JOptionPane.ERROR_MESSAGE);
     }
   }

   private class BotaoConteudoListener implements ActionListener {
     public void actionPerformed( ActionEvent e ) {
       String nomeArquivo = "" + arquivoField.getText();
       Arquivo arquivo = null;

       if ( nomeArquivo != "" ) {

         //Escolhe uma das op��es
         try {
            if (metodo.equals("REAL") ) {
              arquivo = (arqReal == null)? new ArquivoReal( nomeArquivo ) : arqReal;
              arqReal = arquivo;
            } else if (metodo.equals("PROXY") ) {
              arquivo = (arqProxy == null)? new ArquivoProxy( nomeArquivo ) : arqProxy;
              arqProxy = arquivo;
            } else if (metodo.equals("REMOTO") ) {
              arquivo = (arqRemoto == null)? new ArquivoRemoto( nomeArquivo ) : arqRemoto;
              arqRemoto = arquivo;
            }

           //Atualiza �rea de texto com os dados do arquivo
           atualizarTextArea(arquivo.getConteudo());
         } catch (Exception erro) {
           erro.printStackTrace();
           JOptionPane.showMessageDialog(null, "Erro nos dados informados!",
                                           "Erro", JOptionPane.ERROR_MESSAGE);
         }

       } else
         JOptionPane.showMessageDialog(null, "Digite o nome do arquivo!",                                         "Erro", JOptionPane.ERROR_MESSAGE);
     }
   }

   private void atualizarTextArea(String conteudo) {
      resultados.setText(conteudo);
  }

  public static void main(String args[]) {
    JFrame f = new Interface();
    f.pack();
    f.show();
    f.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }
}




