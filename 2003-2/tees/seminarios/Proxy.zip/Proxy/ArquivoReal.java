package proxy;

import java.io.File;
import java.io.FileReader;
import java.io.LineNumberReader;
import java.io.IOException;
import java.io.Serializable;

/**
 * Classe que implementa a interface arquivo e implementa seus m�todos
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */
public class ArquivoReal implements Arquivo, Serializable {

  private File arquivo;
  /**
   * Cria refer�ncia para o arquivo
   * @param path endere�o de origem do arquivo
   */
  public ArquivoReal(String path) {
    arquivo = new File( path );
  }

  /**
   * Retorna o nome real doa arquivo
   */
  public String getNome() {
    return arquivo.getName();
  }

  /**
   * Retorna a fonte dos dados
   */
  public String getFonte() {
    return "REAL";
  }

  /**
   * Retorna o tamanho real do arquivo
   */
  public long getTamanho() {
    return arquivo.length();
  }


  /**
   * Retorna o conteudo real do arquivo
   */
  public String getConteudo() {
    String conteudo = "";
    //Verifica se houve alguma problema no conteudo
    try {
      LineNumberReader reader = new LineNumberReader(new FileReader(arquivo));
      String linha = reader.readLine();
      while (linha != null){
        conteudo += linha +"\n";
        linha = reader.readLine();
      }
      reader.close(); // Fecha a stream
    } catch (IOException ioe) {};
    return conteudo;
 }

}