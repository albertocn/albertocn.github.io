package proxy;

import java.io.LineNumberReader;

/**
 * Interface que define a funcionalidade do arquivo
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */
public interface Arquivo {

  /**
   * Retorna o nome do arquivo
   */
  String getNome();

  /**
   * Retorna o tamanho do arquivo
   */
  long getTamanho();

  /**
   * Retorna a fonte dos dados
   */
  String getFonte();

  /**
   * Retorna o conteudo do arquivo
   */

  String getConteudo();


}