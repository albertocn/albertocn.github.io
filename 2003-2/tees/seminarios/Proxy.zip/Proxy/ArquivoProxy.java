package proxy;

import java.io.*;

/**
 * Classe que implementa a interface arquivo e serve de proxy
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */

public class ArquivoProxy implements Arquivo, Serializable {

    private String nomeArmazenado   = "";  //buffer do nome do arquivo
    private long  tamanhoArmazenado = 0;   //buffer do tamanho do arquivo
    private String path;
    ArquivoReal arquivo;                  //referencia para arquivo real
    private String fonte;

    /**
     * Construtor que armazena refer�ncia
     * @param path caminho do arquivo
     */
    public ArquivoProxy( String path ){
      this.path = path;
    }

    /**
     * Retorna uma instancia d arquivo real
     */
    protected Arquivo getArquivo() {
      if ( arquivo == null  ){
        arquivo = new ArquivoReal( path );
      }
      return arquivo;
    }

    /**
     * Verifica a fonte dos dados solicitados pelo objeto ArquivoProxy
     */
    public String getFonte() {
      if ( arquivo == null  ){
        return "REAL";
      }
      return "CACHE";
    }


    /**
     * Verifica se o nome do arquivo esta armazenado no buffer se n�o estiver
     * vai no arquivo real.
     *
     */
    public String getNome() {
      if ( nomeArmazenado == "" )
        nomeArmazenado = getArquivo().getNome();
      return nomeArmazenado;
    }

    /**
     * Verifica se o tamanho � nulo se for busca o valor do tamanho no arquivo
     * real.
     */
    public long getTamanho() {
      if ( tamanhoArmazenado == 0 )
        tamanhoArmazenado = getArquivo().getTamanho();
      return tamanhoArmazenado;
    }

    /**
     * Retorna o conteudo real do arquivo
     */
    public String getConteudo() {
      return getArquivo().getConteudo();
    }
}