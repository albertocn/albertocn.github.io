package proxy;

import java.net.*;
import java.io.*;


/**
 * Classe que implementa a interface arquivo e implementa seus m�todos remotamente
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */

public class ArquivoRemoto implements Arquivo {

  private Socket cliente;
  private ReqBasica dadosBasicos = null;
  private String path;

  /**
   * Construtor que aramzena refer�ncia
   * @param path caminho do arquivo
   */
  public ArquivoRemoto(String path) {
    this.path = path;
  }

  /**
    * Faz requsicao a um servidor remoto dos dados necess�rios
    * @return
    */
   protected Object getArquivo( int param ) {

     Object arquivoRecebido = null;
     if (param == 1)
       arquivoRecebido = dadosBasicos;

     if (arquivoRecebido == null) {
       try {
          cliente = new Socket(InetAddress.getByName( "127.0.0.1" ), 5000);
          //configura o fluxo de sa�da para objetos
          ObjectOutputStream output = new ObjectOutputStream ( cliente.getOutputStream() );
          //descarrega o buffer de sa�da
          output.flush();
          ObjectInputStream input = new ObjectInputStream ( cliente.getInputStream() );

          output.writeObject( new Requisicao(path, param) );  //Envia mensagem
          output.flush();

          arquivoRecebido = input.readObject();

          if (param == 1) { dadosBasicos = (ReqBasica) arquivoRecebido; } //armazena dados simples

        } catch (EOFException ee) {
          System.out.println("Cliente terminou conexao");
        } catch (Exception io) {
          io.printStackTrace();
        }
     }

     return arquivoRecebido;
   }
   /**
    * Faz requisi��o se a fonte n�o estiver j� armazenada no objeto dadosBasicos
    */
   public String getFonte() {
     if (dadosBasicos == null)
       return ((ReqBasica)getArquivo(1)).getFonte();
     return "CACHE-REMOTO";
   }


   /**
    * Faz requisi��o se o nome do arquivo n�o estiver armazenado no objeto dadosBasicos
    */
   public String getNome() {
     if (dadosBasicos == null)
       return ((ReqBasica)getArquivo(1)).getNome();
     else
       return dadosBasicos.getNome();
   }

   /**
    * Faz requisi��o se o tamanho n�o estiver j� armazenada no objeto dadosBasicos
    *
    */
   public long getTamanho() {
     if (dadosBasicos == null)
       return ((ReqBasica)getArquivo(1)).getTamanho();
     else
       return dadosBasicos.getTamanho();
   }


   /**
    * Faz requisicao solicitando os dados do arquivo real
    */
   public String getConteudo() {
     return ((ReqConteudo)getArquivo(2)).getConteudo();
   }
}