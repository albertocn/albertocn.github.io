package proxy;

import java.io.Serializable;

/**
 * Objeto enviado pelo servidor remoto como resposta a uma requsisicao de conteudo
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */
public class ReqConteudo implements Serializable {

  private String conteudo;

  public ReqConteudo(String conteudo) {
    this.conteudo = conteudo;
  }

  public String getConteudo() { return conteudo; }
}