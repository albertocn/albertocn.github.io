package proxy;


import java.net.*;
import java.io.*;


/**
 * Servidor que vai receber requsicoes do objeto ArquivoRemoto
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */
public class Servidor {

  private Socket conexao;

  public Servidor() {
    Iniciar();
  }

  private void Iniciar() {
   try {
     ServerSocket server = new ServerSocket(5000, 100);

     while (true) {
       System.out.println("Iniciou Servidor...");
       conexao = server.accept();
       //configura o fluxo de sa�da para objetos
       ObjectOutputStream output = new ObjectOutputStream ( conexao.getOutputStream() );
       //descarrega o buffer de sa�da
       output.flush();
       ObjectInputStream input = new ObjectInputStream (conexao.getInputStream() );
       System.out.println("Recebeu algo...");
       Requisicao req = (Requisicao) input.readObject();

       String path = req.getArquivo(); //caminho do arquivo solicitado
       int param = req.getParam();

       Arquivo arquivo = new ArquivoReal(path); //Objeto do arquivo real

       Object resposta;

       //Verifica qual o par�metro recebido para determinar a respota que ser� enviada
       if (param == 1)
         resposta = new ReqBasica(arquivo.getNome(), arquivo.getTamanho(), arquivo.getFonte() );
       else
         resposta = new ReqConteudo( arquivo.getConteudo() );

       output.writeObject( resposta );  //Envia arquivo de reposta
       output.flush();
       System.out.println("Enviou Resposta...");
     }

   } catch (EOFException ee) {
      System.out.println("Cliente terminou conexao");
    } catch (Exception io) {
      io.printStackTrace();
    }
    return;
  }



  public static void main(String[] args) {
    Servidor socketServidor1 = new Servidor();
  }
}
