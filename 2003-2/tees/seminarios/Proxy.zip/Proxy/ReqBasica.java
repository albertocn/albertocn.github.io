package proxy;

import java.io.Serializable;

/**
 * Objeto enviado pelo servidor remoto como resposta a uma requsisicao b�sica
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */

public class ReqBasica implements Serializable {
  private String nome;
  private long tamanho;
  private String fonte;

  public ReqBasica(String nome, long tamanho, String fonte) {
    this.nome = nome;
    this.tamanho = tamanho;
    this.fonte = fonte;
  }

  public String getNome() { return nome; }
  public long getTamanho() { return tamanho; }
  public String getFonte() { return fonte; }

}