package proxy;


import java.io.Serializable;

/**
 * Classe que faz a requisi��o dos dados do arquivo ao servidor remoto
 * @author Marcos Barbosa D�sea
 * @version 1.0
 */

public class Requisicao implements Serializable {

  // informa o nome do arquivo requisitado
  private String arquivo;
  // informa qual o parametro que indica qual ser� a resposta
  private int param;

  /**
   * Construtor padr�o
   */
  public Requisicao(String arquivo, int param) {
    this.arquivo = arquivo;
    this.param   = param;
  }


  public String getArquivo() { return arquivo; }
  public int getParam() { return param; }

}