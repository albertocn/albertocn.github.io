package br.com.plinio.pp.visitor;

public class PaiDogao implements Pizza {

	final String name = "Pai Dog�o";

	public String order() {
		return name;
	}

}