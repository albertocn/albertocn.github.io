package br.com.plinio.pp.visitor;

public class DeMoto implements Visitor {
	
	private String name;
	
	private final String method = "de Moto";
	
	public void visit(Pizza p) {
		name = p.order();
	}

	public String toString() {
		return name + " " + method;
	}
	
}

