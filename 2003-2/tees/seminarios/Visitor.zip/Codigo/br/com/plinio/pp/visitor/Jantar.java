package br.com.plinio.pp.visitor;

public class Jantar {
	public Pizza getJantar() {
		switch ((int) (Math.random() * 3)) {
			case 0 :
				return new LiguePizza();
			case 1 :
				return new MisterPizza();
			case 2 :
				return new PaiDogao();
			default :
				return null;
		}
	}
	public Visitor howto() {
		switch ((int) (Math.random() * 3)) {
			case 0 :
				return new DeMoto();
			case 1 :
				return new DeAPeh();
			case 2 :
				return new DeOnibus();
			default :
				return null;
		}
	}
}
