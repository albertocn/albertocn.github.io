package br.com.plinio.pp.visitor;

public 	class DeOnibus implements Visitor {
	private String name;
	private final String method = "de Bus�o";

	public void visit(Pizza p) {
		name = p.order();
	}

	public String toString() {
		return name + " " + method;
	}
}
