package br.com.plinio.pp.visitor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class VisitorTest {

	public static void main(String[] args) {
		
		List pizzaList = new ArrayList();
		pizzaList.add(new LiguePizza());
		pizzaList.add(new MisterPizza());
		pizzaList.add(new PaiDogao());
		Iterator it = pizzaList.iterator();
		
		System.out.println(
			"E ai cara, quantos lugares para comer tem por aqui??");
		
		while (it.hasNext()) {
			System.out.println(((Pizza) it.next()).order());
		}
		
		Jantar d = new Jantar();
		Pizza pza = d.getJantar();
		Visitor v = d.howto();
		v.visit(pza);
		
		System.out.println("\nE qual o melhor para ir?");
		System.out.println(v);
	}
}
