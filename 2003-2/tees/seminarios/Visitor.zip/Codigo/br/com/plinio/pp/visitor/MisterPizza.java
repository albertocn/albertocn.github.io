package br.com.plinio.pp.visitor;

public class MisterPizza implements Pizza {
	
	final String name = "Mister Pizza";
	
	public String order() {
		return name;
	}
	
}
