package br.com.plinio.pp.visitor;

public class LiguePizza implements Pizza {
	
	final String name = "Ligue Pizza";
	
	public String order() {
		return name;
	}
	
}
