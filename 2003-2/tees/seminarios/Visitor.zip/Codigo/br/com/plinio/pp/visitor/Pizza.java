package br.com.plinio.pp.visitor;

public interface Pizza {

	public String order();

}
