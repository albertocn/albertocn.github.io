package br.com.plinio.pp.visitor;


public interface Visitor {
	
	public void visit(Pizza p);
	
}
