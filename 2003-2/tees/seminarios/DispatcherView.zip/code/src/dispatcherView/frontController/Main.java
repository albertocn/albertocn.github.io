package br.ufs.periodont.ui.dispatcherView.frontController;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

//Classe de servi�os referentes a Usuarios
import br.ufs.periodont.ui.usuarios.Usuarios;
//Objeto DATA ACESS OBJECT do Usuario (contem os dados de um Usuario)
import br.ufs.periodont.data.usuario.UsuarioDAO;
import br.ufs.periodont.ui.dispatcherView.helper.Helper;

/**Servlet que implementa a funcionalidade de Front Controller
 */
public class Main extends HttpServlet {

  /**
   * Constantes que representam os nomes de certos parametros e atributos
   * importantes das requisicoes
   */
  public static final String ATTDISPATCHER = "dispatcher";
  public static final String ATTACAO = "acao";
  public static final String ATTLOGIN = "vLogin";
  public static final String ATTSENHA = "vSenha";
  public static final String ATTUSER = "user";

  /**
   * Constantes usadas no encerramento de sess�o.
   */
  public static final String ACTENCERRAR = "encerrar";
  public static final String PAGENCERRAR = "Encerrar.jsp";

  /**
   * Parametros associados a moldura
   */
  public static final String PARAMMOLDURAINICIO = "molduraInicio";
  public static final String PARAMMOLDURAFIM = "molduraFim";

  private static final String CONTENT_TYPE = "text/html";

  //Initialize global variables
  public void init() throws ServletException {
  }

  /**
   * O get � redirecionado para o post imediatamente.
   */
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    doPost(request, response);
  }

  /**
   * Efetivamente processa as requisi��es HTTP.
   */
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   //Obtendo a stream de sa�da do browser
    PrintWriter out = response.getWriter();

    try {
      //Verifica e possivelmente efetua a autentica��o do usu�rio
      if (!usuarioAutenticado(request))
        autenticarUsuario(request, response);

      //Pr�-processamento para determinar se foi solicitado um encerramento.
      verificarEncerramento(request, response);

      //A requisi��o � ent�o encaminhada ao dispatcher deste usu�rio.
      getDispatcher(request).dispatch(request, response);

      //Ponto central de tratamento de erros.
    } catch (UnauthorizedException ue) {
      out.println("403 - FORBIDDEN ");
      out.println("VOCE N�O EST� AUTORIZADO A VER ESSE CONTE�DO.");
    } catch (Throwable t) {
      out.println(" Um erro foi capturado na execu��o da sua requisi��o.");
      out.println("Erro:");
      out.println(t.toString());
      out.println("Causa: "+t.getCause());
      t.printStackTrace(out);
      t.printStackTrace();
    }

  }

  /**
   * Pr�-processamento feito pelo Front Controller para deteminar se o usu�rio
   * solicitou um encerramento de sess�o.
   */
  private void verificarEncerramento(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException {
    if (req.getParameter(ATTACAO) !=  null)
      //Caso a acao seja encerrar, encaminha para a p�gina de encerramento
      if (req.getParameter(ATTACAO).equals(ACTENCERRAR)) {
        RequestDispatcher rd = req.getRequestDispatcher(PAGENCERRAR);
        rd.forward(req, res);
      }
  }

  //Poderia ser usado para liberar recursos
  public void destroy() {}

  /**
   * Determina se o usu�rio que enviou a Requisicao req est� autenticado.
   */
  private boolean usuarioAutenticado(HttpServletRequest req) {
    HttpSession session = req.getSession();
    //Se o atributo de sess�o que representa o usu�rio � n�o-nulo, ele
    //est� autenticado
    return (session.getAttribute(ATTUSER) != null);
  }

  /**
   * Tenta autenticar um usuario que enviou a Requisicao req.
   * @param req - Requisicao HTTP
   * @param res - Resposta HTTP
   * @throws ServletException - lan�ada quando h� uma falha durante a autentica��o
   */
  private void autenticarUsuario(HttpServletRequest req, HttpServletResponse res) throws ServletException {
    try {
      //S�o verificados os parametros login e senha
      String login = (String) req.getParameter(ATTLOGIN);
      String senha = (String) req.getParameter(ATTSENHA);

      //Chamada a uma classe biblioteca de m�todos referente a usuarios
      UsuarioDAO usuario = Usuarios.autenticarUsuario(login, senha);
      //O objeto que representa o usu�rio � inclu�do na sess�o
      req.getSession().setAttribute(ATTUSER,usuario);

      //Um Dispatcher referente ao tipo do usu�rio � criado e setado na sess�o
      PaginaPrincipal p = PaginaPrincipal.getPaginaPrincipal(usuario.gettipo().intValue());
      req.getSession().setAttribute(ATTDISPATCHER,p);
    } catch (Throwable e) {
/*      try{
        e.printStackTrace(res.getWriter());
      } catch (IOException ioe) {}*/
      //Lan�a um ServletException em caso de erro de autentica��o
      ServletException se = new ServletException("N�o foi poss�vel autenticar",e);
      throw se;
    }
  }

  /**
   * Retorna o objeto de sessao Dispatcher do usuario que enviou a
   * requisicao req
   */
  private PaginaPrincipal getDispatcher(HttpServletRequest req) {
    return (PaginaPrincipal) req.getSession().getAttribute(ATTDISPATCHER);
  }

}



