package br.ufs.periodont.ui.dispatcherView.frontController;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * Dispatcher para a categoria de usu�rio "Atendente"
 */
public class PaginaPrincipalAtendente extends PaginaPrincipal {

  /**
   * URLs (relativas) das partes das molduras.
   * Com a abordagem, n�o deve estar aqui, e sim em uma vis�o
   */
    private static final String MOLDURAINICIO = "/moldura/atendente/InicioMolduraAtendente.jsp";
    private static final String MOLDURAFIM = "/moldura/atendente/FinalMolduraAtendente.jsp";

    /**
     * Retorna a URL da p�gina inicial do administrador
     */
    public String getPaginaInicial() {
      return "PaginaInicialAtendente.jsp";
    }

    /**
     * No exemplo, o atendente n�o tem permiss�o de acesso ao cadastro de usu�rios
     */
    public void verificarPermissao(HttpServletRequest req) throws UnauthorizedException {
      if (req.getParameter(Main.ATTACAO).equals("cadastroUsuario"))
        throw new UnauthorizedException();
    }

    /**
     * Configura a moldura do administrador
     * Com a abordagem, n�o deve estar aqui, e sim em uma vis�o
     */
    public void setMoldura(HttpServletRequest req) {
      req.setAttribute(Main.PARAMMOLDURAINICIO,MOLDURAINICIO);
      req.setAttribute(Main.PARAMMOLDURAFIM, MOLDURAFIM);
    }

  }
