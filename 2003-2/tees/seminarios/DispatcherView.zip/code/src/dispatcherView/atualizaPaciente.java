package br.ufs.periodont.ui.dispatcherView;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import br.ufs.periodont.ui.dispatcherView.helper.Helper;

public class atualizaPaciente extends HttpServlet {

  private static final String CONTENT_TYPE = "text/html";

  //Initialize global variables
  public void init() throws ServletException {
  }


  public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    try {
      System.out.println("Chamando o Helper...");
      Helper helper = getHelper(request);
      System.out.println("Classe do Helper: " + helper.getClass());
      helper.processar(request);
      //retorna p�gina de confirma��o
      RequestDispatcher rd = request.getRequestDispatcher("main?acao=confirm.jsp");
      rd.include(request, response);
    }
    catch (Throwable e) {}
  }

  public void destroy() {}

  private Helper getHelper(HttpServletRequest req) {
    return Helper.getHelper(req);
  }

}