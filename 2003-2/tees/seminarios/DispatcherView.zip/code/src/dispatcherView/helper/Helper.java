package br.ufs.periodont.ui.dispatcherView.helper;

import javax.servlet.http.*;
import br.ufs.periodont.ui.frontController.*;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: </p>
 * @author not attributable
 * @version 1.0
 */

public abstract class Helper {

  public static Helper getHelper(HttpServletRequest request) {
  // acao = (String) req.getParameter(Main.ATTACTION);
    String acao = "";
    acao = (String) request.getParameter(Main.ATTACTION);
    if (acao == null)
      return NullHelper.getInstance();


    if (acao.equals("cadastrarPaciente"))
      return new CadastrarPacienteHelper();
    else
      return NullHelper.getInstance();
  }

  //Criacao dos Helpers

  public abstract void processar(HttpServletRequest request) throws Throwable;

}
