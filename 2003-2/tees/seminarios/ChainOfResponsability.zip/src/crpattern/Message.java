package crpattern;

/**
 * <p>Title: Exemplo da aplica��o do padr�o Chain of Responsability</p>
 * <p>Description: C�digo exemplo</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: -</p>
 * @author Milton C�sar de Souza Leite
 * @version 1.0
 */

import java.lang.String;

public class Message {

  private int identify;
  private String information;

  public Message(int identify, String information ) {
    this.identify = identify;
    this.information = information;
  }

  int getIdentify (){
    return identify;
  }

  String getInformation (){
    return information;
  }
}