package crpattern;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * <p>Title: Exemplo da aplica��o do padr�o Chain of Responsability</p>
 * <p>Description: C�digo exemplo</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: -</p>
 * @author Milton C�sar de Souza Leite
 * @version 1.0
 */

public class FCRPattern extends JFrame {
// Constantes de identifica��o
  private static int MANAGER_IDENTIFY = 1;
  private static final int DIRECTOR_IDENTIFY = 2;
  private static final int VICEPRESIDENT_IDENTIFY = 3;
  private static final int PRESIDENT_IDENTIFY = 4;

  JPanel jPanel = new JPanel();
  JButton jBEnviar = new JButton();
  JLabel jLAcompanhamento = new JLabel();
  JLabel jLMensagem = new JLabel();
  JTextField jTFMensagem = new JTextField();
  JRadioButton jRBDiretor = new JRadioButton();
  JRadioButton jRBGerente = new JRadioButton();
  JRadioButton jRBVPresidente = new JRadioButton();
  JRadioButton jRBPresidente = new JRadioButton();
  JButton jBSair = new JButton();
  static JTextArea jTAAcompanhamento = new JTextArea();
  JScrollPane scb = new JScrollPane(jTAAcompanhamento);

// Variaveis que participam da cadeia de responsabilidade
  President president = new President(PRESIDENT_IDENTIFY);
  VicePresident vicepresident = new VicePresident(president, VICEPRESIDENT_IDENTIFY);
  Director director = new Director(vicepresident, DIRECTOR_IDENTIFY);
  Manager manager = new Manager(director, MANAGER_IDENTIFY);

  public FCRPattern() {
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void jbInit() throws Exception {
    jPanel.setLayout(new GridBagLayout());
    jBEnviar.setFont(new java.awt.Font("SansSerif", 1, 11));
    jBEnviar.setText("Enviar");
    jBEnviar.addActionListener(new FCRPattern_jBEnviar_actionAdapter(this));
    jLAcompanhamento.setFont(new java.awt.Font("SansSerif", 1, 11));
    jLAcompanhamento.setText("Acompanhamento");
    jLMensagem.setFont(new java.awt.Font("SansSerif", 1, 11));
    jLMensagem.setText("Mensagem");
    jTFMensagem.setText("jTextField2");
    jRBDiretor.setFont(new java.awt.Font("SansSerif", 1, 11));
    jRBDiretor.setText("Diretor");
    jRBGerente.setFont(new java.awt.Font("SansSerif", 1, 11));
    jRBGerente.setText("Gerente");
    jRBGerente.addActionListener(new FCRPattern_jRBGerente_actionAdapter(this));
    jRBVPresidente.setFont(new java.awt.Font("SansSerif", 1, 11));
    jRBVPresidente.setText("Vice Presidente");
    jRBVPresidente.addActionListener(new FCRPattern_jRBVPresidente_actionAdapter(this));
    jRBPresidente.setFont(new java.awt.Font("SansSerif", 1, 11));
    jRBPresidente.setText("Presidente");
    jRBPresidente.addActionListener(new FCRPattern_jRBPresidente_actionAdapter(this));
    jBSair.setFont(new java.awt.Font("SansSerif", 1, 11));
    jBSair.setText("Sair");
    jBSair.addActionListener(new FCRPattern_jBSair_actionAdapter(this));
    jTAAcompanhamento.setCaretColor(Color.black);
    this.getContentPane().add(jPanel);
    addComponent(jLMensagem, 0 , 0, 1, 1, 0, 0, 0, 0, new Insets (2, 2, 2, 2));
    addComponent(jTFMensagem, 0, 1, 1, 1, 0, 0, 0, 0, new Insets (2, 2, 2, 2));
    addComponent(jRBGerente, 0, 2, 1, 1, 0, 0, 0, 0, new Insets (4, 4, 4, 4));
    addComponent(jRBDiretor, 0, 3, 1, 1, 0, 0, 0, 0, new Insets (4, 4, 4, 4));
    addComponent(jRBVPresidente, 0, 4, 1, 1, 0, 0, 0, 0, new Insets (4, 4, 4, 4));
    addComponent(jRBPresidente, 0, 5, 1, 1, 0, 0, 0, 0, new Insets (4, 4, 4, 4));
    addComponent(jBEnviar, 0, 6, 1, 1, 0, 0, 0, 0, new Insets (4, 4, 4, 4));
    addComponent(jBSair, 0, 7, 1, 1, 0, 0, 0, 0, new Insets (4, 4, 4, 4));
    addComponent(jLAcompanhamento, 1, 0, 1, 1, 0, 0, 0, 0, new Insets (2, 2, 2, 2));
    addComponent(scb, 1, 1, 3, 7, 100, 100, 0, 0, new Insets (4, 4, 4, 4));
    jRBDiretor.addActionListener(new FCRPattern_jRBDiretor_actionAdapter(this));
    this.setSize (600, 480);
    this.setTitle("Cadeia de Responsabilidade");
//    pack();
  }

  void jRBGerente_actionPerformed(ActionEvent e) {
    jRBDiretor.setSelected(false);
    jRBVPresidente.setSelected(false);
    jRBPresidente.setSelected(false);
  }

  void jRBDiretor_actionPerformed(ActionEvent e) {
    jRBGerente.setSelected(false);
    jRBVPresidente.setSelected(false);
    jRBPresidente.setSelected(false);
  }

  void jRBVPresidente_actionPerformed(ActionEvent e) {
    jRBGerente.setSelected(false);
    jRBDiretor.setSelected(false);
    jRBPresidente.setSelected(false);
  }

  void jRBPresidente_actionPerformed(ActionEvent e) {
    jRBGerente.setSelected(false);
    jRBDiretor.setSelected(false);
    jRBVPresidente.setSelected(false);
  }

  void jBSair_actionPerformed(ActionEvent e) {
    System.exit(0);
  }

  void jBEnviar_actionPerformed(ActionEvent e) {
    if (jRBGerente.isSelected()) {
      manager.request(new Message(4, jTFMensagem.getText()));
    }
    else
      if (jRBDiretor.isSelected()) {
        manager.request(new Message(5, jTFMensagem.getText()));
      }
      else
        if (jRBVPresidente.isSelected()) {
          manager.request(new Message(6, jTFMensagem.getText()));
        }
        else
          if (jRBPresidente.isSelected()) {
            manager.request(new Message(7, jTFMensagem.getText()));
          }
  }

  public static void showResponse(String response) {
    jTAAcompanhamento.append(response);
  }

  public void addComponent(Component comp, int gridx, int gridy, int gridwidth, int gridheight, int weightx, int weighty, int ipadx, int ipady, Insets insets) {
     GridBagConstraints gbc = new GridBagConstraints();
     gbc.gridx = gridx;
     gbc.gridy = gridy;
     gbc.gridwidth = gridwidth;
     gbc.gridheight = gridheight;
     gbc.weightx = weightx;
     gbc.weighty = weighty;
     gbc.ipadx = ipadx;
     gbc.ipady = ipady;
     gbc.insets = insets;
     gbc.fill = GridBagConstraints.BOTH;
     jPanel.add (comp, gbc);
  }
}

class FCRPattern_jRBGerente_actionAdapter implements java.awt.event.ActionListener {
  FCRPattern adaptee;

  FCRPattern_jRBGerente_actionAdapter(FCRPattern adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRBGerente_actionPerformed(e);
  }
}

class FCRPattern_jRBDiretor_actionAdapter implements java.awt.event.ActionListener {
  FCRPattern adaptee;

  FCRPattern_jRBDiretor_actionAdapter(FCRPattern adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRBDiretor_actionPerformed(e);
  }
}

class FCRPattern_jRBVPresidente_actionAdapter implements java.awt.event.ActionListener {
  FCRPattern adaptee;

  FCRPattern_jRBVPresidente_actionAdapter(FCRPattern adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRBVPresidente_actionPerformed(e);
  }
}

class FCRPattern_jRBPresidente_actionAdapter implements java.awt.event.ActionListener {
  FCRPattern adaptee;

  FCRPattern_jRBPresidente_actionAdapter(FCRPattern adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jRBPresidente_actionPerformed(e);
  }
}

class FCRPattern_jBSair_actionAdapter implements java.awt.event.ActionListener {
  FCRPattern adaptee;

  FCRPattern_jBSair_actionAdapter(FCRPattern adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jBSair_actionPerformed(e);
  }
}

class FCRPattern_jBEnviar_actionAdapter implements java.awt.event.ActionListener {
  FCRPattern adaptee;

  FCRPattern_jBEnviar_actionAdapter(FCRPattern adaptee) {
    this.adaptee = adaptee;
  }
  public void actionPerformed(ActionEvent e) {
    adaptee.jBEnviar_actionPerformed(e);
  }
}