package crpattern;

/**
 * <p>Title: Exemplo da aplica��o do padr�o Chain of Responsability</p>
 * <p>Description: C�digo exemplo</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: -</p>
 * @author Milton C�sar de Souza Leite
 * @version 1.0
 */

public class VicePresident extends Handler {

  private final int doc = 6;

  public VicePresident(Handler handler, int identify) {
    super (handler, identify);
  }

  public void handleResponse (Message message) {
    if (doc == message.getIdentify()){
      crpattern.FCRPattern.showResponse("O k !!\nVice-president(" + identify + ") recebeu o " + ++count + "� documento: " + message.getInformation() + " !!\n");
    }
    else {
      crpattern.FCRPattern.showResponse("Vice Presidente nao responsavel !!!\n");
      super.handleResponse(message);
    }
  }
}