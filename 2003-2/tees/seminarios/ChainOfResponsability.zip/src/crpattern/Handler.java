package crpattern;

/**
 * <p>Title: Exemplo da aplica��o do padr�o Chain of Responsability</p>
 * <p>Description: C�digo exemplo</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: -</p>
 * @author Milton C�sar de Souza Leite
 * @version 1.0
 */

import java.lang.String;

public abstract class Handler {

  private Handler handler = null;
  protected int identify;
  protected int count;

  public Handler(Handler handler, int identify) {
    this.handler = handler;
    this.identify = identify;
  }

  public void handleResponse (Message message) {
    if (handler != null){
      try {
        handler.handleResponse(message);
      } catch (Exception e){
        System.out.println(e.getMessage());
      }
    }
  }

  public void request (Message message){
    handleResponse(message);
  }
}