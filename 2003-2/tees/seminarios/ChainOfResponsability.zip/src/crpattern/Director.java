package crpattern;

/**
 * <p>Title: Exemplo da aplica��o do padr�o Chain of Responsability</p>
 * <p>Description: C�digo exemplo</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: -</p>
 * @author Milton C�sar de Souza Leite
 * @version 1.0
 */

public class Director extends Handler{

  private final int doc = 5;

  public Director(Handler handler, int identify) {
    super(handler, identify);
//    this.setHandler(handler, identify);
  }

  public void handleResponse (Message message) {
    if (doc == message.getIdentify()){
      crpattern.FCRPattern.showResponse("Yes !!\nDirector(" + identify + ") recebeu o " + ++count + "� documento: " + message.getInformation() + " !!\n");
    }
    else {
      crpattern.FCRPattern.showResponse("Diretor nao responsavel !!!\n");
      super.handleResponse(message);
    }
  }
}