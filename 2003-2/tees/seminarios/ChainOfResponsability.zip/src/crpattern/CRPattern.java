package crpattern;

import javax.swing.*;

/**
 * <p>Title: Exemplo da aplica��o do padr�o Chain of Responsability</p>
 * <p>Description: C�digo exemplo</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: -</p>
 * @author Milton C�sar de Souza Leite
 * @version 1.0
 */

public class CRPattern {

  public CRPattern() {
    FCRPattern fcrpattern = new FCRPattern();
    fcrpattern.show();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  public static void main(String[] args) {
    CRPattern crpattern = new CRPattern();
  }

  private void jbInit() throws Exception {
  }
}