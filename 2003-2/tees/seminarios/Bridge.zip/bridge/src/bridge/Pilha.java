package bridge;

// Abstraction Refinada de Colecoes
// Suas operacoes fazem uso dos metodos de Abstraction, que por sua vez
// fazem uso dos m�todos da interface Implementor (EstruturadeDados)

public class Pilha extends Colecoes {

  public Pilha() {

  }

  void empilhar(Object obj) {
    if ( mudouEstrutura( EstruturadeDadosInstancia.getTipo() ) )
      this.mudarImpConc();
    super.inserirPos(tamanho(),obj);
  }

  Object desempilhar() {
    if ( mudouEstrutura( EstruturadeDadosInstancia.getTipo() ) )
      this.mudarImpConc();
    Object o = super.consultarPos(tamanho()-1);
    super.removerPos(tamanho()-1);
    return o;
  }

  Object consultar() {
    if ( mudouEstrutura( EstruturadeDadosInstancia.getTipo() ) )
      this.mudarImpConc();
    return super.consultarPos(tamanho()-1);
  }


//////////////////////////////////////////////
//protegendo os metodos da utilizacao indevida
  void inserirPos(int pos, Object obj) throws UnsupportedOperationException
  {
    if (pos != tamanho())
      { throw new UnsupportedOperationException("Opera��o n�o permitida. S� � poss�vel empilhar no topo da pilha."); }
    else
       super.inserirPos(pos, obj);
  }

  void removerPos(int pos) throws UnsupportedOperationException
  {
    if (pos != tamanho()-1)
      { throw new UnsupportedOperationException("Opera��o n�o permitida. S� � poss�vel desempilhar do tipo da pilha."); }
    else
       super.removerPos(pos);
  }

  Object consultarPos(int pos) throws UnsupportedOperationException
  {
    if (pos != tamanho()-1)
      { throw new UnsupportedOperationException("Opera��o n�o permitida. S� � poss�vel consultar o topo da pilha."); }
    else
       return super.consultarPos(pos);
  }


}