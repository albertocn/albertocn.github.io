package bridge;

import java.util.LinkedList;

/*
 ConcreteImplementor
 Uma das implementa��es da abstracao Colecoes.
 Implementa os metodos definidos na classe abstrata EstruturadeDados,
 que ser�o usados pelos metodos da classe Abstraction.
 */

public class ListaLigada extends EstruturadeDados {

  LinkedList lista;

  public ListaLigada() {
    System.out.println("Implementa��o ListaLigada.");
    lista = new LinkedList();
  }

  public void inserirPosEst(int pos, Object obj){
    lista.add(pos, obj);
  }

  public void removerPosEst(int pos){
    lista.remove(pos);
  }

  public void removerPosEst(Object obj){
    lista.remove(obj);
  }

  public Object consultarEst(int pos){
    return lista.get(pos);
  }

  public int tamanhoEst() {
    return lista.size();
  }
}