package bridge;

//classe Abstraction define a interface das abstracoes
//e mantem referencia para a implementacao

public abstract class Colecoes {

  protected EstruturadeDados est;

  public Colecoes() {
    this.est = EstruturadeDadosInstancia.getEstrutura();
  }

  /******** m�todos ********/

  void inserirPos(int pos, Object obj){
    est.inserirPosEst(pos, obj);
  }

  void removerPos(int pos) {
//    if (est != getEst()) mudarImpConc();
    est.removerPosEst(pos);
  }

  Object consultarPos(int pos) {
  //  if (est != getEst()) mudarImpConc();
    return est.consultarEst(pos);
  }

  int tamanho() {
     return getEst().tamanhoEst();
  }

  /*************************/

  //fixa a referencia � implementacao a ser considerada.
  void setEstrutura() {
     this.est = EstruturadeDadosInstancia.getEstrutura();
  }

  //obtem a referencia � implementacao a ser considerada.
  EstruturadeDados getEst() {
     return est;
  }


  boolean mudouEstrutura ( char tipo ) {
    return ( (tipo == 'L') && ( getEst() instanceof Vetor) ) ||
        ( (tipo == 'V') && ( getEst() instanceof ListaLigada) );
  }

  // Quando alguma alteracao precisa ser feita na abstracao e se verifica
  // que a implementacao concreta foi mudada, a transferencia dos dados da
  // implementacao anterior para a nova � feita atrav�s desse m�todo
  void mudarImpConc(){
    System.out.println(  "Mudan�a dinamica de implementacao."   );
    EstruturadeDados estantiga = est;
    setEstrutura();
    int tam = estantiga.tamanhoEst();
    for (int i = 0; i < tam; i++) {
      est.inserirPosEst(i, estantiga.consultarEst(i));
    }
    est = this.getEst();
  }

}