package bridge;


public class EstruturadeDadosInstancia {

     public static final char VETOR = 'V';
     public static final char LISTA = 'L';

     // para evitar que a Abstracao seja instanciada sem que
     // tenha sido definida a implementa��o vamos usar a
     // ListaLigada como padrao caso a aplica��o cliente nao
     // tenha estabelecido/optado por uma implementacao
     private static char tipo = LISTA;

     public static EstruturadeDados getEstrutura()
     {
         if (tipo == LISTA)
           return new ListaLigada();
         else
            return new Vetor();
     }

     public static void setTipo(char novoTipo) {
       tipo = novoTipo;
     }

     public static char getTipo() {
       return tipo;
     }
}

