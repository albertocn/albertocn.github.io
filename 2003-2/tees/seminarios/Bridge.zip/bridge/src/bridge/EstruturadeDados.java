package bridge;

//classe abstrata Implementor define a interface das implentacoes

public abstract class EstruturadeDados {

  public EstruturadeDados() {
  }

  abstract void inserirPosEst(int pos, Object obj);
  abstract void removerPosEst(int pos);
  abstract Object consultarEst(int pos);
  abstract int tamanhoEst();

}