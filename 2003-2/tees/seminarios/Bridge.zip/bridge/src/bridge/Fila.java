package bridge;

// Abstraction Refinada de Colecoes
// suas operacoes fazem uso dos metodos de Abstraction que por sua vez
// fazem uso dos m�todos da interface Implementor (EstruturadeDados)

import java.lang.UnsupportedOperationException;

public class Fila extends Colecoes {

  public Fila() {
  }

  void inserir(Object obj) {
    if ( mudouEstrutura( EstruturadeDadosInstancia.getTipo() ) )
      this.mudarImpConc();
    super.inserirPos(tamanho(),obj);
  }

  void remover() {
    if ( mudouEstrutura( EstruturadeDadosInstancia.getTipo() ) )
      this.mudarImpConc();
    super.removerPos(0);
  }

  Object consultar() {
    if ( mudouEstrutura( EstruturadeDadosInstancia.getTipo() ) )
      this.mudarImpConc();
    return super.consultarPos(0);
  }



//protegendo os metodos da utilizacao indevida
  void inserirPos(int pos, Object obj) throws UnsupportedOperationException
  {
    if (pos != tamanho())
      { throw new UnsupportedOperationException("Opera��o n�o permitida. S� � poss�vel inserir no fim da fila."); }
    else
       super.inserirPos(pos, obj);
  }

  void removerPos(int pos) throws UnsupportedOperationException
  {
    if (pos != 0)
      { throw new UnsupportedOperationException("Opera��o n�o permitida. S� � poss�vel remover o primeiro da fila."); }
    else
       super.removerPos(pos);
  }

  Object consultarPos(int pos) throws UnsupportedOperationException
  {
    if (pos != 0)
      { throw new UnsupportedOperationException("Opera��o n�o permitida. S� � poss�vel consultar o primeiro da fila."); }
    else
       return super.consultarPos(pos);
  }

}