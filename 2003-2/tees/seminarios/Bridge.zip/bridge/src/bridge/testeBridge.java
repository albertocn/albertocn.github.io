package bridge;


//aplicacao cliente que faz uso da Bridge

public class testeBridge {


  public static void testaPilha() {
    // opta pela implementacao vetor (ConcreteImplementor)
    EstruturadeDadosInstancia.setTipo('V');

    //criando a Abstracao Refinada
    Pilha pi = new Pilha();
    System.out.println(  "Criamos uma pilha..."   );

    //exercitando os metodos
    pi.empilhar(new String("A"));
    System.out.println(   "Empilhou A.    topo: " +  pi.consultar()   );   //exibir A
    pi.empilhar(new String("B"));
    System.out.println(   "Empilhou B.    topo: " +  pi.consultar()   );   //exibir B
    pi.empilhar(new String("C"));
    System.out.println(   "Empilhou C.    topo: " +  pi.consultar()   );   //exibir C
    pi.empilhar(new String("D"));
    System.out.println(   "Empilhou D.    topo: " +  pi.consultar()   );   //exibir D
    pi.empilhar(new String("E"));
    System.out.println(   "Empilhou E.    topo: " +  pi.consultar()   );   // exibir E

    pi.desempilhar();

    // mudar a Pilha para estrutura de dados ListaLigada
    EstruturadeDadosInstancia.setTipo('L');

    System.out.println(   "Desempilhou... agora o topo �: " +  pi.desempilhar()   );
    System.out.println(   "Desempilhou... agora o topo �: " +  pi.desempilhar()   );
    System.out.println(   "Desempilhou... agora o topo �: " +  pi.desempilhar()   );
    System.out.println(   "Desempilhou... agora o topo �: " +  pi.desempilhar()   );

  }

  public static void testaFila() {
    EstruturadeDadosInstancia est;

    // opta pela implementacao vetor (ConcreteImplementor)
    EstruturadeDadosInstancia.setTipo('L');
    //criando a Abstracao Refinada
    Fila fi = new Fila();
    System.out.println(  "Criamos uma fila..."   );

    //exercitando os metodos
    fi.inserir(new String("A"));
    System.out.println(   "Inseriu A no fim da fila. A frente da fila �: " + fi.consultar()   );   //exibir A
    fi.inserir(new String("B"));
    System.out.println(   "Inseriu B no fim da fila. A frente da fila �: " + fi.consultar()   );   //exibir A
    fi.inserir(new String("C"));
    System.out.println(   "Inseriu C no fim da fila. A frente da fila �: " + fi.consultar()   );   //exibir A
    fi.inserir(new String("D"));
    System.out.println(   "Inseriu D no fim da fila. A frente da fila �: " + fi.consultar()   );   //exibir A
    fi.inserir(new String("E"));
    System.out.println(   "Inseriu E no fim da fila. A frente da fila �: " + fi.consultar()   );   //exibir A

    // mudar a Pilha para estrutura de dados ListaLigada
    EstruturadeDadosInstancia.setTipo('V');

    fi.remover();
    System.out.println(   "Removeu quem estava na frente. Agora o primeiro �: " + fi.consultar()   );
    fi.remover();
    System.out.println(   "Removeu quem estava na frente. Agora o primeiro �: " + fi.consultar()   );
    fi.remover();
    System.out.println(   "Removeu quem estava na frente. Agora o primeiro �: " + fi.consultar()   );
    fi.remover();
    System.out.println(   "Removeu quem estava na frente. Agora o primeiro �: " + fi.consultar()   );
    fi.remover();
    System.out.println(   "Removeu quem estava na frente. Agora a fila esta vazia "  );
  }

  public static void main(String[] args)
  {
    testaPilha();
    testaFila();
  }
}