package bridge;

import java.util.ArrayList;

/*
 ConcreteImplementor
 Uma das implementa��es da abstracao Colecoes.
 Implementa os metodos definidos na classe abstrata EstruturadeDados,
 que ser�o usados pelos metodos da classe Abstraction.
 */

public class Vetor extends EstruturadeDados {

  ArrayList vet;

  public Vetor() {
    System.out.println("Implementa��o Vetor");
    vet = new ArrayList();
  }

  public void inserirPosEst(int pos, Object obj){
    vet.add(pos, obj);
  }

  public void removerPosEst(int pos){
    vet.remove(pos);
  }

  public void removerPosEst(Object obj){
    vet.remove(obj);
  }

  public Object consultarEst(int pos){
    return vet.get(pos);
  }

  public int tamanhoEst() {
    return vet.size();
  }

}