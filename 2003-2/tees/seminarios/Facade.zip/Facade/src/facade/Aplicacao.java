package facade;

/**
 * <p>Title: Aplicacao </p>
 * <p>Description: Mostra transacoes de compras e cadastramento de
 *                 produtos e clientes </p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public class Aplicacao {

  public static void main(String args[]) {
    //Obtendo a instancia unica da Fachada
    Facade fachada = Facade.getInstance();
    //As operacoes s�o feitas utilizando apenas a Fachada
    fachada.registrarCliente("Z�", 0);
    fachada.registrarCliente("Jo�o",1);
    fachada.registrarProduto("Hamburguer",0,1.2);
    fachada.registrarProduto("Cachorro Quente",1,1.5);
    fachada.registrarProduto("Coca-cola",2,1.2);
    fachada.registrarProduto("Guaran�",3,1.2);
    fachada.comprar(0, 1);
    fachada.comprar(2, 1);
    fachada.fecharCompra(1);
    fachada.comprar(1, 0);
    fachada.comprar(3, 0);
    fachada.fecharCompra(0);
  }

}