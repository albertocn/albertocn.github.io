package facade;

/**
 * <p>Title: Fachada </p>
 * <p>Description: Define uma interface unica mais geral para os subsistemas</p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public class Facade {

   //Cria a instancia unica usando o padrao Singleton
  private static Facade instanciaUnica = new Facade();
  BancoDeDados banco = new BancoDeDados();

  private Facade() {}

  //Retorna a instancia unica da Fachada
  public static Facade getInstance() {
    return (instanciaUnica);
  }

  //Registra um cliente no banco de dados da aplicacao
  public void registrarCliente(String nome, int id) {
    Cliente cliente = Cliente.create(nome, id);
    Carrinho carrinho = Carrinho.create();
    cliente.adicionarCarrinho(carrinho);
    banco.adicionarCliente(cliente, id);
  }

  //Registra um produto no banco de dados da aplicacao
  public void registrarProduto(String nome, int id, double preco) {
    Produto prod = Produto.create(nome, id, preco);
    banco.adicionarProduto(prod, id);
  }

  //Realiza a transa��o de compra
  public void comprar(int prodID, int clienteID) {
    Cliente c = banco.selectCliente(clienteID);
    Produto p = banco.selectProduto(prodID);
    c.getCarrinho().adicionar(p);
  }

  //Finaliza uma compra de um dado Cliente
  public void fecharCompra(int clienteID) {
    Cliente c = banco.selectCliente(clienteID);
    double valor = c.getCarrinho().getTotal();
    banco.processarPagamento(c, valor);
  }
}
