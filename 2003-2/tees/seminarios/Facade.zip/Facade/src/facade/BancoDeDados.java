package facade;

/**
 * <p>Title: Banco de Dados </p>
 * <p>Description: Realiza superficialmente o papel de um banco de dados </p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public class BancoDeDados {

  Cliente[] listaDeClientes = new Cliente[2];
  Produto[] listaDeProdutos = new Produto[4];

  public BancoDeDados () {}

  //Adiciona um cliente ao banco de dados
  public void adicionarCliente (Cliente c, int i) {
    listaDeClientes[i] = c;
  }

  //Adiciona um produto ao banco de dados
  public void adicionarProduto (Produto p, int i) {
    listaDeProdutos[i] = p;
  }

  //Retorna um cliente cadastrado no banco de dados
  public Cliente selectCliente (int id) {
    return(listaDeClientes[id]);
  }

  //Retorna um produto cadastrado no banco de dados
  public Produto selectProduto (int id) {
    return(listaDeProdutos[id]);
  }

  //Processa o pagamento de um dado Cliente
  public void processarPagamento (Cliente c, double valor) {
    int cont = c.getCarrinho().numProdutos;
    //Imprime os produtos do carrinho de compras do cliente
    for (int i=0; i < cont; i++) {
      System.out.print(c.getCarrinho().lista[i].nome + " -> R$");
      System.out.println(c.getCarrinho().lista[i].preco);
    }
    //Imprime o total pago pelo cliente
    System.out.println("O cliente " + c.nome + " pagou a quantia de R$" + valor);
  }


}