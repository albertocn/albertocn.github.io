package facade;

/**
 * <p>Title: Cliente </p>
 * <p>Description: Define um cliente </p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public class Cliente {

  String nome;
  int id;
  Carrinho carro;

  Cliente(String n, int i) {
    this.nome = n;
    this.id = i;
  }

  //Cria um cliente
  public static Cliente create(String n, int i) {
    Cliente cli = new Cliente(n,i);
    return(cli);
  }

  //Atribui um carrinho de compras ao cliente
  public void adicionarCarrinho (Carrinho car) {
    this.carro = car;
  }

  //Retorna o carrinho de compras do cliente
  public Carrinho getCarrinho() {
    return(this.carro);
  }
}