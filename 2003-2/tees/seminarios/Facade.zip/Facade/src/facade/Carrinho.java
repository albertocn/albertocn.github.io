package facade;

/**
 * <p>Title: Carrinho </p>
 * <p>Description: Define um carrinho de compras </p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public class Carrinho {

  Produto[] lista = new Produto[2];
  double total;
  int numProdutos;

  Carrinho () {
    this.total = 0;
    this.numProdutos = 0;
  }

  //Cria um carrinho de compras
  public static Carrinho create () {
    Carrinho c = new Carrinho();
    return (c);
  }

  //Coloca o produto no carrinho de compras
  public void adicionar(Produto p) {
    lista[numProdutos] = p;
    this.total = this.total + p.preco;
    this.numProdutos = this.numProdutos + 1;
  }

  //Retorna o preco total dos produtos colocados no carrinho
  public double getTotal() {
    return(this.total);
  }
}