package facade;

/**
 * <p>Title: Produto </p>
 * <p>Description: Define um produto </p>
 * @author Tiago Santos Oliveira
 * @version 1.0
 */

public class Produto {

  String nome;
  int id;
  double preco;

  Produto (String n, int i, double p) {
    this.nome = n;
    this.id = i;
    this.preco = p;
  }

  //Cria um Produto
  public static Produto create (String n, int i, double p) {
    Produto prod = new Produto(n, i, p);
    return(prod);
  }

  //Retorna o preco do produto
  public double getPreco() {
    return (preco);
  }
}