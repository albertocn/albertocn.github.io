package plp;

public interface ProgramaPLP {	
	Object executar();
	boolean checaTipo();
}
