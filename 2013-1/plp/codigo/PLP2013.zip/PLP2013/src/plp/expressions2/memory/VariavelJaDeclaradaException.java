package plp.expressions2.memory;

import plp.expressions2.expression.Id;

/**
 * Lan�ada quando se tenta incluir uma vari�vel com o mesmo nome no contexto.
 * 
 * @author Alberto Costa Neto
 * 
 */
public class VariavelJaDeclaradaException extends IdentificadorJaDeclaradoException {
  
	private static final long serialVersionUID = 1L;

	public VariavelJaDeclaradaException(Id id){
		super("Vari�vel " + id + " j� declarada.");
	}
}