package plp.expressions2.memory;

import plp.expressions2.expression.Id;

/**
 * Lan�ada quando se tenta e n�o se consegue obter um Identificador
 * do contexto.
 * 
 * @author Alberto Costa Neto
 * 
 */
public class IdentificadorNaoDeclaradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public IdentificadorNaoDeclaradoException(String msg) {
		super(msg);
	}
	
	public IdentificadorNaoDeclaradoException(Id id){
		this("Identificador " + id + " n�o declarado.");
	}
}