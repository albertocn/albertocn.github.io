package plp.expressions2.memory;

import plp.expressions2.expression.Valor;


public class ContextoExecucao extends Contexto<Valor>
        implements AmbienteExecucao {

}
