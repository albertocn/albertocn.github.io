package plp.expressions2.memory;

import plp.expressions2.expression.Id;

/**
 * Lan�ada quando se tenta obter do contexto uma vari�vel que n�o 
 * foi declarada naquele contexto.
 *  
 * @author Alberto Costa Neto
 *
 */
public class VariavelNaoDeclaradaException extends IdentificadorNaoDeclaradoException{
	
	private static final long serialVersionUID = 1L;

	public VariavelNaoDeclaradaException(Id id){
		super("Vari�vel " + id + " n�o declarada.");
	}
}