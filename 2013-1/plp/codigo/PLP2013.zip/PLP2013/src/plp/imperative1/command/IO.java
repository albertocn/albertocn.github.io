package plp.imperative1.command;

public interface  IO extends  Comando {
  
}
