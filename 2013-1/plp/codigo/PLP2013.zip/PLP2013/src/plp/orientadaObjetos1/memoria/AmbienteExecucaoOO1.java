package plp.orientadaObjetos1.memoria;

import java.util.HashMap;
import java.util.Stack;

import plp.expressions2.expression.Id;
import plp.expressions2.memory.VariavelNaoDeclaradaException;
import plp.orientadaObjetos1.excecao.declaracao.ObjetoJaDeclaradoException;
import plp.orientadaObjetos1.excecao.declaracao.ObjetoNaoDeclaradoException;
import plp.orientadaObjetos1.excecao.execucao.EntradaInvalidaException;
import plp.orientadaObjetos1.expressao.valor.Valor;
import plp.orientadaObjetos1.expressao.valor.ValorRef;
import plp.orientadaObjetos1.memoria.colecao.ListaValor;
import plp.orientadaObjetos1.util.Tipo;

/**
 * Classe que representa um ambiente de execu��o, contendo om mapeamento
 * entre identificadores e valores.
 */
public interface AmbienteExecucaoOO1 extends AmbienteOO1<Valor> {
    /**
     * Obt�m a pilha de mapeamentos de valores associados em identificadores
     * @return a pilha de mapeamentos de valores associados em identificadores.
     */
	public Stack<HashMap<Id, Valor>> getPilha();

    /**
     * Retorna o mapeamento com as defini�oes das classes.
     * @return o mapeamento com as defini�oes das classes.
     */
    public HashMap<Id, DefClasse> getMapDefClasse();

    /**
     * Obt�m a pilha com os mapeamentos de refer�ncias em objetos.
     * @return a pilha com os mapeamentos de refer�ncias em objetos.
     */
    public Stack<HashMap<ValorRef, Objeto>> getPilhaObjeto();

    /**
     * Mapeia um valor refer�ncia a um objeto.
     * @param valorRef Valor refer�ncia.
     * @param objeto Objeto.
     * @throws ObjetoJaDeclaradoException Quando esse objeto j� foi declarado.
     */
    public void mapObjeto(ValorRef valorRef, Objeto objeto) throws ObjetoJaDeclaradoException;

    /**
     * Altera o valor associado a um identificador.
     * @param idArg Identificador.
     * @param valorId O valor a ser associado ao identificador.
     * @throws VariavelNaoDeclaradaException Quando a vari�vel n�o foi
     * declarada.
     */
    public void changeValor(Id idArg, Valor valorId) throws VariavelNaoDeclaradaException;

    /**
     * Obt�m o objeto associado a um dado valor referencia.
     * @param valorRef Valor refer�ncia
     * @return o objeto associado a um dado valor referencia.
     * @throws ObjetoNaoDeclaradoException Quando o objeto n�o foi declarado.
     */
    public Objeto getObjeto(ValorRef valorRef) throws ObjetoNaoDeclaradoException;

    /**
     * Obt�m a pr�xima refer�ncia de acordo com o contexto atual de execu��o.
     * @return a pr�xima refer�ncia de acordo com o contexto atual de execu��o.
     */
    public ValorRef getProxRef();

    /**
     * Obt�m o valor referencia atual.
     * @return o  valor referencia atual.
     */
    public ValorRef getRef();

    /**
     * L� da entrada padr�o e associa o conte�do a um determinado identificador.
     * @param tipoIdLido Tipo do identificador ao qual ser� associado o valor
     * lido.
     * @return o valor lido.
     * @throws EntradaInvalidaException Quando a entrada fornecida n�o pode
     * ser atribu�da ao tipo do identificador.
     */
    public Valor read(Tipo tipoIdLido) throws EntradaInvalidaException;

    /**
     * Escreve um valor 'v' na sa�da.
     * @param v O valor a ser escrito.
     * @return o ambiente de execu��o, que representa o estado atual.
     */
    public AmbienteExecucaoOO1 write(Valor v);

    /**
     * Obt�m a entrada.
     * @return a entrada.
     */
    public ListaValor getEntrada();

    /**
     * Obt�m a sa�da.
     * @return a sa�da.
     */
    public ListaValor getSaida();

    /**
     * Obt�m um novo contexto de execu��o com a mesma entrada, sa�da e pilha
     * de mapeamentos id/valor.
     * @return um novo contexto de execu��o com a mesma entrada, sa�da e pilha
     * de mapeamentos id/valor.
     */
    public ContextoExecucaoOO1 getContextoIdValor();
}
