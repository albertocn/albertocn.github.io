package plp.functional1.memory;

import plp.expressions2.memory.AmbienteExecucao;
import plp.functional1.util.DefFuncao;


public interface AmbienteExecucaoFuncional extends AmbienteExecucao,
		AmbienteFuncional<DefFuncao> {

}
