package test.plp.parsers;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import plp.ProgramaPLP;
import plp.expressions1.parser.ParseException;

public abstract class BaseParserTest {
	
	public void testarProgramaOk(String codigoFonte, String valorEsperado) {		
		try {			
			ProgramaPLP p = parse(codigoFonte);
			checarERodar(codigoFonte, valorEsperado, p);
		} catch (ParseException e) {
			e.printStackTrace();
			fail("Erro sintatico");
		} catch (Exception e) {
			e.printStackTrace();
			fail("Erro desconhecido");
		}
	}
	

	public void checarERodar(String codigoFonte, String valorEsperado, ProgramaPLP p) {
		if (p.checaTipo()) {
			String valorObtido = p.executar().toString();
			assertEquals("Erro no programa:" + codigoFonte, valorEsperado, valorObtido);
		} else {
			fail("Erro de tipo");
		}
	}

	public Object checarERodar(String codigoFonte) {
		try {			
			ProgramaPLP p = parse(codigoFonte);
			if (p.checaTipo()) {
				return p.executar().toString();
			} else {
				fail("Erro de tipo");
			}
		} catch (ParseException e) {
			e.printStackTrace();
			fail("Erro sintatico");
		} catch (Exception e) {
			e.printStackTrace();
			fail("Erro desconhecido");
		}
		return null;
	}
	
	public abstract ProgramaPLP parse(String codigoFonte) throws Exception;
}
