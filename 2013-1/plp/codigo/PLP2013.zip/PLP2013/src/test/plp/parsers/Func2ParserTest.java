package test.plp.parsers;

import java.io.StringReader;

import org.junit.Test;

import plp.ProgramaPLP;
import plp.functional2.parser.Func2Parser;
import plp.functional2.parser.ParseException;

public class Func2ParserTest extends BaseParserTest {
	
	@Test
	public void testSoma() {
		String program = "let fun soma x y = x + y in soma(2,4)";
		testarProgramaOk(program, "6");
	}

	@Test
 public void testProduto() {
		String program = "let fun prod x y = if y == 0 then 0 else x + prod(x, y-1) in prod(3,5)";
		testarProgramaOk(program, "15");
	}

	@Test
	public void testFatorial() {
		String program = "let fun prod x y = if y == 0 then 0 else x + prod(x, y-1) in " +
			                "let var k = 5, fun fat n = if n == 0 then 1 else prod(n, fat(n-1)) in fat(k)";
		testarProgramaOk(program, "120");
	}
	
	@Test
	public void testExpressaoSimples() {
		testarProgramaOk("let fun ident x = x in ident(11)", "11");
	}
	
	@Test
	public void testVarDeclaration() {
		testarProgramaOk("let var x = 10 in x", "10");
	}
	
	@Test
	public void testExpressao() {
		testarProgramaOk("10 + 5 - 3", "12");
	}

	public ProgramaPLP parse(String codigoFonte) throws ParseException {
		return new Func2Parser(new StringReader(codigoFonte)).Input();
	}	
}
