package plp.expressions2.memory;

import plp.expressions2.expression.Valor;

public interface AmbienteExecucao extends Ambiente<Valor> {

}
