package plp.expressions2.memory;

import plp.expressions2.expression.Id;

/**
 * Lan�ada quando se tenta fazer o binding de um identificador
 * existente no contexto.
 * 
 * @author Alberto Costa Neto
 * 
 */
public class IdentificadorJaDeclaradoException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public IdentificadorJaDeclaradoException(String msg) {
		super(msg);
	}
	
	public IdentificadorJaDeclaradoException(Id id){
		this("Identificador " + id + " j� declarado.");
	}
}