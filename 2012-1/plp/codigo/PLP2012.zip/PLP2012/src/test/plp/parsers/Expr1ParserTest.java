package test.plp.parsers;

import java.io.StringReader;

import org.junit.Test;

import plp.ProgramaPLP;
import plp.expressions1.parser.Exp1Parser;
import plp.expressions1.parser.ParseException;

public class Expr1ParserTest extends BaseParserTest {
	
	@Test
	public void testExprInt1() {
		testarProgramaOk("- 2 + 5 - 10", "-7");
	}
	
	@Test
	public void testExprStr1() {
		testarProgramaOk("\"expressions\" ++ \" \" ++ \"1\"", "\"expressions 1\"");
	}
	
	@Test
	public void testLengthStr1() {
		testarProgramaOk("length \"abc\"", "3");
	}
	
	@Test
	public void testExprBool1() {
		testarProgramaOk("false or true and not false", "true");
	}
	
	@Test
	public void testEqualsInt1() {
		testarProgramaOk("10 == 5 + 4 + 1", "true");
	}	

	public ProgramaPLP parse(String codigoFonte) throws ParseException {
		return new Exp1Parser(new StringReader(codigoFonte)).Input();
	}	
}
