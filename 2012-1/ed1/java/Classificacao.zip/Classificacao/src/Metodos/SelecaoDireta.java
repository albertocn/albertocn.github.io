package Metodos;

/**
 * Metodo de classificacao por Selecao Direta
 */
public class SelecaoDireta extends MetodoClassificacao {

	public void ordenar(Comparable[] lista, int primeiro, int ultimo){        
        for(int i = primeiro ; i < ultimo; i++){
            int posMenor = i;
            for(int j = i + 1; j <= lista.length - 1; j++){
                if(menor(lista[j], lista[posMenor])){
                    posMenor = j;
                }
            }
            if(posMenor != i){
            	troca(lista, i, posMenor);
            }
        }
    }
}
