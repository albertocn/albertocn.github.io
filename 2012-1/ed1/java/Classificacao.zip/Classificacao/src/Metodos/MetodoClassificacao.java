package Metodos;

public abstract class MetodoClassificacao {

	/** 
	 * Ordena o array por completo
	 */
    public void ordenar(Comparable[] lista) {
    	ordenar(lista, 0, lista.length - 1);
    }
	
    /**
     * Ordena o array por completo se inicio e fim coincidirem com 0 e dados.length.
     * Tambem suporta ordenacao de parte do array.
     * 
     * @param dados Array a ser ordenado
     * @param primeiro Posicicao inicial da parte do array que sera ordenada 
     * @param ultimo Posicicao final da parte do array que sera ordenada (deve ser no
     *               maximo igual ao tamanho do array - 1).
     */
	public abstract void ordenar(Comparable[] dados, int primeiro, int ultimo);
	
    public boolean maior(Comparable a, Comparable b) {
    	return a.compareTo(b) == 1;
    }
    
    public boolean maiorIgual(Comparable a, Comparable b) {
    	return a.compareTo(b) >= 0;
    }
    
    public boolean menor(Comparable a, Comparable b) {
    	return a.compareTo(b) == -1;
    }
    
    public boolean menorIgual(Comparable a, Comparable b) {
    	return a.compareTo(b) <= 0;
    }
    
    public boolean igual(Comparable a, Comparable b) {
    	return a.compareTo(b) == 0;
    }
    
    public void troca(Comparable[] dados, int posA, int posB) {
    	Comparable temp = dados[posA];
    	dados[posA] = dados[posB];
    	dados[posB] = temp;
    }
}
