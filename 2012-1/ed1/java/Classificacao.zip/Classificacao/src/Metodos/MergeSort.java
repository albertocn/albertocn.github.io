package Metodos;

/**
 * Metodo de classificacao MergeSort
 */
public class MergeSort extends MetodoClassificacao {


	public void ordenar(Comparable[] lista, int primeiro, int ultimo) {
		if (primeiro < ultimo) {
			int Meio = (ultimo + primeiro) / 2;
			ordenar(lista, primeiro, Meio);
			ordenar(lista, Meio + 1, ultimo);
			merge(lista, primeiro, Meio, ultimo);
		}
	}

	private void merge(Comparable[] lista, int primeiro, int meio, int ultimo) {
		Comparable[] Temp = new Comparable[lista.length];
		int proxEsquerda = primeiro;
		int proxDireita = meio + 1;
		int i = primeiro;

		while ( (proxEsquerda <= meio) && (proxDireita <= ultimo)) {
			if (menor(lista[proxEsquerda], lista[proxDireita])) {
				Temp[i++] = lista[proxEsquerda++];
			} else {
				Temp[i++] = lista[proxDireita++];
			}			
		}

		while (proxEsquerda <= meio) {
			Temp[i++] = lista[proxEsquerda++];
		}
		while (proxDireita <= ultimo) {			
			Temp[i++] = lista[proxDireita++];
		}

		for (i = primeiro; i <= ultimo; i++) {
			lista[i] = Temp[i];
		}
	}
}
