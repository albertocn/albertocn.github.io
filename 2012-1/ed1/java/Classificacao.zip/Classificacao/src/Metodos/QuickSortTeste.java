package Metodos;

public class QuickSortTeste extends MetodoClassificacaoTeste {
	
	@Override
	protected void ordenar(Integer[] lista) {
		new QuickSort().ordenar(lista);
	}
}
