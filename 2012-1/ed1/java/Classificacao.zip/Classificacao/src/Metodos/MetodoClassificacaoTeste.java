package Metodos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import junit.framework.TestCase;

import org.junit.Test;

public abstract class MetodoClassificacaoTeste extends TestCase {

	public MetodoClassificacaoTeste() {
		super();
	}

	@Test
	public void testVazia() {
	    Integer[] lista = {};
	    Integer[] listaEsperada = {};
	
	    ordenarEComparar(lista, listaEsperada);
	}

	@Test
	public void testUmElemento() {
	    Integer[] lista = {1};
	    Integer[] listaEsperada = {1};
	
	    ordenarEComparar(lista, listaEsperada);
	}

	@Test
	public void testDoisElementos() {
	    Integer[] lista = {10, 1};
	    Integer[] listaEsperada = {1, 10};
	
	    ordenarEComparar(lista, listaEsperada);
	}

	@Test
	public void testTresElementos() {
	    Integer[] lista = {10, 20, 1};
	    Integer[] listaEsperada = {1, 10, 20};
	
	    ordenarEComparar(lista, listaEsperada);
	}

	@Test
	public void testNormal() {
	    Integer[] lista = {20,6,8,14,97,1};
	    Integer[] listaEsperada = {1,6,8,14,20,97};
	
	    ordenarEComparar(lista, listaEsperada);
	}

	@Test
	public void testDecrescente() {
	    Integer[] lista = {97,20,14,8,6,1};
	    Integer[] listaEsperada = {1,6,8,14,20,97};
	    
	    ordenarEComparar(lista, listaEsperada);
	}
	
	@Test
	public void testMuitosElementosMisturados() {
		
		final int TOTAL = 10000;
		
		// Gera valores sequenciais de 1 a TOTAL e coloca no array esperado
		Integer[] arrayEsperado = new Integer[TOTAL];
		for (int i = 1; i <= TOTAL; i++) {
			arrayEsperado[i - 1] = i;
		}
		
		// Copia os valores do arrayEsperado para uma List e depois mistura
		List<Integer> listaMisturada = new ArrayList<Integer>(TOTAL);
		for (Integer o : arrayEsperado) {
			listaMisturada.add(o);
		}		
		Collections.shuffle(listaMisturada);

		// Copia de volta da List para o array os valores ja misturados 
		Integer[] arrayMisturado = new Integer[TOTAL];
		int i = 0;
		for (Integer valor : listaMisturada) {
			arrayMisturado[i++] = valor;
		}
		
	    ordenarEComparar(arrayMisturado, arrayEsperado);
	}
	
	@Test
	public void testMuitosElementosDecrescente() {
		
		final int TOTAL = 10000;
		
		// Gera valores sequenciais de 1 a TOTAL e coloca no array esperado
		Integer[] arrayEsperado = new Integer[TOTAL];
		Integer[] arrayDecrescente = new Integer[TOTAL];		
		for (int i = 1; i <= TOTAL; i++) {
			arrayEsperado[i - 1] = i;
			arrayDecrescente[TOTAL - i] = i;
		}
		
	    ordenarEComparar(arrayDecrescente, arrayEsperado);
	}
	
public void testMuitosElementosCrescente() {
		
		final int TOTAL = 10000;
		
		// Gera valores sequenciais de 1 a TOTAL e coloca no array esperado
		Integer[] arrayEsperado = new Integer[TOTAL];
		Integer[] arrayCrescente = new Integer[TOTAL];		
		for (int i = 1; i <= TOTAL; i++) {
			arrayEsperado[i - 1] = i;
			arrayCrescente[i - 1] = i;
		}
		
	    ordenarEComparar(arrayCrescente, arrayEsperado);
	}


	
	protected void ordenarEComparar(Integer[] lista, Integer[] listaEsperada) {
//		imprimirArray("array esperado:", listaEsperada);
//		imprimirArray("array misturado:", lista);
		
		ordenar(lista);

//		imprimirArray("array ordenado:", lista);
	    
	    for(int i = 0; i < lista.length; i++){
	        assertEquals(listaEsperada[i], lista[i]);	   
	    }		
	}
	
	protected abstract void ordenar(Integer[] lista);
	
	private void imprimirArray(String s, Integer[] lista) {
		System.out.print(s + ": {");
		for (int i = 0; i < lista.length; i++) {
			System.out.print(" " + lista[i].intValue());	
		}
		System.out.println("}");
	}
}