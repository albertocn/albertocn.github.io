package Metodos;

/**
 * Metodo de Classificacao QuickSort
 */
public class QuickSort extends MetodoClassificacao {

	public void ordenar(Comparable[] v, int ini, int fim) {
		int meio;

		if (ini < fim) {
			meio = Particao(v, ini, fim);
			ordenar(v, ini, meio);
			ordenar(v, meio + 1, fim);
		}
	}

	public int Particao(Comparable[] lista, int primeiro, int ultimo) {
		int posIniPivo = (primeiro + ultimo) / 2;
		if (posIniPivo != primeiro) {
			troca(lista, primeiro, posIniPivo);
		}

		Comparable pivo = lista[primeiro];
		int i = primeiro;
		int j = ultimo;

		do {
			while ((i < ultimo) && menorIgual(lista[i], pivo)) {
				i++;
			}
			while ((j > primeiro) && maior(lista[j], pivo)) {
				j--;
			}
			if (i < j) {
				troca(lista, i, j);
			}
		} while (i < j);

		troca(lista, primeiro, j);
		return j;
	}
}
