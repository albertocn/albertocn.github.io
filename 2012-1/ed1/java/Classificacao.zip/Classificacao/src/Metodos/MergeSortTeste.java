package Metodos;

public class MergeSortTeste extends MetodoClassificacaoTeste {
	
	@Override
	protected void ordenar(Integer[] lista) {
		new MergeSort().ordenar(lista);
	}
}
