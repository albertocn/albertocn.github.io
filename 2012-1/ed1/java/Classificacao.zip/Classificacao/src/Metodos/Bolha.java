package Metodos;

public class Bolha extends MetodoClassificacao {

	/**
	 * Metodo de Classificacao Bolha
	 */
	public void ordenar(Comparable[] lista, int primeiro, int ultimo) {
		int posUltimaTroca = ultimo;
		boolean troquei = false;
		do {
			troquei = false;
			int fim = posUltimaTroca;
			for (int i = primeiro; i < fim; i++) {
				if (maior(lista[i], lista[i + 1])) {
					troca(lista, i, i + 1);
					posUltimaTroca = i;
					troquei = true;
				}

			}
		} while (troquei);
	}
}