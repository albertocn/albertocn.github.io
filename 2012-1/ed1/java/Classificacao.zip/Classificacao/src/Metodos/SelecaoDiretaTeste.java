package Metodos;

public class SelecaoDiretaTeste extends MetodoClassificacaoTeste {
	
	@Override
	protected void ordenar(Integer[] lista) {
		new SelecaoDireta().ordenar(lista);
	}
}
