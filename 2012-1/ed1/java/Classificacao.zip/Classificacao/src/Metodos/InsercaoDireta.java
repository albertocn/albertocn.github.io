package Metodos;

/**
 * Metodo de classificacao por Insercao Direta
 */
public class InsercaoDireta extends MetodoClassificacao {
    
    public void ordenar(Comparable[] lista, int primeiro, int ultimo) {
        Comparable atual;
        int inicioParte2, j;
        for (inicioParte2 = primeiro + 1; inicioParte2 <= ultimo; inicioParte2++){
            j = inicioParte2;
            atual = lista[j];
            
            while( (j > 0) && (menor(atual, lista[j - 1]))) {
                lista[j] = lista[j - 1];
                j--;
            }
            lista[j] = atual;
        }
    }
}

