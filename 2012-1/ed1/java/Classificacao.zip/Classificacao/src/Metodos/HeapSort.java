package Metodos;

/**
 * Metodo de classificacao HeapSort
 */
public class HeapSort extends MetodoClassificacao {
    
    protected static int pai(int indFilho){
        return ((indFilho + 1) / 2) - 1;
    }
    
    protected static int filhoEsq(int indPai){  
        return indPai * 2 + 1;
    }
    
    protected static int filhoDir(int indPai){
        return indPai * 2 + 2;
    }
    
    private void inserirNoHeap(Comparable[] lista, int i){
        int indPai = pai(i);
        int indFilho = i;
        
        while( (indFilho > 0) && menor(lista[indPai], lista[indFilho])) {
        	troca(lista, indPai, indFilho);
            indFilho = indPai;
            indPai = pai(indPai);
        }
    }
    
    private void reposicionarRaizNoHeap(Comparable[] lista, int tamHeap){
        int i = 0;
        while((filhoDir(i) <= tamHeap) && 
        	  (menor(lista[i], lista[filhoEsq(i)]) || menor(lista[i], lista[filhoDir(i)]))){
        	
            if(maior(lista[filhoEsq(i)], lista[filhoDir(i)])){
            	troca(lista, i, filhoEsq(i));
                i = filhoEsq(i);
            }
            else{
            	troca(lista, i, filhoDir(i));
                i = filhoDir(i);
            }
        }
        
        if(filhoEsq(i) == tamHeap){
            if(menor(lista[i], lista[filhoEsq(i)])){
            	troca(lista, i, filhoEsq(i));
            }
        }
    }
    
    public void ordenar(Comparable[] lista, int primeiro, int ultimo){
        int i;
        
        for(i = primeiro + 1; i <= ultimo; i++){
            inserirNoHeap(lista, i);
        }
        
        for(i = ultimo ; i > 0 ; i--){
        	troca(lista, i, 0);
            reposicionarRaizNoHeap(lista, i - 1);
            
        }    	
    }
}
