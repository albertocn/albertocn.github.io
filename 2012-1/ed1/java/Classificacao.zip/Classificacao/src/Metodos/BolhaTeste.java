package Metodos;

public class BolhaTeste extends MetodoClassificacaoTeste {
	
	@Override
	protected void ordenar(Integer[] lista) {
		new Bolha().ordenar(lista);
	}
}
