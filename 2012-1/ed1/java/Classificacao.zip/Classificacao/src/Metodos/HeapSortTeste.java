package Metodos;

import org.junit.Test;

public class HeapSortTeste extends MetodoClassificacaoTeste {
	
	@Override
	protected void ordenar(Integer[] lista) {
		new HeapSort().ordenar(lista);
	}
	
	
	@Test
	public void testPaiFilhos() {
		assertEquals(0, HeapSort.pai(1));
		assertEquals(0, HeapSort.pai(2));
		assertEquals(1, HeapSort.filhoEsq(0));
		assertEquals(2, HeapSort.filhoDir(0));		

		assertEquals(1, HeapSort.pai(3));
		assertEquals(1, HeapSort.pai(4));
		assertEquals(3, HeapSort.filhoEsq(1));
		assertEquals(4, HeapSort.filhoDir(1));

		assertEquals(2, HeapSort.pai(5));
		assertEquals(2, HeapSort.pai(6));
		assertEquals(5, HeapSort.filhoEsq(2));
		assertEquals(6, HeapSort.filhoDir(2));
		
		assertEquals(3, HeapSort.pai(7));
		assertEquals(3, HeapSort.pai(8));
		assertEquals(7, HeapSort.filhoEsq(3));
		assertEquals(8, HeapSort.filhoDir(3));
	}
}
