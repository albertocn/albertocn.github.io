package Metodos;

public class InsercaoDiretaTeste extends MetodoClassificacaoTeste {
	
	@Override
	protected void ordenar(Integer[] lista) {
		new InsercaoDireta().ordenar(lista);
	}
}
