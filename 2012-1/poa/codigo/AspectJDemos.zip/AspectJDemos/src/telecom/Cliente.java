package telecom;

import java.util.Vector;
import java.util.List;

/**
 * Clientes tem um id unico (nome) e codigo de area. Seguem um protocolo
 * para gerenciar chamadas telefonicas, podendo: chamar, atender e desligar.
 */
public class Cliente {

	private String nome;
	private int codigoArea;
	private List<Chamada> chamadas = new Vector<Chamada>();

	public Cliente(String nome, int codigoArea) {
		this.nome = nome;
		this.codigoArea = codigoArea;
	}

	public String toString() {
		return nome + "(" + codigoArea + ")";
	}
	
	public int getCodigoArea() {
		return codigoArea;
	}

	public boolean mesmoCodigoArea(Cliente other) {
		return codigoArea == other.codigoArea;
	}

	public Chamada chamar(Cliente receiver) {
		Chamada call = new Chamada(this, receiver);
		adicionarChamada(call);
		return call;
	}

	public void atender(Chamada call) {
		call.atender();
		adicionarChamada(call);
	}

	public void desligar(Chamada call) {
		call.desligar(this);
		removerChamada(call);
	}

	protected void removerChamada(Chamada c) {
		chamadas.remove(c);
	}

	protected void adicionarChamada(Chamada c) {
		chamadas.add(c);
	}
}
