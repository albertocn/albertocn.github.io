package telecom.simulacao;

import telecom.Chamada;
import telecom.Cliente;

public abstract class SimulacaoAbstrata {

	public static SimulacaoAbstrata simulation;

	/**
	 * Cria objetos e faz com que interajam
	 */
	public void run() {
		Cliente jose = new Cliente("Jose", 79);
		Cliente pedro = new Cliente("Pedro", 79);
		Cliente maria = new Cliente("Maria", 11);

		imprimir("Jose liga para Pedro...");
		Chamada c1 = jose.chamar(pedro);
		esperar(2.0);
		imprimir("Pedro atende...");
		pedro.atender(c1);
		esperar(4.0);
		imprimir("Jose desliga...");
		jose.desligar(c1);
		reportar(jose);
		reportar(pedro);
		reportar(maria);

		imprimir("Pedro liga para Maria...");
		Chamada c2 = pedro.chamar(maria);
		imprimir("Maria atende...");
		maria.atender(c2);
		esperar(3.5);
		imprimir("Maria desliga...");
		maria.desligar(c2);
		reportar(jose);
		reportar(pedro);
		reportar(maria);
	}

	/**
	 * Imprime o tempo de conexao para o cliente
	 */
	abstract protected void reportar(Cliente c);

	protected static void esperar(double segundos) {
		Object lock = new Object();
		synchronized (lock) {
			try {
				lock.wait((long) (segundos * 1000));
			} catch (InterruptedException e) {
			}
		}
	}

	protected static void imprimir(String s) {
		System.out.println(s);
	}
}