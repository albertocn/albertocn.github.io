package telecom;

/**
 * Conexoes sao circuitos entre clientes. Existem dois tipos de conexao:
 * local e de longa distancia.
 */
public abstract class Conexao {

	private static final int PENDENTE = 0;
	private static final int COMPLETADA = 1;
	private static final int DESLIGADA = 2;

	Cliente ligador, recebedor;
	private int estado = PENDENTE;

	Conexao(Cliente a, Cliente b) {
		this.ligador = a;
		this.recebedor = b;
	}

	public int getState() {
		return estado;
	}

	public Cliente getLigador() {
		return ligador;
	}

	public Cliente getRecebedor() {
		return recebedor;
	}
	
	public boolean foiCompletada() {
		return getState() == Conexao.COMPLETADA;
	}
	
	public void conectar() {
		estado = COMPLETADA;
		System.out.println("conexao completada");
	}

	public void desconectar() {
		estado = DESLIGADA;
		System.out.println("conexao desligada");
	}	
}