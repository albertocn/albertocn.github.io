import java.applet.*;
import java.awt.*;
import java.awt.event.*;

public class  AVLApplet extends Applet {
	private TextField input = new TextField(10);
	private Button addNode = new Button("Add");
	private Button removeNode = new Button("Remove");
	private Button reset = new Button("Reset");
	private AVLTree tree;
	private int[][] showTree;
	private int delay = 1000;
	public void init() {
		try{
			delay = Integer.parseInt(getParameter("delay"));
		}catch(NumberFormatException e) {
		}
		newTree();
		addNode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				reset.setEnabled(false);
				removeNode.setEnabled(false);
				addNode.setEnabled(false);
				try{
					tree.add(new ElementObject(Integer.parseInt(input.getText())));
				}catch(NumberFormatException e) {
					showStatus("Invalid Number Format");
				}
				reset.setEnabled(true);
				removeNode.setEnabled(true);
				addNode.setEnabled(true);
				input.setText(""); 
				input.requestFocus();
			}
		});
		removeNode.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				reset.setEnabled(false);
				removeNode.setEnabled(false);
				addNode.setEnabled(false);
				try{
					tree.remove(new ElementObject(Integer.parseInt(input.getText())));
				}catch(NumberFormatException e) {
					showStatus("Invalid Number Format");
				}
				reset.setEnabled(true);
				removeNode.setEnabled(true);
				addNode.setEnabled(true);
				input.setText(""); 
				input.requestFocus();
			}
		});
		reset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				newTree();
				input.requestFocus();
				pause("Reset");
			}
		});
		/*
		 * java.security.AccessControlException: access denied
		 * 
		input.setFont(new Font("Tahoma", Font.PLAIN, 18));
		addNode.setFont(new Font("Tahoma", Font.BOLD, 12));
		reset.setFont(new Font("Tahoma", Font.BOLD, 12));
		*/
		this.add(input);
		this.add(addNode);
		this.add(removeNode);
		this.add(reset);
	}
	public void paint(Graphics g) {
		try {
			for (int i = 1; i < showTree.length; i++)
					g.drawLine(showTree[i][2],
						showTree[i][1]+50,
						showTree[showTree[i][4]][2],
						showTree[showTree[i][4]][1]+50);
			for (int i = 0; i < showTree.length; i++) {
				int margin=-13;
				if(showTree[i][0]<-99) margin = -13;
				else if(showTree[i][0]<-9) margin = -10;
				else if(showTree[i][0]<0) margin = -5;
				else if(showTree[i][0]<10) margin = -2;
				else if(showTree[i][0]<100) margin = -7;
				else if(showTree[i][0]<1000) margin = -10;
				if((char)showTree[i][3] == 'L')	g.setColor(Color.RED);
				else if((char)showTree[i][3] == 'R')	g.setColor(Color.GREEN);
				else g.setColor(Color.YELLOW);
				g.fillOval(showTree[i][2]-12, showTree[i][1]+38,25,25);
				g.setColor(Color.BLACK);
				g.drawString(Integer.toString(showTree[i][0]), showTree[i][2]+margin, showTree[i][1]+54);
			}
		}catch(NullPointerException e) {
		}
	}
	private void newTree() {
		tree = new AVLTree(this);
	}
	public synchronized void pause(String process) {
		showTree = tree.toCoordinates(25, getWidth(),true);
		showStatus(process);
	    update(getGraphics());
		try {
			wait(delay);
		} 
		catch (InterruptedException e) {
		}
	}
}
