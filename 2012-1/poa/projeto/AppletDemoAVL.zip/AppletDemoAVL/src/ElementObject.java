public class ElementObject implements Comparable {
	protected int val;
	public ElementObject(int v) {
		val = v;
	}
	public int compareTo(Object o) {
		if (o instanceof ElementObject)
			return this.val - ((ElementObject) o).val;
		return 0;
	}
}
