public class TreeEntry {
	protected Object element;
	protected TreeEntry left, right, parent;
	protected char balanceFactor;
	public TreeEntry(TreeEntry p, Object elem) {
		parent = p;
		left = null;
		right = null;
		element = elem;
		balanceFactor = '=';
	}
}
