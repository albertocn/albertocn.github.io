public class AVLTree {
	protected TreeEntry root;
	public int size, height;
	public AVLApplet parentApplet;
	static boolean LEFT = true;
	static boolean RIGHT = false;
	public AVLTree(AVLApplet a) {
		root = null;
		size = 0;
		height = 0;
		parentApplet = a;
	}
	/*
	 * add and other relate methods
	 */
	public void add(Object elem) {
		TreeEntry e = root, e2 = null;
		if (root == null) {
			root = new TreeEntry(null, elem);
			size++;
			height++;
			parentApplet.pause("Root");
			return;
		}
		while (true) {
			if (((Comparable) (e.element)).compareTo(elem) > 0) {
				if (e.balanceFactor != '=')
					e2 = e;
				if (e.left == null) {
					e.left = new TreeEntry(e, elem);
					size++;
					fixAfterInsertion(e2, e.left);
					break;
				}
				e = e.left;
			} else if (((Comparable) (e.element)).compareTo(elem) < 0) {
				if (e.balanceFactor != '=')
					e2 = e;
				if (e.right == null) {
					e.right = new TreeEntry(e, elem);
					size++;
					fixAfterInsertion(e2, e.right);
					break;
				}
				e = e.right;
			} else
				break;
		}
	}
	protected void fixAfterInsertion(TreeEntry ancestor, TreeEntry inserted) {
		Object o = inserted.element;
		if (ancestor == null) {
			if (((Comparable) o).compareTo(root.element) < 0)
				root.balanceFactor = 'L';
			else
				root.balanceFactor = 'R';
			parentApplet.pause(
				"Case 1: ancestor == null -> adjust root and path only");
			adjustPath(root, inserted);
			parentApplet.pause("Case 1: adjusted path");
			height++;
		} // Case 1: ancestor == null -> adjust root and path only 
		else if (
			(ancestor.balanceFactor == 'L'
				&& ((Comparable) o).compareTo(ancestor.element) > 0)
				|| (ancestor.balanceFactor == 'R'
					&& ((Comparable) o).compareTo(ancestor.element) < 0)) {
			ancestor.balanceFactor = '=';
			parentApplet.pause("Case 2: ancestor.balanceFactor becomes =");
			adjustPath(ancestor, inserted);
			parentApplet.pause("Case 2: adjusted path");
		} // Case 2: ancestor.balanceFactor becomes '='
		else if (
			ancestor.balanceFactor == 'R'
				&& ((Comparable) o).compareTo(ancestor.right.element) > 0) {
			ancestor.balanceFactor = '=';
			parentApplet.pause("Case 3: requires single left rotation");
			rotateLeft(ancestor);
			parentApplet.pause("Case 3: left rotated");
			adjustPath(ancestor.parent, inserted);
			parentApplet.pause("Case 3: adjusted path");
		} // Case 3: requires single left rotation
		else if (
			ancestor.balanceFactor == 'L'
				&& ((Comparable) o).compareTo(ancestor.left.element) < 0) {
			ancestor.balanceFactor = '=';
			parentApplet.pause("Case 4: requires single right rotation");
			rotateRight(ancestor);
			parentApplet.pause("Case 4: right rotated");
			adjustPath(ancestor.parent, inserted);
			parentApplet.pause("Case 4: adjusted path");
		} // Case 4: requires single right rotation
		else if (
			ancestor.balanceFactor == 'L'
				&& ((Comparable) o).compareTo(ancestor.left.element) > 0) {
			parentApplet.pause("Case 5: requires left-right rotation");
			rotateLeft(ancestor.left);
			parentApplet.pause("Case 5: fisrt - left rotation");
			rotateRight(ancestor);
			parentApplet.pause("Case 5: second - right rotation");
			adjustLeftRight(ancestor, inserted);
			parentApplet.pause("Case 5: adjusted left - right");
		} // Case 5: requires left-right rotation
		else {
			parentApplet.pause("Case 6: requires right-left rotation");
			rotateRight(ancestor.right);
			parentApplet.pause("Case 6: fisrt - right rotation");
			rotateLeft(ancestor);
			parentApplet.pause("Case 6: second - left rotation");
			adjustRightLeft(ancestor, inserted);
			parentApplet.pause("Case 6: adjusted right - left");
		} // Case 6: requires right-left rotation
	}
	protected void adjustPath(TreeEntry to, TreeEntry inserted) {
		Object o = inserted.element;
		TreeEntry temp = inserted.parent;
		while (temp != to) {
			if (((Comparable) o).compareTo(temp.element) < 0)
				temp.balanceFactor = 'L';
			else
				temp.balanceFactor = 'R';
			temp = temp.parent;
			parentApplet.pause("Adjusting path");
		}
	}
	protected void adjustLeftRight(TreeEntry ancestor, TreeEntry inserted) {
		Object o = inserted.element;
		if (ancestor.parent == inserted)
			ancestor.balanceFactor = '=';
		else if (((Comparable) o).compareTo(ancestor.parent.element) < 0) {
			ancestor.balanceFactor = 'R';
			adjustPath(ancestor.parent.left, inserted);
		} else {
			ancestor.balanceFactor = '=';
			ancestor.parent.left.balanceFactor = 'L';
			adjustPath(ancestor, inserted);
		}
	}
	protected void adjustRightLeft(TreeEntry ancestor, TreeEntry inserted) {
		Object o = inserted.element;
		if (ancestor.parent == inserted)
			ancestor.balanceFactor = '=';
		else if (((Comparable) o).compareTo(ancestor.parent.element) > 0) {
			ancestor.balanceFactor = 'L';
			adjustPath(ancestor.parent.right, inserted);
		} else {
			ancestor.balanceFactor = '=';
			ancestor.parent.right.balanceFactor = 'R';
			adjustPath(ancestor, inserted);
		}
	}
	private void rotateLeft(TreeEntry p) {
		TreeEntry r = p.right;
		p.right = r.left;
		if (r.left != null)
			r.left.parent = p;
		r.parent = p.parent;
		if (p.parent == null)
			root = r;
		else if (p.parent.left == p)
			p.parent.left = r;
		else
			p.parent.right = r;
		r.left = p;
		p.parent = r;
	}
	private void rotateRight(TreeEntry p) {
		TreeEntry l = p.left;
		p.left = l.right;
		if (l.right != null)
			l.right.parent = p;
		l.parent = p.parent;
		if (p.parent == null)
			root = l;
		else if (p.parent.left == p)
			p.parent.left = l;
		else
			p.parent.right = l;
		l.right = p;
		p.parent = l;
	}
	/*
	 * remove  and other relate methods
	 */
	public boolean remove(Object elem) {
		TreeEntry e = root, suc;
		while (e != null) {
			if (((Comparable) e.element).compareTo(elem) == 0) {
				if (size == 1) {
					root = null;
					size = 0;
					parentApplet.pause("Remove root");
					return true;
				}
				suc = successor(e);
				e.element = suc.element;
				size--;
				removeEntry(suc);
				return true;
			} else if (((Comparable) e.element).compareTo(elem) > 0)
				e = e.left;
			else
				e = e.right;
		}
		parentApplet.pause("No Match found");
		return false;
	}
	protected void removeEntry(TreeEntry e) {
		TreeEntry p = e.parent;
		e.parent = null;
		if (e == p.right) {
			p.right = e.right;
			if (p.right != null)
				p.right.parent = p;
			parentApplet.pause("Removed");
			fixAfterDeletion(p, RIGHT);
		} else {
			p.left = e.right;
			if (p.left != null)
				p.left.parent = p;
			parentApplet.pause("Removed");
			fixAfterDeletion(p, LEFT);
		}
	}
	protected void fixAfterDeletion(TreeEntry entry, boolean shortened) {
		TreeEntry e = entry, p;
		char f;
		boolean s, s2 = shortened;
		for (s = shortened; e != null; e = p, s = s2) {
			p = e.parent;
			if (p != null)
				s2 = (p.left == e) ? LEFT : RIGHT;
			parentApplet.pause("Balancing");
			if (e.balanceFactor == '=') {
				e.balanceFactor = (s == LEFT) ? 'R' : 'L';
				parentApplet.pause("Adjust balance factor");
				return;
			}
			if (e.balanceFactor == 'L') {
				if (s == LEFT) {
					e.balanceFactor = '=';
					parentApplet.pause("Adjust balance factor");
				} else {
					if (e.left.balanceFactor == 'R') {
						f = e.left.right.balanceFactor;
						e.left.balanceFactor = (f == 'R') ? 'L' : '=';
						e.left.right.balanceFactor = 'L';
						parentApplet.pause(
							"Adjust balance factor before left-right rotation");
						rotateLeft(e.left);
						parentApplet.pause("Left rotation");
					}
					f = e.left.balanceFactor;
					e.left.balanceFactor = (f == 'L') ? '=' : 'R';
					e.balanceFactor = (f == 'L') ? '=' : 'L';
					parentApplet.pause(
						"Adjust balance factor before right rotation");
					rotateRight(e);
					parentApplet.pause("Right rotation");
				}
			} else {
				if (s == RIGHT) {
					e.balanceFactor = '=';
					parentApplet.pause("Adjust balance factor");
				} else {
					if (e.right.balanceFactor == 'L') {
						f = e.right.left.balanceFactor;
						e.right.balanceFactor = (f == 'L') ? 'R' : '=';
						e.right.left.balanceFactor = 'R';
						parentApplet.pause(
							"Adjust balance factor before right-left rotation");
						rotateRight(e.right);
						parentApplet.pause("Right rotation");
					}
					f = e.right.balanceFactor;
					e.right.balanceFactor = (f == 'R') ? '=' : 'L';
					e.balanceFactor = (f == 'R') ? '=' : 'R';
					parentApplet.pause(
						"Adjust balance factor before left rotation");
					rotateLeft(e);
					parentApplet.pause("Left rotation");
				}
			}
		}
	}
	protected TreeEntry successor(TreeEntry e) {
		TreeEntry temp = e;
		if (e.right != null) {
			temp = temp.right;
			while (temp.left != null)
				temp = temp.left;
			return temp;
		}
		// CAUTION: This return value is only proven correct with AVL tree.
		return e.left == null ? e : e.left;
	}
	/*
	 * other method
	 */
	public int[][] toCoordinates(int h, int w, boolean fixH) {
		int c[][] = new int[size][5];
		int i[] = { 0 };
		int hStep = (height > 1) ? h / (height - 1) : 0;
		hStep = fixH ? h : hStep;
		traverseToCoordinates(root, i, c, 0, w / 2, hStep, w / 4, -1);
		return c;
	}
	private void traverseToCoordinates(
		TreeEntry e,
		int i[],
		int c[][],
		int y,
		int x,
		int h,
		int w,
		int p) {
		int curI = i[0];
		if (e == null)
			return;
		if (e.element instanceof ElementObject) {
			c[i[0]][0] = ((ElementObject) (e.element)).val; // integer value
			c[i[0]][1] = y; // vertical position
			c[i[0]][2] = x; // horizontal position
			c[i[0]][3] = (int) e.balanceFactor; // balance factor
			c[i[0]][4] = p; // index of parent in c[][]
			i[0]++;
		}
		traverseToCoordinates(e.left, i, c, y + h, x - w, h, w / 2, curI);
		traverseToCoordinates(e.right, i, c, y + h, x + w, h, w / 2, curI);
	}
	public static void traverse(AVLTree t, int mode) {
		switch (mode) {
			case 0 :
				preorder(t.root);
				break;
			case 1 :
				inorder(t.root);
				break;
			case 2 :
				postorder(t.root);
				break;
			default :
				break;
		}
	}
	protected static void preorder(TreeEntry e) {
		if (e == null)
			return;
		System.out.print(
			((ElementObject) (e.element)).val + "" + e.balanceFactor + "\t");
		preorder(e.left);
		preorder(e.right);
	}
	protected static void inorder(TreeEntry e) {
		if (e == null)
			return;
		inorder(e.left);
		System.out.print(
			((ElementObject) (e.element)).val + "" + e.balanceFactor + "\t");
		inorder(e.right);
	}
	protected static void postorder(TreeEntry e) {
		if (e == null)
			return;
		postorder(e.left);
		postorder(e.right);
		System.out.print(
			((ElementObject) (e.element)).val + "" + e.balanceFactor + "\t");
	}
}
