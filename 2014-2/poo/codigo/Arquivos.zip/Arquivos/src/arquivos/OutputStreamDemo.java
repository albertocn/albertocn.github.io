package arquivos;

import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;

public class OutputStreamDemo {

    private static final int NUM_LINHAS = 100;

    public OutputStreamDemo(String caminho) throws IOException {

        OutputStream os = new FileOutputStream(caminho);
        PrintStream ps = new PrintStream(os);

        // Escreve o objeto String no arquivo
        ps.print(criarString(NUM_LINHAS));
        
        ps.flush(); // For�a a escrita dos buffers
        ps.close(); // Fecha a stream
    }

    // Cria uma String que ser� gravada
    private String criarString(int numLinhas) {

        // ByteArrayOutputStream mant�m a sa�da em um array
        // e permite recuper�-lo posteriormente
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        // PrintStream permite imprimir tipos primitivos,
        // Strings e Objetos. Facilita tamb�m a inclus�o
        // de separadores de linha
        PrintStream ps = new PrintStream(baos);

        // Escreve no PrintStream o n�mero de linhas especificado
        // contendo o n�mero da linha e uma String na forma
        // NomeX, onde X representa o nome da linha
        for (int i = 1; i <= numLinhas; i++) {
            ps.println("" + i + " Nome" + i);
        }

        return baos.toString();
    }

    public static void main(String[] args) {
        try {
            String arquivo = "arqs" +
                             System.getProperty("file.separator") +
                             "OutputStream.txt";
            System.out.println("Gravando " + arquivo + "...");
            new OutputStreamDemo(arquivo);
            System.out.println("Arquivo gravado");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}