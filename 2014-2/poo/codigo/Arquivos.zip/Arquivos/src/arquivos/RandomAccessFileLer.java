package arquivos;

import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFileLer {

    public RandomAccessFileLer(String caminho) throws IOException {

        // Cria um RandomAccessFile somente para leitura
        RandomAccessFile raf = new RandomAccessFile(caminho, "r");

        // Imprime os bytes contidos no arquivo como n�meros
        // inteiros no sentido inverso (do final do arquivo
        // para o in�cio)
        imprimirNumeros(raf);

        // Fecha a stream
        raf.close();
    }

    private void imprimirNumeros(RandomAccessFile raf)
            throws IOException {

        // Anda do final ao in�cio do arquivo
        for (long i = raf.length() - 1; i >= 0; i--) {

            // Posiciona ponteiro. Como i vai diminuindo
            // durante o la�o, o ponteiro anda do fim
            // do arquivo par ao in�cio
            raf.seek(i);

            // Faz a leitura do byte e imprime como um
            // n�mero inteiro
            System.out.println((int) raf.read());
        }
    }

    public static void main(String[] args) {
        try {
          String arquivo = "arqs" +
                           System.getProperty("file.separator") +
                           "RandomAccessFile.dat";
          System.out.println("Lendo " + arquivo + "...");
          new RandomAccessFileLer(arquivo);
          System.out.println("Arquivo lido");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}