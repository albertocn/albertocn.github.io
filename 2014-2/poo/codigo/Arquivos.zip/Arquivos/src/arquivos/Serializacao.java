package arquivos;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Serializacao {

    // Nome do arquivo no qual os objetos ser�o serializados
    private String caminho;

    public Serializacao(String caminho) throws IOException {
        this.caminho = caminho;

        // Cria 5 alunos
        Collection c = criarAlunos(5);

        // Imprime os alunos na tela
        imprimirObjetos(c.iterator());

        // Grava os objetos Aluno em arquivo
        gravarAlunos(c);

        // Coloca uma linha divis�ria na tela
        imprimirSeparador();

        // Faz a leitura dos objetos Aluno serializados
        // em arquivo para uma nova cole��o
        Collection c2 = lerAlunos();

        // Imprime os objetos Aluno lidos do arquivo
        imprimirObjetos(c2.iterator());
    }

    // Cria uma cole��o de objetos Aluno
    private Collection criarAlunos(int num) {
        Collection c = new ArrayList();

        for (int i = 0; i < num; i++) {
            c.add(new Aluno("Aluno" + i,
                            (int) (Math.random() * 1000),
                            (int) (Math.random() * 1000)));
        }

        return c;
    }

    // Imprime acess�veis pelo iterator
    private void imprimirObjetos(Iterator it) {
        while (it.hasNext()) {
            System.out.println(it.next());
        }
    }

    // Imprime um separador na tela
    private void imprimirSeparador() {
        System.out.println();
        for (int i = 0; i < 80; i++) {
            System.out.print("=");
        }
        System.out.println();
    }

    // Grava os alunos no arquivo
    private void gravarAlunos(Collection c) throws IOException {

        // Abre o arquivo
        FileOutputStream fos = new FileOutputStream(caminho);
        ObjectOutputStream oos = new ObjectOutputStream(fos);

        // Grava o n�mero de alunos
        oos.writeInt(c.size());

        // Grava os objetos alunos
        Iterator it = c.iterator();
        while (it.hasNext()) {
            oos.writeObject(it.next());
        }

        oos.flush();  // For�a a escrita dos buffers
        oos.close();  // Fecha a stream
    }

    // L� os alunos do arquivo
    private Collection lerAlunos() throws IOException {

        // Abre o arquivo
        FileInputStream fis = new FileInputStream(caminho);
        ObjectInputStream ois = new ObjectInputStream(fis);

        Collection alunos = new ArrayList();

        // Obt�m o n�mero de alunos gravados no arquivo
        int num = ois.readInt();

        try {
            // Obt�m os objetos do arquivo e adiciona na cole��o
            for (int i = 0; i < num; i++) {
                alunos.add(ois.readObject());
            }
        } catch (ClassNotFoundException e) {
            // A classe Aluno n�o foi encontrada
            e.printStackTrace();
        } finally {
            ois.close();  // Fecha a stream
        }

        return alunos;
    }

    public static void main(String[] args) {
        try {
            String arquivo = "arqs" +
                             System.getProperty("file.separator") +
                             "Serializacao.ser";

            new Serializacao(arquivo);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

// Classe simples que representa um aluno que possui
// um nome e um array com duas notas. O fato
// de implementar Serializable n�o obriga a classe
// a definir nenhum m�todo adicional
class Aluno implements Serializable {
    private String nome;
    private int[]  notas = new int[2];

    public Aluno(String nome, int nota1, int nota2) {
        this.nome = nome;
        notas[0] = nota1;
        notas[1] = nota2;
    }

    // Sobrep�e o m�todo herdado de Object
    public String toString() {
        return nome + "  -  Nota1: " +
               (notas[0]/100.0) + "  |  Nota2: " +
               (notas[1]/100.0);
    }
}