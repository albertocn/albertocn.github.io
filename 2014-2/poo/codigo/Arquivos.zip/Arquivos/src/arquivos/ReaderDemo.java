package arquivos;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.StringTokenizer;

public class ReaderDemo {

  public ReaderDemo(String caminho) throws IOException {

    // Obt�m um Reader para o arquivo especificado
    LineNumberReader reader = new LineNumberReader(new FileReader(caminho));

    // L� o n�mero de linhas gravadas no arquivo
    String linha = reader.readLine();
    int numLinhas = Integer.parseInt(linha);
    System.out.println("" + numLinhas + " linha(s)");

    lerLinhas(reader, numLinhas);

    reader.close(); // Fecha a stream
  }

  // Faz a leitura do n�mero de linhas especificado
  // e imprime na tela
  private void lerLinhas(LineNumberReader reader, int total)
          throws IOException {
    while ( total >= reader.getLineNumber() ) {
      int lin = reader.getLineNumber();
      System.out.println("Linha[" + lin + "]: " + reader.readLine());
    }
  }

  public static void main(String[] args) {
    try {
      String arquivo = "arqs" +
                       System.getProperty("file.separator") +
                       "Writer.txt";
      System.out.println("Lendo " + arquivo + "...");
      new ReaderDemo(arquivo);
      System.out.println("Arquivo lido");
    } catch (FileNotFoundException e) {
    	System.out.println("Arquivo nao encontrado");
        e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}