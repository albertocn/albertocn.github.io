package arquivos;

import java.io.IOException;
import java.io.RandomAccessFile;

public class RandomAccessFileEscrever {

    public RandomAccessFileEscrever(String caminho) throws IOException {

        // Cria um RandomAccessFile para leitura e escrita
        RandomAccessFile raf = new RandomAccessFile(caminho, "rw");

        // Grava dez bytes no arquivo. Os bytes representam
        // n�meros n�meros inteiros de 1 a 10
        gravarNumeros(raf, 1, 10);

        // Fecha a stream
        raf.close();
    }

    private void gravarNumeros(RandomAccessFile raf,
                               int              inicio,
                               int              fim)
            throws IOException {

        // Ajusta o tamanho do arquivo. Se o tamanho do
        // era maior que o escolhido, ser� truncado
        raf.setLength(fim - inicio + 1);

        // Coloca o ponteiro na posi��o em que a pr�xima
        // escrita (ou leitura) seja efetuada na posi��o 0
        // do arquivo
        raf.seek(0);

        // Imprime os inteiros como bytes
        for (int i = inicio; i <= fim; i++) {
            // Imprime um byte. Ap�s imprimir o ponteiro
            // passa automaticamente para pr�xima posi��o
            raf.write((byte) i);
        }
    }

    public static void main(String[] args) {
        try {
            String arquivo = "arqs" +
                             System.getProperty("file.separator") +
                             "RandomAccessFile.dat";

            System.out.println("Gravando " + arquivo + "...");
            new RandomAccessFileEscrever(arquivo);
            System.out.println("Arquivo gravado");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}