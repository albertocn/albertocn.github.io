package arquivos;

import java.io.IOException;
import java.io.Writer;
import java.io.FileWriter;

public class WriterDemo {

    private static final int NUM_LINHAS = 1000;

    private String separadorDeLinhas;

    public WriterDemo(String caminho) throws IOException {
        // Obt�m um Writer para o arquivo especificado
        Writer w = new FileWriter(caminho);

        // Escreve na primeira linha o n�mero de
        // linhas escritas no arquivo
        w.write("" + NUM_LINHAS + getSeparadorDeLinhas());

        escreverLinhas(w, NUM_LINHAS);

        w.flush(); // For�a a escrita dos buffers
        w.close(); // Fecha a stream
    }

    // Escreve no Writer o n�mero de linhas especificado
    // contendo o n�mero da linha e uma String na forma
    // NomeX, onde X representa o nome da linha
    private void escreverLinhas(Writer w, int num)
            throws IOException {

        for (int i = 1; i <= num; i++) {
            w.write("" + i + " Nome" + i + getSeparadorDeLinhas());
        }
    }

    // Retorna o separador de linhas da plataforma
    private String getSeparadorDeLinhas() {
        if (separadorDeLinhas == null) {
            separadorDeLinhas = System.getProperty("line.separator");
        }
        return separadorDeLinhas;
    }

    public static void main(String[] args) {
        try {
            String arquivo = "arqs" +
                             System.getProperty("file.separator") +
                             "Writer.txt";
            System.out.println("Gravando " + arquivo + "...");
            long antes = System.currentTimeMillis();
            new WriterDemo(arquivo);
            long tempo = System.currentTimeMillis() - antes;
            System.out.println("Arquivo gravado em " + tempo + " ms");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}