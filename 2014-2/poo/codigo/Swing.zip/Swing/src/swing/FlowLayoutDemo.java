package swing;

import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;

public class FlowLayoutDemo extends JFrame {

  public FlowLayoutDemo() {

    Container contentPane = getContentPane();

    contentPane.setLayout(new FlowLayout());

    contentPane.add(new JButton("Button 1"));
    contentPane.add(new JButton("2"));
    contentPane.add(new JButton("Button 3"));
    contentPane.add(new JButton("Button com nome grande 4"));
    contentPane.add(new JButton("Button 5"));

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        System.exit(0);
      }
    });
  }

  public static void main(String args[]) {
    JFrame f = new FlowLayoutDemo();
    f.setTitle("FlowLayoutDemo");
    f.pack();
    f.show();
  }
}