package swing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class JRadioButtonDemo extends JFrame {

  private JLabel selecionados = new JLabel();
  private JRadioButton rb1, rb2, rb3;
  private ButtonGroup bg = new ButtonGroup();

  public JRadioButtonDemo() {
    super("JRadioButton Demo");

    JPanel painel;

    // Constr�i um painel com os radio buttons
    rb1 = new JRadioButton();
    rb1.setText("JRadioButton 1");
    rb2 = new JRadioButton("JRadioButton 2");
    rb3 = new JRadioButton("JRadioButton 3");
    rb3.setEnabled(true);
    painel = new JPanel();
    painel.add(rb1);
    painel.add(rb2);
    painel.add(rb3);
    painel.add(selecionados);
    getContentPane().add(painel);

    // Adiciona os bot�es ao grupo
    bg.add(rb1);
    bg.add(rb2);
    bg.add(rb3);

    RadioListener listener = new RadioListener();
    rb1.addActionListener( listener );
    rb2.addActionListener( listener );
    rb3.addActionListener( listener );

    pack();
    show();
  }

  private class RadioListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      selecionados.setText("");
      if (rb1.isSelected()) {
        selecionados.setText(rb1.getText());
      } else if (rb2.isSelected()) {
        selecionados.setText(rb2.getText());
      } else if (rb3.isSelected()) {
        selecionados.setText(rb3.getText());
      }
      pack();
    }
  }

  public static void main( String args[] ) {
    JRadioButtonDemo application = new JRadioButtonDemo();
    application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }
}