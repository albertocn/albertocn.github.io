package swing;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSeparator;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

public class MenuDemo extends JFrame {

  private JTextArea area = new JTextArea( 20, 40 );
  private JMenuBar barra = new JMenuBar();
  private JMenu menu = new JMenu("Arquivo");
  private JPopupMenu popup = new JPopupMenu();

  public MenuDemo() {
    super( "Menu Demo" );

    Container contentPane = getContentPane();
    contentPane.setLayout( new BorderLayout() );

    menu.setMnemonic(KeyEvent.VK_A);
    
    // inclui um item de menu abrir simples
    JMenuItem imAbrir = new JMenuItem("Abrir");
    menu.add( imAbrir );

    // inclui um item de menu salvar com um �cone
    JMenuItem imSalvar = new JMenuItem("Salvar", new ImageIcon( "salvar.gif" ));
    imSalvar.setMnemonic(KeyEvent.VK_S);
    menu.add( imSalvar );

    // Cria uma separa��o no menu
    menu.add( new JSeparator() );

    // Cria um submenu com CheckBox e RadioButton
    JMenu subMenu = new JMenu( "Fonte" );
    JCheckBoxMenuItem negrito = new JCheckBoxMenuItem( "Negrito" );
    JCheckBoxMenuItem italico = new JCheckBoxMenuItem( "It�lico" );
    subMenu.add( negrito );
    subMenu.add( italico );
    subMenu.add( new JSeparator() );
    JRadioButtonMenuItem grande = new JRadioButtonMenuItem( "Grande" );
    JRadioButtonMenuItem medio = new JRadioButtonMenuItem( "M�dia" );
    JRadioButtonMenuItem pequeno = new JRadioButtonMenuItem( "Pequena" );
    ButtonGroup bg = new ButtonGroup();
    bg.add( grande );
    bg.add( medio );
    bg.add( pequeno );
    subMenu.add( grande );
    subMenu.add( medio );
    subMenu.add( pequeno );
    menu.add( subMenu );


    // cria e coloca itens de menu recortar, copiar e colar
    JMenuItem imRecortar = new JMenuItem("Recortar", new ImageIcon("recortar.gif"));
    JMenuItem imCopiar = new JMenuItem("Copiar", new ImageIcon("copiar.gif"));
    JMenuItem imColar = new JMenuItem("Colar", new ImageIcon("colar.gif"));
    popup.add(imRecortar);
    popup.add(imCopiar);
    popup.add(imColar);


    // Adiciona os menus na barra
    barra.add(menu);
    barra.add(popup);
    setJMenuBar( barra );


    // cria os do popup (�rea de texto e barra de menu)
    MouseListener popupListener = new PopupListener();
    area.addMouseListener(popupListener);
    barra.addMouseListener(popupListener);

    // cria os listeners dos itens de menu (imprime mensagem na �rea de texto)
    adicionarListenersMenu( menu );
    adicionarListenersMenu( subMenu );
    adicionarListenersPopup( popup );

    JScrollPane spArea = new JScrollPane( area,
                                          ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,
                                          ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
    contentPane.add( BorderLayout.CENTER, spArea );

    pack();
    show();
  }

  private class PopupListener extends MouseAdapter {
    public void mouseReleased(MouseEvent e) {
      if (e.isPopupTrigger()) {
        popup.show(e.getComponent(), e.getX(), e.getY());
      }
    }
  }

  private class MenuItemListener implements ActionListener {
    public void actionPerformed( ActionEvent e ) {
      JMenuItem item = (JMenuItem) e.getSource();
      area.append( item.getText() );
      area.append( System.getProperty("line.separator") );
    }
  }

  private void adicionarListenersMenu( JMenu m ) {
    adicionarListeners( m.getMenuComponents() );
  }

  private void adicionarListenersPopup( JPopupMenu p ) {
    adicionarListeners( p.getComponents() );
  }

  private void adicionarListeners( Component[] componentes ) {
    ActionListener listener = new MenuItemListener();
    for (int i = 0; i < componentes.length; i++ ) {
      if ( componentes[i] instanceof JMenuItem ) {
        JMenuItem item = (JMenuItem) componentes[i];
        item.addActionListener( listener );
      }
    }
  }

  public static void main(String[] args) {
    MenuDemo application = new MenuDemo();
    application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }
}