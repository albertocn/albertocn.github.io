package swing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class JTextFieldDemo extends JFrame {

  private JLabel usuarioLabel = new JLabel("Usu�rio");
  private JLabel senhaLabel = new JLabel("Senha");
  private JTextField usuarioField = new JTextField(10);
  private JPasswordField senhaField = new JPasswordField(10);

  public JTextFieldDemo() {
    super("JTextField Demo");

    // Constr�i um painel com os os text fields
    JPanel painel = new JPanel();
    painel.add( usuarioLabel );
    painel.add( usuarioField );
    painel.add( senhaLabel );
    painel.add( senhaField );
    getContentPane().add(painel);

    usuarioField.addActionListener( new UsuarioListener() );
    senhaField.addActionListener( new SenhaListener() );

    senhaField.setEnabled( false );
    senhaField.setEchoChar( '%' );

    pack();
    show();
  }

  private class UsuarioListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      if ( !usuarioField.getText().equalsIgnoreCase("alberto") ) {
        System.out.println( "USU�RIO INV�LIDO" );
      } else {
        System.out.println( "usu�rio v�lido" );
        usuarioField.setEnabled(false);
        senhaField.setEnabled(true);
        senhaField.requestFocus();
      }
    }
  }

  private class SenhaListener implements ActionListener {
    public void actionPerformed(ActionEvent e) {
      String senha = new String( senhaField.getPassword() );
      if ( !senha.equalsIgnoreCase("123") ) {
        System.out.println( "SENHA INV�LIDA" );
        senhaField.setText("");
      } else {
        senhaField.setEnabled(false);
        System.out.println( "senha v�lida" );
      }
    }
  }

  public static void main( String args[] ) {
    JTextFieldDemo application = new JTextFieldDemo();
    application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }
}