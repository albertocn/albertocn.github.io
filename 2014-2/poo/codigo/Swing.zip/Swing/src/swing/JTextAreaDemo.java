package swing;

import java.awt.BorderLayout;
import java.awt.Container;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.File;
import java.io.IOException;

import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.Reader;

import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class JTextAreaDemo extends JFrame {

  private JList arquivos = new JList();
  private JTextArea conteudo = new JTextArea( 20, 80 );

  public JTextAreaDemo() {
    super( "JTextArea Demo" );

    Container contentPane = getContentPane();
    contentPane.setLayout( new BorderLayout() );

    arquivos.setListData( obterArquivos() );
    arquivos.addListSelectionListener( new ArquivosListener() );

    JScrollPane spLista = new JScrollPane(arquivos,
                                          JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                                          JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
    JScrollPane spTextArea = new JScrollPane(conteudo,
                                             JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
                                             JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);

    contentPane.add( BorderLayout.NORTH, spLista );
    contentPane.add( BorderLayout.SOUTH, spTextArea );

    pack();
    show();
  }

  private class ArquivosListener implements ListSelectionListener {
    public void valueChanged (ListSelectionEvent e) {
      atualizarTextArea();
    }
  }

  private void atualizarTextArea() {
    try {
      File f = (File) arquivos.getSelectedValue();
      Reader reader = new InputStreamReader( new FileInputStream( f ) );
      conteudo.read( reader, null );
    } catch (IOException e) {
      conteudo.setText( e.getMessage() );
    }
  }

  private Vector obterArquivos() {
    Vector arqs = new Vector();
    try {
      File dir = new File(".").getCanonicalFile();
      File[] conteudoDir = dir.listFiles();
      for (int i = 0; i < conteudoDir.length; i++) {
        if (conteudoDir[i].isFile()) {
          arqs.add( conteudoDir[i]);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return arqs;
  }

  public static void main( String args[] ) {
    JTextAreaDemo application = new JTextAreaDemo();
    application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
  }
}
