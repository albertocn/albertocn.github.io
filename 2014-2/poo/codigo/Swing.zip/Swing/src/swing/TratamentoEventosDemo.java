package swing;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class TratamentoEventosDemo extends JFrame {

  private DialogSimples2 dialog;
  private JTextArea      ta;
  private JButton        btnAbrir;
  private JCheckBox      cbxModal;

  public TratamentoEventosDemo() {
    ta = new JTextArea(5, 40);
    ta.setEditable(false);
    Container c = getContentPane();
    JScrollPane sp = new JScrollPane(ta);
    c.add("Center", sp);
    btnAbrir = new JButton("Abrir a caixa de di�logo");
    cbxModal = new JCheckBox("Modal");
    JPanel panel = new JPanel();
    panel.add(btnAbrir);
    panel.add(cbxModal);
    c.add("South", panel);
    createListeners();    
  }

  private void createListeners() {
    // Registra o Listener da janela
    this.addWindowListener(new WindowListenerMembro(this));

    // Listener do bot�o de abrir
    btnAbrir.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        getDialog().setModal(cbxModal.isSelected());
        getDialog().show();
      }
    });
  }

  // Retorna uma caixa de di�logo. Cria a caixa de di�logo
  // Se n�o tiver sido criada anteriormente
  private JDialog getDialog() {
    if (dialog == null) {
      dialog = new DialogSimples2(this, "Dialog Simples");
    }
    return dialog;
  }

  public void setTexto(String texto) {
    ta.append(texto + "\n");
  }

  // Listener do frame implementado como uma classe membro
  private class WindowListenerMembro extends WindowAdapter {
    private JFrame f;
    public WindowListenerMembro(JFrame f)    { this.f = f; }
    public void windowClosing(WindowEvent e) { f.dispose(); }
    public void windowClosed(WindowEvent e)  { System.exit(0); }
  }

  public static void main(String args[]) {
    TratamentoEventosDemo frame = new TratamentoEventosDemo();
    frame.setTitle("TratamentoEventosDemo");
    frame.pack();
    frame.show();
  }
}

class DialogSimples2 extends JDialog {

  JTextField            campo;
  TratamentoEventosDemo pai;
  JButton               btnOk;
  JButton               btnCancelar;

  DialogSimples2(JFrame f, String titulo) {
    super(f, titulo, false);
    pai = (TratamentoEventosDemo) f;

    Container c = getContentPane();
    c.setLayout( new BorderLayout() );

    // Cria a se��o do meio
    JPanel p1 = new JPanel();
    JLabel label = new JLabel("Entre com o texto:");
    p1.add(label);
    campo = new JTextField(40);
    p1.add(campo);
    c.add( p1, BorderLayout.CENTER );

    // Cria o bot�o na se��o de baixo
    JPanel p2 = new JPanel();
    p2.setLayout(new FlowLayout(FlowLayout.RIGHT));
    btnCancelar = new JButton("Cancelar");
    btnOk = new JButton("Ok");
    p2.add(btnCancelar);
    p2.add(btnOk);
    c.add(p2, BorderLayout.SOUTH);

    createListeners();

    pack();
  }

  private void createListeners() {
    // Cria o Listener para o bot�o "cancelar" atrav�s
    // de uma classe local e registra uma inst�ncia
    // dessa classe como listener do bot�o "cancelar"
    class CancelarListener implements ActionListener {
      public void actionPerformed(ActionEvent e) {
        hide();
      }
    }
    btnCancelar.addActionListener(new CancelarListener());
        
    // Cria o Listener do bot�o "ok" atrav�s de uma
    // classe an�nima que estende a classe local
    // do bot�o cancelar e a registra uma inst�ncia
    // dessa classe como listener do bot�o "ok"
    btnOk.addActionListener(new CancelarListener() {
      public void actionPerformed(ActionEvent e) {
        pai.setTexto(campo.getText());
        System.out.println("Fui chamado");
        super.actionPerformed(e);
      }
    });
  }
}

