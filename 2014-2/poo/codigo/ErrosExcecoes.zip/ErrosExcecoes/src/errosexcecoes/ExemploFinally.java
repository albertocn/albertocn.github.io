package errosexcecoes;

public class ExemploFinally {

  public static void main(String[] args) {
	 int z = 0;
     try {
       int x = 1, y = 0;

       // Provoca uma java.lang.ArithmeticException       
       z = x / y;       

     } catch (ArithmeticException e) {
       //System.out.println("Entrou no catch");
    	 System.out.println("Divisao por 0");
    	 z = 20;
     } catch (Exception e) {
    	 System.out.println("Erro inesperado");
     } finally {
       System.out.println("Entrou no finally");
       System.out.println("Valor de z = " + z);
     }
  }
}