package errosexcecoes;

import java.io.*;

public class ExemploThrows {

	public ExemploThrows(String nome) {
		metodoQueTrataExcecao(nome);
	}

	private void metodoQueTrataExcecao(String nome) {
		System.out.println("Inicio de metodoQueTrataExcecao");
		try {
			metodoQueRepassa(nome);
		} catch (FileNotFoundException e) {
			System.out.println("Arquivo n�o encontrado");
		} catch (IOException e) {
			System.out.println("Erro de I/O inesperado");
		}
		System.out.println("Fim de metodoQueTrataExcecao");
	}

	private void metodoQueRepassa(String nome) throws IOException {
		System.out.println("Inicio de metodoQueRepassa");
		
		metodoQueGera(nome);
		System.out.println("Fim de metodoQueRepassa");
	}

	private void metodoQueGera(String nome) throws FileNotFoundException {
		System.out.println("Inicio de metodoQueGera");
		BufferedReader br = new BufferedReader(new FileReader(nome));
		System.out.println("Fim de metodoQueGera");
	}

	public static void main(String[] args) {
		new ExemploThrows("Teste");
	}
}