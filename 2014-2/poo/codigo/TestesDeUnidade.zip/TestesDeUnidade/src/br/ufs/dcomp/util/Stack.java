package br.ufs.dcomp.util;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

/**
 * Classe que implementa uma pilha de objetos
 *
 * @author Alberto Costa Neto
 */
public class Stack {

    // Lista com os elementos da Pilha
    private List elements = createList();

    private List cache = null;

    /**
     * Cria uma pilha
     */
    public Stack() {}

    /**
     * Insere um objeto no fundo da pilha
     */
    public void insert(Object object) {
        if (object == null) {
            throw new IllegalArgumentException("object == null");
        }

        synchronized (this) {
            invalidateCache();
            elements.add(elements.size(), object);
        }
    }

    /**
     * Retira o objeto do topo da pilha
     */
    public Object top() {
        synchronized (this) {
            invalidateCache();

            if (isEmpty()) {
                return null;
            }
            return elements.remove(elements.size() - 1);
        }
    }

    /**
     * Esvazia a pilha
     */
    public void clear() {
        synchronized (this) {
            elements.clear();
            invalidateCache();
        }
    }

    /**
     * Retorna um ListIterador que permite percorrer os elementos.
     * A ordem natural � da frente da fila para o fundo, ou seja,
     * o primeiro elemento � o pr�ximo a sair da fila
     */
    public ListIterator iterator() {
        synchronized (this) {
            return Collections.unmodifiableList(getCache()).listIterator();
        }
    }

    /**
     * Retorna o tamanho da fila (n�mero de objetos)
     */
    public long size() {
        synchronized (this) {
            return elements.size();
        }
    }

    /**
     * Retorna true se a fila est� vazia
     */
    public boolean isEmpty() {
        synchronized (this) {
            return elements.isEmpty();
        }
    }


    /**
     * Factory Method que permite alterar a implementa��o da lista
     * a ser usada para manter a fila
     */
    protected List createList() {
        return new LinkedList();
    }

    // Invalida o cache
    private void invalidateCache() {
        cache = null;
    }

    // Retorna um objeto List
    private List getCache() {
        synchronized (this) {
            // Cria o cache se necess�rio
            if (cache == null) {
                cache = Arrays.asList(elements.toArray());
                Collections.reverse(cache);
            }
            return cache;
        }
    }
}
