package colecoes;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class SomenteLeitura {
  public static void main(String args[]) {
    Set set = new HashSet();
    set.add("A");
    set.add("B");
    set = Collections.unmodifiableSet(set);
    set.add("D"); // provoca uma exce��o UnsupportedOperationException
  }
}
