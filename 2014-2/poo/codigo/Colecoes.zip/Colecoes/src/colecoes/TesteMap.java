package colecoes;

import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class TesteMap {
  public static void main(String args[]) {
    Map map = new HashMap();
    Integer um = new Integer(1);
    for (int i = 0, n = args.length; i < n; i++) {
      String chave = args[i];
      Integer frequencia = (Integer) map.get(chave);
      if (frequencia == null) {
        frequencia = um;
      } else {
        int valor = frequencia.intValue();
        frequencia = new Integer(valor + 1);
      }
      map.put(chave, frequencia);
    }
    System.out.println(map);

    Map sortedMap = new TreeMap(map);
    System.out.println(sortedMap);

    Map m = new java.util.WeakHashMap();
    m.put(new Integer(2), "2");
    System.out.println( m.get( new Integer(2) ) );
  }
}
