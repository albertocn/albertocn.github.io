package colecoes;

import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;

public class Pessoa implements Comparable {

  private long id;
  private final String nome;

  public Pessoa( long id, String nome ) {
    this.id = id;
    this.nome = nome;
  }

  public String getNome() { return nome; };

  public int compareTo( Object outro ) {
    Pessoa p = (Pessoa) outro;
    if ( this.id > p.id ) {
      return 1;
    } if ( this.id < p.id ) {
      return -1;
    }
    return 0;
  }

  public String toString() {
    return "(Id:" + id  + " Nome:" + nome + ')';
  }

  public static void main(String[] args) {
    List pessoas = new ArrayList();
    pessoas.add( new Pessoa(3, "B") );
    pessoas.add( new Pessoa(4, "Z") );
    pessoas.add( new Pessoa(1, "A") );
    pessoas.add( new Pessoa(2, "X") );
    System.out.println( "Inicial.: " + pessoas );

    Set pessoasPorId = new TreeSet( pessoas );
    System.out.println( "Por ID..: " + pessoasPorId );
  }
}