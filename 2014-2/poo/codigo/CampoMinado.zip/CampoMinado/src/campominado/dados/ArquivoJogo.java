package campominado.dados;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.StringTokenizer;

import campominado.dominio.CampoMinado;
import campominado.dominio.Celula;
import campominado.dominio.Jogador;
import campominado.dominio.Jogo;

public class ArquivoJogo {
	
	public static final int SEM_MINA = 0;
	public static final int COM_MINA = -1;

	public static final int ABERTO = 0;
	public static final int NAO_ABERTO = -1;

	private Jogo jogo;
	
	private String caminhoArquivo;
	private String nome;

	/**
	 * Carrega os dados referentes a um Jogador. Caso o jogador seja um usu�rio
	 * existente, os n�meros de partidas e vit�rias, o melhor tempo de jogo, a
	 * matriz de minas e a matriz com o estado do jogo s�o restaurados a partir
	 * do arquivo.
	 */
	public ArquivoJogo(String caminho, String nome) throws IOException {
		this.nome = nome;
		this.caminhoArquivo = caminho + nome + ".txt";
		carregar();
	}

	/**
	 * Carrega todos os dados do arquivo.
	 * 
	 * @throws FileNotFoundException Lan�ado quando o arquivo n�o existe.
	 * @throws IOException Erro aconteceu durante a leitura.
	 */
	public void carregar() throws FileNotFoundException, IOException {
		BufferedReader r = new BufferedReader(new FileReader(caminhoArquivo));

		this.jogo = new Jogo(carregarJogador(nome, r), carregarCampo(r),
				// REFATORAR
				// Precisa carregar o tempo decorrido do jogo tamb�m
				0);

		r.close();
	}

	/**
	 * Carrega os dados do Jogador � partir do arquivo passado.
	 * 
	 * @param r
	 *            Reader do qual se faz a leitura dos dados do Jogador.
	 */

	protected Jogador carregarJogador(String nome, BufferedReader r)
			throws NumberFormatException, IOException {
		int partidas = Integer.parseInt(r.readLine());
		int vitorias = Integer.parseInt(r.readLine());
		long melhorTempo = Integer.parseInt(r.readLine());
		return new Jogador(nome, partidas, vitorias, melhorTempo);
	}

	/**
	 * Carrega os dados do Campo Minado � partir do arquivo passado.
	 * 
	 * @param r
	 *            Reader do qual se faz a leitura dos dados das matrizes do
	 *            campo minado.
	 */
	protected CampoMinado carregarCampo(BufferedReader r) throws IOException {
		int[][] minas = lerMatriz(r.readLine());
		int[][] status = lerMatriz(r.readLine());
		return new CampoMinado(minas, status);
	}

	/**
	 * Retorna o Jogo conforme est� no arquivo.
	 * 
	 * @return Jogo contendo os dados que vieram do arquivo.
	 */
	public Jogo getJogo() {
		return jogo;
	}
	
	/**
	 * Retorna o Campo Minado conforme est� no arquivo.
	 * 
	 * @return CampoMinado contendo os dados que vieram do arquivo.
	 */
	public CampoMinado getCampo() {
		return jogo.getCampo();
	}

	/**
	 * Retorna o Jogador conforme est� no arquivo.
	 * 
	 * @return Jogagor com os dados que vieram do arquivo.
	 */
	public Jogador getJogador(String nome) {
		return jogo.getJogador();
	}

	/**
	 * Faz a leitura dos dados da matriz, sendo que os elementos est�o separados
	 * por v�rgulas.
	 */
	private int[][] lerMatriz(String linha) {
		int[][] matriz = criarMatriz();
		StringTokenizer st = new StringTokenizer(linha, ",");
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.COLUNAS; j++) {
				matriz[i][j] = Integer.parseInt(st.nextToken());
			}
		}
		return matriz;
	}

	/**
	 * Cria uma matriz com as dimens�es do campo minado.
	 */
	private int[][] criarMatriz() {
		return new int[CampoMinado.LINHAS][CampoMinado.COLUNAS];
	}
	
	/** 
     * Salva os dados importantes do jogo, ou seja, do jogador e 
     * dos valores das matrizes minas e impressao.
	 */
	public void gravar(Jogo jogo)
			throws IOException {
		
		BufferedWriter w = new BufferedWriter(new FileWriter(caminhoArquivo));

		gravarJogador(jogo.getJogador(), w);
		gravarCampoMinado(jogo.getCampo(), w);
				
		w.flush();
		w.close();
	}
	
	/**
	 * Salva dados como partidas, vit�rias e melhor tempo do jogador.
     */
	private void gravarJogador(Jogador jogador, BufferedWriter w)
			throws IOException {
		w.write("" + jogador.getPartidas());
		w.newLine();
		w.write("" + jogador.getVitorias());
		w.newLine();
		w.write("" + jogador.getMelhorTempo());
		w.newLine();
	}

	/**
	 * Grava todos os valores da matriz do campo minado.
     */
	private void gravarCampoMinado(CampoMinado campo, BufferedWriter w)
			throws IOException {
		StringBuffer sbMinas = new StringBuffer();
		StringBuffer sbAbertas = new StringBuffer();
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.LINHAS; j++) {
				Celula cel = campo.getCelula(i, j);
				sbMinas.append(cel.contemMina()? COM_MINA : campo.getMinasAoRedor(cel));
				sbMinas.append(',');
				sbAbertas.append(cel.aberta()? ABERTO : NAO_ABERTO);
				sbAbertas.append(',');
			}
		}		
		gravarStringBufferNoArquivo(w, sbMinas);
		gravarStringBufferNoArquivo(w, sbAbertas);
	}

	/**
	 * Grava o StringBuffer em arquivo em um BufferedWriter j� aberto. 
	 * @param w Writer no qual ser�o escritos os dados.
	 * @param sb Cont�m os dados a serem escritos
	 * @throws IOException Lan�ada caso ocorra algum erro durante a grava��o.
	 */
	private void gravarStringBufferNoArquivo(BufferedWriter w, StringBuffer sb)
			throws IOException {
		sb.deleteCharAt(sb.length() - 1);
		w.write(sb.toString());
		w.newLine();
	}
}