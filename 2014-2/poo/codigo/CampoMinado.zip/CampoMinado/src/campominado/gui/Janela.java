package campominado.gui;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.JOptionPane;

import campominado.dados.ArquivoJogo;
import campominado.dominio.CampoMinado;
import campominado.dominio.Jogador;
import campominado.dominio.Jogo;

public class Janela extends JFrame {

	private static final String TITULO_JANELA = "Campo Minado";

	private static final String DIR_DEFAULT = "contas";

	private static final String MENU = "Menu";
	private static final String MENU_FECHAR = "Fechar";
	private static final String MENU_SALVAR = "Salvar";
	private static final String MENU_REINICIAR = "Reiniciar";
	
	private static final String MSG_QUAL_NOME = "Qual � seu nome?";
	private static final String ERRO_NOME_OBRIGATORIO = "� necess�rio inserir seu nome.";
	private static final String ERRO_NOME_INVALIDO = "N�o deixe seu nome em branco. Evite usar espa�os em branco.";
	private static final String MSG_PROGRAMA_ENCERRADO = "O programa est� sendo encerrado.";
	private static final String NAO_PODE_SALVAR_PARTIDA_PERDIDA = "Voc� n�o pode salvar uma partida perdida.";
	private static final String CONTA_SALVA = "Sua conta foi salva com sucesso.";


	// matriz de bot�es
	private JButton botoes[][] = new JButton[CampoMinado.LINHAS][CampoMinado.COLUNAS];
	private Jogo jogo;
    private ArquivoJogo arqJogo;

	// REFATORAR 
    // Colocar estes atributos na classe Jogo
    private boolean primeiroclick = true;	
	long fim, inicio;

	private JMenu menu = new JMenu(MENU);

	public Janela() {
		super(TITULO_JANELA);

		// inicia um gridlayout com as dimens�es do campo minado
		getContentPane().setLayout(
				new GridLayout(CampoMinado.LINHAS, CampoMinado.COLUNAS, 1, 1));
		
		criarBotoesCampoMinado(getContentPane());
		
		setJMenuBar(criarBarraMenu());
	}

	/**
	 * Cria os bot�es que comp�em o campo minado.
	 * @param container Container no qual ser�o inseridos os bot�es.
	 */
	protected void criarBotoesCampoMinado(Container container) {
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.COLUNAS; j++) {
				botoes[i][j] = new JButton("");
				botoes[i][j].addActionListener(new BotaoListener(i, j));
				container.add(botoes[i][j]);
			}
		}
	}

	/**
	 * Cria a barra de menu do jogo.
	 * @return Inst�ncia de JMenuBar com os itens de menu e listeners associados.
	 */
	protected JMenuBar criarBarraMenu() {
		 // Item de Menu Reiniciar
		JMenuItem Reiniciar = new JMenuItem(MENU_REINICIAR);
		Reiniciar.addActionListener(new Reiniciar());
		menu.add(Reiniciar);
		
		// Item de Menu Salvar
		JMenuItem Salvar = new JMenuItem(MENU_SALVAR);
		Salvar.addActionListener(new Salvar());
		menu.add(Salvar);
		
		// Separador
		menu.add(new JSeparator());
		
		// Item de Menu Fechar
		JMenuItem Fechar = new JMenuItem(MENU_FECHAR);
		Fechar.addActionListener(new Fechar());
		menu.add(Fechar);

		// Barra de menu
		JMenuBar barra = new JMenuBar();
		barra.add(menu);
		return barra;
	}

	/**
	 * Este evento � respons�vel por salvar as suas contas dos usu�rios.
	 */
	private class Salvar implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if (jogo.perdeu()) {
				JOptionPane.showMessageDialog(null, NAO_PODE_SALVAR_PARTIDA_PERDIDA);
			} else {
				salvarJogo();				
			}
		}
	};

	/**
	 * Este evento � respons�vel pelo fechamento do programa, caso voc� clique
	 * no submenu "Fechar".
	 */
	private class Fechar implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JOptionPane.showMessageDialog(null, MSG_PROGRAMA_ENCERRADO);
			System.exit(0);
		}
	};

	/**
	 * Evento acionado para reiniciar todo o jogo.
	 */
	private class Reiniciar implements ActionListener {
		
		private static final String MSG_NUMERO_PARTIDA = "Essa � sua partida de n�mero: ";

		public void actionPerformed(ActionEvent e) {
			jogo.reiniciar();
			
			inicio = System.currentTimeMillis();
			primeiroclick = true;
			
			atualizarTela();
			
			jogo.getJogador().adicionarPartidas();			
			JOptionPane.showMessageDialog(null, MSG_NUMERO_PARTIDA + jogo.getJogador().getPartidas() + ".");
		}
	};


	/**
	 * Trata o evento de clique que atualiza a situa��o do campo minado.
	 * Os bot�es que foram descobertos a cada clique ser�o desabilitados.
	 */
	private class BotaoListener implements ActionListener {

		private int linha, coluna;

		public BotaoListener(int i, int j) {
			this.linha = i;
			this.coluna = j;
		}

		public void actionPerformed(ActionEvent e) {

			// Se for o primeiro click do jogo, o tempo ser� capturado e
			// utilizado para ver o tempo de partida do jogador.
			if (primeiroclick) {
				inicio = System.currentTimeMillis();
				primeiroclick = false;
			}

			jogo.abrirCelula(linha, coluna);
			atualizarTela();
		}
	}

	/**
	 * M�todo que atualiza a tela de situa��o.
	 */
	public void atualizarTela() {
		if (jogo.encerrado()) {
			jogo.getCampo().abrirTodasCelulas();
		}
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.COLUNAS; j++) {
				botoes[i][j].setText(" ");
				botoes[i][j].setIcon(null);
				if (jogo.getCampo().getCelula(i,j).aberta()) {
					botoes[i][j].setEnabled(false);
					if (jogo.getCampo().getCelula(i,j).contemMina()) {
						botoes[i][j].setIcon(new ImageIcon("bomba.png"));
					} else if (jogo.getCampo().getMinasAoRedor(i,j) > 0) {
					    botoes[i][j].setText("" + jogo.getCampo().getMinasAoRedor(i,j));
					}
				} else {
					botoes[i][j].setEnabled(true);
				}
			}
		}
		if (jogo.ganhou()) {
			encerrarPartidaVitoria();
		} else if (jogo.perdeu()){
			encerrarJogoDerrota();
		}
	}
	

	/**
	 * Encerra o jogo com uma vit�ria, finalizando a contagem de tempo.
	 */
	private void encerrarPartidaVitoria() {
		encerrarContagemDeTempo();
		jogo.getJogador().contar(inicio, fim);
		jogo.getJogador().adicionarVitorias();		
		exibirResultado("Voc� ganhou esta partida em "
						+ jogo.getJogador().getMelhorTempo() + "segundos. E tem "
						+ jogo.getJogador().getVitorias() + " vit�rias.");
	}

	/**
	 * Encerra o jogo com uma derrota, mostrando a posi��o de todas
	 * as bombas e finalizando a contagem de tempo.
	 */
	private void encerrarJogoDerrota() {
		encerrarContagemDeTempo();
		exibirResultado("Voc� perdeu esta partida em "
				+ jogo.getJogador().calcularTempo(inicio, fim) + " segundos.");
	}

	/**
	 * Abre uma caixa de di�logo para comunicar o resultado ao usu�rio.
	 */
	private void exibirResultado(String msg) {
		JOptionPane.showMessageDialog(null, msg);
	}

	
	/**
	 * Encerra a contagem de tempo de jogo.
	 */
	private void encerrarContagemDeTempo() {
		fim = System.currentTimeMillis();
	}

	/**
	 * Salva o jogo em um arquivo na pasta indica pela constante
	 * DIR_DEFAULT.
	 */
	public void salvarJogo() {
		try {
			arqJogo.gravar(jogo);
			JOptionPane.showMessageDialog(null, CONTA_SALVA);
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * Carrega o jogo salvo, caso ele existe na pasta indicada pela constante
	 * DIR_DEFAULT.
	 */
	public void carregarJogoSalvo() {

		try {
			String caminho = DIR_DEFAULT + System.getProperty("file.separator");
			this.arqJogo = new ArquivoJogo(caminho, jogo.getJogador().getNome());
			this.jogo = arqJogo.getJogo();
			// REFATORAR
			// PRECISA ADICIONAR? E A CONTAGEM DE TEMPO ACUMULADO?
			this.jogo.getJogador().adicionarPartidas();
			JOptionPane.showMessageDialog(null,
					"Esta � sua partida de n�mero: " + jogo.getJogador().getPartidas()
							+ ".");

		} catch (IOException e) {

		}
		System.out.println("Matriz carregada do arquivo");
		System.out.println(jogo.getCampo().toString());
		atualizarTela();
	}

	/**
	 * Efetua o cadastro do jogador, caso n�o tenha sido ainda cadastrado. Ao
	 * ser informado um nome inv�lido, avisa.
	 */
	public void cadastrarNovoJogador() {		
		do {
			String nome = JOptionPane.showInputDialog(MSG_QUAL_NOME);
			if (nomeInvalido(nome)) {
				JOptionPane.showMessageDialog(null, ERRO_NOME_INVALIDO);
			} else {
				jogo = new Jogo(nome);
				jogo.getJogador().adicionarPartidas();
				break;
			}
		} while (true);
	}
	

	/**
	 * Um nome � inv�lido se � igual a branco ou cont�m espa�o em branco.
	 * 
	 * @return true se o nome for inv�lido e false caso contr�rio.
	 */
	private boolean nomeInvalido(String nome) {
		return nome.equals("") || nome.contains(" ");
	}

	public static void main(String[] args) {
		Janela aplicacao = new Janela();
		aplicacao.pack();
		aplicacao.setSize(550, 400);
		aplicacao.setVisible(true);

		try {
			aplicacao.cadastrarNovoJogador();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, ERRO_NOME_OBRIGATORIO);
			System.exit(0);
		}

		aplicacao.carregarJogoSalvo();
		aplicacao.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}