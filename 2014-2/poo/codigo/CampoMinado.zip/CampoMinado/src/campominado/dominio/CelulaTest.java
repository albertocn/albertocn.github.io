package campominado.dominio;

import static org.junit.Assert.*;

import org.junit.Test;

public class CelulaTest {

	@Test
	public void test() {
		// C�lula fechada e sem mina
		Celula c1 = new Celula(0, 0, false, false);
		assertFalse("N�o deveria conter mina", c1.contemMina());
		assertTrue("C�lula deveria estar fechada e sem mina", c1.fechadaSemMina());		
		c1.colocarMina();
		assertFalse("C�lula deveria estar fechada e com mina", c1.fechadaSemMina());
		assertTrue("Deveria conter mina", c1.contemMina());
		assertFalse("N�o deveria estar aberta", c1.aberta());
		c1.abrir();
		assertTrue("Deveria estar aberta", c1.aberta());
		
		// C�lula fechada e com mina
		Celula c2 = new Celula(2, 4, false, true);
		assertEquals(2, c2.linha());
		assertEquals(4, c2.coluna());		
		assertFalse("C�lula n�o deveria estar fechada e sem mina", c2.fechadaSemMina());
	}	
}