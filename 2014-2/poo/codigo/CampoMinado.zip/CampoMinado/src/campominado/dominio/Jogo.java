package campominado.dominio;

/**
 * Representa o Jogo de Campo Minado, o qual tem um Campo Minado
 * e um Jogador corrente.
 * 
 * @author Alberto
 */
public class Jogo {
	
	private Jogador jogador;
	private CampoMinado campo;

	private long tempoAcumulado;

	private int estado;
	
	public static final int NAO_INICIADO = 0;
	public static final int INICIADO = 1;	
	public static final int GANHOU = 2;
	public static final int PERDEU = 3;

	/**
	 * Cria um Jogo para um Jogador que nunca jogou.
	 * 
	 * @param nome Nome do Jogador.
	 */
	public Jogo(String nome) {
		this(new Jogador(nome), new CampoMinado(), 0);
	}

	/**
	 * Cria um Jogo referente a um Jogador e CampoMinado j�
	 * existentes.
	 *  
	 * @param jogador Jogador usando o sistema.
	 * @param campo Estado do Campo Minado. 
	 * @param tempoAcumulado Tempo acumulado do jogo em milisegundos.
	 */
	public Jogo(Jogador jogador, CampoMinado campo, long tempoAcumulado) {
		setJogador(jogador);
		setCampo(campo);
		this.tempoAcumulado = tempoAcumulado;
		this.estado = NAO_INICIADO;
	}
	
	public Jogador getJogador() {
		return this.jogador;
	}
	public CampoMinado getCampo() {
		return this.campo;
	}
	
	public void setJogador(Jogador jogador) {
		this.jogador = jogador;
	}
	public void setCampo(CampoMinado campo) {
		this.campo = campo;
	}
	
	/**
	 * Processa a abertura de uma c�lula, podendo ganhar o jogo, perder
	 * ou apenas abrir a c�lula (e talvez suas vizinhas)
	 * @param linha n�mero da linha da c�lula a ser aberta 
	 * @param coluna n�mero da coluna da c�lula a ser aberta
	 */
	public void abrirCelula(int linha, int coluna) {
		Celula c = getCampo().getCelula(linha, coluna);
		getCampo().abrirCelula(c);

		if (c.contemMina()) {
			this.estado = PERDEU;
		} else if (getCampo().soRestamMinas()) {
			this.estado = GANHOU;
		}
	}
	
	/**
	 * Reinicia o Jogo, limpando o campo minado.
	 */
	public void reiniciar() {
		this.estado = NAO_INICIADO;
		this.campo = new CampoMinado();
	}
	
	/**
	 * Retorna true quando o jogo foi encerrado, seja
	 * com vit�ria ou derrota
	 */
	public boolean encerrado() {
		return ganhou() || perdeu();
	}
	
	/**
	 * Verifica perdeu o jogo.
	 */
	public boolean perdeu() {
		return estado == PERDEU;
	}
	
	/**
	 * Verifica se ganhou o jogo.
	 */
	public boolean ganhou() {
		return estado == GANHOU;
	}
}