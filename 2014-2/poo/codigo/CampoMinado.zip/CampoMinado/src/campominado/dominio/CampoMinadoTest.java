package campominado.dominio;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CampoMinadoTest {

	private CampoMinado campo;

	@Before
	public void setUp() {
		campo = new CampoMinado();
	}

	@Test
	public void testSortearPosicaoDasMinas() {
		assertEquals("N�mero de minas inesperado", CampoMinado.TOTAL_MINAS,
				contarMinas());
	}

	private int contarMinas() {
		int total = 0;
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.COLUNAS; j++) {
				if (campo.getCelula(i, j).contemMina())
					total++;
			}
		}
		return total;
	}

	@Test
	public void testSoRestamMinas() {
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.COLUNAS; j++) {
				if (!campo.getCelula(i, j).contemMina()) {
					campo.getCelula(i, j).abrir();
				}
			}
		}
		assertTrue("S� deveriam restar as minas fechadas",
				campo.soRestamMinas());
	}

	@Test
	public void testExisteMinaAberta() {
		assertTrue("Nenhuma mina deveria estar aberta", !campo.existeMinaAberta());
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.COLUNAS; j++) {
				if (campo.getCelula(i, j).contemMina()) {
					campo.getCelula(i, j).abrir();
					break;
				}
			}
		}
		assertTrue("Alguma mina deveria estar aberta", campo.existeMinaAberta());
	}

	@Test
	public void testGetMinasAoRedorIntInt() {
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.COLUNAS; j++) {
				if (!campo.getCelula(i, j).contemMina()) {
					int minasAoRedor = 0;
					
					for (int linViz = i -1; linViz <= i + 1; linViz++)
						for (int colViz = j -1; colViz <= j + 1; colViz++)
							if (!((linViz == i) && (colViz == j)) && 
								campo.dentroDaMatriz(linViz, colViz)) {
								campo.getCelula(linViz, colViz).abrir();
								if (campo.getCelula(linViz, colViz).contemMina()) {
									minasAoRedor++;
								}
							}
					assertEquals("Minas ao redor contado errado em (" + i + "," + j + ")", 
							minasAoRedor, campo.getMinasAoRedor(i,j));
				}
			}
		}
	}

	@Test
	public void testDentroDaMatriz() {
		assertFalse("Deveria estar fora da matriz", campo.dentroDaMatriz(-1, 0));
		assertFalse("Deveria estar fora da matriz", campo.dentroDaMatriz(0, -1));
		assertFalse("Deveria estar fora da matriz", campo.dentroDaMatriz(-1, -1));
		assertFalse("Deveria estar fora da matriz", campo.dentroDaMatriz(CampoMinado.LINHAS, 0));
		assertFalse("Deveria estar fora da matriz", campo.dentroDaMatriz(0, CampoMinado.COLUNAS));
		assertFalse("Deveria estar fora da matriz", campo.dentroDaMatriz(CampoMinado.LINHAS, CampoMinado.COLUNAS));
		assertTrue("Deveria estar dentro da matriz", campo.dentroDaMatriz(0, 0));
		assertTrue("Deve ter pelo menos 1 linha", CampoMinado.LINHAS >= 1);
		assertTrue("Deve ter pelo menos 1 coluna", CampoMinado.COLUNAS >= 1);
		assertTrue("Deveria estar dentro da matriz", campo.dentroDaMatriz(CampoMinado.LINHAS-1, CampoMinado.COLUNAS-1));		
	}
}