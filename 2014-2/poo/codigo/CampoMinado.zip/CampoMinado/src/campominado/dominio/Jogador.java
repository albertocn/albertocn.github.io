package campominado.dominio;

/**
 *  Representa um Jogador do Campo Minado.
 *
 *  @author Alberto
 *  
 *  REFATORAR A CONTAGEM DE TEMPO
 */
public class Jogador {
	
	private String nome;
	private int partidas;
	private int vitorias;
	private long melhorTempo;
	
	/**
	 * Cria um jogador com um nome definido, um n�mero de vit�rias e de partidas 
	 * igual a zero. O melhor tempo � iniciado com 0.
	 *
	 * @param nome Nome do jogador.
	 */
	public Jogador(String nome) {
		this(nome, 0, 0, 0);
	}
	
	/**
	 * Cria um Jogador.
	 * @param nome Nome do Jogador.
	 * @param partidas N�mero de partidas que j� jogou.
	 * @param vitorias N�mero de vit�rias que j� obteve.
	 * @param melhorTempo Melhor tempo obtido dentre as vit�rias.
	 */
	public Jogador(String nome, int partidas, int vitorias, long melhorTempo) {
		this.nome = nome;
		this.partidas = partidas;
		this.vitorias = vitorias;
		this.melhorTempo = melhorTempo;
	}
	
	public void setPartidas(int partidas) {
		this.partidas = partidas;
	}

	public void setVitorias(int vitorias) {
		this.vitorias = vitorias;
	}

	public void setTempo(long tempo) {
		this.melhorTempo = tempo;
	}

	/**
	 * Salva o �ltimo tempo do jogador, somente se ele ganhar.
	 * 
	 * @param inicio Momento em que foi iniciada a partida. 
	 * @param fim Momento em que foi finalizada a partida.
	 * @return
	 */
	public long contar(long inicio, long fim) {
		long cronometro = calcularTempo(inicio, fim);
		if (this.melhorTempo == 0 || cronometro < this.melhorTempo) {
			this.melhorTempo = cronometro;
		}
		return cronometro;
	}

	/**
	 * Calcula o tempo do jogo em segundos.
	 * 
	 * @param inicio
	 * @param fim
	 * @return
	 */
	public long calcularTempo(long inicio, long fim) {
		return (fim - inicio) / 1000;
	}

	public long getMelhorTempo() {
		return this.melhorTempo;
	}

	public String getNome() {
		return this.nome;
	}

	public int getPartidas() {
		return this.partidas;
	}

	public int getVitorias() {
		return this.vitorias;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * Incrementa o n�mero de partidas do jogador.
	 */
	public void adicionarPartidas() {
		++this.partidas;
	}

	/**
	 * Incrementa o n�mero de vit�rias do jogador.
	 */
	public void adicionarVitorias() {
		++this.vitorias;
	}
}