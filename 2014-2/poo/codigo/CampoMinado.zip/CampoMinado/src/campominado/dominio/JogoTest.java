package campominado.dominio;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class JogoTest {
	private static final String NOME_JOGADOR = "Teste";

	private Jogo jogo;

	@Before
	public void setUp() {
		jogo = new Jogo(NOME_JOGADOR);
	}

	@Test
	public void testGetJogador() {
		assertEquals("Nome diferente do esperado", NOME_JOGADOR, jogo
				.getJogador().getNome());
	}

	@Test
	public void testPerdeu() {
		assertFalse("N�o deveria ter encerrado", jogo.encerrado());
		for (int i = 0; i < (CampoMinado.LINHAS) && !jogo.perdeu(); i++) {
			for (int j = 0; (j < CampoMinado.COLUNAS) && !jogo.perdeu(); j++) {
				jogo.abrirCelula(i, j);
				if (jogo.getCampo().existeMinaAberta()) {
					assertTrue("Deveria ter perdido", jogo.perdeu());					
				}
			}
		}
		assertTrue("Deveria ter encerrado", jogo.encerrado());
	}

	@Test
	public void testGanhou() {
		assertFalse("N�o deveria ter encerrado", jogo.encerrado());
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.COLUNAS; j++) {
				if (!jogo.getCampo().getCelula(i,j).contemMina()) {
					jogo.abrirCelula(i,j);
				}
			}
		}
		assertTrue("Deveria ter ganho", jogo.ganhou());
		assertTrue("Deveria ter encerrado", jogo.encerrado());		
	}
}