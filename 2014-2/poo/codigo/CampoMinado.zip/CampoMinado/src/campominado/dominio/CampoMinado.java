package campominado.dominio;

import java.util.Random;

import campominado.dados.ArquivoJogo;

public class CampoMinado {
	
	/** Total de posi��es existentes no campo minado */
	public static final int TOTAL_MINAS = 10;
	/** N�mero de linhas do campo minado */
	public static final int LINHAS = 8;
	/** N�mero de colunas do campo minado */	
	public static final int COLUNAS = 8;
	/** Quantidade de c�lulas do campo minado */	
	public static final int TOTAL_CELULAS = LINHAS * COLUNAS;
	
	/** Matriz que cont�m as c�lulas que podem conter minas */
	private Celula[][] matriz;	

	/**
	 * Inicia o campo minado vazio.
	 */
	public CampoMinado() {
		this.matriz = criarMatrizCelulas();
		this.sortearPosicaoDasMinas();
	}

	/**
	 * Cria um Campo Minado a partir das matrizes de minas e de status.
	 * 
	 * @param minas
	 *            Matriz com as posi��es das minas.
	 * @param status
	 *            Matriz com o estado das posi��es abertas.
	 */
	public CampoMinado(int[][] minas, int[][] status) {
		this.matriz = criarMatrizCelulas();
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.COLUNAS; j++) {
				if (minas[i][j] == ArquivoJogo.COM_MINA)
					getCelula(i,j).colocarMina();
			}
		}
		for (int i = 0; i < CampoMinado.LINHAS; i++) {
			for (int j = 0; j < CampoMinado.COLUNAS; j++) {
				if (status[i][j] == ArquivoJogo.ABERTO) {
					getCelula(i,j).abrir();
				}
			}
		}
	}
	
	/**
	 * Cria uma matriz de c�lulas vazias e inicialmente fechadas e sem minas.
	 * @return Matriz de c�lulas criada.
	 */
	private Celula[][] criarMatrizCelulas() {
		Celula[][] matriz = new Celula[LINHAS][COLUNAS];
		for (int i = 0; i < LINHAS; i++) {
			for (int j = 0; j < COLUNAS; j++) {
				matriz[i][j] = new Celula(i, j, false, false);
			}
		}
		return matriz;
	}
	
	/**
	 * Retorna a c�lula da matriz na posi��o informada pelos par�metros.
	 * @param i n�mero da linha da c�lula. 
	 * @param j n�mero da coluna da c�lula.
	 * @return Celula da linha e coluna informada.
	 */
	public Celula getCelula(int i, int j) {
		return matriz[i][j];
	}

	/**
	 * Sorteia a posi��o das minas de forma aleat�ria.
	 */
	public void sortearPosicaoDasMinas() {
		for (int i = 0; i < TOTAL_MINAS; i++) {
			int linhasorteada, colunasorteada;

			do {
				linhasorteada = gerarInteiroAleatorio(0, LINHAS - 1);
				colunasorteada = gerarInteiroAleatorio(0, COLUNAS - 1);

			} while (getCelula(linhasorteada, colunasorteada).contemMina());

			getCelula(linhasorteada, colunasorteada).colocarMina();
		}
	}

	/**
	 * Se o n�mero de c�lulas abertas for igual ao n�mero de c�lulas menos o
	 * n�mero de minas, s� restam minas.
	 */
	public boolean soRestamMinas() {
		int abertas = 0;
		for (int i = 0; i < LINHAS; i++) {
			for (int j = 0; j < COLUNAS; j++) {
				if (getCelula(i,j).aberta()) {
					abertas++;
				}
			}
		}
		return abertas == TOTAL_CELULAS - TOTAL_MINAS;
	}
	
	/**
	 * Verifica se existe alguma das c�lulas abertas contendo uma mina.
	 */
	public boolean existeMinaAberta() {
		for (int i = 0; i < LINHAS; i++) {
			for (int j = 0; j < COLUNAS; j++) {
				if (getCelula(i,j).aberta() && getCelula(i,j).contemMina()) {
					return true;
				}
			}
	    }
		return false;
	}
	

	/**
	 * Retorna um n�mero aleat�rio de min a max (inclusive).
	 * 
	 * @param min
	 *            valor m�nimo que pode ser gerado.
	 * @param max
	 *            valoar m�ximo que pose ser gerado.
	 * @return Valor entre min e max (min <= valor <= max).
	 */
	protected int gerarInteiroAleatorio(int min, int max) {
		Random random = new Random();
		return random.nextInt(max) + min;
	}

	/**
	 * Abrir todas as c�lulas existentes no campo minado
	 */
	public void abrirTodasCelulas() {
		for (int i = 0; i < LINHAS; i++) {
			for (int j = 0; j < COLUNAS; j++) {
				getCelula(i,j).abrir();
			}
	    }
	}
	
	/**
	 * Abre as c�lulas vizinhas que n�o t�m minas e as vizinhas destes tamb�m,
	 * recursivamente. Se tiver minas ao redor, s� abre a c�lula clicada.
	 */
	public void abrirVizinhas(Celula c) {
		if (!c.contemMina() && (getMinasAoRedor(c) == 0)) {
			for (int i = -1; i <= 1; i++) {
				for (int j = -1; j <= 1; j++) {
					int linViz = c.linha() + i;
					int colViz = c.coluna() + j;
					if (dentroDaMatriz(linViz, colViz)) {
						Celula celViz = getCelula(linViz, colViz);
						if (celViz.fechadaSemMina()) {
							abrirCelula(celViz);
						}
					}
				}
			}
		}
	}

	/**
	 * Abre uma c�lula e tenta abrir suas vizinhas.
	 * @param cel C�lula a ser aberta.
	 */
	public void abrirCelula(Celula cel) {
		cel.abrir();
		abrirVizinhas(cel);
	}

	/**
	 * Retorna o n�mero de minas ao redor de uma c�lula.
	 * 
	 * @return n�mero de minas ao redor de uma c�lula.
	 */
	public int getMinasAoRedor(Celula c) {
		return getMinasAoRedor(c.linha(), c.coluna());
	}
	
	/**
	 * Retorna o n�mero de minas ao redor de uma c�lula.
	 * 
	 * @return n�mero de minas ao redor de uma c�lula.
	 */
	public int getMinasAoRedor(int lin, int col) {
		int total = 0;
		if (!getCelula(lin, col).contemMina()) {
			for (int i = -1; i <= 1; i++) {
				for (int j = -1; j <= 1; j++) {
					int linViz = lin + i;
					int colViz = col + j;
					if (dentroDaMatriz(linViz, colViz)
							&& !((lin == linViz) && (col == colViz))) {
						if (getCelula(linViz, colViz).contemMina()) {
							total++;
						}
					}
				}
			}
		}
		return total;
	}

	
	/**
	 * Retorna true se os �ndices encontram-se dentro da Matriz.
	 * 
	 * @param linViz
	 *            n�mero da linha.
	 * @param colViz
	 *            n�mero da coluna.
	 * @return true se os n�meros de linha e coluna est�o na faixa poss�vel.
	 */
	public boolean dentroDaMatriz(int linViz, int colViz) {
		return (linViz >= 0) && (linViz < LINHAS) && (colViz >= 0)
				&& (colViz < COLUNAS);
	}

	/**
	 * Retorna a matriz do campo minado, incluindo as informa��es
	 * de onde est�o as minas e as dicas.
	 * 
	 * @return Retorna a matriz do campo minado no formato de
	 * caracteres que indicam se h� mina e d� dicas de proximidades
	 * das minas.
	 */
	public String toString() {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < LINHAS; i++) {
			for (int j = 0; j < COLUNAS; j++) {
				Celula c = getCelula(i,j);
				if (c.contemMina()) {
					sb.append('B');
				} else {
					sb.append(getMinasAoRedor(c));
				}
				sb.append(' ');
			}
			sb.append("\n");
		}
		
		return sb.toString();
	}

	/**
	 * Retorna o estado da matriz no formato de uma matriz de caracteres.
	 *  
	 * @return matriz no formato de String.
	 */
	public String toStringEstado() {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < LINHAS; i++) {
			for (int j = 0; j < COLUNAS; j++) {
				Celula c = getCelula(i,j);
				if (c.aberta()) {
					if (c.contemMina()) {
						sb.append('B');
					} else {
						sb.append(getMinasAoRedor(c));
					}
				} else {
					sb.append('_');
				}
				sb.append(' ');
			}

			sb.append("\n");
		}
		return sb.toString();
	}
}