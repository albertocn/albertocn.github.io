package campominado.dominio;

/**
 * Representa uma c�lula do campo minado.
 * @author Alberto
 */
public class Celula {

	private int lin, col;
	private boolean contemMina;
	private boolean aberta;

	/**
	 * Cria uma c�lula do campo minado.
	 * @param lin N�mero da linha na qual a c�lula se encontra na matriz.
	 * @param col N�mero da coluna na qual a c�lula se encontra na matriz.
	 * @param contemMina Indica se a c�lula cont�m uma mina.
	 * @param aberta Indica se a c�lula est� aberta.
	 * @param matriz Matriz que cont�m todas as c�lulas.
	 */
	public Celula(int lin, int col, boolean contemMina, boolean aberta) {
		this.lin = lin;
		this.col = col;
		this.contemMina = contemMina;
		this.aberta = aberta;
	}

	/**
	 * Linha na qual a c�lula se encontra na matriz.
	 * @return N�mero da linha na qual a c�lula se encontra na matriz.
	 */
	public int linha() {
		return lin;
	}

	/**
	 * Coluna na qual a c�lula se encontra na matriz.
	 * @return N�mero da coluna na qual a c�lula se encontra na matriz.
	 */
	public int coluna() {
		return col;
	}

	/**
	 * Retorna se a c�lula est� aberta (vis�vel)
	 * 
	 * @return true quando a c�lula est� aberta (vis�vel) e false caso contr�rio
	 */
	public boolean aberta() {
		return aberta;
	}	

	/**
	 * Marca a c�lula como aberta (vis�vel).
	 */
	public void abrir() {
		this.aberta = true;
	}

	/**
	 * Indica se a c�lula cont�m mina.
	 * 
	 * @return true quando a c�lula tem uma mina e false caso contr�rio
	 */
	public boolean contemMina() {
		return this.contemMina;
	}

	/**
	 * Coloca uma mina na c�lula.
	 */
	public void colocarMina() {
		this.contemMina = true;
	}

	/**
	 * Indica se uma c�lula est� fechada e n�o tem mina (o jogador n�o acertar�
	 * uma mina.
	 * 
	 * @return true caso a c�lula esteja aberta e n�o tenha mina.
	 */
	public boolean fechadaSemMina() {
		return !aberta() && !contemMina();
	}
}