package pesquisa;

import junit.framework.TestCase;

import org.junit.Test;

public class PesquisaTeste extends TestCase {

	public PesquisaTeste() {
		super();
	}

	@Test
	public void testVazia() {
	    Integer[] lista = {};
	    
	    assertEquals(-1, Pesquisa.sequencial(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.binaria(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.binariaRec(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.interpolada(lista, 0, lista.length - 1, 5));
	}

	@Test
	public void testUmElemento() {
	    Integer[] lista = {1};

	    // Procura um valor existente
	    assertEquals(0, Pesquisa.sequencial(lista, 0, lista.length - 1, 1));
	    assertEquals(0, Pesquisa.binaria(lista, 0, lista.length - 1, 1));
	    assertEquals(0, Pesquisa.binariaRec(lista, 0, lista.length - 1, 1));
	    assertEquals(0, Pesquisa.interpolada(lista, 0, lista.length - 1, 1));	    

	    // Procura um valor inexistente
	    assertEquals(-1, Pesquisa.sequencial(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.binaria(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.binariaRec(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.interpolada(lista, 0, lista.length - 1, 5));	    
	}

	@Test
	public void testDoisElementos() {
	    Integer[] lista = {10, 100};

	    // Procura um valor existente
	    assertEquals(0, Pesquisa.sequencial(lista, 0, lista.length - 1, 10));
	    assertEquals(0, Pesquisa.binaria(lista, 0, lista.length - 1, 10));
	    assertEquals(0, Pesquisa.binariaRec(lista, 0, lista.length - 1, 10));	    
	    assertEquals(0, Pesquisa.interpolada(lista, 0, lista.length - 1, 10));	    

	    assertEquals(1, Pesquisa.sequencial(lista, 0, lista.length - 1, 100));
	    assertEquals(1, Pesquisa.binaria(lista, 0, lista.length - 1, 100));
	    assertEquals(1, Pesquisa.binariaRec(lista, 0, lista.length - 1, 100));	    
	    assertEquals(1, Pesquisa.interpolada(lista, 0, lista.length - 1, 100));	    

	    // Procura um valor inexistente
	    assertEquals(-1, Pesquisa.sequencial(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.binaria(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.binariaRec(lista, 0, lista.length - 1, 5));	    
	    assertEquals(-1, Pesquisa.interpolada(lista, 0, lista.length - 1, 5));	    
	}

	@Test
	public void testTresElementos() {
	    Integer[] lista = {1, 10, 20};
	
	    // Procura um valor existente
	    assertEquals(0, Pesquisa.sequencial(lista, 0, lista.length - 1, 1));
	    assertEquals(0, Pesquisa.binaria(lista, 0, lista.length - 1, 1));
	    assertEquals(0, Pesquisa.binariaRec(lista, 0, lista.length - 1, 1));
	    assertEquals(0, Pesquisa.interpolada(lista, 0, lista.length - 1, 1));	    

	    assertEquals(1, Pesquisa.sequencial(lista, 0, lista.length - 1, 10));
	    assertEquals(1, Pesquisa.binaria(lista, 0, lista.length - 1, 10));
	    assertEquals(1, Pesquisa.binariaRec(lista, 0, lista.length - 1, 10));
	    assertEquals(1, Pesquisa.interpolada(lista, 0, lista.length - 1, 10));
	    
	    assertEquals(2, Pesquisa.sequencial(lista, 0, lista.length - 1, 20));
	    assertEquals(2, Pesquisa.binaria(lista, 0, lista.length - 1, 20));
	    assertEquals(2, Pesquisa.binariaRec(lista, 0, lista.length - 1, 20));
	    assertEquals(2, Pesquisa.interpolada(lista, 0, lista.length - 1, 20));

	    // Procura um valor inexistente
	    assertEquals(-1, Pesquisa.sequencial(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.binaria(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.binariaRec(lista, 0, lista.length - 1, 5));	    
	    assertEquals(-1, Pesquisa.interpolada(lista, 0, lista.length - 1, 5));	    
	}

	@Test
	public void testNormal() {
	    Integer[] lista = {1,6,8,14,20,97};

	    // Procura um valor existente
	    assertEquals(4, Pesquisa.sequencial(lista, 0, lista.length - 1, 20));
	    assertEquals(4, Pesquisa.binaria(lista, 0, lista.length - 1, 20));
	    assertEquals(4, Pesquisa.binariaRec(lista, 0, lista.length - 1, 20));	    
	    assertEquals(4, Pesquisa.interpolada(lista, 0, lista.length - 1, 20));	    

	    // Procura um valor inexistente
	    assertEquals(-1, Pesquisa.sequencial(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.binaria(lista, 0, lista.length - 1, 5));
	    assertEquals(-1, Pesquisa.binariaRec(lista, 0, lista.length - 1, 5));	    
	    assertEquals(-1, Pesquisa.interpolada(lista, 0, lista.length - 1, 5));	    
	}

	private static final int TOTAL_VALORES = 30000;		

	@Test
	public void testMuitosElementosSequencial() {		
		Integer[] vetor = gerarVetor(TOTAL_VALORES);		
		
		for (int posEsperada = 0; posEsperada < vetor.length; posEsperada++) {
			assertEquals(posEsperada, Pesquisa.sequencial(vetor, 0, vetor.length - 1, vetor[posEsperada]));
		}		
	}
	
	@Test
	public void testMuitosElementosBinaria() {
		Integer[] vetor = gerarVetor(TOTAL_VALORES);		
		
		for (int posEsperada = 0; posEsperada < vetor.length; posEsperada++) {
			assertEquals(posEsperada, Pesquisa.binaria(vetor, 0, vetor.length - 1, vetor[posEsperada]));
		}		
	}

	@Test
	public void testMuitosElementosBinariaRec() {
		Integer[] vetor = gerarVetor(TOTAL_VALORES);		
		
		for (int posEsperada = 0; posEsperada < vetor.length; posEsperada++) {
			assertEquals(posEsperada, Pesquisa.binariaRec(vetor, 0, vetor.length - 1, vetor[posEsperada]));
		}			
	}

	@Test
	public void testMuitosElementosInterpolada() {
		Integer[] vetor = gerarVetor(TOTAL_VALORES);		
		
		for (int posEsperada = 0; posEsperada < vetor.length; posEsperada++) {
			assertEquals(posEsperada, Pesquisa.interpolada(vetor, 0, vetor.length - 1, vetor[posEsperada]));
		}			
	}

	/**
	 * Gera um vetor com TOTAL valores partindo de 1 a ate TOTAL de forma
	 * crescente.
	 */
	protected Integer[] gerarVetor(final int TOTAL) {
		// Gera valores sequenciais de 1 a TOTAL e coloca no array
		Integer[] vetor = new Integer[TOTAL];
		for (int i = 1; i <= TOTAL; i++) {
			vetor[i - 1] = i;
		}
		return vetor;
	}	
}