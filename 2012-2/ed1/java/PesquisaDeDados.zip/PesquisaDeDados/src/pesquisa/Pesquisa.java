package pesquisa;

public class Pesquisa {

	/**
	 * Efetua a busca pela Chave entre as posicoes Inicio e Fim, partindo de
	 * Inicio sequencialmente ate o Fim. Se encontrar, retorna a posicao. Caso
	 * contrario retorna -1.
	 */
	public static int sequencial(Comparable[] vetor, int inicio, int fim,
			Comparable chave) {
		for (int pos = inicio; pos <= fim; pos++) {
			if (chave.equals(vetor[pos])) {
				return pos;
			}
		}
		return -1;
	}

	/**
	 * Efetua a busca binaria pela Chave entre as posicoes Inicio e Fim. Se
	 * encontrar, retorna a posicao. Caso contrario retorna -1.
	 */
	public static int binaria(Comparable[] vetor, int inicio, int fim,
			Comparable chave) {

		while (inicio <= fim) {
			int meio = (inicio + fim) / 2;
			if (chave.compareTo(vetor[meio]) < 0) {
				fim = meio - 1;
			} else {
				if (chave.compareTo(vetor[meio]) > 0) {
					inicio = meio + 1;
				} else {
					return meio;
				}
			}
		}

		return -1;
	}

	/**
	 * Efetua a busca binaria pela Chave entre as posicoes Inicio e Fim. Se
	 * encontrar, retorna a posicao. Caso contrario retorna -1.
	 */
	public static int binariaRec(Comparable[] vetor, int inicio, int fim,
			Comparable chave) {
		if (inicio > fim) {
			return -1;
		} else {
			int meio = (inicio + fim) / 2;
			if (chave.compareTo(vetor[meio]) < 0) {
				return binariaRec(vetor, inicio, meio - 1, chave);
			} else if (chave.compareTo(vetor[meio]) > 0) {
				return binariaRec(vetor, meio + 1, fim, chave);
			} else {
				return meio;
			}
		}
	}

	/**
	 * Efetua a busca interpolada pela Chave entre as posicoes Inicio e Fim. Se
	 * encontrar, retorna a posicao. Caso contrario retorna -1.
	 */
	public static int interpolada(Integer[] vetor, int inicio, int fim,
			Integer chave) {

		// So tem um elemento e eh igual ao procurado
		if (inicio == fim && vetor[inicio] == chave) {
			return inicio;
		}		

		while ( (inicio < fim) && (vetor[inicio] <= chave) && (vetor[fim] >= chave) ) {			
			int meio = inicio + 
					 ((chave - vetor[inicio]) * (fim - inicio)) / (vetor[fim] - vetor[inicio]);
			
			if (vetor[meio] < chave) {
				inicio = meio + 1;
			} else if (vetor[meio] > chave) {
				fim = meio - 1;
			} else {
				return meio;
			}
		}
		
		return -1;
	}
}
