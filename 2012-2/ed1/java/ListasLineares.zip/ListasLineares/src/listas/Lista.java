package listas;


/**
 * Lista que mantem objetos associados a chaves.
 */
public interface Lista {
	
	/** 
	 * Verifica se a lista esta vazia, ou seja, nao contem objetos.
	 * 
	 * @return true se a lista nao tem objetos e false quando tem um ou mais objetos.
	 */	
	boolean vazia();
	
	/** 
	 * Verifica se a lista esta cheia, ou seja, nao comporta mais objetos.
	 * 
	 * @return true se a lista nao comporta mais objetos e false caso contrario.
	 */	
	boolean cheia();
	
	/**
	 *  Retorna o tamanho da lista, isto e, o numero de objetos armazenados na lista.
	 *  
	 *  @return N�mero de objetos efetivamente contidos na lista.
	 */
	int tamanho();
	
	/**
	 *  Insere um objeto na lista associado a chave.
	 * 
	 *  @return true se conseguir inserir e false caso um objeto com a chave passada ja exista na lista.
	 */
	boolean inserir( int chave , Object nodo);
	
	/** 
	 *  Remove o objeto associado a chave passada da lista.
	 * 
	 *  @return true se conseguir remover e false caso um objeto com a chave passada nao for encontrado.
	 */
	boolean remover(int chave);
	
	/** 
	 *  Obtem o objeto associado a chave passada.
	 *  
	 *  @return Objeto associado a chave encontrado ou null caso nao haja um objeto associado a chave passada. 
	 */
	Object obter(int chave);
	
	/** 
	 * Altera o objeto associado a chave passada na lista.
	 * 
	 * @return true caso consiga encontrar e alterar o objeto com a chave passada. Caso nao encontre, retorna false.
	 */
	boolean alterar(int chave, Object dado);

	/**
	 *  Apaga todos os objetos da lista.
	 */
	void apagar();
	
	/**
	 * Retorna um objeto iterador para percorrer a lista.
     *
     * @return instancia de uma classe que implementa a interface Iterador.
	 */
	Iterador iterador();
}
