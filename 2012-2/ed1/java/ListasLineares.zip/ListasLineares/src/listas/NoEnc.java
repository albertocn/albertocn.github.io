package listas;

public class NoEnc extends No {
	
	 /** Referencia para o proximo No da Lista. */
	private NoEnc proximo;		
	
	public NoEnc(int chave, Object info, NoEnc proximo) {
		super(chave, info);
		this.proximo = proximo;
	}

	public NoEnc getProximo() {
		return this.proximo;
	}

	public void setProximo(NoEnc proximo) {
		this.proximo = proximo;
	}
}
