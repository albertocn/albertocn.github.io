package listas;

public interface Iterador {
	
	/** 
	 * Retorna o proximo objeto da estrutura de dados.
	 */
	Object getProximo();
	
	/**
	 * Indica se ha um proximo item na estrutura de dados.
	 *  
	 * @return true quando ha um proximo e false caso contrario.
	 */
	boolean temProximo();
}
