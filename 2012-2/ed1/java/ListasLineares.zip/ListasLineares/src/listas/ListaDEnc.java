package listas;

/**
 * Lista simplesmente encadeada na qual cada no tem uma referencia
 * para o proximo no da lista.
 */
public class ListaDEnc extends ListaEncAbs {

	protected int tamanho = 0;
	protected NoDEnc cauda = null;
	
	/**
	 * Retorna a referencia para cabeca apos o Cast para a subclasse NoDEnc.
	 */
	protected NoDEnc getCabeca() {
		return (NoDEnc) this.cabeca;
	}
	
	/**
	 * Retorno o valor do atributo tamanho, que deve ser alterado sempre que 
	 * houver uma insercao ou remocao (inclusive apagar todos).
	 */
	@Override
	public int tamanho() {
		return this.tamanho;
	}
	
	/**
	 * Atribui null as referencias para o Anterior e Proximo visando facilitar a coleta de lixo. 
	 * Alem de apagar os nos, faz a atualizacao do tamanho para o valor zero. 
	 */
	@Override
	public void apagar() {
		while (this.cabeca != null) {
			NoDEnc PApagar = this.getCabeca();
			this.cabeca = this.getCabeca().getProximo();
			PApagar.setProximo(null);
			PApagar.setAnterior(null);
		}
		this.tamanho = 0;
		this.cauda = null;
	}

	/** 
	 * Insere um objeto associado a chave na cabeca da lista, ou seja, a antiga cabeca passa
	 * a ser o segundo elemento no encadeamento.
	 */
	@Override
	public boolean inserir(int chave, Object info) {
		NoDEnc novoNo = new NoDEnc(chave, info, null, this.getCabeca());
		
        if (this.cabeca != null) {
		   this.getCabeca().setAnterior(novoNo);
        }

		this.cabeca = novoNo;

        if (this.cauda == null) {
           this.cauda = novoNo;
        }
		        		
   		this.tamanho++;
		return true;
	}

	/** 
	 * Remove o objeto associado a chave passada, tomando cuidado de corrigir
	 * a referencia Proximo de seu anterior na lista, a referencia Anterior
	 * de seu proximo na lista, alem da Cabeca e/ou Cauda quando o objeto
	 * removido encontra-se no inicio e/ou no final da lista.
	 */
	@Override
	public boolean remover(int chave) {
		NoDEnc PAtual = this.getCabeca();

		while (PAtual != null) {
			if (PAtual.getChave() == chave) {
				if (PAtual == this.getCabeca())
					this.cabeca = PAtual.getProximo();

				if (PAtual == this.cauda)
					this.cauda = PAtual.getAnterior();

				if (PAtual.getProximo() != null)
					PAtual.getProximo().setAnterior(PAtual.getAnterior());

				if (PAtual.getAnterior() != null)
					PAtual.getAnterior().setProximo(PAtual.getProximo());

				this.tamanho--;
				return true;
			} else {
				PAtual = PAtual.getProximo();
			}
		}
		return false;
	}
}