package listas;

/**
 * Lista simplesmente encadeada na qual os nos sao ordenados pelo valor da chave,
 * sendo que o menor valor da lista esta na cabeca. Nao sao aceitas chaves
 * duplicadas.
 */
public class ListaOrd extends ListaEncAbs {
	
	protected int tamanho = 0;
	
	
	/**
	 * Retorno o valor do atributo tamanho, que deve ser alterado sempre que 
	 * houver uma insercao ou remocao (inclusive apagar todos).
	 */
	@Override
	public int tamanho() {
		return this.tamanho;
	}
	
	
	/**
	 * Alem de apagar os nos, faz a atualizacao do tamanho para o valor zero. 
	 */
	@Override
	public void apagar() {
		super.apagar();
		this.tamanho = 0;
	}


	/**
	 * Insere na lista de forma ordenada, retornando true quando conseguir.
	 * Nao permite a insercao de chaves duplicadas, retornando false neste caso.
	 */
	@Override
	public boolean inserir(int chave, Object info) {

		NoEnc PAtual = this.cabeca;
		NoEnc PAnterior = null;

		while (PAtual != null){
			if (PAtual.getChave() == chave){ // Achou uma chave igual. Nao pode inserir chave duplicada
				return false;
			} else if(PAtual.getChave() > chave) { // Encontrou uma chave maior. Deve inserir antes do no PAtual
				break;
			}  else { // Ainda pode estar para frente na lista
				PAnterior = PAtual;  						
				PAtual = PAtual.getProximo();
			}
		}
		
		// Criacao do novo No 
		NoEnc PNovo = new NoEnc(chave, info, PAtual);
		
		//Isercao do novo No na cabeca ou apos PAnterior
		if (PAnterior == null) {
			this.cabeca = PNovo;
		} else {
			PAnterior.setProximo(PNovo);
		}

		this.tamanho++;
		return true;
	}

	/**
	 * Remove, caso exista, o no com a chave passada. Para a busca pelo no quando encontra uma chave
	 * maior que a procurada, ja que a lista e ordenada.  
	 */
	@Override
	public boolean remover(int chave) {
		NoEnc PAtual = this.cabeca;
		NoEnc PAnterior = null;

		while (PAtual != null) {
			if (PAtual.getChave() == chave) { // Encontrou o no a ser removido
				if (PAnterior == null) {
					this.cabeca = PAtual.getProximo();
				} else {
					PAnterior.setProximo(PAtual.getProximo());
				}
				this.tamanho--;
				return true;
			} else if (PAtual.getChave() > chave) { // Nao e possivel mais encontrar a chave
				return false;
			} else { // Ainda pode-se encontrar a chave na lista
				PAnterior = PAtual;
				PAtual = PAtual.getProximo();
			}
		}

		return false;
	}

	
	/**
	 * Retorna o n� que cont�m a chave passada.
	 * 
	 * @param chave Chave cujo no deseja-se obter
	 * @return NoEnc encontrado ou null quando a chave n�o tem objeto correspondente na lista.
	 */
	@Override
	protected NoEnc obterNo(int chave) {
		NoEnc PAtual = this.cabeca;
		while (PAtual != null) {
			if (PAtual.getChave() == chave) {
				break;
			} else if (PAtual.getChave() > chave) {
				PAtual = null;
			} else {
				PAtual = PAtual.getProximo();
			}
		}
		return PAtual;
	}
}
