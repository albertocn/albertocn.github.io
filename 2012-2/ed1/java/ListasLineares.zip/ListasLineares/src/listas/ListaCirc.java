package listas;


/**
 * Lista simplesmente encadeada na qual cada no tem uma referencia
 * para o proximo no da lista.
 */
public class ListaCirc extends ListaEncAbs {
	
	protected int tamanho = 0;
	
	/**
	 * Cria um no cabeca, sendo que Proximo referencia o proprio no
	 * criado, caracterizando a lista como circular.  
	 */
	public ListaCirc() {
		this.cabeca = new NoEnc(0, null, null);
		this.cabeca.setProximo(this.cabeca);
	}
	
	@Override
	public int tamanho() {
		return this.tamanho;
	}
	
	@Override
	public boolean vazia() {
		return this.tamanho == 0;
	}
	
	/**
	 * Atribui null as referencias para o Proximo visando facilitar a coleta de lixo. 
	 */
	@Override
	public void apagar() {
		NoEnc PApagar = this.cabeca.getProximo();
		while (PApagar != this.cabeca) {
			this.cabeca.setProximo(PApagar.getProximo());
			PApagar.setProximo(null);
			PApagar = this.cabeca.getProximo();
		}
		this.tamanho = 0;
	}	
	
	/** 
	 * Insere um objeto associado a chave na cabeca da lista, ou seja, a antiga cabeca passa
	 * a ser o segundo elemento no encadeamento.
	 */
	@Override
	public boolean inserir(int chave, Object info) {
		this.cabeca.setProximo(new NoEnc(chave, info, this.cabeca.getProximo()));
		this.tamanho++;
		return true;
	}
	
	/** 
	 * Remove o objeto associado a chave passada, tomando cuidado de corrigir
	 * a referencia Proximo de seu anterior na lista ou a Cabeca quando o objeto
	 * removido encontra-se no inicio da lista.
	 */
	@Override
	public boolean remover(int chave) {

		NoEnc PAnterior = this.cabeca;		

		// Percorre a lista ate encontrar um no com a chave procurada.
		// Remove o no e corrige a referencia do no anterior para o proximo no.
 	    while (PAnterior.getProximo() != this.cabeca) {
 	    	NoEnc PAtual = PAnterior.getProximo();

 	    	if (PAtual.getChave() == chave) {
		       PAnterior.setProximo(PAtual.getProximo());
		       this.tamanho--;
		       return true;
 	    	}
		    PAnterior = PAtual;
 	    }
 	    
 	    return false;
	}
	
	
	/**
	 * Retorna o n� que cont�m a chave passada.
	 * 
	 * @param chave Chave cujo no deseja-se obter
	 * @return NoEnc encontrado ou null quando a chave n�o tem objeto correspondente na lista.
	 */
	@Override
	protected NoEnc obterNo(int chave) {
		NoEnc PAtual = this.cabeca.getProximo();
		while (PAtual != this.cabeca) {
			if (PAtual.getChave() == chave) {
				break;
			}
			PAtual = PAtual.getProximo();
		}

		return PAtual == this.cabeca ? null : PAtual;
	}


	public String toString() {
		StringBuffer sb = new StringBuffer("Tamanho = " + tamanho() + ", ");
		sb.append("Nos = [");
		NoEnc atual = this.cabeca.getProximo();
		while (atual != this.cabeca) {			
			sb.append(atual);
			atual = atual.getProximo();
		}
		sb.append(']');
		return sb.toString();
	}

	
	@Override
	public Iterador iterador() {
		return new ListaCircIterador(this);
	}

	
	protected class ListaCircIterador extends ListaEnc.ListaEncIterador {
		
		protected ListaEncAbs listaIteracao;
		
		public ListaCircIterador(ListaEncAbs lista) {
			super(lista);
			super.atual = super.atual.getProximo();
			this.listaIteracao = lista;			
		}
		
		public boolean temProximo() {
			return super.atual != listaIteracao.cabeca;
		}		
	}
}