package listas;

/**
 * Lista simplesmente encadeada na qual cada no tem uma referencia
 * para o proximo no da lista.
 */
public class ListaEnc extends ListaEncAbs {

	/** 
	 * Insere um objeto associado a chave na cabeca da lista, ou seja, a antiga cabeca passa
	 * a ser o segundo elemento no encadeamento.
	 */
	public boolean inserir(int chave, Object info) {
		this.cabeca = new NoEnc(chave, info, this.cabeca);		
		return true;
	}
	
	/** 
	 * Remove o objeto associado a chave passada, tomando cuidado de corrigir
	 * a referencia Proximo de seu anterior na lista ou a Cabeca quando o objeto
	 * removido encontra-se no inicio da lista.
	 */
	public boolean remover(int chave) {
		boolean Sucesso = false;
		if (!vazia()) {
			NoEnc PAtual, PAnterior;
			if (this.cabeca.getChave() == chave) {
				this.cabeca = this.cabeca.getProximo();
				Sucesso = true;
			} else {
				PAtual = this.cabeca;
				while (PAtual.getProximo() != null) {
					PAnterior = PAtual;
					PAtual = PAtual.getProximo();

					if (PAtual.getChave() == chave) {
						PAnterior.setProximo(PAtual.getProximo());
						Sucesso = true;
						break;
					}
				}
			}

		}
		return Sucesso;
	}
}