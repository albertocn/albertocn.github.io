package listas;

public class NoDEnc extends NoEnc {
	
	 /** Referencia para os Nos anterior e proximo da Lista. */
	private NoDEnc anterior;		
	
	public NoDEnc(int chave, Object info, NoDEnc anterior, NoDEnc proximo) {
		super(chave, info, proximo);
		this.anterior = anterior; 
	}

	public NoDEnc getAnterior() {
		return anterior;
	}

	public void setAnterior(NoDEnc anterior) {
		this.anterior = anterior;
	}

	@Override
	public NoDEnc getProximo() {
		return (NoDEnc) super.getProximo();
	}

	@Override
	public void setProximo(NoEnc proximo) {
		super.setProximo(proximo);
	}
}
