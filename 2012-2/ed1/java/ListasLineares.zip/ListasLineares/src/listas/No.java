package listas;

public class No {
	
	private int chave;
	private Object info;
	
	public No(int chave, Object info){
		this.chave = chave; 
		this.info = info;
	}

	public Object getInfo() {
		return info;
	}

	public void setInfo(Object info) {
		this.info = info;
	}

	public int getChave() {
		return chave;
	}

	public void setChave(int chave) {
		this.chave = chave;
	}
	
	public String toString() {
		return "(" + getChave() + ":" + getInfo() + ")";
	}
}