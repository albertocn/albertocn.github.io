package listas;


public abstract class ListaEncAbs implements Lista {

	/** Referencia para a Cabeca da lista */
	protected NoEnc cabeca;

	@Override
	public boolean vazia() {
		return this.cabeca == null;
	}

	@Override
	public boolean cheia() {
		return false;
	}	

	@Override
	public int tamanho() {
		NoEnc no = this.cabeca;
		int n = 0;
		while (no != null) {
			no = no.getProximo();
			n++;
		}
		return n;
	}

	/**
	 * Atribui null as referencias para o Proximo visando facilitar a coleta de lixo. 
	 */
	@Override
	public void apagar() {
		while (this.cabeca != null) {
			NoEnc PApagar = this.cabeca;
			this.cabeca = this.cabeca.getProximo();
			PApagar.setProximo(null);
		}
	}

	/**
	 * Obtem o Objeto armazenado no No atraves da chave passada. 
	 */
	@Override
	public Object obter(int chave) {
		NoEnc PAtual = obterNo(chave);
		if (PAtual == null) {
			return null;
		} else {
			return PAtual.getInfo();
		}
	}

    /**
     * Busca o no que armazena a chave passada e altera o Objeto guardado nele.
     */
	@Override
	public boolean alterar(int chave, Object dado) {
		NoEnc PAtual = obterNo(chave);
		if (PAtual != null) {
			PAtual.setInfo(dado);
		}
		return PAtual != null;
	}
	
	/**
	 * Retorna o n� que cont�m a chave passada.
	 * 
	 * @param chave Chave cujo no deseja-se obter
	 * @return NoEnc encontrado ou null quando a chave n�o tem objeto correspondente na lista.
	 */
	protected NoEnc obterNo(int chave) {
		NoEnc PAtual = this.cabeca;
		while (PAtual != null) {
			if (PAtual.getChave() == chave) {
				break;
			}
			PAtual = PAtual.getProximo();
		}
		return PAtual;
	}

	
	public String toString() {
		StringBuffer sb = new StringBuffer("Tamanho = " + tamanho() + ", ");
		sb.append("Nos = [");
		NoEnc atual = this.cabeca;
		while (atual != null) {			
			sb.append(atual);
			atual = atual.getProximo();
		}
		sb.append(']');
		return sb.toString();
	}
	
	@Override
	public Iterador iterador() {
		return new ListaEncIterador(this);
	}

	/**
	 * Itera na Lista Encadeada da cabeca para a cauda.
	 */
	protected class ListaEncIterador implements Iterador {
		
		protected NoEnc atual = null;
		
		public ListaEncIterador(ListaEncAbs lista) {
			atual = lista.cabeca;
		}
		
		public Object getProximo() {
			if (temProximo()) {
				Object obj = atual.getInfo();
				atual = atual.getProximo();
				return obj;
			} else {
				throw new IllegalStateException("Tentando continuar interacao alem do permitido");
			}
		}
		
		public boolean temProximo() {			
			return atual != null;
		}
	}
}