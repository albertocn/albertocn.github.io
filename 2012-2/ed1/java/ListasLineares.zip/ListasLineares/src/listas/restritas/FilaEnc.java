package listas.restritas;

public class FilaEnc implements Fila{
	
	/** Numero de nos contidos na fila */
	private int tamanho;	
	
	/** Referencia para o primeiro No da Fila (frente). */
	private No primeiro;
	
	/** Referencia para o ultimo No da Fila (fundo). */
	private No ultimo;
	
	/**
	 * Cria a Fila e inicializa as referencias para o primeiro e ultimo elemento
	 * da fila para null, alem de tamanho receber o valor inicial 0. 
	 */
	public FilaEnc(){
		this.primeiro = null;
		this.ultimo = null;
		this.tamanho = 0;
	}	

	/** 
	 * Retorna true caso o tamanho seja 0.
	 */
	@Override
	public boolean vazia() {
		return tamanho == 0;
	}

	/**
	 * Sempre retorna false porque nao da para prever quando ha espaco disponivel
	 * na memoria, logo nunca estaria cheia.
	 */
	@Override
	public boolean cheia() {
		return false;
	}
	
	/**
	 * Retorna o tamanho da Fila.
	 */
	@Override
	public int tamanho() {
		return tamanho;
	}
	
	/**
	 * Inseri um objeto no final da fila. Caso a lista esteja vazia, o objeto estara
	 * tambem na frente da fila.
	 */
	@Override
	public boolean inserir(Object info) {		
		No novoNo = new No(info);
		
		if (vazia()) {
			this.primeiro = novoNo;
		}
		else {
			this.ultimo.setProximo(novoNo);			
		}
		this.ultimo = novoNo;
		
		this.tamanho++;		
		return true;
	}

	/**
	 * Retira um objeto da frente da fila.
	 */
	@Override
	public Object retirar() {
		No antigoPrimeiro = this.primeiro;
		this.primeiro = this.primeiro.getProximo();
		antigoPrimeiro.setProximo(null);
		this.tamanho--;
		if (vazia()) {
			this.ultimo = null;
		}
		return antigoPrimeiro.getInfo();
	}
	
	/** 
	 * Retorna o valor do primeiro No da fila, caso exista.
	 */
	@Override
	public Object frente() {
		if(!vazia()){
			return primeiro.getInfo();
		} else {
			throw new IllegalStateException("Underflow da Fila");
		}
	}

	/** 
	 * Apaga toda a Fila, No a No, atribuiando null a cada um 
	 */
	@Override
	public void apagar() {
		if(!vazia()){
			No noLiberar = this.primeiro;
			while (noLiberar != null){
				this.primeiro = this.primeiro.getProximo();
				noLiberar.setProximo(null);
				noLiberar = this.primeiro;
			}
            this.ultimo = null;
            this.tamanho = 0;
		}
	}
}