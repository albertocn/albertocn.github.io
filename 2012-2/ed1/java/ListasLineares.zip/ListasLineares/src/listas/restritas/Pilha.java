package listas.restritas;

public interface Pilha {
	
	/**
	 * Coloca um novo objeto no topo da pilha.
     */
	boolean empilhar(Object dado);
	
	/**
	 * Retira o objeto contido no topo da pilha, fazendo com que o novo topo
	 * da pilha seja o objeto que esta abaixo do retirado.
	 */
	Object desempilhar();
	
	/** 
	 * Retorna o objeto que encontra-se no topo da pilha, sem retira-lo.
	 */
	Object topo();

	/**
	 * Apaga todos os elementos da pilha.
	 */
	void apagar();

	/**
	 * Retorna o numero de objetos contidos na pilha.
	 */
	int tamanho();
	
	/**
	 * Retorna true se nao houver objetos na pilha.
	 */
	boolean vazia();

	/**
	 * Retorna true se a pilha estiver cheia.
	 */
	boolean cheia();
}