package listas.restritas;

public class PilhaArray implements Pilha {
	
	/** Numero atual de objetos armazenados */
	protected int tamanho;
	
	/** Array que armazena os objetos inseridos na Pilha */
	protected Object[] pilha;
	
	
	/** 
	 * Cria uma Pilha com a capacidade informada.
	 */
	public PilhaArray(int capacidade){
		this.pilha = new Object[capacidade];
		this.tamanho = 0;
	}
	

	/**
	 * Retorna true caso o tamanho seja igual a 0
	 */
	@Override
	public boolean vazia() {
		return this.tamanho == 0;
	}
	
	/**
	 * Retorna true quando o numero de objetos na Pilha ja ocupa toda a capacidade
	 * do array.
	 */
	@Override
	public boolean cheia() {
		return this.tamanho == this.pilha.length;
	}

	/**
	 * Retorna o numero de objetos contidos no array e nao a sua capacidade.
	 */
	@Override
	public int tamanho() {
		return this.tamanho;
	}

	
	/** 
	 * Empilha o objeto passado no topo da pilha, ou seja, na proxima posicao
	 * disponivel do array (tamanho + 1).
	 */
	@Override
	public boolean empilhar(Object dado) {
		if(!cheia()){
			pilha[tamanho++] = dado;
			return true;
		}
		return false;
	}

	/**
	 * Retira o objeto do topo pilha, ou seja, da posicao (tamanho).
	 */
	@Override
	public Object desempilhar() {
		Object obj = topo();
		this.pilha[--this.tamanho] = null;
		return obj;
	}

	/** 
	 * Retorna o objeto no da pilha, mas sem retira-lo.
	 */
	@Override
	public Object topo() {
		if(!vazia()){
			return this.pilha[tamanho() - 1];
		} else {
			throw new IllegalStateException("Underflow da Pilha");
		}		
	}

	/** 
	 * Apaga todos os objetos contidos na pilha, fazendo com que cada elemento
	 * do array referencie null, visando facilitar a coleta de lixo.
	 */
	@Override
	public void apagar() {
		while (this.tamanho > 0) {
			this.pilha[--this.tamanho] = null;
		}
	}
}
