package listas.restritas;

public interface Fila {
	
	/**
	 * Insere um objeto no final (fundo) da fila. O objeto nao pode
	 * ser null.
	 * 
	 * @return true caso consiga inserir e false caso contrario
	 */	
	boolean inserir(Object nodo);
	
	/**
	 * Retira um objeto da frente da fila.
	 * 
	 * @return O objeto que se encontrava na frente da fila.
	 */
	Object retirar();
	
	/**
	 * Retorna o objeto que se encontra na frente da fila, sem retira-lo.
	 * 
	 * @return O objeto que se encontra na frente da fila.
	 */
	Object frente();
	
	/**
	 * Apaga todos os elementos da fila.
	 */
	void apagar();

	/**
	 * Retorna o numero de objetos contidos na fila.
	 */
	int tamanho();
	
	/**
	 * Retorna true se nao houver objetos na fila.
	 */
	boolean vazia();

	/**
	 * Retorna true se a fila estiver cheia.
	 */
	boolean cheia();
}
