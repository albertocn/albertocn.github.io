package listas.restritas;

/**
 * Fila baseada em array cuja capacidade e determinada no momento da 
 * instanciacao.
 */
public class FilaArray implements Fila {
	
	/** Quantidade de objetos contidos na fila */
	protected int tamanho;
	
	/** Inicio da fila (frente) */
	protected int inicio;
	
	/** Fim da fila (fundo) */
	protected int fim;
	
	/** Array de Object que guarda os objetos inseridos na fila. */
	protected Object[] fila;	
	
	/** 
	 * Cria uma fila com a capacidade informada.
	 */
	public FilaArray(int capacidade){
		this.fila = new Object[capacidade];
		this.tamanho = 0;
		this.inicio = 0;
		this.fim = 0;
	}	
	
	/**
	 * Retorna true caso o tamanho seja igual a 0
	 */
	@Override
	public boolean vazia() {
		return this.tamanho == 0;
	}
	
	/**
	 * Retorna true quando o numero de objetos na Fila ja ocupa toda a capacidade
	 * do array.
	 */
	@Override
	public boolean cheia() {
		return this.tamanho == this.fila.length;
	}

	/**
	 * Retorna o numero de objetos contidos no array e nao a sua capacidade.
	 */
	@Override
	public int tamanho() {
		return this.tamanho;
	}
	
	/** 
	 * Inseri (enfileira) um objeto na fila. Primeiro verifica-se se a mesma est� vazia.
	 * Em caso positivo, o objeto � inserido na posi��o 0. Caso contrario, calcula-se
	 * o lugar do proximo objeto.
	 */
	public boolean inserir(Object dado) {
		if (!cheia()) {		
			this.fim = vazia() ? this.inicio = 0 : avancarIndice(this.fim);
			this.fila[fim] = dado;
			this.tamanho++;
			return true;
		}
		return false;
	}

	/**
	 * Retira um objeto da frente da fila.
	 */
	public Object retirar() {
		Object primeiro = frente();
		this.fila[this.inicio] = null;
		this.inicio = avancarIndice(this.inicio);
		this.tamanho--;
		return primeiro;
	}

	/** 
	 * Retorna o primeiro da fila, sem retira-lo.
	 */
	public Object frente() {				
		if (!vazia()){
			return this.fila[this.inicio];
		} else {
			throw new IllegalStateException("Underflow da Pilha");
		}		
	}

	/** 
	 * Apaga todos os objetos contidos na fila, fazendo com que cada elemento
	 * do array referencie null, visando facilitar a coleta de lixo.
	 */
	@Override
	public void apagar() {
		while (!vazia()) {
			this.fila[this.inicio] = null;
			this.inicio = avancarIndice(this.inicio);
			this.tamanho--;
		}
		this.inicio = 0;
		this.fim = 0;
	}
	
	/**
	 * Avanca a posicao do indice do array passada uma posicao para 
	 * a direita. Caso chegue ao limite, volta para a posicao 0.
	 */
	private int avancarIndice(int pos) {
		return (pos + 1) % this.fila.length;
	}
}
