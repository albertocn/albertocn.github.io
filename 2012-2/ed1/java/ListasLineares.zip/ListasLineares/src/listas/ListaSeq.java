package listas;

import listas.Lista;
import listas.No;

/**
 * Lista que armazena objetos associados a chaves utilizando um array de
 * objetos.
 */
public class ListaSeq implements Lista {

	private int tam = 0;
	private No[] arrayDeNos;

	/**
	 * Cria a lista com a capacidade maxima passada.
	 */
	public ListaSeq(int capacidade) {
		this.arrayDeNos = new No[capacidade];
	}

	public int tamanho() {
		return this.tam;
	}

	public boolean vazia() {
		return tamanho() == 0;
	}

	public boolean cheia() {
		return tamanho() == arrayDeNos.length;
	}

	/**
	 * Realiza a insercao no final da lista baseada em array, ou seja, na
	 * posicao mais a esquerda do array disponivel.
	 */
	public boolean inserir(int chave, Object info) {
		if (cheia()) {
			return false;
		} else {
			arrayDeNos[tam++] = new No(chave, info);
			return true;
		}
	}

	/**
	 * Procura da esquerda para a direita no array ate encontra um no com a
	 * chave igual a passada. Caso encontre, move todos os nos a direita dele
	 * uma posicao a esquerda para aproveitar o espaco vago.
	 * 
	 * @return true caso consiga efetuar a remocao e false caso contrario.
	 */
	public boolean remover(int chave) {
		for (int i = 0; i < this.tamanho(); i++) {
			if (arrayDeNos[i].getChave() == chave) {
				for (int j = i + 1; j < this.tamanho(); j++) {
					arrayDeNos[j - 1] = arrayDeNos[j];
				}

				arrayDeNos[--tam] = null;
				return true;
			}
		}
		return false;
	}

	/**
	 * Libera as referencias para cada no, liberando-os para a coleta de lixo. A
	 * lista pode ser utilizada normalmente como uma lista recem criada apos ter
	 * sido apagada.
	 */
	public void apagar() {
		for (int i = 0; i < this.tamanho(); i++) {
			arrayDeNos[i] = null;
		}
		this.tam = 0;
	}

	/**
	 * Procura o objeto associado a chave passada da esquerda para a direita no
	 * array.
	 */
	public Object obter(int chave) {
		for (int i = 0; i < tamanho(); i++) {
			if (arrayDeNos[i].getChave() == chave) {
				return arrayDeNos[i].getInfo();
			}
		}
		return null;
	}

	/**
	 * Procura da esquerda para a direita no array um no com a chave passada e
	 * altera o objeto armazenado pelo que foi passado como parametro.
	 */
	public boolean alterar(int chave, Object dado) {
		for (int i = 0; i < tamanho(); i++) {
			if (arrayDeNos[i].getChave() == chave) {
				arrayDeNos[i].setInfo(dado);
				return true;
			}
		}
		return false;
	}
	
	
	public String toString() {
		StringBuffer sb = new StringBuffer("Tamanho = " + tamanho() + ", ");
		sb.append("Nos = [");
		for (int i = 0; i < tamanho(); i++) {
			sb.append(arrayDeNos[i]);
		}
		sb.append(']');
		return sb.toString();
	}
	

	public Iterador iterador() {
		return new ListaSeqIterador(this);		
	}

	/**
	 * Itera no array da ListaSeq passada da posicao 0 ate (tamanho - 1).
	 */
	private class ListaSeqIterador implements Iterador {
		
		private int pos = 0;
		private ListaSeq lista;
		
		public ListaSeqIterador(ListaSeq lista) {
			this.lista = lista;			
		}
		
		public Object getProximo() {
			if (temProximo()) {
				return lista.arrayDeNos[pos++].getInfo();
			} else {
				throw new IllegalStateException("Tentando acessar posicao inexistente: " + (pos+1));
			}
		}
		
		public boolean temProximo() {
			return pos < lista.tamanho();
		}
	}
}