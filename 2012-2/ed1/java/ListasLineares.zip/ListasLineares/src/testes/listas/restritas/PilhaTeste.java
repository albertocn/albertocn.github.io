package testes.listas.restritas;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import listas.restritas.Pilha;

import org.junit.Before;
import org.junit.Test;

public abstract class PilhaTeste {

	protected final int TOTAL_ELEMENTOS = 100; 

	protected Pilha pilha;

	public PilhaTeste() {
		super();
	}

	@Before
	public void setUp() throws Exception {
		 pilha = criarPilha();
	}

	@Test
	public final void testGeral() {
		assertTrue(pilha.vazia());
		assertEquals(0, pilha.tamanho());
		
		incluirIntegers(pilha, TOTAL_ELEMENTOS);
		assertEquals(TOTAL_ELEMENTOS, pilha.topo());
		for (int i = TOTAL_ELEMENTOS; i >= 1; i--) {
			assertEquals(i, pilha.desempilhar());
			assertEquals(i - 1, pilha.tamanho());
		}
		
		assertTrue(pilha.vazia());
		assertEquals(0, pilha.tamanho());
	
	}

	@Test
	public final void testVazia() {
		assertTrue(pilha.vazia());
	}

	@Test
	public final void testCheia() {
		assertFalse(pilha.cheia());
	}

	@Test
	public final void testTamanho() {
		assertEquals(0, pilha.tamanho());
		incluirIntegers(pilha, TOTAL_ELEMENTOS);
	}

	@Test
	public final void testEmpilhar() {
		assertTrue("Deveria conseguir empilhar", pilha.empilhar("Objeto"));
	}

	@Test
	public final void testDesempilhar() {
		assertTrue("Deveria conseguir empilhar", pilha.empilhar("Objeto"));
		assertEquals("Objeto", pilha.desempilhar());
	}

	@Test
	public final void testApagar() {
		incluirIntegers(pilha, TOTAL_ELEMENTOS);
		assertEquals(TOTAL_ELEMENTOS, pilha.topo());
		
		pilha.apagar();
		assertTrue(pilha.vazia());
	}

	@Test
	public final void testTopo() {
		assertTrue("Deveria conseguir empilhar", pilha.empilhar("Objeto"));
		assertEquals("Objeto", pilha.topo());
		assertEquals("Objeto", pilha.topo());
		assertEquals("Objeto", pilha.topo());
	}

	/** 
	 * Factory Method para retornar uma instancia da Pilha encadeada ou baseada em array 
	 */
	protected abstract Pilha criarPilha();

	protected void incluirIntegers(Pilha pilha, int n) {
		for (int i = 1; i <= n; i++) {
			pilha.empilhar(i);
			assertEquals(i, pilha.tamanho());
		}
	}

}