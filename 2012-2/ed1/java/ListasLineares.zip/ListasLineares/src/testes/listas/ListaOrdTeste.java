package testes.listas;


import listas.Iterador;
import listas.Lista;
import listas.ListaOrd;

import org.junit.Test;

public class ListaOrdTeste extends ListaGenericTest {
	
	@Test
	public void testInserirRemoverIterar() {
		Lista l = criarLista();

		assertTrue(l.inserir(5, "E"));
		assertTrue(l.inserir(4, "D"));
		assertTrue(l.inserir(3, "C"));
		assertTrue(l.inserir(2, "B"));
		assertTrue(l.inserir(1, "A"));
		assertTrue(l.inserir(6, "F"));		
		assertEquals(6, l.tamanho());
		
		assertTrue(l.remover(6));
		assertEquals(5, l.tamanho());
		
		String[] esperados = getOrdemObjetosIteracao();
		int pos = 0;
		Iterador it = l.iterador();
		while (it.temProximo()) {
			assertEquals(esperados[pos++], it.getProximo().toString());			
		}
	}

	@Test
	public void testCheia() {
		assertFalse(lista.cheia());
	}
	
	protected String[] getOrdemObjetosIteracao() {		
		final String[] objs = {"A", "B", "C", "D", "E"};
		return objs;
	}
	
	protected String getToStringEsperado() {
		return "Tamanho = 5, Nos = [(1:A)(2:B)(3:C)(4:D)(5:E)]";
	}
	
	protected Lista criarLista() {
		return new ListaOrd();
	}
}