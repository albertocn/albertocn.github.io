package testes.listas;

import junit.framework.TestCase;


import listas.Iterador;
import listas.Lista;

import org.junit.Before;
import org.junit.Test;

public abstract class ListaGenericTest extends TestCase {

	protected Lista lista;

	@Before
	public void setUp() throws Exception {
		lista = criarLista();
		preencher(lista);
	}

	@Test
	public void testInserir() {
		Lista l = criarLista();
	
		// Testa inserir e tamanho
		assertEquals(0, l.tamanho());
		preencher(l);
		assertEquals(5, l.tamanho());
	}

	@Test
	public void testRemover() {
		assertTrue(lista.remover(2));
		assertEquals(4, lista.tamanho());
		
		assertTrue(lista.remover(1));
		assertEquals(3, lista.tamanho());
		
		assertTrue(lista.remover(5));
		assertEquals(2, lista.tamanho());

		assertTrue(lista.remover(3));
		assertEquals(1, lista.tamanho());

		// Nao deveria mais conseguir remover
		assertFalse(lista.remover(2));
		assertEquals(1, lista.tamanho());

		// Remocao do ultimo
		assertTrue(lista.remover(4));
		assertEquals(0, lista.tamanho());

		assertTrue(lista.vazia());
	}

	@Test
	public void testObter() {
		assertEquals("A", lista.obter(1));
		assertEquals("E", lista.obter(5));
		assertNull(lista.obter(0));
	}

	@Test
	public void testAlterar() {
		assertTrue(lista.alterar(1, "a"));
		assertTrue(lista.alterar(5, "e"));
		assertFalse(lista.alterar(6, "f"));
	}

	@Test
	public void testApagar() {
		lista.apagar();
		assertTrue(lista.vazia());
		assertEquals(0, lista.tamanho());
		assertFalse(lista.cheia());
	}


	@Test
	public void testIterador() {
		Iterador it = lista.iterador();
		
		String[] objs = getOrdemObjetosIteracao();
		int pos = 0;
		
		while (it.temProximo()) {
			assertEquals(objs[pos++], it.getProximo());
		}
		
		assertFalse(it.temProximo());
	}
	
	@Test
	public void testToString() {
		assertEquals(getToStringEsperado(), lista.toString());
	}
	
	protected String getToStringEsperado() {
		return "Tamanho = 5, Nos = [(1:A)(2:B)(3:C)(4:D)(5:E)]";
	}

	protected String[] getOrdemObjetosIteracao() {		
		final String[] objs = {"A", "B", "C", "D", "E"};
		return objs;
	}
	
	/**
	 * Factory method que permite mudar o tipo de lista criado, fazendo com 
	 * que esta classe de teste possa ser usada para testar varias listas
	 */
	protected abstract Lista criarLista();
	
	private void preencher(Lista lista) {
		assertTrue(lista.inserir(1, "A"));
		assertTrue(lista.inserir(2, "B"));
		assertTrue(lista.inserir(3, "C"));
		assertTrue(lista.inserir(4, "D"));
		assertTrue(lista.inserir(5, "E"));
	}
}