package testes.listas;

import listas.Lista;
import listas.ListaDEnc;

public class TListaDEnc {
	public static void main(String[] args){
		Lista Lista = new ListaDEnc();
		
		if(Lista.inserir(1, "Jeremias")){
			System.out.println("Inseriu o item de chave 1");
		}
		
		if(Lista.inserir(2, "Altair")){
			System.out.println("Inseriu o item de chave 2");
		}
		
		if(Lista.inserir(3, "H�lio")){
			System.out.println("Inseriu o item de chave 3");
		}
		
		System.out.println();
		System.out.println(Lista.toString());
		System.out.println();
		
		if(Lista.alterar(1,"Jo�o")){
			System.out.println("Alterou o item de chave 1");
		}
		
		if(Lista.alterar(3,"Guto")){
			System.out.println("Alterou o item de chave 3");
		}
		
		System.out.println();
		System.out.println(Lista.toString());
		System.out.println();
		
		if(Lista.remover(2)){
			System.out.println("Removeu o item de chave 2");
		}
		
		System.out.println();
		System.out.println(Lista.toString());
		System.out.println();
	}
}
