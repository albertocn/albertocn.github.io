package testes.listas.restritas;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({FilaArrayTeste.class, FilaEncTeste.class, PilhaArrayTeste.class, PilhaEncTeste.class})
public class AllTests {

}
