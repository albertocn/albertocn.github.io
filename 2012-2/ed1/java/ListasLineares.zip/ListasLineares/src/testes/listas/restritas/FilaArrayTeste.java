package testes.listas.restritas;

import listas.restritas.Fila;
import listas.restritas.FilaArray;

public class FilaArrayTeste extends FilaTeste {

	@Override
	protected Fila criarFila() {
		return new FilaArray(TOTAL_ELEMENTOS);
	}
}