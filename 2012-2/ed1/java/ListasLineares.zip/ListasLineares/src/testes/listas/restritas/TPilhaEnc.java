package testes.listas.restritas;

import listas.restritas.Pilha;
import listas.restritas.PilhaEnc;

public class TPilhaEnc {
	public static void main(String[] args){
		Pilha pilha = new PilhaEnc();
		
		if(pilha.empilhar(")")){
			System.out.println("Empilhou )");
		}
		
		if(pilha.empilhar("50")){
			System.out.println("Empilhou 50");
		}
		
		if(pilha.empilhar("*")){
			System.out.println("Empilhou *");
		}
		
		if(pilha.empilhar("10")){
			System.out.println("Empilhou 10");
		}
		
		if(pilha.empilhar("(")){
			System.out.println("Empilhou (");
		}
		
		if(pilha.empilhar("+")){
			System.out.println("Empilhou +");
		}
		
		if(pilha.empilhar("5")){
			System.out.println("Empilhou 5");
		}
				
		while(!pilha.vazia()){
			System.out.print(pilha.desempilhar() );
		}
	}
}
