package testes.listas.restritas;

import listas.restritas.Fila;
import listas.restritas.FilaEnc;

public class FilaEncTeste extends FilaTeste {

	@Override
	protected Fila criarFila() {
		return new FilaEnc();
	}
}