package testes.listas;

import listas.Lista;
import listas.ListaDEnc;

import org.junit.Test;

public class ListaDEncTeste extends ListaGenericTest {

	@Test
	public void testCheia() {
		assertFalse(lista.cheia());
	}
	
	protected String[] getOrdemObjetosIteracao() {		
		final String[] objs = {"E", "D", "C", "B", "A"};
		return objs;
	}
	
	protected String getToStringEsperado() {
		return "Tamanho = 5, Nos = [(5:E)(4:D)(3:C)(2:B)(1:A)]";
	}
	
	protected Lista criarLista() {
		return new ListaDEnc();
	}
}