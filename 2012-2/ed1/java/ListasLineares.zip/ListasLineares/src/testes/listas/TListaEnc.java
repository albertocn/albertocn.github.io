package testes.listas;

import listas.Lista;
import listas.ListaEnc;

public class TListaEnc {

	public static void main(String[] args) {
		Lista lista = new ListaEnc();
		
		if(lista.inserir(1,"A") ){
			System.out.println("Inseriu 1");
		}
		
		System.out.println("Obter Dado de Chave 1: " + lista.obter(1));
		System.out.println("Tamanho: " + lista.tamanho());
		
		if (lista.inserir(2,"B")){
			System.out.println("Inseriu 2");
		}
		
		System.out.println("Obter Dado de Chave 2: " + lista.obter(1));
		System.out.println("Tamanho: " + lista.tamanho());
		
		if( lista.inserir(3,"C") ){
			System.out.println("Inseriu 3");
		}
		
		System.out.println("Obter Dado de Chave 3: " + lista.obter(1));
		System.out.println("Tamanho: " + lista.tamanho());
		
		if( lista.remover(3)){
			System.out.println("Removeu item de chave 3");
		}
		
		System.out.println("Tamanho: " + lista.tamanho());
		System.out.println(lista.toString());
	}

}
