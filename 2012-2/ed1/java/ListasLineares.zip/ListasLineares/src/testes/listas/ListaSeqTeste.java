package testes.listas;

import listas.Lista;
import listas.ListaSeq;

import org.junit.Test;


public class ListaSeqTeste extends ListaGenericTest {

	static final int CAPACIDADE_LISTA = 100;
	
	@Test
	public void testCheia() {
		Lista l = criarLista();
		
		for (int i = 1; i <= CAPACIDADE_LISTA; i++) {
			l.inserir(i, "Obj" + i);			
		}
		
		assertTrue(l.cheia());
		assertFalse(l.inserir(CAPACIDADE_LISTA+1, "Obj"));
	}
	
	protected Lista criarLista() {
		return new ListaSeq(CAPACIDADE_LISTA);
	}
}