package testes.listas.restritas;

import java.util.Scanner;

import listas.restritas.Fila;
import listas.restritas.FilaEnc;

public class TFilaEnc {
	public static boolean TestarParentesis(String frase){
		boolean Sucesso = false;
		Fila fila = new FilaEnc();
		
		for(int i = 0; i < frase.length(); i++){
			if(frase.charAt(i) == '('){
				fila.inserir(frase.charAt(i));
			}
			else{
				if(frase.charAt(i) == ')'){
					if(fila.vazia()){
						for(int j = 0; j <= i-1 ; j++){
							System.out.print(" ");
						}
						System.out.println("^");
						return Sucesso = false;
					}
					else{
						fila.retirar();
					}
				}
			}
		}
		
		if(fila.vazia()){
			Sucesso = true;
		}
		else{
			for(int k = 0; k < frase.indexOf('('); k++){
				System.out.print(" ");
			}
			System.out.println("^");
		}
		
		return Sucesso;
		
	}
	
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		System.out.println("Digite a frase com os par�ntesis:");
		String s1 = new String();
		
		s1 = input.nextLine();
		
		System.out.println(s1);
		
		if(TestarParentesis(s1)){
			System.out.println("Sem Erro!");
		}
		else{
			System.out.println("Erro na frase!");
		}
	}
}
