package testes.listas.restritas;

import listas.restritas.Fila;
import listas.restritas.FilaArray;
import listas.restritas.Pilha;
import listas.restritas.PilhaArray;
import java.util.Scanner;

/**
 * Programa para testar se uma string e um palindromo, usa uma fila e pilha com
 * array.
 */
public class Palindromo {
	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		String palavra = new String();

		System.out.println("Digite uma palavra para saber se eh um palindromo");
		palavra = input.nextLine();

		Fila fila = new FilaArray(palavra.length());
		Pilha pilha = new PilhaArray(palavra.length());

		for (int i = 0; i < palavra.length(); i++) {
			if (palavra.charAt(i) != ' ') {
				fila.inserir(palavra.charAt(i));
			    pilha.empilhar(palavra.charAt(i));
			}
		}

		System.out.println("Palavra enfileirada/empilhada");
		while (!pilha.vazia()) {			
			if (fila.retirar() != pilha.desempilhar()) {
				System.out.println("Nao eh palindromo");
				break;
			}
		}

		if (fila.tamanho() == 0) {
			System.out.println("Eh um palindromo");
		}

	}

}
