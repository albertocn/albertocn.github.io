package testes.listas.restritas;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import listas.restritas.Fila;

import org.junit.Before;
import org.junit.Test;

public abstract class FilaTeste {

	protected final int TOTAL_ELEMENTOS = 100; 

	protected Fila fila;

	public FilaTeste() {
		super();
	}

	@Before
	public void setUp() throws Exception {
		 fila = criarFila();
	}

	@Test
	public final void testGeral() {
		assertTrue(fila.vazia());
		assertEquals(0, fila.tamanho());
		
		incluirIntegers(fila, TOTAL_ELEMENTOS);
		assertEquals(1, fila.frente());
		for (int i = 1; i <= TOTAL_ELEMENTOS; i++) {
			assertEquals(i, fila.retirar());
			assertEquals(TOTAL_ELEMENTOS - i, fila.tamanho());
		}
		
		assertTrue(fila.vazia());
		assertEquals(0, fila.tamanho());
		
		assertTrue("Deveria conseguir inserir na fila", fila.inserir("A"));
		assertTrue("Deveria conseguir inserir na fila", fila.inserir("B"));
		assertEquals("A", fila.retirar());
		
		assertTrue("Deveria conseguir inserir na fila", fila.inserir("C"));		
		assertEquals("B", fila.retirar());
		assertEquals("C", fila.retirar());
		
		assertTrue("Deveria conseguir inserir na fila", fila.inserir("D"));
		assertEquals("D", fila.retirar());
		assertTrue("Deveria conseguir inserir na fila", fila.inserir("E"));
		assertEquals("E", fila.retirar());		
	}

	@Test
	public final void testVazia() {
		assertTrue(fila.vazia());
	}

	@Test
	public final void testCheia() {
		assertFalse(fila.cheia());
	}

	@Test
	public final void testTamanho() {
		assertEquals(0, fila.tamanho());
		incluirIntegers(fila, TOTAL_ELEMENTOS);
	}

	@Test
	public final void testInserir() {
		assertTrue("Deveria conseguir inserir na fila", fila.inserir("Objeto"));
	}

	@Test
	public final void testRetirar() {
		assertTrue("Deveria conseguir retirar da fila", fila.inserir("Objeto"));
		assertEquals("Objeto", fila.retirar());
	}

	@Test
	public final void testApagar() {
		incluirIntegers(fila, TOTAL_ELEMENTOS);
		assertEquals(1, fila.frente());
		
		fila.apagar();
		assertTrue(fila.vazia());
	}

	@Test
	public final void testFrente() {
		assertTrue("Deveria conseguir inserir na fila", fila.inserir("Objeto"));
		assertEquals("Objeto", fila.frente());
		assertEquals("Objeto", fila.frente());
		assertEquals("Objeto", fila.frente());
	}

	/** 
	 * Factory Method para retornar uma instancia da Fila encadeada ou baseada em array 
	 */
	protected abstract Fila criarFila();

	protected void incluirIntegers(Fila fila, int n) {
		for (int i = 1; i <= n; i++) {
			fila.inserir(i);
			assertEquals(i, fila.tamanho());
		}
	}

}