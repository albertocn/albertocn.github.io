package testes.listas;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ListaCircTeste.class, ListaDEncTeste.class,
		ListaEncTeste.class, ListaOrdTeste.class, ListaSeqTeste.class })
public class AllTests {

}
