package testes.listas.restritas;

import listas.restritas.Pilha;
import listas.restritas.PilhaEnc;

public class PilhaEncTeste extends PilhaTeste {

	@Override
	protected Pilha criarPilha() {
		return new PilhaEnc();
	}
}
