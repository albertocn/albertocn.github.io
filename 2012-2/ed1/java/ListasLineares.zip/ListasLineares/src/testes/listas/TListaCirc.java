package testes.listas;

import listas.Lista;
import listas.ListaCirc;

public class TListaCirc {
	
	public static void main(String[] args) {
		Lista lista = new ListaCirc();
		
		if(lista.inserir(1, "1A")){
			System.out.println("Inseriu o item de chave 1");
		}
		
		if(lista.inserir(2, "2B")){
			System.out.println("Inseriu o item de chave 2");
		}
		
		if(lista.inserir(3, "3C")){
			System.out.println("Inseriu o item de chave 3");
		}
		
		System.out.println();
		System.out.println(lista.toString());
		System.out.println();
		
		if(lista.alterar(1,"1Z")){
			System.out.println("Alterou o item de chave 1");
		}
		
		if(lista.alterar(3,"3H")){
			System.out.println("Alterou o item de chave 3");
		}
		
		System.out.println();
		System.out.println(lista.toString());
		System.out.println();
		
		if(lista.remover(2)){
			System.out.println("Removeu o item de chave 2");
		}
		
		System.out.println();		
		System.out.println(lista.toString());
		System.out.println();
		
		boolean Sucesso = true;
		StringBuilder str = new StringBuilder("H");
		int i = 4;		
		
		// Inserindo na Lista, ate que ela encha completamente, a cada 10000 itens, 
		// mostra em qual chave esta.
		while (Sucesso){
			try {
				Sucesso = lista.inserir(i, str);
				if(Sucesso){
					if (i % 10000 == 0)
						System.out.println("Inseriu o item de chave " + i);
				}
				i++;
			} catch (OutOfMemoryError e) {
				System.out.println("Cheia");
				Sucesso = false;
			}
		}
	}
}
