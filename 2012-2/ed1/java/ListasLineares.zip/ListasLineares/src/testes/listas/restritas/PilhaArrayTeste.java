package testes.listas.restritas;

import listas.restritas.Pilha;
import listas.restritas.PilhaArray;

public class PilhaArrayTeste extends PilhaTeste {

	@Override
	protected Pilha criarPilha() {
		return new PilhaArray(TOTAL_ELEMENTOS);
	}
}