package multilistas;

public class DemoMatrizEsparsa {
    
    public static void main(String[] args) {
    	
        MatrizEsparsa Matriz = new MatrizEsparsa(5, 5);

        Matriz.mudar(1, 1, "Local 1 1");
        Matriz.mudar(2, 2, "Local 2 2");
        
        System.out.println("Primeira Obtencao");
        System.out.println(Matriz.obter(2, 2));        
        
        if (Matriz.obter(2,2) != null){
            System.out.println("Ok: " + Matriz.obter(2,2));
        }
        else{
            System.out.println("Erro: Nao conseguiu obter (2,2)");
        }
        
        Matriz.limpar(2,2);
        if (Matriz.obter(2,2) != null){
            System.out.println("Erro: conseguiu obter (2,2): " + Matriz.obter(2,2));
        }
        else{
            System.out.println("Ok: Nao conseguiu obter (2,2)");
        }
        
        Matriz.apagar();
    }
}