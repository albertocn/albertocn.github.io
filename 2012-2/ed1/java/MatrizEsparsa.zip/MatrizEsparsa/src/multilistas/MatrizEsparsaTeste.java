package multilistas;

import junit.framework.TestCase;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MatrizEsparsaTeste extends TestCase {

	private MatrizEsparsa matriz;
	
	private static final int LINHAS = 100, COLUNAS = 300;	
	
	@Before
	public void setUp() {
		matriz = new MatrizEsparsa(LINHAS, COLUNAS);
	}
	
	@After
	public void tearDown() {
		matriz.apagar();
	}

	@Test
	public void testGeral() {
		for (int lin = 1; lin <= LINHAS; lin++) {
			for (int col = 1; col <= COLUNAS; col++) {
				matriz.mudar(lin, col, "Valor (" + lin + ", " + col + ")");
			}
		}
		
		for (int col = 1; col <= COLUNAS; col++) {
			for (int lin = 1; lin <= LINHAS; lin++) {				
				assertEquals("Valor (" + lin + ", " + col + ")", matriz.obter(lin, col));
				matriz.limpar(lin,col);
				assertNull(matriz.obter(lin, col));
				matriz.mudar(lin, col, "Novo Valor (" + lin + ", " + col + ")");
				assertEquals("Novo Valor (" + lin + ", " + col + ")", matriz.obter(lin, col));
			}
		}
		
		// Limpando algunas linhas da matriz, da ultima coluna para a primeira				
		limparLinha(LINHAS / 2);
		limparLinha(1);
		limparLinha(LINHAS - 1);
		limparLinha(LINHAS);
	}

	protected void limparLinha(int linhaALimpar) {
		for (int col = COLUNAS; col >= 1; col--) {
			matriz.limpar(linhaALimpar, col);
			assertNull(matriz.obter(linhaALimpar, col));
		}
	}
	
	@Test
	public void testApagar() {
		MatrizEsparsa m = new MatrizEsparsa(4,5);
		m.mudar(1, 1, "cel 1,1");
		m.mudar(1, 2, "cel 1,2");
		m.mudar(1, 3, "cel 1,3");
		m.mudar(1, 4, "cel 1,4");
		m.mudar(1, 5, "cel 1,5");
		m.mudar(2, 2, "cel 2,2");
		m.mudar(2, 3, "cel 2,3");
		m.mudar(3, 1, "cel 3,1");
		m.apagar();
	}
}
