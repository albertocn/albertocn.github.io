package multilistas;

/**
 * Matriz Esparsa com linhas e colunas que podem espacos vazios
 * visando aproveitar melhor a memoria.
 */
public class MatrizEsparsa {

	/** Referencia para o No (0,0) */
    private No Matriz;
    
    /** 
     * Armazena um valor contido na matriz. Contem adicionalmente o numero da linha, coluna
     * e referencias para a proxima coluna e proxima linha.
     */
    private class No {
        private int linha;
        private int coluna;
        private No proxLinha;
        private No proxColuna;
        private Object valor;

        /**
         * Cria um No da Matriz.
         * 
         * @param lin Linha a quer pertence o No
         * @param col Coluna a quer pertence o No
         * @param pl Referencia para o proximo No da mesma Linha
         * @param pc Referencia para o proximo No da mesma Coluna
         * @param inf Objeto a ser armazenado no No
         */
        private No(int lin, int col,No pl,No pc, Object inf){
            this.linha = lin;
            this.coluna = col;
            this.proxLinha = pl;
            this.proxColuna = pc;
            this.valor = inf;
        }
        
        public int getColuna() {
            return coluna;
        }


        public int getLinha() {
            return linha;
        }


        public No getProxColuna() {
            return proxColuna;
        }

        public void setProxColuna(No ProxColuna) {
            this.proxColuna = ProxColuna;
        }

        public No getProxLinha() {
            return proxLinha;
        }

        public void setProxLinha(No ProxLinha) {
            this.proxLinha = ProxLinha;
        }

        public Object getValor() {
            return valor;
        }

        public void setValor(Object Valor) {
            this.valor = Valor;
        }
        
        public void desconectar() {
        	this.setProxLinha(null);
        	this.setProxColuna(null);
        }
    }
    
    /**
     * Cria uma Matriz, criando o primeiro No, com linha 0 e Coluna 0, e criando o 
     * a linha 0 com col Colunas e a coluna 0 com lin Linhas.
     * 
     * @param numLinhas Numero de linhas que a matriz deve comportar.
     * @param numColunas Numero de colunas que a matriz deve comportar.
     */
    public MatrizEsparsa(int numLinhas, int numColunas){
    	
        this.Matriz = new No(0,0,null,null,null);
        this.Matriz.setProxLinha(this.Matriz);
        this.Matriz.setProxColuna(this.Matriz);

        // Inicializa a linha 0
        No PAnterior = Matriz;
        
        for(int i = 1; i <= numColunas; i++){
            No P = new No(0,i,null,Matriz,null);
            PAnterior.setProxColuna(P);
            P.setProxLinha(P);            
            PAnterior = P;
        }
        
        // Inicializa a coluna 0
        PAnterior = Matriz;
        
        for(int i = 1; i <= numLinhas; i++){
            No P = new No(i,0,Matriz,null,null);
            PAnterior.setProxLinha(P);
            P.setProxColuna(P);
            PAnterior = P;
        }
    }
    
    /**
     * Retorna o No que esta acima da posicao especificada por lin e col 
     */
    protected No obterAcima(int lin, int col){
        No PC = Matriz;
      
        // Primeiramente avancando ate a coluna especificada 
        while(PC.getColuna() < col){
            PC = PC.getProxColuna();
        }
        
        // PAnterior recebe PC, que esta na coluna desejada,
        // caso ja esteja na linha, nem entra no proximo laco
        No PAnterior = PC;
        No PL = PC.getProxLinha();
        
        // Movimenta ate a linha especificada e consequenetemente achando o No
        while((PL.getLinha() < lin) && (PL.getLinha() != 0)) {
            PAnterior = PL;
            PL = PL.getProxLinha();
        }
        
        return PAnterior;
    }
    
    /** 
     * Retorna o No que esta a esquerda da posicao especificada por lin e col
     */
    protected No obterEsquerda(int lin, int col){
        No PL = Matriz;
        
        // Primeiramente avancando ate a linha especificada 
        while(PL.getLinha() < lin){
            PL = PL.getProxLinha();
        }

        // PAnterior recebe PL, que esta na linha desejada,
        // caso ja esteja na coluna, nem entra no proximo laco
        No PAnterior = PL;
        No PC = PL.getProxColuna();
        
        // Movimenta ate a coluna especificada e consequentemente achando o No
        while(PC.getColuna() < col && PC.getColuna() != 0){
            PAnterior = PC;
            PC = PC.getProxColuna();
        }
        
        return PAnterior;
    }

    /**
     * Cria um No e insere abaixo de PAcima e a direita de PEsquerda. O numero da linha do 
     * No inserido e igual a PEsquerda.getLinha() e o numero da coluna igual a PAcima.getColuna()
     */
    protected void inserirDepois(No PAcima, No PEsquerda, Object Dado){
        No P = new No(PEsquerda.getLinha(), PAcima.getColuna(),
        		      PAcima.getProxLinha(), PEsquerda.getProxColuna(),
        		      Dado);
        PAcima.setProxLinha(P);
        PEsquerda.setProxColuna(P);
    }
    
    /**
     * Retorna o No contido na posicao (lin e col) especificada.
     * Caso nao exista, retorna null.
     */
    protected No obterNo(int lin, int col){
        No P = obterAcima(lin, col);
        return P.getProxLinha().getLinha() == lin ?  P.getProxLinha() : null;
    }
    
    
    /** 
     * Apaga o No que esta a direita de PEsquerda e abaixo de PAcima, 
     * fazendo com que PEsquerda.getProxColuna e PAcima.getProxLinha 
     * referenciem os valores contidos no No a ser apagado.
     */
    protected void apagarDepois(No PAcima, No PEsquerda){
    	PAcima.setProxLinha(PAcima.getProxLinha().getProxLinha());
        PEsquerda.setProxColuna(PEsquerda.getProxColuna().getProxColuna());
    }
    
    /** 
     * Obtem o Valor contido na posicao (lin e col) especificada da Matriz.
     * Se o No existir, retorna true e Valor recebe o valor contido no No.
     * Caso o No nao exista, retorna false e Valor fica inalterado.
     */
    public Object obter(int lin, int col){
    	No noObtido = obterNo(lin, col);
        return noObtido != null ? noObtido.getValor() : null;
    }
    
    /**
     * Faz com que exista um No com o valor passado na posicao (lin e col)
     * especificada.
     */
    public void mudar(int lin, int col, Object dado){
        No PAcima = obterAcima(lin,col);
        if(PAcima.getProxLinha().getLinha() == lin){
            PAcima.getProxLinha().setValor(dado);
        }
        else{
            inserirDepois(PAcima, obterEsquerda(lin,col), dado);
        }
    }
    
    /**
     * Apaga da Matriz o No existente na posicao especificada por lin e col.
     */
    public void limpar(int lin, int col){
        No PAcima = obterAcima(lin, col);
        if(PAcima.getProxLinha().getLinha() == lin){
            apagarDepois(PAcima, obterEsquerda(lin, col));
        }
    }

   
    /**
     * Apaga toda a Matriz da memoria, ou seja, desconecta
     * todos os Nos linha por linha.
     */
    public void apagar() {
    	
        // Anda linha a linha na matriz
        No linCol0 = this.Matriz;
        do {
            No proxLinhaCol0 = linCol0.getProxLinha();
            apagarLinha(linCol0);
            linCol0 = proxLinhaCol0;
        } while (linCol0.getLinha() != 0);        
       
        // Libera a referencia para o elemento inicial (0,0)
        this.Matriz = null;
    }

	/**
     * Apaga todos os Nos da mesma Linha a partir da coluna 0, percorrendo
     * coluna a coluna da linha passada, partindo do No referenciado pelo
	 * parametro linha e desconecta cada um deles.
	 */
	protected void apagarLinha(No linhaCol0) {
		No coluna = linhaCol0;
		do {
		    No proxColuna = coluna.getProxColuna();
		    coluna.desconectar();
		    coluna = proxColuna;
		} while (coluna.getColuna() != 0);
		
	}

	
//    /**
//     * Apaga toda a matriz da memoria.
//     */
//    public void apagar() {
//    	
//    	   // Apaga, linha por linha os elementos contidos na matriz esparsa
//    	   No PL = Matriz.getProxLinha();
//    	   No PC = null;
//    	   while (PL.getLinha() != 0) {
//    	      PC = PL.getProxColuna();
//
//    	      while (PC.getColuna() != 0) {
//    	         No PAnterior = PC;
//    	         PC = PC.getProxColuna();
//    	         PAnterior.desconectar();
//    	      }
//
//    	      PL = PL.getProxLinha();
//    	   }
//
//    	   // Apagando a linha 0
//    	   PC = Matriz.getProxColuna();
//    	   while (PC.getColuna() != 0) {
//    	      No PAnterior = PC;
//    	      PC = PC.getProxColuna();
// 	          PAnterior.desconectar();
//    	   }
//    	   
//    	   // Apagando a coluna 0
//    	   PL = Matriz.getProxLinha();
//    	   while (PL.getLinha() != 0) {
//    	      No PAnterior = PL;
//    	      PL = PL.getProxLinha();
// 	          PAnterior.desconectar();
//    	   }
//
//    	   // Apaga o elemento [0,0]
//    	   Matriz = null;
//    }
}
