package arvores;

public interface ArvoreBinariaBusca extends ArvoreBinaria {

	/**
	 * Obtem um dado de acordo com a chave passada. Caso nao encontre, retorna null.
	 */
	Object obter(Comparable chave);
	
	/**
	 * Procura um No que contenha uma chave igual a passada. Caso
	 * encontre, copia dado sobre o dado do No e retorna true. Se
	 * nao encontrar, retorna false.
	 */
	boolean alterar(Comparable chave, Object dado);

	/**
	 * Tenta inserir um No na Arvore e se conseguir, retorna true.
	 */
	boolean inserir(Comparable chave, Object dado);
	
	/**
	 * Retira o No contendo chave da arvore. Se esse No for retirado,
	 * retorna true. Caso contrario, retorna false.
	 */
	boolean remover(Comparable chave);
}
