package arvores;

/**
 * Lancada quando tenta-se inserir uma chave duplicada na arvore
 */
public class ChaveDuplicadaException extends Exception {

}
