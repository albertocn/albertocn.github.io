package arvores;

/**
 * Arvore Binaria.
 */
public interface ArvoreBinaria {
    
	No getRaiz();
	void setRaiz(No no);
    boolean vazia();
    void deltree();
}
