package arvores;

public class ArvBinBuscaRecTeste extends ArvBinBuscaTeste {

	/**
	 * Cria uma instancia da classe ArvBinBuscaRec.
	 */
	@Override
	protected ArvoreBinariaBusca criarArvoreBinariaBusca() {
		return new ArvBinBuscaRec();
	}
}


