package arvores;

public class ArvBinBusca extends ArvBin implements ArvoreBinariaBusca {

	@Override
	public Object obter(Comparable chave) {
		No no = encontrarNoOuPai(chave);		
		if (no == null) {
			return null;
		} else if (no.getChave().equals(chave)) {
			return no.getDado();
		} else {
			return null;
		}
	}
	
	@Override
	public boolean alterar(Comparable chave, Object dado) {
		No no = encontrarNoOuPai(chave);		
		if (no != null) {
			if (no.getChave().equals(chave)) { 
				no.setDado(dado);
				return true;
			}
		}
		return false;
	}

	@Override
	public boolean inserir(Comparable chave, Object dado) {

		// Se Arvore estiver vazia entao so e necessario criar o No, mas se nao
	    // estiver, entao sera�feita a procura (pela chave) na arvore. Se for achada
	    // alguma ocorrencia da chave na arvore(chave duplicada), entao retornara
	    // false. Caso contrario dado sera adicionado em uma das subarvores de Arvore
	    if (this.vazia()) {
	    	this.setRaiz(criarNo(chave, dado));
	    } else {
	    	No P = encontrarNoOuPai(chave);
	    	// Checa se existe chave duplicada
	    	if (chave.equals(P.getChave())) {
	    		return false;
	    	} else if (chave.compareTo(P.getChave()) == -1) {
	    		P.adicionarFilhoEsquerda(chave, dado);
	    	}   else {
	    		P.adicionarFilhoDireita(chave, dado);
	    	}
	    }
	    return true;
    }	
	
	@Override
	public boolean remover(Comparable chave) {
		No no = encontrarNoOuPai(chave);
		
		if ((no != null) && no.getChave().equals(chave)) { // Encontrou e vai remover
		
           if (!no.temNoEsquerdo()) { // Arvore nao tem subarvores ou tem somente a direita

               // Se existir, corrige a referencia para o filho direito do No a ser removido, 
        	   // fazendo-o referenciar o pai do No a ser removido
               if (no.temNoDireito()) {
            	   no.getDireito().setPai(no.getPai());            	   
               }
            	
               corrigirRefDoPaiParaFilho(no, no.getDireito());               
               
           } else if (!no.temNoDireito()) { // Arvote tem somente o filho esquerdo

               // Corrige a referencia para o Pai do filho esquerdo do No a ser removido, 
        	   // fazendo-o referenciar o pai do No a ser removido
        	   no.getEsquerdo().setPai(no.getPai());
        	   
        	   corrigirRefDoPaiParaFilho(no, no.getEsquerdo());
        	   
           } else {
        	   
        	   // No a ser removido precisa ser substituido pelo sucessor imediato porque
        	   // tem filhos esquerdo e direito 
               substituir(no, no.getDireito());
           }
			
           return true;
		}
		
		return false;
	}

		
	/**
	 * Retorna uma referencia para o No com chave igual a procurada.
	 * Caso nao encontre, retorna uma referencia para o pai do No.
	 */
	private No encontrarNoOuPai(Comparable chave) {
		No PAnt = null;
		boolean Achou = false;
		No P = this.getRaiz();

		// Laco que fara o deslocamento de P ate que tenha chegado ao local onde
		// deveria estar o No ou tenha o encontrado
		while ((P != null) && !Achou) {			
			PAnt = P;
			if (chave.compareTo(P.getChave()) == 0) {
				Achou = true;
			} else if (chave.compareTo(P.getChave()) == -1) {					
				P = P.getEsquerdo();
			} else {
				P = P.getDireito();
			}
		}

		// Caso tenha achado, retorna P. Caso contrario retorna PAnt
		return Achou ? P : PAnt;
	}


	/**
	 * Se o No a ser removido tem pai, precisa-se atualizar a referencia do pai para
	 * o filho do filho (que pode ser seu filho esquerdo ou direito).
	 */
	private void corrigirRefDoPaiParaFilho(No noRemovido, No noSubsituto) {
	   if (noRemovido.temNoPai()) {
		   No pai = noRemovido.getPai();
		   if (pai.getEsquerdo() == noRemovido) {
			   pai.setEsquerdo(noSubsituto);
		   } else {
		       pai.setDireito(noSubsituto);
		   }
	   } else { // O No sendo removido e a a raiz da arvore
		   this.setRaiz(noSubsituto);            	   
	   }
	}

	/**
	 * Determina o sucessor imediato do parametro no. Quando
	 * encontrar, copia para o parametro no os os dados contidos 
	 * no parametro sucessor e muda a referencia sucessor para o 
	 * seu No direito. No final, apaga o No onde se encontrava o Sucessor
	 */
	private void substituir(No no, No sucessor) {
		
		// Desce ate o no mais a esquerda da subarvore
		while (sucessor.temNoEsquerdo()) {
			sucessor = sucessor.getEsquerdo();
		}
	   
  	    // Substitui os dados do no removido pelos de seus sucessor 
		no.setChave(sucessor.getChave());
		no.setDado(sucessor.getDado());

		// Se existir, corrige a referencia para o pai contida no filho direito
		// de sucessor, fazendo-o apontar para o pai do sucessor }
		if (sucessor.temNoDireito()) {
		   sucessor.getDireito().setPai(sucessor.getPai());
		}
		        
		// Corrige a referencia do pai do sucessor imediato do no removido
		corrigirRefDoPaiParaFilho(sucessor, sucessor.getDireito());
		     
		sucessor.limparNo();		       
	}	
}
