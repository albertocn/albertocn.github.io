package arvores;

import java.util.LinkedList;
import java.util.List;

public class VisitorGuardaNos implements Visitor {
	
	private List<No> nos = new LinkedList<No>();
	 
	@Override
	public void visite(No no) {
		this.nos.add(no);
	}
	
	public Object[] getNosArray() {
		return this.nos.toArray();
	}
	
	public List<No> getNos() {
		return this.nos;
	}

	protected void conferirResultadoNavegacao(Object[] resultado) {
		int i = 0;
		for (No no : getNos()) {			
			ArvBinBuscaTeste.assertEquals(resultado[i++].toString(), no.getChave().toString());
		}
	}

}
