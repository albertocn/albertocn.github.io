package arvores.avl;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

public class NoAVLTeste extends TestCase {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testGeral() {

		NoAVL no = new NoAVL(1, "A");
		
		assertEquals(0, no.getAltura());

		no.adicionarFilhoDireita(2, "B");
		no.getDireito().adicionarFilhoDireita(5, "E");

		assertEquals(2, no.getAltura());

//	    A
//	      B  
//          E
		
		no.rotacaoParaEsquerda(); // A e Pivo
		
//		  B
//		A   E

		assertFalse(no.isRaiz());
		
		no = no.getPai();  // Sobe para B
		assertTrue(no.isRaiz());
		assertNotNull(no.getEsquerdo());
		assertEquals(2, no.getEsquerdo().getPai().getChave());
		assertNotNull(no.getDireito());
		assertEquals(2, no.getDireito().getPai().getChave());		
		
		
		assertEquals(1, no.getAltura());
		assertEquals(1, no.getEsquerdo().getChave());
		assertEquals(5, no.getDireito().getChave());		
		
		no.getDireito().adicionarFilhoEsquerda(3, "C");  // C a esquerda de E
		
//		    B
//		A       E
//            C
		    
		
		no.getDireito().getEsquerdo().adicionarFilhoDireita(4, "D"); // D a direita de C

//	    B
//	A       E
//        C
//         D		
		
		assertEquals(3, no.getAltura());
		
		// Testando a rotacao dupla separadamente
		
		// Rotacao a esquerda sobre filho esquerdo (C) do pivo (E)
		no.getDireito().getEsquerdo().rotacaoParaEsquerda();
		
//	    B
//	A       E
//        D
//       C 		
	
		assertEquals(2, no.getChave()); // No e B
		assertEquals(3, no.getAltura());
		
		// Rotacao a direita sobre o Pivo (E) 
		no.getDireito().rotacaoParaDireita();
		
//	    B
//	A       D
//        C   E
		
		assertEquals(2, no.getAltura());
		assertEquals(4, no.getDireito().getChave());  // D
		assertEquals(3, no.getDireito().getEsquerdo().getChave());  // C
		assertEquals(5, no.getDireito().getDireito().getChave());  // E
		
		no.getDireito().getDireito().adicionarFilhoDireita(6, "F"); // F a direita de E

		
//	    B
//	A       D
//        C   E		
//              F		
		
		no.rotacaoParaEsquerda();
		
//	     D
//	  B     E
//  A  C      F		
		
		no = no.getPai();  // Sobe para o D
		
		assertEquals(2, no.getAltura());
		assertEquals(4, no.getChave());
		assertEquals(2, no.getEsquerdo().getChave());
		assertEquals(1, no.getEsquerdo().getEsquerdo().getChave());
		assertEquals(3, no.getEsquerdo().getDireito().getChave());		

		no.getDireito().getDireito().adicionarFilhoDireita(8, "H"); // H a direita de F		

//	      D
//	  B      E
//  A   C      F
//              H	
		no.getDireito().getDireito().rotacaoParaEsquerda();  // Rotacao a esquerda sobre F
		

//	      D
//	  B       E
//  A   C      H
//            F		
		
		// Pivo E (balanco -2) e filho direito (balanco +1)
		assertEquals(-2, no.getDireito().balanco());
		assertEquals(1, no.getDireito().getDireito().balanco());
		
		// Rotacao dupla
		no.getDireito().rotacaoDuplaDireitaEsquerda(); 

//	      D
//	  B       F
//  A   C   E   H	
		
		assertEquals(2, no.getAltura());
		assertEquals(2, no.getEsquerdo().getChave());
		assertEquals(6, no.getDireito().getChave());
		
		assertEquals(4, no.getDireito().getPai().getChave()); // O pai de F eh D
		assertEquals(6, no.getDireito().getEsquerdo().getPai().getChave()); // O pai de E eh F		
		
		assertEquals(0, no.balanco());
		assertEquals(0, no.getEsquerdo().balanco());
		assertEquals(0, no.getDireito().balanco());		
		
		no.disposeArvore();
	}
}