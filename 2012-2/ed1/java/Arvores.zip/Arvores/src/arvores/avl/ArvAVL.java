package arvores.avl;

import arvores.ArvBinBuscaRec;
import arvores.ChaveDuplicadaException;
import arvores.ChaveNaoEncontradaException;
import arvores.No;

public class ArvAVL extends ArvBinBuscaRec {
	
	@Override
	public NoAVL getRaiz() {
		return (NoAVL) super.getRaiz();
	}
	
	@Override
	public boolean inserir(Comparable chave, Object dado) {
		try {
			NoAVL no = (NoAVL) inserir(chave, dado, this.getRaiz());
			this.setRaiz(no.getRaiz());
			return true;
		} catch (ChaveDuplicadaException e) {
			return false;
		}
    }
	
	/**
	 * Inserir o dado na arvore de acordo com a sua chave. Quando a chave
	 * ja existe, lanca uma excecao indicando a duplicacao da chave.
	 */
	@Override
	protected NoAVL inserir(Comparable chave, Object dado, No n)  throws ChaveDuplicadaException {
		NoAVL noInserido = (NoAVL) super.inserir(chave, dado, n);
		balancearAscendentes(noInserido);
		return noInserido;
	}

	@Override
	public boolean remover(Comparable chave) {
		NoAVL no = obter(chave, super.getRaiz());		
		if (no != null) {
			try {
				NoAVL noRemovido = (NoAVL) super.remover(chave, no);
				balancearAscendentes(noRemovido);
				return true;
			} catch (ChaveNaoEncontradaException e) {}
			
		}
		return false; 
	}
	
	/**
	 * Verifica o balanco e efetua rotacoes visando corrigir o
	 * desbalanceamento provodado pela remocao.
	 */
	private void balancearAscendentes(NoAVL no) {
		if (no != null) { // Ainda nao chegou na Raiz
			NoAVL pai = no.getPai();
			no.atualizarAltura();
			
			if (no.desbalanceado()) {
				no.rotacionar();
				
				// Se o no rotacionado eh a raiz da arvore (seu pai eh null),
				// reajusta a raiz da arvore apos a rotacao efetuada usando
				// as referencias dos nos para a Raiz
				if (pai == null) {
					this.setRaiz(no.getRaiz());
				}
			}
			balancearAscendentes(pai);			
		}
	}

	@Override
	protected NoAVL obter(Comparable chave, No no) {
		return (NoAVL) super.obter(chave, no);
	}
	
	 
	/**
	 * Factory Method para criacao de um No da arvore AVL. Pode ser sobreposto
	 * por subclasses para retornar subclasses de NoAVL
	 */
	@Override
	protected NoAVL criarNo(Comparable chave, Object dado, No esq, No dir, No pai) {
		return new NoAVL(chave, dado, esq, dir, pai);
	}
}