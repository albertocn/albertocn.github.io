package arvores.avl;

import arvores.No;

public class NoAVL extends No {
	
	/** Altura do No, sendo que um No folha tem altura 0. */
	private int altura = 0;
	
    public NoAVL(Comparable chave, Object dado){
    	this(chave, dado, null, null, null);
    }
    
    public NoAVL(Comparable chave, Object dado, No esq, No dir, No pai) {
    	super(chave, dado, null, null, pai);
    }
    
    @Override
    public NoAVL getEsquerdo() {
    	return (NoAVL) super.getEsquerdo();
    }
        
    @Override
    public NoAVL getDireito() {
    	return (NoAVL) super.getDireito();
    }
    
    @Override
    public NoAVL getPai() {
    	return (NoAVL) super.getPai();
    }
    
    @Override
    public boolean adicionarFilhoEsquerda(Comparable chave, Object dado) {
    	if (!temNoEsquerdo()) {
    		this.setEsquerdo(new NoAVL(chave, dado, null, null, this));
    		return true;
    	}
    	return false;
    }
    
    @Override
    public boolean adicionarFilhoDireita(Comparable chave, Object dado) {
    	if (!temNoDireito()) {
    		this.setDireito(new NoAVL(chave, dado, null, null, this));
    		return true;
    	}
    	return false;
    }
    
    /**
     * Retorna true se o No corrente esta balanceado, ou seja,
     * tem balanco igual a -1, 0 ou 1.
     */
    public boolean balanceado() {
    	return (balanco() >= -1) && (balanco() <= 1);    	
    }
    
    /**
     * Retorna true se o No corrente esta desbalanceado, ou seja,
     * tem balanco fora da faixa -1 a 1.
     */
    public boolean desbalanceado() {
    	return !balanceado();    	
    }    

    /**
     * Retorna o balanco de um No da Arvore AVL.
     */
    public int balanco() {
    	int bal = 0;
    	if (this.temNoEsquerdo()) {
    		bal += 1 + this.getEsquerdo().getAltura();
    	}
    	if (this.temNoDireito()) {
    		bal -= 1+ this.getDireito().getAltura();
    	}    	
    	return bal;
    }
    
    /**
     * Retorna a altura do No. Um No folha tem altura 0.
     */
    public int getAltura() {
		return altura;
	}

    /**
     * Altera a altura do No. Deve ser um valor maior ou igual a 0.
     */
	public void setAltura(int altura) {
		if (altura < 0) {
			throw new IllegalArgumentException("Altura com valor negativo nao eh permitido");
		}
		this.altura = altura;
	}
  
    /**
	 * Atualiza a altura do No com base na altura do filho mais alto.
	 */
	protected void atualizarAltura() {
		this.setAltura(getAlturaFilhoMaisAlto() + 1);
	}

	/**
	 * Retorna a altura do filho mais alto.
	 */
    private int getAlturaFilhoMaisAlto() {
    	int alturaFilhoEsq = this.temNoEsquerdo() ? this.getEsquerdo().getAltura() : -1;
    	int alturaFilhoDir = this.temNoDireito() ? this.getDireito().getAltura() : -1;    	
    	return Math.max(alturaFilhoEsq, alturaFilhoDir);
    }


	/**
	 * Verifica os balancos de um No e efetua a rotacao adequada
	 * para deixar o no com balanco entre -1 e 1.
	 */
	public void rotacionar() {
		if (balanco() < -1) {
			if (getDireito().balanco() <= 0) {
				rotacaoParaEsquerda();
			} else {
				rotacaoDuplaDireitaEsquerda();
			}
		} else if (balanco() > 1){
			if (getEsquerdo().balanco() >= 0) {
				rotacaoParaDireita();
			} else {
				rotacaoDuplaEsquerdaDireita();
			}					
		}
	}

    
    /**
     * Efetua uma rotacao simples para a esquerda considerando o No
     * corrente como o pivo.
     */
    public void rotacaoParaEsquerda() {    	
    	NoAVL filhoDir = this.getDireito();
    	NoAVL temp = filhoDir.getEsquerdo();
    	
    	filhoDir.setEsquerdo(this);    	
    	trocarPaiComNo(filhoDir);
    	
    	this.setDireito(temp);
    	if (temp != null) {
    		temp.setPai(this);
    	}
    	
        this.atualizarAltura();
        filhoDir.atualizarAltura();
    }

    /**
     * Efetua uma rotacao simples para a direita considerando o No
     * corrente como o pivo.
     */
    public void rotacaoParaDireita() {
    	NoAVL filhoEsq = this.getEsquerdo();
    	NoAVL temp = filhoEsq.getDireito();    	

    	filhoEsq.setDireito(this);    	
    	trocarPaiComNo(filhoEsq);
    	
    	this.setEsquerdo(temp);
    	if (temp != null) {
    		temp.setPai(this);
    	}
    	
        this.atualizarAltura();
        filhoEsq.atualizarAltura();
    }

	/**
	 * Faz com que o No passado como parametro passe a ter como 
	 * No pai o pai do No corrente. Ao mesmo tempo, faz com que
	 * o pai do No corrente passe a enxerga-lo como filho.
	 */
	protected void trocarPaiComNo(NoAVL outroNo) {
		outroNo.setPai(this.getPai());    	
    	if (this.isFilhoEsquerdo()) {
    		outroNo.getPai().setEsquerdo(outroNo);
    	} else if (this.isFilhoDireito()) {
    		outroNo.getPai().setDireito(outroNo);
    	}
    	this.setPai(outroNo);
	}
    
    
    /**
     * Rotacao dupla esquerda direita. Rotaciona primeiro o filho
     * esquerdo para a esquerda e depois o proprio pivo (no atual)
     * como parametro para a direita.
     */
    public void rotacaoDuplaEsquerdaDireita()
    {
    	this.getEsquerdo().rotacaoParaEsquerda();
        this.rotacaoParaDireita();
    }

    /**
     * Rotacao dupla direita esquerda. Rotaciona primeiro o filho
     * direito para a direita e depois o proprio pivo (no atual)
     * como parametro para a esquerda
     */
    public void rotacaoDuplaDireitaEsquerda()
    {
    	this.getDireito().rotacaoParaDireita();
        this.rotacaoParaEsquerda();
    }
}
