package arvores.avl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import junit.framework.TestCase;

import org.junit.Test;

import arvores.ArvoreBinariaBusca;

public class ArvAVLTeste extends TestCase {

	/**
	 * Cria uma instancia da classe ArvBinBuscaRec.
	 */
	protected ArvoreBinariaBusca criarArvoreBinariaBusca() {
		return new ArvAVL();
	}
	

	@Test
	public void testRotacoes() {
		ArvoreBinariaBusca arv = criarArvoreBinariaBusca();
		
		arv.inserir(3, "C");
		
		assertFalse(arv.getRaiz().temNoEsquerdo());
		assertFalse(arv.getRaiz().temNoDireito());

		arv.inserir(1, "A");		
		arv.inserir(5, "E");

		assertTrue(arv.getRaiz().temNoEsquerdo());
		assertTrue(arv.getRaiz().temNoDireito());

//		      C
//		  A       E

		arv.inserir(2, "B");
		arv.inserir(4, "D");

//		      C
//		  A       E
//		    B   D


		arv.inserir(6, "F");
		arv.inserir(7, "G");		

//	           C
//	       A       E
//	         B   D   F
// 		              G

		// Testa alteracoes
		assertTrue(arv.alterar(1, "a"));
		assertTrue(arv.alterar(4, "d"));
		assertTrue(arv.alterar(7, "g"));
		assertFalse(arv.alterar(10, "Z")); // Nao altera

//            C
//        a       E
//          B   d   F
//	                 g
		
		// Testa obtencoes
		String[] dadosEsperados = {"a", "B", "C", "d", "E", "F", "g"};
		for (int i = 1; i <= 7; i++) {
			assertEquals(dadosEsperados[i-1], arv.obter(i).toString());
		}
		
		// Testa a remocao de No com 1 filho direito
		assertTrue(arv.remover(1)); // Remove A
		assertFalse(arv.remover(1)); // Nao remove A porque ja nao deve existir

//           C
//       B       E
//             d   F
//	                 g
		
//       Apos a rotacao para a esquerda sobre C (3)

//             E
//         C      F
//       B   d      g

		assertEquals(3, arv.getRaiz().getEsquerdo().getChave());

		// Testa a remocao de No com Raiz com 2 filhos e sucessor imediato direto		
		assertTrue(arv.remover(5)); // Remove E
		assertFalse(arv.remover(5)); // Nao remove E porque ja nao deve existir
		assertEquals(6, arv.getRaiz().getChave());
		
//             F 
//         C      g
//       B   d     
	

		// Testa a remocao de No folha sem provocar rotacao
		assertTrue(arv.remover(2)); // Remove B
		assertFalse(arv.remover(2)); // Nao remove B porque ja nao deve existir
		assertEquals(6, arv.getRaiz().getChave());		
		assertEquals(7, arv.getRaiz().getDireito().getChave());		

//               F 
//           C      g
//             d     


		// Testa a remocao de No folha que provoca rotacao dupla esquerda direita
		assertTrue(arv.remover(7)); // Remove g
		assertFalse(arv.remover(7)); // Nao remove B porque ja nao deve existir		
		
		assertEquals(4, arv.getRaiz().getChave());		
		assertEquals(3, arv.getRaiz().getEsquerdo().getChave());
		assertEquals(6, arv.getRaiz().getDireito().getChave());		
		
		
//           d
//       C       F

		assertTrue(arv.remover(3)); // Remove C
		assertFalse(arv.remover(3)); // Nao remove C porque ja nao deve existir
		assertEquals(4, arv.getRaiz().getChave());		
		assertEquals(6, arv.getRaiz().getDireito().getChave());
		
//           F
//       d    
		
		assertTrue(arv.remover(6)); // Remove F
		assertFalse(arv.remover(6)); // Nao remove F porque ja nao deve existir
		assertEquals(4, arv.getRaiz().getChave());		

//       d    				
		
		assertTrue(arv.remover(4)); // Remove d
		assertFalse(arv.remover(4)); // Nao remove d porque ja nao deve existir
		assertTrue(arv.vazia());
	}
	

	@Test
	public void testInserirRetirarMuitos() {
		ArvoreBinariaBusca arv = criarArvoreBinariaBusca();
		
		// Numero de elementos a serem inseridos e retirados da arvore AVL
		final int NUM = 30000;
		
		// Constroi o array com NUM valores inteiros
		List<Integer> chaves = new ArrayList<Integer>(NUM);
		for (int i = 1; i <= NUM; i++) {
			chaves.add(i);
		}		
		Collections.shuffle(chaves);
		
		inserirChavesNaArvore(chaves, arv);
		
		Collections.shuffle(chaves);

		removerChavesDaArvorer(chaves, arv);
		
		assertTrue(arv.vazia());		
	}


	/**
	 * @param chaves
	 * @param arv
	 */
	protected void inserirChavesNaArvore(List<Integer> chaves,
			ArvoreBinariaBusca arv) {
		for (int i = 0; i < chaves.size(); i++) {
			assertTrue(arv.inserir(chaves.get(i), "Num " + chaves.get(i)));
			 // Insercao de valor duplicado deveria retornar false
			assertFalse(arv.inserir(chaves.get(i), "Num " + chaves.get(i)));
		}
	}


	/**
	 * @param chaves
	 * @param arv
	 */
	protected void removerChavesDaArvorer(List<Integer> chaves,
			ArvoreBinariaBusca arv) {
		for (int i = 0; i < chaves.size(); i++) {
			assertTrue(arv.remover(chaves.get(i)));
			// Insercao de valor duplicado deveria retornar false
			assertFalse(arv.remover(chaves.get(i)));
		}
	}
	
	
	@Test
	public void testRemoverComProblema() {
		ArvoreBinariaBusca arv = criarArvoreBinariaBusca();
		Integer[] chaves = {3, 8, 6, 9, 4, 1, 5, 7, 2, 10};
		for (int i = 0; i < chaves.length; i++) {
			arv.inserir(chaves[i], "Num " + chaves[i]);
			checarBalancos((ArvAVL) arv);			
		}
		Integer[] chavesR = {5, 3, 6, 1, 10, 8, 7, 4, 2, 9};
		for (int i = 0; i < chavesR.length; i++) {
			arv.remover(chavesR[i]);
			checarBalancos((ArvAVL) arv);			
		}	
	}
			

	@Test
	public void testRemoverComProblema2() {
		ArvoreBinariaBusca arv = criarArvoreBinariaBusca();
		Integer[] chaves = {14, 7, 4, 1, 15, 8, 5, 10, 3, 13, 11, 6, 2, 12, 9};
		for (int i = 0; i < chaves.length; i++) {
			arv.inserir(chaves[i], "Num " + chaves[i]);
			checarBalancos((ArvAVL) arv);			
		}
		Integer[] chavesR = {3, 14, 11, 1, 9, 10, 4, 2, 13, 5, 7, 8, 6, 15, 12};
		for (int i = 0; i < chavesR.length; i++) {
			arv.remover(chavesR[i]);
			checarBalancos((ArvAVL) arv);			
		}	
	}

	
	@Test
	public void testInserirComProblema() {
		ArvoreBinariaBusca arv = criarArvoreBinariaBusca();

		Integer[] chaves = {15, 4, 1, 12, 7, 16, 8, 2, 20, 11, 10, 9, 14, 3, 19, 18, 13, 5, 17, 6};
		for (int i = 0; i < chaves.length; i++) {
			arv.inserir(chaves[i], "Num " + chaves[i]);
			checarBalancos((ArvAVL) arv);			
		}		
	}
	
	private void checarBalancos(ArvAVL arv) {		
		if (!arv.vazia()) {
			assertNotNull(arv);
			assertNotNull(arv.getRaiz());
			assertTrue(balancoOK(arv.getRaiz()));
		}
	}
	
	private boolean balancoOK(NoAVL no) {
		if (no == null) {
			return true;
		} else {
			return no.balanceado() && balancoOK(no.getEsquerdo()) && balancoOK(no.getDireito());
		}		
	}
	
}


