package arvores;

/**
 * Representa a informacao e as referencias contidas em um No da arvore binaria.
 */
public class No {
   
	private Comparable chave;
    private Object dado;

    private No direito;
    private No esquerdo;
    private No pai;
    
    public No(Comparable chave, Object dado){
    	this(chave, dado, null, null, null);
    }
    
    public No(Comparable chave, Object dado, No esq, No dir, No pai) {
    	this.chave = chave;
    	this.dado = dado;
    	this.esquerdo = esq;
    	this.direito = dir;
    	this.pai = pai;
    }

    public Comparable getChave() {
        return chave;
    }

    public void setChave(Comparable chave) {
    	if (chave == null) {
    		throw new IllegalArgumentException("chave nao pode ser null");
    	}
        this.chave = chave;
    }
    
    public Object getDado() {
        return dado;
    }

    public void setDado(Object dado) {
    	if (dado == null) {
    		throw new IllegalArgumentException("dado nao pode ser null");
    	}
        this.dado = dado;
    }
    
    public No getEsquerdo() {
        return this.esquerdo;
    }

    public void setEsquerdo(No Esquerda) {
        this.esquerdo = Esquerda;
    }

    public boolean temNoEsquerdo() {
    	return getEsquerdo() != null;
    }

    public No getDireito() {
        return this.direito;
    }

    public void setDireito(No Direita) {
        this.direito = Direita;
    }
    
    public boolean temNoDireito() {
    	return getDireito() != null;
    }

    public No getPai() {
        return pai;
    }

    public void setPai(No Pai) {
        this.pai = Pai;
    }
    
    public boolean temNoPai() {
    	return getPai() != null;
    }
    
    public No getRaiz() {
    	return isRaiz() ? this : getPai().getRaiz();    	
    }
    
    public boolean isRaiz() {
    	return !temNoPai();
    }
    
    public boolean isFolha() {
    	return !temNoEsquerdo() && !temNoDireito(); 
    }
    
    public boolean isFilhoEsquerdo() {
    	return temNoPai() && (getPai().getEsquerdo() == this); 
    }
    
    public boolean isFilhoDireito() {
    	return temNoPai() && (getPai().getDireito() == this); 
    }

    public boolean adicionarFilhoEsquerda(Comparable chave, Object dado) {
    	if (!temNoEsquerdo()) {
    		this.setEsquerdo(new No(chave, dado, null, null, this));
    		return true;
    	}
    	return false;
    }
    
    public boolean adicionarFilhoDireita(Comparable chave, Object dado) {
    	if (!temNoDireito()) {
    		this.setDireito(new No(chave, dado, null, null, this));
    		return true;
    	}
    	return false;
    }

    /**
     * Desaloca da memoria o No atual e seus descendentes (sem atualizar
     * a referencia do pai para este No).
     */
    public void disposeArvore() {
    	if (temNoEsquerdo()) {
    		getEsquerdo().disposeArvore();
    	}
    	if (temNoDireito()) {
    		getDireito().disposeArvore();
    	}    	
    	limparNo();
    }

    /**
     * Desaloca da memoria o No atual e seus descendentes, atualizando, se necessario, 
     * a referencia do pai para este No.
     */
    public void deltree() {
    	if (temNoPai()) {
    		No pai = getPai();
    		if (pai.getEsquerdo() == this) {
    			pai.setEsquerdo(null);
    		} else {
    			pai.setDireito(null);
    		}
    	}
		disposeArvore();
    }
    
    /** 
     * Visita o proprio No, depois a subarvore esquerda e finalmente
     * a subarvore direita.
     * 
     * @param visitor Objeto que contem a operacao a ser executada ao
     *                visitar cada No.
     */
    public void preOrdem(Visitor visitor) {
    	visitor.visite(this);

    	if (temNoEsquerdo()) {
    		getEsquerdo().preOrdem(visitor);
    	}
    	
    	if (temNoDireito()) {
    		getDireito().preOrdem(visitor);
    	}
    }    

    /** 
     * Visita a subarvore esquerda, depois a direita e finalmente
     * o proprio No.
     * 
     * @param visitor Objeto que contem a operacao a ser executada ao
     *                visitar cada No.
     */
    public void posOrdem(Visitor visitor) {
    	if (temNoEsquerdo()) {
    		getEsquerdo().posOrdem(visitor);
    	}
    	
    	if (temNoDireito()) {
    		getDireito().posOrdem(visitor);
    	}
    	
    	visitor.visite(this);
    }
    
    /** 
     * Visita a subarvore esquerda, depois o proprio No e finalmente
     * a subarvore direita.
     * 
     * @param visitor Objeto que contem a operacao a ser executada ao
     *                visitar cada No.
     */
    public void inOrdem(Visitor visitor) {
    	if (temNoEsquerdo()) {
    		getEsquerdo().inOrdem(visitor);
    	}

    	visitor.visite(this);

    	if (temNoDireito()) {
    		getDireito().inOrdem(visitor);
    	}
    }
    
    /**
     * Limpa todas as referencias contidas no No para facilitar a coleta de lixo.
     */
	public void limparNo() {
		this.chave = null;
    	this.dado = null;
    	this.esquerdo = null;
    	this.direito = null;
    	this.pai = null;
	}
    
    /**
     * Retorna o dado transformado em String
     */
    public String toString() {
    	return "chave: " + getChave().toString() + ", dado:" + getDado().toString();
    }    
}