package arvores;

public interface Visitor {
	
	public void visite(No no);
}
