package arvores;

public class TNo {
	
	public static void main(String[] args) {
		
		No arv = new No(1, "A");
		
		arv.adicionarFilhoEsquerda(2, "B");
		arv.adicionarFilhoDireita(5, "E");
		
		//         A
		//      B     E

		arv.getEsquerdo().adicionarFilhoEsquerda(3, "C");
		arv.getEsquerdo().adicionarFilhoDireita(4, "D");

		//          A
		//       B     E
        //	    C D

		arv.getDireito().adicionarFilhoEsquerda(6, "F");
		arv.getDireito().getEsquerdo().adicionarFilhoDireita(7, "G");		

		//          A
		//       B     E
        //	    C D   F
        //	           G

		imprimirCaracteristicas(Caracteristicas.obterCaracteristicas(arv));

		arv.preOrdem(new ImprimirVisitor());
		System.out.println();
	
		arv = arv.getDireito(); // Vai para o No E
		System.out.println("Existe no esquerdo = " + arv.temNoEsquerdo()); // Deve ser true
		System.out.println("Existe no direito = " + arv.temNoDireito()); // Deve ser false		

		arv = arv.getEsquerdo(); // Vai para o No F
		arv = arv.getDireito(); // Vai para o No G
		System.out.println("Esperando G, obtido " + arv.getDado().toString());

		arv = arv.getPai(); // Vai para F
		System.out.println("Esperando F, obtido " + arv.getDado().toString());		

		arv = arv.getRaiz(); // Vai para A
		System.out.println("Esperando A, obtido " + arv.getDado().toString());

		arv.disposeArvore();
	}

	protected static void imprimirCaracteristicas(Caracteristicas carac) {
		System.out.println("Altura esperada 3, obtida " + carac.getAltura());
		System.out.println("NumNos esperada 7, obtida " + carac.getNumNos());
		System.out.println("Soma esperada 11, obtida " + carac.getSoma());		
		System.out.println("CompMedio esperado 1.5714285714285714, obtida " + carac.getCompMedio());
	}
}

class ImprimirVisitor implements Visitor {
	@Override
	public void visite(No no) {
		System.out.print(" " + no.getDado().toString());
	}
}