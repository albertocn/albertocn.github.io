package arvores;

/**
 * Contem as caracteristicas de uma arvore
 */
public class Caracteristicas {
	private int numNos, altura, soma;
	
	private Caracteristicas() {
		this(0, 0, 0);
	}
	
	private Caracteristicas(int numNos, int altura, int soma) {
		this.numNos = numNos;
		this.altura = altura;
		this.soma = soma;    		
	}
	
	public int getNumNos() {
		return numNos;
	}

	public int getAltura() {
		return altura;
	}

	public int getSoma() {
		return soma;
	}

	public double getCompMedio() {
		return ((double) this.soma) / this.numNos;
	}
	
	public void incNumNos() {
		this.numNos++;
	}
	
	public void incSoma(int nivel) {
		this.soma += nivel;
	}
	
	public void setAlturaSeMaior(int nivel) {
		if (nivel > this.altura){
			this.altura = nivel;
		}   		
	}
	
    /**
     * Retorna as caracteristicas atuais da Arvore partindo do No
     * passado como parametro.
     */
    public static Caracteristicas obterCaracteristicas(No no) {
    	Caracteristicas carac = new Caracteristicas();    	
    	carac.inOrdemCaracteristicas(no, carac, 0);    	
    	return carac;    	
    }

    
    /**
     * Visita a subarvore esquerda, depois o proprio No e finalmente
     * a subarvore direita, passando um objeto que guarda as caracteristicas
     * e nivel atual do No.
     * 
     * @param no No a partir do qual comeca a visita InOrdem
     * @param carac Objeto caracteristicas usado para guardar informacoes a 
     *              serem obtidas
     * @param visitor Objeto que contem a operacao a ser executada ao
     *                visitar cada No.
     */
    public void inOrdemCaracteristicas(No no, Caracteristicas carac, int nivel) {
    	if (no.temNoEsquerdo()) {
    		inOrdemCaracteristicas(no.getEsquerdo(), carac, nivel + 1);
    	}

    	carac.incNumNos();
    	carac.incSoma(nivel);
   		carac.setAlturaSeMaior(nivel);
    	
    	if (no.temNoDireito()) {
    		inOrdemCaracteristicas(no.getDireito(), carac, nivel + 1);
    	}
    }
}
