package arvores;

/**
 * Representa uma arvore binaria, onde cada no tem uma referencia
 * para os seus filhos esquerdo e direito. Alem disso, cada no possui
 * referencia para o pai.
 */
public class ArvBin implements ArvoreBinaria {
	
    protected No raiz;
  
    public ArvBin(){
        raiz = null;
    }
    
    @Override
    public No getRaiz() {
    	return this.raiz;
    }
    
    @Override
    public void setRaiz(No no) {
    	this.raiz = no;
    }
    
    @Override
    public boolean vazia() {
        return raiz == null;
    }

    
    /**
     * Desaloca da memoria Arvore e seus descendentes, atualizando, se
     * necessario, a referencia do dessa arvore ou atribuindo o valor
|            nil a Arvore, quando for a raiz.
     */
    @Override
    public void deltree() {
    	if (this.raiz!= null) {
    		raiz.deltree();
    		this.raiz = null;
    	}
    }
    
	public String toString() {
		return toString(this.getRaiz());
	}


	private String toString(No no) {
		StringBuffer sb = new StringBuffer();
		if (no != null) {
			sb.append(no.getChave());
			if (!no.isFolha()) {
				sb.append("(");
				sb.append(no.temNoEsquerdo() ? toString(no.getEsquerdo()).toString() : "_");
				sb.append(",");
				sb.append(no.temNoDireito() ? toString(no.getDireito()).toString() : "_");
				sb.append(")");
			}	
		}
		return sb.toString();
	}


	/**
	 * Factory Method para criacao de um No da arvore binaria. Pode ser sobreposto
	 * por subclasses para retornar subclasses de No
	 */
	protected No criarNo(Comparable chave, Object dado) {
		return criarNo(chave, dado, null, null, null);
	}
	
	/**
	 * Factory Method para criacao de um No da arvore binaria. Pode ser sobreposto
	 * por subclasses para retornar subclasses de No
	 */
	protected No criarNo(Comparable chave, Object dado, No pai) {
		return criarNo(chave, dado, null, null, pai);
	}
	
	/**
	 * Factory Method para criacao de um No da arvore binaria. Pode ser sobreposto
	 * por subclasses para retornar subclasses de No
	 */
	protected No criarNo(Comparable chave, Object dado, No esq, No dir, No pai) {
		return new No(chave, dado, esq, dir, pai);
	}
}
