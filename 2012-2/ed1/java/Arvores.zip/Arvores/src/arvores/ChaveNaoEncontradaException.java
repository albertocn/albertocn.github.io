package arvores;

/**
 * Lancada quando tenta-se encontrar uma chave que nao existe na arvore.
 */
public class ChaveNaoEncontradaException extends Exception {

}
