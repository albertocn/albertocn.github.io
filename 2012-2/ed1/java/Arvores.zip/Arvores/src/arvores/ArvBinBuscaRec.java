package arvores;

/**
 * Implementa uma Arvore Binaria de Busca utilizando recursividade.
 *
 */
public class ArvBinBuscaRec extends ArvBin implements ArvoreBinariaBusca {

	@Override
	public Object obter(Comparable chave) {
		No no = obter(chave, super.getRaiz());
		return no == null ? null : no.getDado(); 
	}
	
	@Override
	public boolean alterar(Comparable chave, Object dado) {
		No no = obter(chave, this.getRaiz());
		if (no != null) {
			no.setDado(dado);
			return true;
		}
		return false;
	}

	/**
	 * Retorna uma referencia para o No com chave igual a procurada.
	 * Caso nao encontre, retorna null.
	 */
	protected No obter(Comparable chave, No no) {
        if( no == null )
            return null;
        if( chave.compareTo( no.getChave() ) < 0 )
            return obter( chave, no.getEsquerdo() );
        else if( chave.compareTo( no.getChave() ) > 0 )
            return obter( chave, no.getDireito() );
        else
            return no;    // Encontrou
	}
																																																																												
	@Override
	public boolean inserir(Comparable chave, Object dado) {
		try {			
			No noInserido = inserir(chave, dado, this.getRaiz());
			if (noInserido.isRaiz()) {
				this.setRaiz(noInserido);
			}
			return true;
		} catch (ChaveDuplicadaException e) {
			return false;
		}
    }
	
	/**
	 * Inserir o dado na arvore de acordo com a sua chave. Quando a chave
	 * ja existe, lanca uma excecao indicando a duplicacao da chave.
	 */
	protected No inserir(Comparable chave, Object dado, No pai)  throws ChaveDuplicadaException {
    	if (pai == null) {
    		return criarNo(chave, dado);
    	} else if (chave.compareTo(pai.getChave()) < 0) { // Chave menor que a do No
    		if (pai.temNoEsquerdo()) {
    			return inserir(chave, dado, pai.getEsquerdo());
    		} else {
    			pai.setEsquerdo(criarNo(chave, dado, null, null, pai));
    			return pai.getEsquerdo();
    		}
    	} else if (chave.compareTo(pai.getChave()) > 0) { // Chave maior que a do No
    		if (pai.temNoDireito()) {
        		return inserir(chave, dado, pai.getDireito());
    		} else {
    			pai.setDireito(criarNo(chave, dado, null, null, pai));
    			return pai.getDireito();
    		}
    	} else {  // Chave igual (duplicada)
    		throw new ChaveDuplicadaException();    	
    	}
    }

	
	@Override
	public boolean remover(Comparable chave) {
		try {
		    remover(chave, getRaiz());
		    return true;
		} catch(ChaveNaoEncontradaException e) {
			return false;
		}		
	}
	
	
	/**
	 * Retira o No contendo chave da arvore apontada por No e retorna o mesmo.
	 * Se esse nao for retirado, lanca uma excecao ChaveNaoEncontradaException
	 */
	protected No remover(Comparable chave, No no) throws ChaveNaoEncontradaException {
		
	    // Se a arvore estiver vazia, o No nao sera retirado, pois nao existe. Mas
	    // se nao estiver vazia, sera feita a procura atraves de chamadas
	    // recursivas de remover, pegando a subarvore esquerda quando Chave for
	    // menor que o valor da chave no No ou a subarvore direita quando for maior.
	    // Existem dois pontos de parada, o primeiro quando a subarvore onde esta
	    // sendo feita a busca esta vazia e o segundo quando a Chave for encontrada.
	    // Nesse caso acontecera�a remocao
	   if (no == null) {
		   throw new ChaveNaoEncontradaException();		   
		   
	   } else if (chave.compareTo( no.getChave() ) < 0) {
	       return remover(chave, no.getEsquerdo());
	       
	   } else if (chave.compareTo( no.getChave() ) > 0) {
		   return remover(chave, no.getDireito());

		 // Como nesse ponto chave = no.getChave(), devemos verificar
         // se o No possui duas, uma ou nenhuma subarvore. No primeiro caso
         // deve ser procurado na subarvore direita o sucessor imediato do No
         // e coloca-lo no lugar do No removido. Nos outros dois casos, so
         // e necessario remover o No e ajustar as referencias
	   } else {

           if (!no.temNoEsquerdo()) { // Arvore nao tem subarvores ou tem somente a direita

               // Se existir, corrige a referencia para o filho direito do No a ser removido, 
        	   // fazendo-o referenciar o pai do No a ser removido
               if (no.temNoDireito()) {
            	   no.getDireito().setPai(no.getPai());            	   
               }
            	
               substituirFilho(no, no.getDireito());
               
               return no;
               
           } else if (!no.temNoDireito()) { // Arvote tem somente o filho esquerdo

               // Corrige a referencia para o Pai do filho esquerdo do No a ser removido, 
        	   // fazendo-o referenciar o pai do No a ser removido
        	   no.getEsquerdo().setPai(no.getPai());
        	   
        	   substituirFilho(no, no.getEsquerdo());
        	   
        	   return no;
        	   
           } else {
        	   
        	   // No a ser removido precisa ser substituido pelo sucessor imediato porque
        	   // tem filhos esquerdo e direito
               No sucessor = sucessor(no);
               no.setChave(sucessor.getChave());
               no.setDado(sucessor.getDado());
               
               // Remove o sucessor imediato da subarvore direita
               return remover(sucessor.getChave(), sucessor);
           }
	   }
	}

	/**
	 * Substitui a refencia que o no pai mantem para um No filho por 
	 * outro No filho. Decide se precisa atualizar a referencia do pai para
	 * o filho do filho (que pode ser seu filho esquerdo ou direito) ou
	 * o atributo Raiz da arvore.
	 */
	public void substituirFilho(No filhoAntigo, No filhoNovo) {
	   if (filhoAntigo.temNoPai()) {
		   No pai = filhoAntigo.getPai();
		   if (filhoAntigo.isFilhoEsquerdo()) {
			   pai.setEsquerdo(filhoNovo);
		   } else {
		       pai.setDireito(filhoNovo);
		   }
	   } else { // O No sendo removido e a a raiz da arvore
		   this.setRaiz(filhoNovo);            	   
	   }
	}

	
	/**
	 * Retorna o sucessor imediato de um No.
	 * @param no
	 * @return
	 */
	private No sucessor(No no) {
		return menorValorSubarvore(no.getDireito());
	}
	
	/**
     * Retorna o menor valor de uma subarvore com raiz passada como parametro.
     * Util para encontrar o sucessor imediato.
     */
	private No menorValorSubarvore(No no) {
		if ((no == null) || !no.temNoEsquerdo()) {
			return no;
		} else {
			return menorValorSubarvore( no.getEsquerdo() );			
		}
	}
}
