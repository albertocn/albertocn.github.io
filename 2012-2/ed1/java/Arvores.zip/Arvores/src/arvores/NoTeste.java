package arvores;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

public class NoTeste extends TestCase {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testGeral() {

		No no = new No(1, "A");
		
		assertFalse(no.temNoEsquerdo());
		assertFalse(no.temNoDireito());

		no.adicionarFilhoEsquerda(2, "B");
		no.adicionarFilhoDireita(5, "E");

		assertTrue(no.temNoEsquerdo());
		assertTrue(no.temNoDireito());

//		    A
//		  B   E

		no.getEsquerdo().adicionarFilhoEsquerda(3, "C");
		no.getEsquerdo().adicionarFilhoDireita(4, "D");

//		    A
//		  B   E
//		 C D

		no.getDireito().adicionarFilhoEsquerda(6, "F");
		no.getDireito().getEsquerdo().adicionarFilhoDireita(7, "G");

//		    A
//		  B   E
//		 C D F
//		      G


		Caracteristicas carac = Caracteristicas.obterCaracteristicas(no);
		assertEquals(3, carac.getAltura());
		assertEquals(7, carac.getNumNos());
		assertEquals(11, carac.getSoma());
		assertEquals(11.0/7.0, carac.getCompMedio());

		VisitorGuardaNos visitorPre = new VisitorGuardaNos();
		no.preOrdem(visitorPre);
		Integer[] resultadoPre = {1, 2, 3, 4, 5, 6, 7};
		visitorPre.conferirResultadoNavegacao(resultadoPre);
		
		VisitorGuardaNos visitorPos = new VisitorGuardaNos();
		no.posOrdem(visitorPos);
		Integer[] resultadoPos = {3, 4, 2, 7, 6, 5, 1};
		visitorPos.conferirResultadoNavegacao(resultadoPos);
		
		VisitorGuardaNos visitorIn = new VisitorGuardaNos();
		no.inOrdem(visitorIn);
		Integer[] resultadoIn = {3, 2, 4, 1, 6, 7, 5};
		visitorIn.conferirResultadoNavegacao(resultadoIn);

		no = no.getDireito(); // Vai para o No E
		assertTrue(no.temNoEsquerdo());
		assertFalse(no.temNoDireito());

		no = no.getEsquerdo(); // Vai para o No F
		no = no.getDireito(); // Vai para o No G
		assertEquals("G", no.getDado());

		no = no.getPai(); // Vai para F
		assertEquals("F", no.getDado());
		
		no = no.getRaiz(); // Vai para A
		assertEquals("A", no.getDado());	
		
		no.getEsquerdo().deltree(); // Apaga a subarvore a partir de F		
		assertFalse(no.temNoEsquerdo());

		no.disposeArvore();
	}
}