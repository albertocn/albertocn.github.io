package arvores;

import junit.framework.TestCase;

import org.junit.Test;

public class ArvBinBuscaTeste extends TestCase {

	/**
	 * Metodo que retorna a instancia da Arvore Binaria
	 * a ser testada, podendo ser de qualquer classe
	 * que implemente a interface ArvoreBinariaBusca.
	 */
	protected ArvoreBinariaBusca criarArvoreBinariaBusca() {
		return new ArvBinBusca();
	}


	@Test
	public void testGeral() {
		ArvoreBinariaBusca arv = criarArvoreBinariaBusca();
		
		arv.inserir(3, "C");
		
		assertFalse(arv.getRaiz().temNoEsquerdo());
		assertFalse(arv.getRaiz().temNoDireito());

		arv.inserir(1, "A");		
		arv.inserir(5, "E");

		assertTrue(arv.getRaiz().temNoEsquerdo());
		assertTrue(arv.getRaiz().temNoDireito());

//		      C
//		  A       E

		arv.inserir(2, "B");
		arv.inserir(4, "D");

//		      C
//		  A       E
//		    B   D


		arv.inserir(6, "F");
		arv.inserir(7, "G");		

//	           C
//	       A       E
//	         B   D   F
// 		              G

		Caracteristicas carac = Caracteristicas.obterCaracteristicas(arv.getRaiz());
		assertEquals(3, carac.getAltura());
		assertEquals(7, carac.getNumNos());
		assertEquals(11, carac.getSoma());
		assertEquals(11.0/7.0, carac.getCompMedio());

		VisitorGuardaNos visitorPre = new VisitorGuardaNos();
		arv.getRaiz().preOrdem(visitorPre);
		Integer[] resultadoPre = {3, 1, 2, 5, 4, 6, 7};
		visitorPre.conferirResultadoNavegacao(resultadoPre);
		
		VisitorGuardaNos visitorPos = new VisitorGuardaNos();
		arv.getRaiz().posOrdem(visitorPos);
		Integer[] resultadoPos = {2, 1, 4, 7, 6, 5, 3};
		visitorPos.conferirResultadoNavegacao(resultadoPos);
		
		VisitorGuardaNos visitorIn = new VisitorGuardaNos();
		arv.getRaiz().inOrdem(visitorIn);
		Integer[] resultadoIn = {1, 2, 3, 4, 5, 6, 7};
		visitorIn.conferirResultadoNavegacao(resultadoIn);

		No no = arv.getRaiz().getEsquerdo(); // Vai para o No A
		assertFalse(no.temNoEsquerdo());
		assertTrue(no.temNoDireito());

		no = no.getPai(); // Volta para A
		no = no.getDireito(); // Vai para o No E
		no = no.getDireito(); // Vai para o No F
		assertEquals("F", no.getDado());
		no = no.getDireito(); // Vai para o No G
		assertEquals("G", no.getDado());

		no = no.getPai(); // Vai para F
		assertEquals("F", no.getDado());
		
		// Testa alteracoes
		assertTrue(arv.alterar(1, "a"));
		assertTrue(arv.alterar(4, "d"));
		assertTrue(arv.alterar(7, "g"));
		assertFalse(arv.alterar(10, "Z")); // Nao altera
		
		// Testa obtencoes
		String[] dadosEsperados = {"a", "B", "C", "d", "E", "F", "g"};
		for (int i = 1; i <= 7; i++) {
			assertEquals(dadosEsperados[i-1], arv.obter(i).toString());
		}
		
		// Testa a remocao de No com 1 filho direito
		assertTrue(arv.remover(1)); // Remove A
		assertFalse(arv.remover(1)); // Nao remove A porque ja nao deve existir
		assertEquals(2, arv.getRaiz().getEsquerdo().getChave());

//           C
//       B       E
//             d   F
//	                 g
		
		// Testa a remocao de No com Raiz com 2 filhos e sucessor imediato nao direto		
		assertTrue(arv.remover(3)); // Remove C
		assertFalse(arv.remover(3)); // Nao remove C porque ja nao deve existir
		assertEquals(4, arv.getRaiz().getChave());

//           d
//       B       E
//                 F
//	                 g

		// Testa a remocao de No com Raiz com 2 filhos e sucessor imediato direto
		assertTrue(arv.remover(4)); // Remove d
		assertFalse(arv.remover(4)); // Nao remove d porque ja nao deve existir
		assertEquals(5, arv.getRaiz().getChave());		
		assertEquals(6, arv.getRaiz().getDireito().getChave());		
		
//           E
//       B       F
//                 g
		
		// Testa a remocao de Nos folhas
		assertTrue(arv.remover(2)); // Remove B
		assertTrue(arv.remover(7)); // Remove g		
		assertFalse(arv.remover(2)); // Nao remove B porque ja nao deve existir
		assertFalse(arv.remover(7)); // Nao remove g porque ja nao deve existir
		assertEquals(5, arv.getRaiz().getChave());
		assertEquals(6, arv.getRaiz().getDireito().getChave());
		assertFalse(arv.getRaiz().temNoEsquerdo());
		
//          E
//              F

		// Testa a remocao da raiz com 1 sucessor direto
		assertTrue(arv.remover(5)); // Remove E
		assertFalse(arv.remover(5)); // Nao remove E porque ja nao deve existir
		assertEquals(6, arv.getRaiz().getChave());

//          F
		
		// Testa a remocao do unico elemento da arvore
		assertTrue(arv.remover(6)); // Remove F
		assertFalse(arv.remover(6)); // Nao remove F porque ja nao deve existir		
		assertTrue(arv.vazia());

		arv.deltree();
	}
}


