package teste2;

public class DequeEnc implements Deque {

	private class No {
		private No anterior, proximo;
		private Object valor;

		public No(No ant, No prox, Object valor) {
			this.anterior = ant;
			this.proximo = prox;
			this.valor = valor;			
		}
	}

	private No inicio = null;
	private No fim = null;
	private long tamanho;

	@Override
	public long tamanho() {
		return this.tamanho;
	}

	@Override
	public boolean vazia() {
		return tamanho() == 0;
	}

	@Override
	public void inserirInicio(Object o) {
		if (vazia()) {
			inserirPrimeiroNo(o);
		} else {
			this.inicio = this.inicio.anterior = new No(null, this.inicio, o);
		}
		this.tamanho++;
	}

	private void inserirPrimeiroNo(Object o) {
		this.fim = this.inicio = new No(null, null, o);
	}

	@Override
	public void inserirFinal(Object o) {
		if (vazia()) {
			inserirPrimeiroNo(o);
		} else {
			this.fim = this.fim.proximo = new No(this.fim, null, o);
		}
		this.tamanho++;
	}

	@Override
	public Object retirarInicio() {
		confirmarNaoVazia();
		Object o = this.inicio.valor;
		this.inicio = this.inicio.proximo;
		this.tamanho--;
		if (vazia()) {
			this.fim = null;
		} else {
			this.inicio.anterior = null;
		}
		return o;
	}

	@Override
	public Object retirarFinal() {
		confirmarNaoVazia();
		Object o = this.fim.valor;
		this.fim = this.fim.anterior;
		this.tamanho--;
		if (vazia()) { 
			this.inicio = null;
		} else {
			this.fim.proximo = null;
		}
		return o;
	}

	private void confirmarNaoVazia() {
		if (vazia()) {
			throw new IllegalStateException(
					"Tentando retirar valor de uma deque vazia");
		}
	}

	@Override
	public Deque subDequeInicio(int n) {
		DequeEnc dqInicio = new DequeEnc();
		No noAtual = this.inicio;
		while ((noAtual != null) && (n-- > 0)) {
			dqInicio.inserirFinal(noAtual.valor);
			noAtual = noAtual.proximo; 
		}
		return dqInicio;
	}

	@Override
	public Deque subDequeFinal(int n) {
		DequeEnc dqFinal = new DequeEnc();
		No noAtual = this.fim;
		while ((noAtual != null) && (n-- > 0)) {
			dqFinal.inserirInicio(noAtual.valor);
			noAtual = noAtual.anterior; 
		}
		return dqFinal;
	}
}
