package teste2;

public interface Deque {
	/** Retorna o numero de elementos */
	long tamanho();
	/** Retorna true se o tamanho for igual a 0 */
	boolean vazia();
	/** Insere o objeto passado no Inicio da Deque */
	void inserirInicio(Object o);
	/** Insere o objeto passado no Final da Deque */	
	void inserirFinal(Object o);
	/** 
	 * Retira o objeto que esta no Inicio da Deque.
	 * @exception IllegalStateException quando a Deque esta vazia 
	 */
	Object retirarInicio();
	/**
	 * Retira o objeto que esta no Final da Deque
	 * @exception IllegalStateException quando a Deque esta vazia 
	 */
	Object retirarFinal();	
	/** 
	 * Retorna uma nova Deque contendo os n primeiros elementos da Deque atual. 
	 * Caso n seja maior que o tamanho da Deque, retorna todos os valores 
	 * contidos na Deque.
	 */
	Deque subDequeInicio(int n);
	/** 
	 * Retorna uma nova Deque contendo os n ultimos elementos da Deque atual.
	 * Caso n seja maior que o tamanho da Deque, retorna todos os valores 
	 * contidos na Deque. 
	 */
	Deque subDequeFinal(int n);
}
