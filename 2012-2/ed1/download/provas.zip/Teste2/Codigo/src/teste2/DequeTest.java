package teste2;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DequeTest {
	
	protected Deque deq;
	
	@Before
	public void setUp() throws Exception {
		deq = new DequeEnc();
		deq.inserirFinal("D");
		deq.inserirFinal("E");
		deq.inserirInicio("C");
	}

	@Test
	public void testInserirRetirarInicio() {
		// C D E		
		assertEquals("C", deq.retirarInicio());		
		// D E		
		deq.inserirInicio("B");		
		// B D E		
		assertEquals(3, deq.tamanho());		
		while (!deq.vazia()) {
			deq.retirarInicio();
		}		
		// Vazia
		deq.inserirInicio("a");		
		// a
		assertEquals("a", deq.retirarInicio());		
		// Vazia
		assertEquals(0, deq.tamanho());
	}

	@Test
	public void testInserirRetirarFinal() {
		// C D E
		while (!deq.vazia()) {
			deq.retirarFinal();
		}
		// Vazia		
		assertEquals(0, deq.tamanho());		
		deq.inserirFinal("A");
		// A
		deq.inserirFinal("B");
		// A B
		deq.inserirFinal("C");		
		// A B C
		assertEquals("C", deq.retirarFinal());		
		// A B		
		deq.inserirFinal("D");		
		// A B D		
		assertEquals(3, deq.tamanho());		
	}
	
	@Test
	public void testSubDeque() {
		// C D E
		deq.inserirFinal("F");
		// C D E F
		deq.inserirInicio("B");
		// B C D E F
		deq.inserirInicio("A");
		// A B C D E F
		
		Deque dqIgual = deq.subDequeInicio(10);
		assertEquals(6, dqIgual.tamanho());		
		assertEquals("A", deq.retirarInicio());
		// B C D E F
		assertEquals("F", deq.retirarFinal());
		
		// B C D E		
		Deque dqInicio = deq.subDequeInicio(2);		
		// dqInicio = B C
		assertEquals(2, dqInicio.tamanho());		
		assertEquals("B", dqInicio.retirarInicio());
		assertEquals("C", dqInicio.retirarFinal());

		Deque dqFinal = deq.subDequeFinal(2);
		// dqFinal = D E
		assertEquals(2, dqFinal.tamanho());		
		assertEquals("D", dqFinal.retirarInicio());
		
		
		// B C D E
		assertEquals(4, deq.tamanho());		
		assertEquals("B", deq.retirarInicio());
		assertEquals("E", deq.retirarFinal());
		
		// dqFinal = E
		Deque dqUnico = dqFinal.subDequeInicio(1);
		// dqUnico = E
		assertEquals(1, dqUnico.tamanho());
		assertEquals("E", dqUnico.retirarInicio());
	}	
}
