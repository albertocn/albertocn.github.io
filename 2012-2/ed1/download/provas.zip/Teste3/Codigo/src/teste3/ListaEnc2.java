package teste3;

import listas.ListaEnc;
import listas.NoEnc;

public class ListaEnc2 extends ListaEnc {

	public ListaEnc2 selecaoDireta() {
		ListaEnc2 copia = this.clonar();
		ListaEnc2 listaOrd = new ListaEnc2();

		while (copia.cabeca != null) {
			NoEnc noMaior = copia.retirarMaior();
			listaOrd.inserirNaCabeca(noMaior);
		}
		return listaOrd;
	}

	/**
	 * Copia os dados de uma lista para outra na mesma ordem da original.
	 */
	private ListaEnc2 clonar() {
		ListaEnc2 copia = new ListaEnc2();
		if (this.cabeca != null) {
			NoEnc atual = this.cabeca;
			NoEnc ultimoCopiado = copia.cabeca = copiarNo(atual);
			while (atual.getProximo() != null) {
				atual = atual.getProximo();
				ultimoCopiado.setProximo(copiarNo(atual));
				ultimoCopiado = ultimoCopiado.getProximo();
			}		
		}
		return copia;
	}

	/** 
	 * Retira o maior No da lista.
	 */
	private NoEnc retirarMaior() {		
		if (this.cabeca != null) {
			// Guarda referencia para o No antes do maior e para o maior
			NoEnc antesMaior = null;
			NoEnc maior = this.cabeca;
			// Guarda referencia para o No antes do atual e para o atual
			NoEnc antesAtual = this.cabeca;
			NoEnc atual = this.cabeca.getProximo();
			
			while (atual != null) {
				// Encontrou um No com chave Maior
				if (atual.getChave() > maior.getChave()) {
					antesMaior = antesAtual;
					maior = atual;
				}
				antesAtual = atual;
				atual = atual.getProximo();
			}

			if (antesMaior == null) {//this.cabeca == maior)  { // Retirada da cabeca
				this.cabeca = this.cabeca.getProximo();
			} else { // Retirada do meio
				antesMaior.setProximo(maior.getProximo());
			}
			// Retira referencia qeu tinha para o proximo na lista
			maior.setProximo(null);
			return maior;
		} else {		
			throw new IllegalStateException("Nenhum elemento na lista para ser retirado");
		}
	}

	/**
	 * Insere um no na cabeca da lista
	 */
	private void inserirNaCabeca(NoEnc no) {
		no.setProximo(this.cabeca);
		this.cabeca = no;		
	}

	private NoEnc copiarNo(NoEnc no) {
		return new NoEnc(no.getChave(), no.getInfo(), null);
	}
}