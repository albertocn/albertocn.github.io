package teste3;

import junit.framework.TestCase;

import listas.Iterador;
import listas.Lista;

import org.junit.Test;

public class ListaDEnc2Test extends TestCase {

	@Test
	public void testInsercaoDireta() {
		ListaDEnc2 l = criarLista();
	
		// Testa inserir e tamanho
		assertEquals(0, l.tamanho());
		preencher(l);
		assertEquals(5, l.tamanho());
		assertEquals(getToStringEsperado(), l.toString());
		
		ListaDEnc2 lOrd = l.insercaoDireta();
		assertEquals(getToStringEsperadoOrdenado(), lOrd.toString());

		assertEquals(5, l.tamanho());
		assertEquals(getToStringEsperado(), l.toString());

		Iterador it = lOrd.iterador();
		
		String[] objs = getOrdemObjetosIteracao();
		int pos = 0;
		
		while (it.temProximo()) {
			assertEquals(objs[pos++], it.getProximo());
		}
		
		assertFalse(it.temProximo());
	}
			
	protected String getToStringEsperado() {
		return "Tamanho = 5, Nos = [(4:D)(3:C)(5:E)(1:A)(2:B)]";
	}

	protected String getToStringEsperadoOrdenado() {
		return "Tamanho = 5, Nos = [(1:A)(2:B)(3:C)(4:D)(5:E)]";
	}

	protected String[] getOrdemObjetosIteracao() {		
		final String[] objs = {"A", "B", "C", "D", "E"};
		return objs;
	}
	
	protected ListaDEnc2 criarLista() {
		return new ListaDEnc2();
	}
	
	private void preencher(Lista lista) {
		assertTrue(lista.inserir(2, "B"));
		assertTrue(lista.inserir(1, "A"));
		assertTrue(lista.inserir(5, "E"));
		assertTrue(lista.inserir(3, "C"));
		assertTrue(lista.inserir(4, "D"));
		
		// (4:D)(3:C)(5:E)(1:A)(2:B)
	}	
}