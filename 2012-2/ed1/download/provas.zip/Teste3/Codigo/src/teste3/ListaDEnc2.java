package teste3;

import listas.ListaDEnc;
import listas.NoDEnc;

public class ListaDEnc2 extends ListaDEnc {

	public ListaDEnc2 insercaoDireta() {
		ListaDEnc2 listaOrd = new ListaDEnc2();

		NoDEnc noParaInserir = this.getCabeca();
		while (noParaInserir != null) {
			listaOrd.inserirNo(noParaInserir);
			noParaInserir = noParaInserir.getProximo();
		}
		return listaOrd;
	}

	private void inserirNo(NoDEnc noParaInserir) {

		// Quando vazia, ser� cabeca e cauda
		if (this.tamanho == 0) {
			this.cabeca = this.cauda = copiarNo(noParaInserir);
		} else {
			NoDEnc noImediatamenteMaior = encontrarImediatamenteMaior(noParaInserir);

			// noParaInserir maior que todos (nova cauda)
			if (noImediatamenteMaior == null) {
				this.cauda = copiarNo(noParaInserir, this.cauda, null);
				this.cauda.getAnterior().setProximo(this.cauda);
			} else {
				NoDEnc noCopiado = copiarNo(noParaInserir,
						noImediatamenteMaior.getAnterior(),
						noImediatamenteMaior);

				// noParaInserir menor que todos (nova cabeca)
				if (noImediatamenteMaior == this.cabeca) {
					this.cabeca = noCopiado;
					// noParaInserir entre cabeca e cauda
				} else {
					noCopiado.getAnterior().setProximo(noCopiado);
				}
				noCopiado.getProximo().setAnterior(noCopiado);
			}
		}
		this.tamanho++;
	}

	/**
	 * Encontra o no que tem a chave imediatamente maior que a do noParaInserir.
	 * Caso o noParaInserir tiver a chave maior que todos, sera retornado null,
	 * indicando que deve ser a nova Cauda.
	 */
	protected NoDEnc encontrarImediatamenteMaior(NoDEnc noParaInserir) {
		NoDEnc no = this.getCabeca();
		while ((no != null) && (no.getChave() < noParaInserir.getChave())) {
			no = no.getProximo();
		}
		return no;
	}

	private NoDEnc copiarNo(NoDEnc no, NoDEnc anterior, NoDEnc proximo) {
		return new NoDEnc(no.getChave(), no.getInfo(), anterior, proximo);
	}

	private NoDEnc copiarNo(NoDEnc no) {
		return new NoDEnc(no.getChave(), no.getInfo(), null, null);
	}
}