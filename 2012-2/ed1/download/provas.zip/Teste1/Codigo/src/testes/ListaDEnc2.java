package testes;

import listas.ListaDEnc;
import listas.NoDEnc;

public class ListaDEnc2 extends ListaDEnc {

	public ListaDEnc reversa() {
		ListaDEnc2 rev = new ListaDEnc2();
		NoDEnc PAtual = this.getCabeca();

		while (PAtual != null) {
			rev.cabeca = new NoDEnc(PAtual.getChave(), PAtual.getInfo(), null,
					rev.getCabeca());
			if (rev.cauda == null) { // Estava vazia
				rev.cauda = rev.getCabeca();
			} else {
				rev.getCabeca().getProximo().setAnterior(rev.getCabeca());
			}
			PAtual = PAtual.getProximo();
		}

		rev.tamanho = this.tamanho;
		return rev;
	}

	public ListaDEnc copiar() {
		ListaDEnc2 rev = new ListaDEnc2();

		NoDEnc PAtual = this.getCabeca();

		while (PAtual != null) {
			NoDEnc PNovo = new NoDEnc(PAtual.getChave(), PAtual.getInfo(),
					null, null);
			if (rev.cabeca == null) {
				rev.cabeca = PNovo;
			} else {
				rev.cauda.setProximo(PNovo);
				PNovo.setAnterior(rev.cauda);
			}
			rev.cauda = PNovo;
			PAtual = PAtual.getProximo();
		}

		rev.tamanho = this.tamanho;
		return rev;
	}

	public ListaDEnc extrairDuplicatas() {
		ListaDEnc2 lista = new ListaDEnc2();

		NoDEnc PAtual = this.getCabeca();

		while (PAtual != null) {
			NoDEnc PAnt = PAtual;
			NoDEnc PIgual = PAtual.getProximo();

			while (PIgual != null) {
				if (PIgual.getChave() == PAtual.getChave()) {					
					// Retira da lista atual
					PAnt.setProximo(PIgual.getProximo());					
					if (PAnt.getProximo() == null) {
						this.cauda = PAnt;
					} else {
						PAnt.getProximo().setAnterior(PAnt);
					}

					// Coloca na lista a ser retornada
					if (lista.cabeca == null) {
						// Na cabeca porque esta vazia
						lista.cabeca = PIgual;
					} else {
						// No final para manter a ordem
						lista.cauda.setProximo(PIgual);
						PIgual.setAnterior(lista.cauda);
					}
					PIgual.setProximo(null);
					lista.cauda = PIgual;
					
					this.tamanho--;
					lista.tamanho++;
				} else {
					PAnt = PIgual;
				}
				PIgual = PAnt.getProximo();
			}
			PAtual = PAtual.getProximo();
		}
		return lista;
	}
}
