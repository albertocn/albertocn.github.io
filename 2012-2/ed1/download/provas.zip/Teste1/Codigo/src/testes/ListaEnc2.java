package testes;

import listas.ListaEnc;
import listas.NoEnc;

public class ListaEnc2 extends ListaEnc {

	public ListaEnc reversa() {
		ListaEnc2 rev = new ListaEnc2();
		NoEnc PAtual = this.cabeca;

		while (PAtual != null) {
			rev.cabeca = new NoEnc(PAtual.getChave(), PAtual.getInfo(),
					rev.cabeca);
			PAtual = PAtual.getProximo();
		}

		return rev;
	}

	public ListaEnc copiar() {
		ListaEnc2 rev = new ListaEnc2();

		NoEnc PAtual = this.cabeca;
		NoEnc PUltRev = null;

		while (PAtual != null) {
			NoEnc PNovo = new NoEnc(PAtual.getChave(), PAtual.getInfo(), null);
			if (PUltRev == null) {
				rev.cabeca = PNovo;
			} else {
				PUltRev.setProximo(PNovo);
			}
			PUltRev = PNovo;
			PAtual = PAtual.getProximo();
		}

		return rev;
	}

	public ListaEnc extrairDuplicatas() {
		ListaEnc2 lista = new ListaEnc2();

		NoEnc PAtual = this.cabeca;
		NoEnc PUltListaDup = null;

		while (PAtual != null) {
			NoEnc PAnt = PAtual;
			NoEnc PIgual = PAtual.getProximo();

			while (PIgual != null) {
				if (PIgual.getChave() == PAtual.getChave()) {
					// Retira da lista atual
					PAnt.setProximo(PIgual.getProximo());

					// Coloca na lista a ser retornada
					if (PUltListaDup == null) {
						// Na cabeca porque esta vazia
						lista.cabeca = PIgual;
					} else {
						// No final para manter a ordem
						PUltListaDup.setProximo(PIgual);
					}
					PIgual.setProximo(null);
					PUltListaDup = PIgual;

				} else {
					PAnt = PIgual;
				}
				PIgual = PAnt.getProximo();
			}

			PAtual = PAtual.getProximo();
		}
		return lista;
	}
}
