package testes;

import static org.junit.Assert.*;

import listas.Lista;
import listas.ListaDEnc;

import org.junit.Before;
import org.junit.Test;

public class ListaDEnc2Test {

	ListaDEnc2 lista = null;
	
	@Before
	public void setUp() throws Exception {
		lista = new ListaDEnc2();		
	}

	@Test
	public final void testReversa() {
		preencher(lista);
		ListaDEnc rev = lista.reversa();
		assertEquals("Tamanho = 6, Nos = [(60:60)(50:50)(40:40)(30:30)(20:20)(10:10)]", lista.toString());
		assertEquals("Tamanho = 6, Nos = [(10:10)(20:20)(30:30)(40:40)(50:50)(60:60)]", rev.toString());
	}
	
	@Test
	public final void testCopiar() {
		preencher(lista);
		assertEquals("Tamanho = 6, Nos = [(60:60)(50:50)(40:40)(30:30)(20:20)(10:10)]", lista.toString());
		ListaDEnc l2 = lista.copiar();
		assertEquals("Tamanho = 6, Nos = [(60:60)(50:50)(40:40)(30:30)(20:20)(10:10)]", l2.toString());
	}

	@Test
	public final void testExtrairDuplicatas() {
		preencher(lista);
		assertEquals("Tamanho = 6, Nos = [(60:60)(50:50)(40:40)(30:30)(20:20)(10:10)]", 
				     lista.toString());
		
		ListaDEnc l2 = lista.extrairDuplicatas();		
		assertEquals("Tamanho = 6, Nos = [(60:60)(50:50)(40:40)(30:30)(20:20)(10:10)]", 
			         lista.toString());
		
		assertEquals("Tamanho = 0, Nos = []", l2.toString());
		
		lista.inserir(10, "10");
		lista.inserir(30, "30");
		lista.inserir(10, "10");
		lista.inserir(70, "70");
		lista.inserir(20, "20");
		
		assertEquals("Tamanho = 11, Nos = [(20:20)(70:70)(10:10)(30:30)(10:10)(60:60)(50:50)(40:40)(30:30)(20:20)(10:10)]",
				     lista.toString());
		ListaDEnc l3 = lista.extrairDuplicatas();
		assertEquals("Tamanho = 7, Nos = [(20:20)(70:70)(10:10)(30:30)(60:60)(50:50)(40:40)]", 
				     lista.toString());
		assertEquals("Tamanho = 4, Nos = [(20:20)(10:10)(10:10)(30:30)]", 
				     l3.toString());
	}

	protected void preencher(Lista l) {
		l.inserir(10, "10");
		l.inserir(20, "20");
		l.inserir(30, "30");
		l.inserir(40, "40");
		l.inserir(50, "50");
		l.inserir(60, "60");		
	}
}