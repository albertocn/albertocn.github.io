package colecoes;
import java.util.*;

public class TesteList {
    public static void main(String args[]) {

        // Insere algumas Strings na lista e teste os m�todos de consulta
        List lista = new ArrayList();
        lista.add("C");
        lista.add("B");
        lista.add("D");
        lista.add("B");
        lista.add("A");
        System.out.println(lista);
        System.out.println("lista[0]: " + lista.get(0));
        System.out.println("lista[2]: " + lista.get(2));
        System.out.println("indexOf(\"B\"): " + lista.indexOf("B") );
        System.out.println("lastIndexOf(\"B\"): " + lista.lastIndexOf("B") );

        // Insere A, B, C, D e E em na "fila". Em seguida, remove os dois
        // �ltimos, que s�o A e B (FIFO)
        LinkedList fila = new LinkedList();
        fila.addFirst("A");
        fila.addFirst("B");
        fila.addFirst("C");
        fila.addFirst("D");
        fila.addFirst("E");
        System.out.println(fila);
        fila.removeLast();
        fila.removeLast();
        System.out.println(fila);

        // Faz o mesmo que o bloco de comandos anterior, mas nao utiliza
        // os m�todos espec�ficos da classe LinkedList
        List fila2 = new LinkedList();
        fila2.add(0, "A");
        fila2.add(0, "B");
        fila2.add(0, "C");
        fila2.add(0, "D");
        fila2.add(0, "E");
        System.out.println(fila2);
        fila2.remove( fila2.size() - 1 );
        fila2.remove( fila2.size() - 1 );
        System.out.println(fila2);
    }
}