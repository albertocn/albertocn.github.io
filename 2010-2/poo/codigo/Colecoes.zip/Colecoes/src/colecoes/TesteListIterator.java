package colecoes;

import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

public class TesteListIterator {


  public static void main(String[] args) {
    List lista = new LinkedList();
    for (int i = 1; i <= 10; i++) {
      lista.add( "S" + i );
    }
    System.out.println(lista);

    imprimirMeioParaInicio( lista );
  }

  private static void imprimirMeioParaInicio( List l ) {
    ListIterator it = l.listIterator( l.size() / 2 );
    System.out.print('[');
    while (it.hasPrevious()) {
      System.out.print( it.previous() );
      if (it.hasPrevious())
        System.out.print(", ");
    }
    System.out.println(']');
  }
}