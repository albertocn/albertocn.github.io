package br.ufs.dcce.entity;

import junit.framework.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.rmi.RemoteException;
import java.util.Properties;

public class AlunoTest extends TestCase {
  private static final String BANCO = "DCCE1";

  private static final String ERROR_NULL_REMOTE = "Remote interface reference is null.  It must be created by calling one of the Home interface methods first.  Make sure that the setUp() method calls one of the create() or finder Home interface wrappers, or the alunoRemote remote reference is assigned there in some other way.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = true;
  private AlunoRemoteHome alunoRemoteHome = null;
  private AlunoRemote alunoRemote = null;

  //Construct the EJB test client
  public AlunoTest(String name) {
    super(name);
  }

  public void initialize() throws Exception {

    long startTime = 0;
    if (logging) {
      log("Initializing bean access.");
      startTime = System.currentTimeMillis();
    }
    //get naming context
    Context context = createContext();

    //look up jndi name
    Object ref = context.lookup(BANCO + '.' +"AlunoRemote");
    //look up jndi name and cast to Home interface
    alunoRemoteHome = (AlunoRemoteHome) PortableRemoteObject.narrow(ref, AlunoRemoteHome.class);
    if (logging) {
      long endTime = System.currentTimeMillis();
      log("Succeeded initializing bean access through Home interface.");
      log("Execution time: " + (endTime - startTime) + " ms.");
    }
  }

  public void setUp() throws Exception {
    super.setUp();
    initialize();

    alunoRemote = findByPrimaryKey("95110523");
  }

  public void tearDown() throws Exception {
    alunoRemoteHome = null;
    alunoRemote = null;
    super.tearDown();
  }

  //----------------------------------------------------------------------------
  // Methods that use Home interface methods to generate a Remote interface reference
  //----------------------------------------------------------------------------

  public AlunoRemote findByPrimaryKey(String matricula) throws Exception {
    long startTime = 0;
    if (logging) {
      log("Calling findByPrimaryKey(" + matricula + ")");
      startTime = System.currentTimeMillis();
    }
    alunoRemote = alunoRemoteHome.findByPrimaryKey(matricula);
    if (logging) {
      long endTime = System.currentTimeMillis();
      log("Succeeded: findByPrimaryKey(" + matricula + ")");
      log("Execution time: " + (endTime - startTime) + " ms.");
    }

    if (logging) {
      log("Return value from findByPrimaryKey(" + matricula + "): " + alunoRemote + ".");
    }
    return alunoRemote;
  }

  //----------------------------------------------------------------------------
  // Methods that use Remote interface methods to access data through the bean
  //----------------------------------------------------------------------------

  public void testGetMatricula() throws RemoteException {
    assertNotNull(ERROR_NULL_REMOTE, alunoRemote);

    long startTime = 0;
    if (logging) {
      log("Calling getMatricula()");
      startTime = System.currentTimeMillis();
    }
    alunoRemote.getMatricula();
    if (logging) {
      long endTime = System.currentTimeMillis();
      log("Succeeded: getMatricula()");
      log("Execution time: " + (endTime - startTime) + " ms.");
    }
  }

  public void testGetNome() throws RemoteException {
    assertNotNull(ERROR_NULL_REMOTE, alunoRemote);

    long startTime = 0;
    if (logging) {
      log("Calling getNome()");
      startTime = System.currentTimeMillis();
    }
    alunoRemote.getNome();
    if (logging) {
      long endTime = System.currentTimeMillis();
      log("Succeeded: getNome()");
      log("Execution time: " + (endTime - startTime) + " ms.");
    }
  }

  public void testGetSituacao() throws RemoteException {
    assertNotNull(ERROR_NULL_REMOTE, alunoRemote);

    long startTime = 0;
    if (logging) {
      log("Calling getSituacao()");
      startTime = System.currentTimeMillis();
    }
    alunoRemote.getSituacao();
    if (logging) {
      long endTime = System.currentTimeMillis();
      log("Succeeded: getSituacao()");
      log("Execution time: " + (endTime - startTime) + " ms.");
    }
  }

  public void testGetCurso() throws RemoteException {
    assertNotNull(ERROR_NULL_REMOTE, alunoRemote);

    long startTime = 0;
    if (logging) {
      log("Calling getCurso()");
      startTime = System.currentTimeMillis();
    }
    alunoRemote.getCurso();
    if (logging) {
      long endTime = System.currentTimeMillis();
      log("Succeeded: getCurso()");
      log("Execution time: " + (endTime - startTime) + " ms.");
    }
  }

  public Context createContext() throws NamingException {
    Properties prop = new Properties();
    prop.setProperty(Context.INITIAL_CONTEXT_FACTORY,
                     "org.jnp.interfaces.NamingContextFactory");
    prop.setProperty(Context.URL_PKG_PREFIXES,
                     "org.jboss.naming:org.jnp.interfaces");
    prop.setProperty(Context.PROVIDER_URL,
                     "machadinho");

    return new InitialContext( prop );
  }



  //----------------------------------------------------------------------------
  // Utility Methods
  //----------------------------------------------------------------------------

  private void log(String message) {
    if (message == null) {
      System.out.println("-- null");
      return ;
    }
    if (message.length() > MAX_OUTPUT_LINE_LENGTH) {
      System.out.println("-- " + message.substring(0, MAX_OUTPUT_LINE_LENGTH) + " ...");
    }
    else {
      System.out.println("-- " + message);
    }
  }
}