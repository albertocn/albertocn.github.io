package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface UsuarioSistemasHome extends javax.ejb.EJBLocalHome {
  public UsuarioSistemas create(String id, String tipo, String senha, String email, Short tentativasAcesso, String bloqueado) throws CreateException;
  public UsuarioSistemas findByPrimaryKey(String id) throws FinderException;
}