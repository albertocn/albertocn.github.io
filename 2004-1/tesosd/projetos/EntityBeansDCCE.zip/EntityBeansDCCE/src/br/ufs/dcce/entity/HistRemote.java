package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface HistRemote extends javax.ejb.EJBObject {
  public String getDisc() throws RemoteException;
  public void setTurma(String turma) throws RemoteException;
  public String getTurma() throws RemoteException;
  public void setAno(String ano) throws RemoteException;
  public String getAno() throws RemoteException;
  public void setPeriodo(String periodo) throws RemoteException;
  public String getPeriodo() throws RemoteException;
  public void setAluno(String aluno) throws RemoteException;
  public String getAluno() throws RemoteException;
  public void setSituacao(String situacao) throws RemoteException;
  public String getSituacao() throws RemoteException;
}