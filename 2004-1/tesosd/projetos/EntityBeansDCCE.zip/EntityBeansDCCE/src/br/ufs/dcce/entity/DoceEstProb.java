package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface DoceEstProb extends javax.ejb.EJBLocalObject {
  public String getMatricula();
  public void setConcluido(String concluido);
  public String getConcluido();
}