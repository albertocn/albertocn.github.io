package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface Ditu extends javax.ejb.EJBLocalObject {
  public String getTurma();
  public String getDisciplina();
  public Integer getAno();
  public Short getPeriodo();
}