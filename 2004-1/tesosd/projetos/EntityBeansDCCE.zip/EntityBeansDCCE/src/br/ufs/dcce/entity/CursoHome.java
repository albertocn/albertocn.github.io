package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface CursoHome extends javax.ejb.EJBLocalHome {
  public Curso findByPrimaryKey(Short codigo) throws FinderException;
}