package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface FormAvDoceEstProbRemote extends javax.ejb.EJBObject {
  public Integer getCodigoAvaliacao() throws RemoteException;
  public String getMatrAluno() throws RemoteException;
  public void setDataPreenchimento(Timestamp dataPreenchimento) throws RemoteException;
  public Timestamp getDataPreenchimento() throws RemoteException;
  public void setResp11(Short resp11) throws RemoteException;
  public Short getResp11() throws RemoteException;
  public void setResp12(Short resp12) throws RemoteException;
  public Short getResp12() throws RemoteException;
  public void setResp13(Short resp13) throws RemoteException;
  public Short getResp13() throws RemoteException;
  public void setResp21(Short resp21) throws RemoteException;
  public Short getResp21() throws RemoteException;
  public void setResp22(Short resp22) throws RemoteException;
  public Short getResp22() throws RemoteException;
  public void setResp23(Short resp23) throws RemoteException;
  public Short getResp23() throws RemoteException;
  public void setResp24(Short resp24) throws RemoteException;
  public Short getResp24() throws RemoteException;
  public void setResp25(Short resp25) throws RemoteException;
  public Short getResp25() throws RemoteException;
  public void setResp26(Short resp26) throws RemoteException;
  public Short getResp26() throws RemoteException;
  public void setResp31(Short resp31) throws RemoteException;
  public Short getResp31() throws RemoteException;
  public void setResp32(Short resp32) throws RemoteException;
  public Short getResp32() throws RemoteException;
  public void setResp41(Short resp41) throws RemoteException;
  public Short getResp41() throws RemoteException;
  public void setResp42(Short resp42) throws RemoteException;
  public Short getResp42() throws RemoteException;
  public void setResp51(Short resp51) throws RemoteException;
  public Short getResp51() throws RemoteException;
  public void setResp52(Short resp52) throws RemoteException;
  public Short getResp52() throws RemoteException;
  public void setResp53(Short resp53) throws RemoteException;
  public Short getResp53() throws RemoteException;
  public void setResp54(Short resp54) throws RemoteException;
  public Short getResp54() throws RemoteException;
}