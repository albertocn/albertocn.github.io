package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface Aluno extends javax.ejb.EJBLocalObject {
  public String getMatricula();
  public String getNome();
  public Short getSituacao();
  public Short getCurso();
}