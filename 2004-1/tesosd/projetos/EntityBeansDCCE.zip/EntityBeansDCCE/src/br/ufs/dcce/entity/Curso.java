package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface Curso extends javax.ejb.EJBLocalObject {
  public Short getCodigo();
  public String getNome();
}