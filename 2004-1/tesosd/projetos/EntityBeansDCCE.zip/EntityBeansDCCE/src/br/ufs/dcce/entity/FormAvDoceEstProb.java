package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.sql.*;

public interface FormAvDoceEstProb extends javax.ejb.EJBLocalObject {
  public Integer getCodigoAvaliacao();
  public String getMatrAluno();
  public void setDataPreenchimento(Timestamp dataPreenchimento);
  public Timestamp getDataPreenchimento();
  public void setResp11(Short resp11);
  public Short getResp11();
  public void setResp12(Short resp12);
  public Short getResp12();
  public void setResp13(Short resp13);
  public Short getResp13();
  public void setResp21(Short resp21);
  public Short getResp21();
  public void setResp22(Short resp22);
  public Short getResp22();
  public void setResp23(Short resp23);
  public Short getResp23();
  public void setResp24(Short resp24);
  public Short getResp24();
  public void setResp25(Short resp25);
  public Short getResp25();
  public void setResp26(Short resp26);
  public Short getResp26();
  public void setResp31(Short resp31);
  public Short getResp31();
  public void setResp32(Short resp32);
  public Short getResp32();
  public void setResp41(Short resp41);
  public Short getResp41();
  public void setResp42(Short resp42);
  public Short getResp42();
  public void setResp51(Short resp51);
  public Short getResp51();
  public void setResp52(Short resp52);
  public Short getResp52();
  public void setResp53(Short resp53);
  public Short getResp53();
  public void setResp54(Short resp54);
  public Short getResp54();
}