package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface AvCursoDoceHome extends javax.ejb.EJBLocalHome {
  public AvCursoDoce create(Integer codigo, Integer ano, Short periodo, String situacao) throws CreateException;
  public AvCursoDoce findByPrimaryKey(Integer codigo) throws FinderException;
}