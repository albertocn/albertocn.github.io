package br.ufs.dcce.entity;

import javax.ejb.*;

abstract public class FormAvDoceEstProbBean implements EntityBean {
  EntityContext entityContext;
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setCodigoAvaliacao(java.lang.Integer codigoAvaliacao);
  public abstract void setMatrAluno(java.lang.String matrAluno);
  public abstract void setDataPreenchimento(java.sql.Timestamp dataPreenchimento);
  public abstract void setResp11(java.lang.Short resp11);
  public abstract void setResp12(java.lang.Short resp12);
  public abstract void setResp13(java.lang.Short resp13);
  public abstract void setResp21(java.lang.Short resp21);
  public abstract void setResp22(java.lang.Short resp22);
  public abstract void setResp23(java.lang.Short resp23);
  public abstract void setResp24(java.lang.Short resp24);
  public abstract void setResp25(java.lang.Short resp25);
  public abstract void setResp26(java.lang.Short resp26);
  public abstract void setResp31(java.lang.Short resp31);
  public abstract void setResp32(java.lang.Short resp32);
  public abstract void setResp41(java.lang.Short resp41);
  public abstract void setResp42(java.lang.Short resp42);
  public abstract void setResp51(java.lang.Short resp51);
  public abstract void setResp52(java.lang.Short resp52);
  public abstract void setResp53(java.lang.Short resp53);
  public abstract void setResp54(java.lang.Short resp54);
  public abstract java.lang.Integer getCodigoAvaliacao();
  public abstract java.lang.String getMatrAluno();
  public abstract java.sql.Timestamp getDataPreenchimento();
  public abstract java.lang.Short getResp11();
  public abstract java.lang.Short getResp12();
  public abstract java.lang.Short getResp13();
  public abstract java.lang.Short getResp21();
  public abstract java.lang.Short getResp22();
  public abstract java.lang.Short getResp23();
  public abstract java.lang.Short getResp24();
  public abstract java.lang.Short getResp25();
  public abstract java.lang.Short getResp26();
  public abstract java.lang.Short getResp31();
  public abstract java.lang.Short getResp32();
  public abstract java.lang.Short getResp41();
  public abstract java.lang.Short getResp42();
  public abstract java.lang.Short getResp51();
  public abstract java.lang.Short getResp52();
  public abstract java.lang.Short getResp53();
  public abstract java.lang.Short getResp54();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
  public FormAvDoceEstProbPK ejbCreate(Integer codigoAvaliacao, String matrAluno, java.sql.Timestamp dataPreenchimento, Short resp11, Short resp12, Short resp13, Short resp21, Short resp22, Short resp23, Short resp24, Short resp25, Short resp26, Short resp31, Short resp32, Short resp41, Short resp42, Short resp51, Short resp52, Short resp53, Short resp54) throws CreateException {
    setCodigoAvaliacao(codigoAvaliacao);
    setMatrAluno(matrAluno);
    setDataPreenchimento(dataPreenchimento);
    setResp11( resp11);
    setResp12( resp12);
    setResp13( resp13);
    setResp21( resp21);
    setResp22( resp22);
    setResp23( resp23);
    setResp24( resp24);
    setResp25( resp25);
    setResp26( resp26);
    setResp31( resp31);
    setResp32( resp32);
    setResp41( resp41);
    setResp42( resp42);
    setResp51( resp51);
    setResp52( resp52);
    setResp53( resp53);
    setResp54( resp54);
    return null;
  }
  public void ejbPostCreate(Integer codigoAvaliacao, String matrAluno, java.sql.Timestamp dataPreenchimento, Short resp11, Short resp12, Short resp13, Short resp21, Short resp22, Short resp23, Short resp24, Short resp25, Short resp26, Short resp31, Short resp32, Short resp41, Short resp42, Short resp51, Short resp52, Short resp53, Short resp54) throws CreateException {
    /**@todo Complete this method*/
  }
}