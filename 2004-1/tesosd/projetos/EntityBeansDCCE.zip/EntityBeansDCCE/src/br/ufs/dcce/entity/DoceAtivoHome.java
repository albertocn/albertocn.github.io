package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface DoceAtivoHome extends javax.ejb.EJBLocalHome {
  public DoceAtivo create(String matricula, String vinculo, String titulacao, String email, String linkHomepage, String linkLattes, String telefones) throws CreateException;
  public DoceAtivo findByPrimaryKey(String matricula) throws FinderException;
}