package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface UsuarioSistemas extends javax.ejb.EJBLocalObject {
  public String getId();
  public void setTipo(String tipo);
  public String getTipo();
  public void setSenha(String senha);
  public String getSenha();
  public void setEmail(String email);
  public String getEmail();
  public void setTentativasAcesso(Short tentativasAcesso);
  public Short getTentativasAcesso();
  public void setBloqueado(String bloqueado);
  public String getBloqueado();
}