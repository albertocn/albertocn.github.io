package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface AvCursoDoceRemote extends javax.ejb.EJBObject {
  public Integer getCodigo() throws RemoteException;
  public void setAno(Integer ano) throws RemoteException;
  public Integer getAno() throws RemoteException;
  public void setPeriodo(Short periodo) throws RemoteException;
  public Short getPeriodo() throws RemoteException;
  public void setSituacao(String situacao) throws RemoteException;
  public String getSituacao() throws RemoteException;
}