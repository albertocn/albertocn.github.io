package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface FormAvDoceRemoteHome extends javax.ejb.EJBHome {
  public FormAvDoceRemote create(Integer codigoAvaliacao, String matrDoce, String matrAluno, Timestamp dataPreenchimento, Short resp01, Short resp02, Short resp03, Short resp04, Short resp05, Short resp06, Short resp07, Short resp08, Short resp09, Short resp11, Short resp10, Short resp12, Short resp13, Short resp14) throws CreateException, RemoteException;
  public FormAvDoceRemote findByPrimaryKey(FormAvDocePK pk) throws FinderException, RemoteException;
}