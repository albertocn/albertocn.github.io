package br.ufs.dcce.entity;

import javax.ejb.*;

abstract public class UsuarioSistemasBean implements EntityBean {
  EntityContext entityContext;
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setId(java.lang.String id);
  public abstract void setTipo(java.lang.String tipo);
  public abstract void setSenha(java.lang.String senha);
  public abstract void setEmail(java.lang.String email);
  public abstract void setTentativasAcesso(java.lang.Short tentativasAcesso);
  public abstract void setBloqueado(java.lang.String bloqueado);
  public abstract java.lang.String getId();
  public abstract java.lang.String getTipo();
  public abstract java.lang.String getSenha();
  public abstract java.lang.String getEmail();
  public abstract java.lang.Short getTentativasAcesso();
  public abstract java.lang.String getBloqueado();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
  public java.lang.String ejbCreate(String id, String tipo, String senha, String email, Short tentativasAcesso, String bloqueado) throws CreateException {
    setId(id);
    setTipo(tipo);
    setSenha(senha);
    setEmail(email);
    setTentativasAcesso(tentativasAcesso);
    setBloqueado(bloqueado);

    return null;
  }
  public void ejbPostCreate(String id, String tipo, String senha, String email, Short tentativasAcesso, String bloqueado) throws CreateException {
  }
}