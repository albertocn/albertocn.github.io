package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface AvDocEstProb extends javax.ejb.EJBLocalObject {
  public Integer getCodigo();
  public void setAno(Integer ano);
  public Integer getAno();
  public void setPeriodo(Short periodo);
  public Short getPeriodo();
  public void setMatrDoce(String matrDoce);
  public String getMatrDoce();
  public void setMatrOrientador(String matrOrientador);
  public String getMatrOrientador();
  public void setSituacao(String situacao);
  public String getSituacao();
}