package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface DoceHome extends javax.ejb.EJBLocalHome {
  public Doce findByPrimaryKey(String matricula) throws FinderException;
}