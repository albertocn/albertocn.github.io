package br.ufs.dcce.entity;

import javax.ejb.*;

abstract public class HistBean implements EntityBean {
  EntityContext entityContext;
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setDisc(java.lang.String disc);
  public abstract void setTurma(java.lang.String turma);
  public abstract void setAno(java.lang.String ano);
  public abstract void setPeriodo(java.lang.String periodo);
  public abstract void setAluno(java.lang.String aluno);
  public abstract void setSituacao(java.lang.String situacao);
  public abstract java.lang.String getDisc();
  public abstract java.lang.String getTurma();
  public abstract java.lang.String getAno();
  public abstract java.lang.String getPeriodo();
  public abstract java.lang.String getAluno();
  public abstract java.lang.String getSituacao();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}