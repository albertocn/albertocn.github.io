package br.ufs.dcce.entity;

import javax.ejb.*;

abstract public class DituBean implements EntityBean {
  EntityContext entityContext;
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setTurma(java.lang.String turma);
  public abstract void setDisciplina(java.lang.String disciplina);
  public abstract void setAno(java.lang.Integer ano);
  public abstract void setPeriodo(java.lang.Short periodo);
  public abstract java.lang.String getTurma();
  public abstract java.lang.String getDisciplina();
  public abstract java.lang.Integer getAno();
  public abstract java.lang.Short getPeriodo();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}