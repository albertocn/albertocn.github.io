package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.sql.*;

public interface EmailCadastradoHome extends javax.ejb.EJBLocalHome {
  public EmailCadastrado create(String id, String tipo, String email, Timestamp dataCadastro, Timestamp dataAtualizado) throws CreateException;
  public EmailCadastrado findByPrimaryKey(String id) throws FinderException;
}