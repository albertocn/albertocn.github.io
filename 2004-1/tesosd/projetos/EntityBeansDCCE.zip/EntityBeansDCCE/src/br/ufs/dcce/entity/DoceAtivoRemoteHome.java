package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface DoceAtivoRemoteHome extends javax.ejb.EJBHome {
  public DoceAtivoRemote create(String matricula, String vinculo, String titulacao, String email, String linkHomepage, String linkLattes, String telefones) throws CreateException, RemoteException;
  public DoceAtivoRemote findByPrimaryKey(String matricula) throws FinderException, RemoteException;
}