package br.ufs.dcce.entity;

import javax.ejb.*;

abstract public class FormAvCursoBean implements EntityBean {
  EntityContext entityContext;
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setCodigoAvaliacao(java.lang.Integer codigoAvaliacao);
  public abstract void setMatrAluno(java.lang.String matrAluno);
  public abstract void setDataPreenchimento(java.sql.Timestamp dataPreenchimento);
  public abstract void setResp01(java.lang.Short resp01);
  public abstract void setResp02(java.lang.Short resp02);
  public abstract void setResp03(java.lang.Short resp03);
  public abstract void setResp04(java.lang.Short resp04);
  public abstract void setResp05(java.lang.Short resp05);
  public abstract void setResp06(java.lang.Short resp06);
  public abstract void setResp07(java.lang.Short resp07);
  public abstract void setResp08(java.lang.Short resp08);
  public abstract void setResp09(java.lang.Short resp09);
  public abstract void setResp10(java.lang.Short resp10);
  public abstract void setResp11(java.lang.Short resp11);
  public abstract void setResp12(java.lang.Short resp12);
  public abstract void setResp13(java.lang.Short resp13);
  public abstract void setResp14(java.lang.Short resp14);
  public abstract void setPontosFortes(java.lang.String pontosFortes);
  public abstract void setPontosFracos(java.lang.String pontosFracos);
  public abstract void setSugestoesMelhorias(java.lang.String sugestoesMelhorias);
  public abstract java.lang.Integer getCodigoAvaliacao();
  public abstract java.lang.String getMatrAluno();
  public abstract java.sql.Timestamp getDataPreenchimento();
  public abstract java.lang.Short getResp01();
  public abstract java.lang.Short getResp02();
  public abstract java.lang.Short getResp03();
  public abstract java.lang.Short getResp04();
  public abstract java.lang.Short getResp05();
  public abstract java.lang.Short getResp06();
  public abstract java.lang.Short getResp07();
  public abstract java.lang.Short getResp08();
  public abstract java.lang.Short getResp09();
  public abstract java.lang.Short getResp10();
  public abstract java.lang.Short getResp11();
  public abstract java.lang.Short getResp12();
  public abstract java.lang.Short getResp13();
  public abstract java.lang.Short getResp14();
  public abstract java.lang.String getPontosFortes();
  public abstract java.lang.String getPontosFracos();
  public abstract java.lang.String getSugestoesMelhorias();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
  public FormAvCursoPK ejbCreate(Integer codigoAvaliacao, String matrAluno, java.sql.Timestamp dataPreenchimento, Short resp01, Short resp02, Short resp03, Short resp04, Short resp05, Short resp06, Short resp07, Short resp08, Short resp09, Short resp10, Short resp11, Short resp12, Short resp13, Short resp14, String pontosFortes, String pontosFracos, String sugestoesMelhorias) throws CreateException {
     setCodigoAvaliacao(codigoAvaliacao);
     setMatrAluno(matrAluno);
     setDataPreenchimento(dataPreenchimento);
     setResp01(resp01);
     setResp02(resp02);
     setResp03(resp03);
     setResp04(resp04);
     setResp05(resp05);
     setResp06(resp06);
     setResp07(resp07);
     setResp08(resp08);
     setResp09(resp09);
     setResp10(resp10);
     setResp11(resp11);
     setResp12(resp12);
     setResp13(resp13);
     setResp14(resp14);
     setPontosFortes(pontosFortes);
     setPontosFracos(pontosFracos);
     setSugestoesMelhorias(sugestoesMelhorias);

    return null;
  }
  public void ejbPostCreate(Integer codigoAvaliacao, String matrAluno, java.sql.Timestamp dataPreenchimento, Short resp01, Short resp02, Short resp03, Short resp04, Short resp05, Short resp06, Short resp07, Short resp08, Short resp09, Short resp10, Short resp11, Short resp12, Short resp13, Short resp14, String pontosFortes, String pontosFracos, String sugestoesMelhorias) throws CreateException {
    /**@todo Complete this method*/
  }
}