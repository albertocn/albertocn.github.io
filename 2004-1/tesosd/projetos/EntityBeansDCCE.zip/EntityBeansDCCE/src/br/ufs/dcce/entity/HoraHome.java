package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface HoraHome extends javax.ejb.EJBLocalHome {
  public Hora findByPrimaryKey(String disciplina) throws FinderException;
}