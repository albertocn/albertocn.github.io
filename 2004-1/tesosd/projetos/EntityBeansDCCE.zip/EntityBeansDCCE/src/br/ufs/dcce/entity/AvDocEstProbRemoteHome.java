package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface AvDocEstProbRemoteHome extends javax.ejb.EJBHome {
  public AvDocEstProbRemote create(Integer codigo, Integer ano, Short periodo, String matrDoce, String matrOrientador, String situacao) throws CreateException, RemoteException;
  public AvDocEstProbRemote findByPrimaryKey(Integer codigo) throws FinderException, RemoteException;
}