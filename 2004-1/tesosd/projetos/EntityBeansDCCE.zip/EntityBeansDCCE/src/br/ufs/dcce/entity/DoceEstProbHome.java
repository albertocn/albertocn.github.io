package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface DoceEstProbHome extends javax.ejb.EJBLocalHome {
  public DoceEstProb findByPrimaryKey(String matricula) throws FinderException;
}