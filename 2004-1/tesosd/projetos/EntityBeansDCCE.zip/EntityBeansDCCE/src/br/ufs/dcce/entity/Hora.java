package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface Hora extends javax.ejb.EJBLocalObject {
  public String getDisciplina();
  public String getTurma();
  public Short getPeriodo();
  public Integer getAno();
  public String getDocente();
}