package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface DoceAtivoRemote extends javax.ejb.EJBObject {
  public String getMatricula() throws RemoteException;
  public void setVinculo(String vinculo) throws RemoteException;
  public String getVinculo() throws RemoteException;
  public void setTitulacao(String titulacao) throws RemoteException;
  public String getTitulacao() throws RemoteException;
  public void setEmail(String email) throws RemoteException;
  public String getEmail() throws RemoteException;
  public void setLinkHomepage(String linkHomepage) throws RemoteException;
  public String getLinkHomepage() throws RemoteException;
  public void setLinkLattes(String linkLattes) throws RemoteException;
  public String getLinkLattes() throws RemoteException;
  public void setTelefones(String telefones) throws RemoteException;
  public String getTelefones() throws RemoteException;
}