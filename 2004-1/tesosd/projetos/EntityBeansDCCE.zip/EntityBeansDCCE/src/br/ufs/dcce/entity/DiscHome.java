package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface DiscHome extends javax.ejb.EJBLocalHome {
  public Disc findByPrimaryKey(String codigo) throws FinderException;
}