package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface DoceRemote extends javax.ejb.EJBObject {
  public String getMatricula() throws RemoteException;
  public String getNome() throws RemoteException;
}