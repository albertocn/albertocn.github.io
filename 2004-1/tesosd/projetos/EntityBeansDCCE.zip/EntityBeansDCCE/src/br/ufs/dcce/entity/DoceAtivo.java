package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface DoceAtivo extends javax.ejb.EJBLocalObject {
  public String getMatricula();
  public void setVinculo(String vinculo);
  public String getVinculo();
  public void setTitulacao(String titulacao);
  public String getTitulacao();
  public void setEmail(String email);
  public String getEmail();
  public void setLinkHomepage(String linkHomepage);
  public String getLinkHomepage();
  public void setLinkLattes(String linkLattes);
  public String getLinkLattes();
  public void setTelefones(String telefones);
  public String getTelefones();
}