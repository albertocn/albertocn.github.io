package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface EmailCadastradoRemote extends javax.ejb.EJBObject {
  public String getId() throws RemoteException;
  public void setTipo(String tipo) throws RemoteException;
  public String getTipo() throws RemoteException;
  public void setEmail(String email) throws RemoteException;
  public String getEmail() throws RemoteException;
  public void setDataCadastro(Timestamp dataCadastro) throws RemoteException;
  public Timestamp getDataCadastro() throws RemoteException;
  public void setDataAtualizado(Timestamp dataAtualizado) throws RemoteException;
  public Timestamp getDataAtualizado() throws RemoteException;
}