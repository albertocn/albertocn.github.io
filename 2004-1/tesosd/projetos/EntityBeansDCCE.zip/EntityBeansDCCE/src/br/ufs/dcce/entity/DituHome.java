package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface DituHome extends javax.ejb.EJBLocalHome {
  public Ditu findByPrimaryKey(String turma) throws FinderException;
}