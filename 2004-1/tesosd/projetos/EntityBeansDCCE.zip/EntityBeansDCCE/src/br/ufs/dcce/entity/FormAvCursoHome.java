package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.sql.*;

public interface FormAvCursoHome extends javax.ejb.EJBLocalHome {
  public FormAvCurso create(Integer codigoAvaliacao, String matrAluno, Timestamp dataPreenchimento, Short resp01, Short resp02, Short resp03, Short resp04, Short resp05, Short resp06, Short resp07, Short resp08, Short resp09, Short resp10, Short resp11, Short resp12, Short resp13, Short resp14, String pontosFortes, String pontosFracos, String sugestoesMelhorias) throws CreateException;
  public FormAvCurso findByPrimaryKey(FormAvCursoPK pk) throws FinderException;
}