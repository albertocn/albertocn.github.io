package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface AlunoRemoteHome extends javax.ejb.EJBHome {
  public AlunoRemote findByPrimaryKey(String matricula) throws FinderException, RemoteException;
}