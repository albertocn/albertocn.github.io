package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CursoRemote extends javax.ejb.EJBObject {
  public Short getCodigo() throws RemoteException;
  public String getNome() throws RemoteException;
}