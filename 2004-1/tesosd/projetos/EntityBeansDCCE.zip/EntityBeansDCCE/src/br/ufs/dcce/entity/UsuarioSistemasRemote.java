package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface UsuarioSistemasRemote extends javax.ejb.EJBObject {
  public String getId() throws RemoteException;
  public void setTipo(String tipo) throws RemoteException;
  public String getTipo() throws RemoteException;
  public void setSenha(String senha) throws RemoteException;
  public String getSenha() throws RemoteException;
  public void setEmail(String email) throws RemoteException;
  public String getEmail() throws RemoteException;
  public void setTentativasAcesso(Short tentativasAcesso) throws RemoteException;
  public Short getTentativasAcesso() throws RemoteException;
  public void setBloqueado(String bloqueado) throws RemoteException;
  public String getBloqueado() throws RemoteException;
}