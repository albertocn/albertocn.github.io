package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface HoraRemoteHome extends javax.ejb.EJBHome {
  public HoraRemote findByPrimaryKey(String disciplina) throws FinderException, RemoteException;
}