package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface DoceEstProbRemoteHome extends javax.ejb.EJBHome {
  public DoceEstProbRemote findByPrimaryKey(String matricula) throws FinderException, RemoteException;
}