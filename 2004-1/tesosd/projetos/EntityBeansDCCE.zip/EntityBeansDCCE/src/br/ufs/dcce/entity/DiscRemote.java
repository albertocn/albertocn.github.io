package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface DiscRemote extends javax.ejb.EJBObject {
  public String getCodigo() throws RemoteException;
  public void setNome(String nome) throws RemoteException;
  public String getNome() throws RemoteException;
  public void setCreditos(Short creditos) throws RemoteException;
  public Short getCreditos() throws RemoteException;
  public void setDepartamento(Short departamento) throws RemoteException;
  public Short getDepartamento() throws RemoteException;
}