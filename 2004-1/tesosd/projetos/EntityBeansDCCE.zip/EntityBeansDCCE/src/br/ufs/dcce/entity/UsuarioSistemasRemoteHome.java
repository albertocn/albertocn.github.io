package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface UsuarioSistemasRemoteHome extends javax.ejb.EJBHome {
  public UsuarioSistemasRemote create(String id, String tipo, String senha, String email, Short tentativasAcesso, String bloqueado) throws CreateException, RemoteException;
  public UsuarioSistemasRemote findByPrimaryKey(String id) throws FinderException, RemoteException;
}