package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface HistRemoteHome extends javax.ejb.EJBHome {
  public HistRemote findByPrimaryKey(String disc) throws FinderException, RemoteException;
}