package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface HistHome extends javax.ejb.EJBLocalHome {
  public Hist findByPrimaryKey(String disc) throws FinderException;
}