package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.sql.*;

public interface FormAvDoceEstProbHome extends javax.ejb.EJBLocalHome {
  public FormAvDoceEstProb create(Integer codigoAvaliacao, String matrAluno, Timestamp dataPreenchimento, Short resp11, Short resp12, Short resp13, Short resp21, Short resp22, Short resp23, Short resp24, Short resp25, Short resp26, Short resp31, Short resp32, Short resp41, Short resp42, Short resp51, Short resp52, Short resp53, Short resp54) throws CreateException;
  public FormAvDoceEstProb findByPrimaryKey(FormAvDoceEstProbPK pk) throws FinderException;
}