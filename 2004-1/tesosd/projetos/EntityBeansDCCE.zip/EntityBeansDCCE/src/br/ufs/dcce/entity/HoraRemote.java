package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface HoraRemote extends javax.ejb.EJBObject {
  public String getDisciplina() throws RemoteException;
  public String getTurma() throws RemoteException;
  public Short getPeriodo() throws RemoteException;
  public Integer getAno() throws RemoteException;
  public String getDocente() throws RemoteException;
}