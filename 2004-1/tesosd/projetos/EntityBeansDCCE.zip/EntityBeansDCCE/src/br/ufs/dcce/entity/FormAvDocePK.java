package br.ufs.dcce.entity;

import java.io.*;

public class FormAvDocePK
    implements Serializable {

  public Integer codigoAvaliacao;
  public String matrDoce;
  public String matrAluno;

  public FormAvDocePK() {
  }

  public FormAvDocePK(Integer codigoAvaliacao, String matrDoce,
                      String matrAluno) {
    this.codigoAvaliacao = codigoAvaliacao;
    this.matrDoce = matrDoce;
    this.matrAluno = matrAluno;
  }

  public boolean equals(Object obj) {
    if (obj != null) {
      if (this.getClass().equals(obj.getClass())) {
        FormAvDocePK that = (FormAvDocePK) obj;
        return ( ( (this.codigoAvaliacao == null) && (that.codigoAvaliacao == null)) ||
                (this.codigoAvaliacao != null &&
                 this.codigoAvaliacao.equals(that.codigoAvaliacao))) &&
            ( ( (this.matrDoce == null) && (that.matrDoce == null)) ||
             (this.matrDoce != null && this.matrDoce.equals(that.matrDoce))) &&
            ( ( (this.matrAluno == null) && (that.matrAluno == null)) ||
             (this.matrAluno != null && this.matrAluno.equals(that.matrAluno)));
      }
    }
    return false;
  }

  public int hashCode() {
    return (codigoAvaliacao + "" + matrDoce + matrAluno).hashCode();
  }
}
