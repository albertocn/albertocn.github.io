package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.sql.*;

public interface FormAvCurso extends javax.ejb.EJBLocalObject {
  public Integer getCodigoAvaliacao();
  public String getMatrAluno();
  public void setDataPreenchimento(Timestamp dataPreenchimento);
  public Timestamp getDataPreenchimento();
  public void setResp01(Short resp01);
  public Short getResp01();
  public void setResp02(Short resp02);
  public Short getResp02();
  public void setResp03(Short resp03);
  public Short getResp03();
  public void setResp04(Short resp04);
  public Short getResp04();
  public void setResp05(Short resp05);
  public Short getResp05();
  public void setResp06(Short resp06);
  public Short getResp06();
  public void setResp07(Short resp07);
  public Short getResp07();
  public void setResp08(Short resp08);
  public Short getResp08();
  public void setResp09(Short resp09);
  public Short getResp09();
  public void setResp10(Short resp10);
  public Short getResp10();
  public void setResp11(Short resp11);
  public Short getResp11();
  public void setResp12(Short resp12);
  public Short getResp12();
  public void setResp13(Short resp13);
  public Short getResp13();
  public void setResp14(Short resp14);
  public Short getResp14();
  public void setPontosFortes(String pontosFortes);
  public String getPontosFortes();
  public void setPontosFracos(String pontosFracos);
  public String getPontosFracos();
  public void setSugestoesMelhorias(String sugestoesMelhorias);
  public String getSugestoesMelhorias();
}