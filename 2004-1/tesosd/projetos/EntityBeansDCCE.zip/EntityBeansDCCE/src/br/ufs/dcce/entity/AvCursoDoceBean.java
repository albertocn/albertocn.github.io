package br.ufs.dcce.entity;

import javax.ejb.*;

abstract public class AvCursoDoceBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer codigo, Integer ano, Short periodo, String situacao) throws CreateException {
    setCodigo(codigo);
    setAno(ano);
    setPeriodo(periodo);
    setSituacao(situacao);
   return null;
  }
  public void ejbPostCreate(java.lang.Integer codigo, Integer ano, Short periodo, String situacao) throws CreateException {
    /**@todo Complete this method*/
  }
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setCodigo(java.lang.Integer codigo);
  public abstract void setAno(java.lang.Integer ano);
  public abstract void setPeriodo(java.lang.Short periodo);
  public abstract void setSituacao(java.lang.String situacao);
  public abstract java.lang.Integer getCodigo();
  public abstract java.lang.Integer getAno();
  public abstract java.lang.Short getPeriodo();
  public abstract java.lang.String getSituacao();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}