package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface FormAvDoceRemote extends javax.ejb.EJBObject {
  public Integer getCodigoAvaliacao() throws RemoteException;
  public String getMatrDoce() throws RemoteException;
  public String getMatrAluno() throws RemoteException;
  public void setDataPreenchimento(Timestamp dataPreenchimento) throws RemoteException;
  public Timestamp getDataPreenchimento() throws RemoteException;
  public void setResp01(Short resp01) throws RemoteException;
  public Short getResp01() throws RemoteException;
  public void setResp02(Short resp02) throws RemoteException;
  public Short getResp02() throws RemoteException;
  public void setResp03(Short resp03) throws RemoteException;
  public Short getResp03() throws RemoteException;
  public void setResp04(Short resp04) throws RemoteException;
  public Short getResp04() throws RemoteException;
  public void setResp05(Short resp05) throws RemoteException;
  public Short getResp05() throws RemoteException;
  public void setResp06(Short resp06) throws RemoteException;
  public Short getResp06() throws RemoteException;
  public void setResp07(Short resp07) throws RemoteException;
  public Short getResp07() throws RemoteException;
  public void setResp08(Short resp08) throws RemoteException;
  public Short getResp08() throws RemoteException;
  public void setResp09(Short resp09) throws RemoteException;
  public Short getResp09() throws RemoteException;
  public void setResp11(Short resp11) throws RemoteException;
  public Short getResp11() throws RemoteException;
  public void setResp10(Short resp10) throws RemoteException;
  public Short getResp10() throws RemoteException;
  public void setResp12(Short resp12) throws RemoteException;
  public Short getResp12() throws RemoteException;
  public void setResp13(Short resp13) throws RemoteException;
  public Short getResp13() throws RemoteException;
  public void setResp14(Short resp14) throws RemoteException;
  public Short getResp14() throws RemoteException;
}