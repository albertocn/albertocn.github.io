package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface AlunoHome extends javax.ejb.EJBLocalHome {
  public Aluno findByPrimaryKey(String matricula) throws FinderException;
}