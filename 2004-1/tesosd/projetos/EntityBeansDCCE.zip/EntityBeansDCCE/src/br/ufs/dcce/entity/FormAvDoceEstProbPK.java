package br.ufs.dcce.entity;

import java.io.*;

public class FormAvDoceEstProbPK
    implements Serializable {

  public Integer codigoAvaliacao;
  public String matrAluno;

  public FormAvDoceEstProbPK() {
  }

  public FormAvDoceEstProbPK(Integer codigoAvaliacao, String matrAluno) {
    this.codigoAvaliacao = codigoAvaliacao;
    this.matrAluno = matrAluno;
  }

  public boolean equals(Object obj) {
    if (obj != null) {
      if (this.getClass().equals(obj.getClass())) {
        FormAvDoceEstProbPK that = (FormAvDoceEstProbPK) obj;
        return ( ( (this.codigoAvaliacao == null) && (that.codigoAvaliacao == null)) ||
                (this.codigoAvaliacao != null &&
                 this.codigoAvaliacao.equals(that.codigoAvaliacao))) &&
            ( ( (this.matrAluno == null) && (that.matrAluno == null)) ||
             (this.matrAluno != null && this.matrAluno.equals(that.matrAluno)));
      }
    }
    return false;
  }

  public int hashCode() {
    return (codigoAvaliacao + "" + matrAluno).hashCode();
  }
}
