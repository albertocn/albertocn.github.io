package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface AvCursoDoceRemoteHome extends javax.ejb.EJBHome {
  public AvCursoDoceRemote create(Integer codigo, Integer ano, Short periodo, String situacao) throws CreateException, RemoteException;
  public AvCursoDoceRemote findByPrimaryKey(Integer codigo) throws FinderException, RemoteException;
}