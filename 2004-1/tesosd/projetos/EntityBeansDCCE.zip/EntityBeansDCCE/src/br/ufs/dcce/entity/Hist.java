package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface Hist extends javax.ejb.EJBLocalObject {
  public String getDisc();
  public void setTurma(String turma);
  public String getTurma();
  public void setAno(String ano);
  public String getAno();
  public void setPeriodo(String periodo);
  public String getPeriodo();
  public void setAluno(String aluno);
  public String getAluno();
  public void setSituacao(String situacao);
  public String getSituacao();
}