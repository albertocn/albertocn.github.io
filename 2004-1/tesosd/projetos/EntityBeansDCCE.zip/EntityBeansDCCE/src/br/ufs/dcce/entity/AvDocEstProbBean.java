package br.ufs.dcce.entity;

import javax.ejb.*;

abstract public class AvDocEstProbBean implements EntityBean {
  EntityContext entityContext;
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setCodigo(java.lang.Integer codigo);
  public abstract void setAno(java.lang.Integer ano);
  public abstract void setPeriodo(java.lang.Short periodo);
  public abstract void setMatrDoce(java.lang.String matrDoce);
  public abstract void setMatrOrientador(java.lang.String matrOrientador);
  public abstract void setSituacao(java.lang.String situacao);
  public abstract java.lang.Integer getCodigo();
  public abstract java.lang.Integer getAno();
  public abstract java.lang.Short getPeriodo();
  public abstract java.lang.String getMatrDoce();
  public abstract java.lang.String getMatrOrientador();
  public abstract java.lang.String getSituacao();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
  public java.lang.Integer ejbCreate(Integer codigo, Integer ano, Short periodo, String matrDoce, String matrOrientador, String situacao) throws CreateException {
    setCodigo(codigo);
    setAno(ano);
    setPeriodo(periodo);
    setMatrDoce(matrDoce);
    setMatrOrientador(matrOrientador);
    setSituacao(situacao);

    return null;
  }
  public void ejbPostCreate(Integer codigo, Integer ano, Short periodo, String matrDoce, String matrOrientador, String situacao) throws CreateException {
    /**@todo Complete this method*/
  }
}