package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface AlunoRemote extends javax.ejb.EJBObject {
  public String getMatricula() throws RemoteException;
  public String getNome() throws RemoteException;
  public Short getSituacao() throws RemoteException;
  public Short getCurso() throws RemoteException;
}