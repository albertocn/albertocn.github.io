package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface CursoRemoteHome extends javax.ejb.EJBHome {
  public CursoRemote findByPrimaryKey(Short codigo) throws FinderException, RemoteException;
}