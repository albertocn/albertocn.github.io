package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;
import java.sql.*;

public interface EmailCadastradoRemoteHome extends javax.ejb.EJBHome {
  public EmailCadastradoRemote create(String id, String tipo, String email, Timestamp dataCadastro, Timestamp dataAtualizado) throws CreateException, RemoteException;
  public EmailCadastradoRemote findByPrimaryKey(String id) throws FinderException, RemoteException;
}