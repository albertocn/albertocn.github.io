package br.ufs.dcce.entity;

import javax.ejb.*;

abstract public class DoceAtivoBean implements EntityBean {
  EntityContext entityContext;
  public void ejbRemove() throws RemoveException {
    /**@todo Complete this method*/
  }
  public abstract void setMatricula(java.lang.String matricula);
  public abstract void setVinculo(java.lang.String vinculo);
  public abstract void setTitulacao(java.lang.String titulacao);
  public abstract void setEmail(java.lang.String email);
  public abstract void setLinkHomepage(java.lang.String linkHomepage);
  public abstract void setLinkLattes(java.lang.String linkLattes);
  public abstract void setTelefones(java.lang.String telefones);
  public abstract java.lang.String getMatricula();
  public abstract java.lang.String getVinculo();
  public abstract java.lang.String getTitulacao();
  public abstract java.lang.String getEmail();
  public abstract java.lang.String getLinkHomepage();
  public abstract java.lang.String getLinkLattes();
  public abstract java.lang.String getTelefones();
  public void ejbLoad() {
    /**@todo Complete this method*/
  }
  public void ejbStore() {
    /**@todo Complete this method*/
  }
  public void ejbActivate() {
    /**@todo Complete this method*/
  }
  public void ejbPassivate() {
    /**@todo Complete this method*/
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
  public java.lang.String ejbCreate(String matricula, String vinculo, String titulacao, String email, String linkHomepage, String linkLattes, String telefones) throws CreateException  {
    setMatricula(matricula);
    setVinculo(vinculo);
    setTitulacao(titulacao);
    setEmail(email);
    setLinkHomepage(linkHomepage);
    setLinkLattes(linkLattes);
    setTelefones(telefones);

    return null;
  }
  public void ejbPostCreate(String matricula, String vinculo, String titulacao, String email, String linkHomepage, String linkLattes, String telefones) throws CreateException  {
  }
}