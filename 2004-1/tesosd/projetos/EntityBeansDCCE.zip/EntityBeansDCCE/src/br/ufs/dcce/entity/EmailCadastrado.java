package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.sql.*;

public interface EmailCadastrado extends javax.ejb.EJBLocalObject {
  public String getId();
  public void setTipo(String tipo);
  public String getTipo();
  public void setEmail(String email);
  public String getEmail();
  public void setDataCadastro(Timestamp dataCadastro);
  public Timestamp getDataCadastro();
  public void setDataAtualizado(Timestamp dataAtualizado);
  public Timestamp getDataAtualizado();
}