package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface AvDocEstProbRemote extends javax.ejb.EJBObject {
  public Integer getCodigo() throws RemoteException;
  public void setAno(Integer ano) throws RemoteException;
  public Integer getAno() throws RemoteException;
  public void setPeriodo(Short periodo) throws RemoteException;
  public Short getPeriodo() throws RemoteException;
  public void setMatrDoce(String matrDoce) throws RemoteException;
  public String getMatrDoce() throws RemoteException;
  public void setMatrOrientador(String matrOrientador) throws RemoteException;
  public String getMatrOrientador() throws RemoteException;
  public void setSituacao(String situacao) throws RemoteException;
  public String getSituacao() throws RemoteException;
}