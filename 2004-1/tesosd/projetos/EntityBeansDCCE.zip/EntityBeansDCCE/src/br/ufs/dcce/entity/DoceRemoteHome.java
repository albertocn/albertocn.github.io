package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface DoceRemoteHome extends javax.ejb.EJBHome {
  public DoceRemote findByPrimaryKey(String matricula) throws FinderException, RemoteException;
}