package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface AvDocEstProbHome extends javax.ejb.EJBLocalHome {
  public AvDocEstProb create(Integer codigo, Integer ano, Short periodo, String matrDoce, String matrOrientador, String situacao) throws CreateException;
  public AvDocEstProb findByPrimaryKey(Integer codigo) throws FinderException;
}