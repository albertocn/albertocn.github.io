package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface DituRemote extends javax.ejb.EJBObject {
  public String getTurma() throws RemoteException;
  public String getDisciplina() throws RemoteException;
  public Integer getAno() throws RemoteException;
  public Short getPeriodo() throws RemoteException;
}