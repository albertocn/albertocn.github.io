package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface DituRemoteHome extends javax.ejb.EJBHome {
  public DituRemote findByPrimaryKey(String turma) throws FinderException, RemoteException;
}