package br.ufs.dcce.entity;

import javax.ejb.*;
import java.util.*;

public interface Disc extends javax.ejb.EJBLocalObject {
  public String getCodigo();
  public void setNome(String nome);
  public String getNome();
  public void setCreditos(Short creditos);
  public Short getCreditos();
  public void setDepartamento(Short departamento);
  public Short getDepartamento();
}