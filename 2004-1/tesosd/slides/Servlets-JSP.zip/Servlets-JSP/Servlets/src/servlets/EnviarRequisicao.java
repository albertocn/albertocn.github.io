package servlets;

import java.net.URL;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class EnviarRequisicao {

  public static void main(String[] args) {
    try {
      URL url = new URL("http", "localhost", 8080, "/Servlets/HelloWorld");
      HttpMessage hm = new HttpMessage( url );
      InputStream is = hm.sendGetMessage();
//      InputStream is = hm.sendPostMessage();
      BufferedReader br = new BufferedReader(
                             new InputStreamReader( is ) );
      do {
        String linha = br.readLine();
        if (linha == null)
          break;
        else
          System.out.println( linha );
      } while (true);

      br.close();

    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}