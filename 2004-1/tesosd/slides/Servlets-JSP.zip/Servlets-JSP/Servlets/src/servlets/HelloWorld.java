package servlets;

import javax.servlet.ServletException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Date;

public class HelloWorld extends HttpServlet {

  static final private String CONTENT_TYPE = "text/html";

  private static final DateFormat df = new SimpleDateFormat("dd/MM/yyyy kk:mm:ss.SSS");

  /** Inicializa vari�veis globais */
  public void init() throws ServletException {
  }

  /**
   * Processa a requisi��o GET HTTP
   */
  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    // Nome do usu�rio
    String usuario = request.getParameter("usuario");

    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>HelloWorld</title></head>");
    out.println("<body>");
    out.println("<p>" + getMsg(usuario) + "</p>");
    out.println("</body></html>");
  }

  // M�todo gancho para libera��o de recursos
  public void destroy() {
  }

  private String getMsg(String usuario) {
    if (usuario == null) {
      usuario = "desconhecido";
    }
    return "<b>" + getDataHoraFormatados() + "</b> Hello, " + usuario + "!";
  }

  private String getDataHoraFormatados() {
    return "["+ df.format( new Date() ) + "]";
  }
}