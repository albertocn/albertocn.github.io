package servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Contador2 extends HttpServlet {
  static final private String CONTENT_TYPE = "text/html";

  private int cont = 0;

  public synchronized void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    int n = cont;
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Contador1</title></head>");
    out.println("<body>");
    n++;
    out.println("<p>Contador = " + n + "</p>");
    out.println("</body></html>");
    cont = n;
  }
}