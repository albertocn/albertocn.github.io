package servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class Contador3 extends HttpServlet {
  static final private String CONTENT_TYPE = "text/html";

  private int cont = 0;

  public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    int n;
    synchronized (this) {
      n = cont;
      n++;
      cont = n;
    }
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>Contador1</title></head>");
    out.println("<body>");
    out.println("<p>Contador = " + n + "</p>");
    out.println("</body></html>");
  }
}