package servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ListaDeProdutos extends HttpServlet {
  static final private String CONTENT_TYPE = "text/html";

  private List produtos = new LinkedList();

  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

    String produto = request.getParameter("NomeProduto");
    if (produto == null) {
      produto = "";
    } else {
      adicionarProduto ( produto );
    }
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>ListaDeProdutos</title></head>");
    out.println("<body>");
    exibirForm ( out, request );
    exibirProdutos ( out );
    out.println("</body></html>");
  }

  private void adicionarProduto ( String produto ) {
    produtos.add( produto );
  }

  private void exibirProdutos( PrintWriter out ) {
    Iterator it = produtos.iterator();
    if ( !it.hasNext() ) {
      out.println("<p><b>N�o h� produtos na lista</b></p>");
    } else {
      while (it.hasNext()) {
        out.println("<p>" + (String) it.next() + "</p>");
      }
    }
  }

  private void exibirForm( PrintWriter out, HttpServletRequest req ) {
    out.println( "<form method=\"GET\" action=\"" + req.getRequestURL() + "\">" );
    out.println("Produto: <input type=\"text\" name=\"NomeProduto\" size=\"20\"></p>");
    out.println( "<input type=\"submit\" value=\"Submeter\">" );
    out.println( "<input type=\"reset\" value=\"Redefinir\">" );
    out.println( "</form>" );
    out.println( "<hr>" );
  }
}