package servlets;

import java.io.*;
import java.net.*;
import java.util.*;

/**
 * Classe usada para facilitar o envio de requisi��es HTTP usando tanto
 * GET como POST
 *
 * <p>
 * Us�-la a partir de um Applet seria da seguinte forma:
 *
 * <blockquote><pre>
 * URL url = new URL(getCodeBase(), "/servlet/ServletName");
 * &nbsp;
 * HttpMessage msg = new HttpMessage(url);
 * &nbsp;
 * Properties props = new Properties();
 * props.put("name", "value");
 * &nbsp;
 * InputStream in = msg.sendGetMessage(props);
 * </pre></blockquote>
 */
public class HttpMessage {

    private URL target = null;

    /**
     * Constr�i uma HttpMessage que pode ser usada para enviar requisi��es
     * HTTP para a URL especificada
     *
     * @param target Nome do arquivo, programa CGI ou Servlet alvo
     * da requisi��o
     */
    public HttpMessage(URL target) {
        this.target = target;
    }

    /**
     * Executa a requisi��o GET sem adicionar par�metros
     *
     * @return InputStream para que a resposta seja lida
     *
     * @exception IOException caso um erro de E/S ocorra
     */
    public InputStream sendGetMessage() throws IOException {
        return sendGetMessage(null);
    }

    /**
     * Executa a requisi��o GET adicionando todos os argumentos � requisi��o
     *
     * @param args Lista de argumentos
     *
     * @return InputStream para que a resposta seja lida
     *
     * @exception IOException caso um erro de E/S ocorra
     */
    public InputStream sendGetMessage(Properties args) throws IOException {
        String argString = "";

        if (args != null) {
            argString = "?" + toEncodedString(args);
        }
        URL url = new URL(target.toExternalForm() + argString);

        URLConnection con = url.openConnection();
        con.setUseCaches(false);

        return con.getInputStream();
    }

    /**
     * Executa a requisi��o POST sem adicionar par�metros
     *
     * @return InputStream para que a resposta seja lida
     *
     * @exception IOException caso um erro de E/S ocorra
     */
    public InputStream sendPostMessage() throws IOException {
        return sendPostMessage(null);
    }

    /**
     * Executa a requisi��o Post adicionando todos os argumentos � requisi��o
     *
     * @param args Lista de argumentos
     *
     * @return InputStream para que a resposta seja lida
     *
     * @exception IOException caso um erro de E/S ocorra
     */
    public InputStream sendPostMessage(Properties args) throws IOException {
        String argString = "";
        if (args != null) {
            argString = toEncodedString(args);
        }

        URLConnection con = target.openConnection();
        con.setDoInput(true);
        con.setDoOutput(true);
        con.setUseCaches(false);
        con.setRequestProperty("Content-Type",
                               "application/x-www-form-urlencoded");

        DataOutputStream out = new DataOutputStream(con.getOutputStream());
        out.writeBytes(argString);
        out.flush();
        out.close();

        return con.getInputStream();
    }

    // Converte uma lista de propriedades em uma String codificada
    private String toEncodedString(Properties args) {
        StringBuffer buf = new StringBuffer();
        Enumeration names = args.propertyNames();
        while (names.hasMoreElements()) {
            String name = (String) names.nextElement();
            buf.append(URLEncoder.encode(name) + "=" +
                       URLEncoder.encode(args.getProperty(name)));
            if (names.hasMoreElements()) {
                buf.append("&");
            }
        }
        return buf.toString();
    }
}
