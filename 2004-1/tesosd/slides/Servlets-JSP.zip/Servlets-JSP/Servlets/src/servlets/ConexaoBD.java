package servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class ConexaoBD extends HttpServlet {
  static final private String CONTENT_TYPE = "text/html";

  private Connection con;

  public void init() throws ServletException {
    String driver = getInitParameter( "driver" );
    String url = getInitParameter( "url" );
    String usuario = getInitParameter( "usuario" );
    String senha = getInitParameter( "senha" );
    try {
      Class.forName( driver );
      con = DriverManager.getConnection( url, usuario, senha );
    } catch (Exception e) {
      // Indica que n�o est� dispon�vel
      throw new UnavailableException("Erro ao abrir conex�o em init");
    }
  }

  public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>ConexaoBD</title></head>");
    out.println("<body>");
    out.println("<h2>Empregados</h2>");
    exibirEmpregados( out );
    out.println("</body></html>");
  }

  private void exibirEmpregados( PrintWriter out ) {
    try {
      Statement stmt = con.createStatement();
      ResultSet rs = stmt.executeQuery( "SELECT emp_no, first_name, last_name FROM employee" );
      while (rs.next()) {
        int empNo = rs.getInt("emp_no");
        String nome = rs.getString("first_name") + " " + rs.getString("last_name");
        out.println("<p>" + empNo + ": " + nome + "</p>");
      }
    } catch (SQLException e) {
      System.out.println( e );
    }
  }

  public void destroy() {
    try {
      con.close();
    } catch(SQLException e) {
      log( "Erro ao fechar conex�o em destroy", e );
    }
  }
}