package servlets;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class ListaDeProdutosSessao extends HttpServlet {
  static final private String CONTENT_TYPE = "text/html";

  public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {

    String produto = request.getParameter("NomeProduto");
    if (produto != null) {
      adicionarProduto ( produto, request );
    }
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    out.println("<html>");
    out.println("<head><title>ListaDeProdutosSessao</title></head>");
    out.println("<body>");
    exibirForm ( out, request );
    exibirProdutos ( out, request );
    out.println("</body></html>");
  }

  private void adicionarProduto ( String produto, HttpServletRequest req) {
    List produtos = getOrCreateProdutos( req );
    produtos.add( produto );
  }

  private void exibirProdutos( PrintWriter out, HttpServletRequest req ) {
    Iterator it = getOrCreateProdutos( req ).iterator();
    if ( !it.hasNext() ) {
      out.println("<p><b>N�o h� produtos na lista</b></p>");
    } else {
      while (it.hasNext()) {
        out.println("<p>" + (String) it.next() + "</p>");
      }
    }
  }

  private List getOrCreateProdutos( HttpServletRequest req) {
    HttpSession session = req.getSession();
    List produtos = (List) session.getAttribute( "produtos" );
    if (produtos == null) {
      produtos = new LinkedList();
      session.setAttribute( "produtos", produtos );
    }
    return produtos;
  }

  private void exibirForm( PrintWriter out, HttpServletRequest req ) {
    out.println( "<form method=\"GET\" action=\"" + req.getRequestURL() + "\">" );
    out.println("Produto: <input type=\"text\" name=\"NomeProduto\" size=\"20\"></p>");
    out.println( "<input type=\"submit\" value=\"Submeter\">" );
    out.println( "<input type=\"reset\" value=\"Redefinir\">" );
    out.println( "</form>" );
    out.println( "<hr>" );
  }
}