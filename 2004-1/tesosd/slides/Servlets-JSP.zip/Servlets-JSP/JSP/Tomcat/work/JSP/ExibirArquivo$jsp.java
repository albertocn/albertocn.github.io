package org.apache.jsp;

import java.io.File;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;


public class ExibirArquivo$jsp extends HttpJspBase {


    static {
    }
    public ExibirArquivo$jsp( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws org.apache.jasper.runtime.JspException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws java.io.IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                synchronized (this) {
                    if (_jspx_inited == false) {
                        _jspx_init();
                        _jspx_inited = true;
                    }
                }
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=ISO-8859-1");
            pageContext = _jspxFactory.getPageContext(this, request, response,
            			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="/ExibirArquivo.jsp";from=(0,33);to=(4,0)]
                out.write("\r\n<HTML>\r\n<HEAD><TITLE>ExibirArquivo</TITLE></HEAD>\r\n<BODY>\r\n");

            // end
            // begin [file="/ExibirArquivo.jsp";from=(4,2);to=(7,0)]
                
                  String usuario = (String) session.getAttribute( "usuario" );
                  if (usuario == null) {
            // end
            // HTML // begin [file="/ExibirArquivo.jsp";from=(7,2);to=(8,4)]
                out.write("\r\n    ");

            // end
            // begin [file="/ExibirArquivo.jsp";from=(8,4);to=(8,36)]
                if (true) {
                    out.clear();
                    String _jspx_qfStr = "";
                    pageContext.forward("Login.jsp" +  _jspx_qfStr);
                    return;
                }
            // end
            // HTML // begin [file="/ExibirArquivo.jsp";from=(8,36);to=(9,0)]
                out.write("\r\n");

            // end
            // begin [file="/ExibirArquivo.jsp";from=(9,2);to=(11,0)]
                
                  }
            // end
            // HTML // begin [file="/ExibirArquivo.jsp";from=(11,2);to=(13,0)]
                out.write("\r\n\r\n");

            // end
            // begin [file="/ExibirArquivo.jsp";from=(13,2);to=(31,0)]
                
                  String dir = request.getParameter( "dir" );
                  if (dir == null) {
                    dir = "/";
                  }
                
                  File diretorio = new File( dir );
                  File[] arqv = diretorio.listFiles();
                
                  out.println("<H2>Arquivos</H2>");
                  for (int i = 0; i != arqv.length; i++)
                    if (arqv[i].isFile())
                      out.println( arqv[i].getName() + " (" + arqv[i].length() + " bytes)<BR>" );
                
                  out.println("<H2>Diretórios</H2>");
                  for (int i = 0; i != arqv.length; i++)
                    if (arqv[i].isDirectory())
                      out.println( arqv[i].getName() + "<BR>" );
            // end
            // HTML // begin [file="/ExibirArquivo.jsp";from=(31,2);to=(33,7)]
                out.write("\r\n</BODY>\r\n</HTML>");

            // end

        } catch (Throwable t) {
            if (out != null && out.getBufferSize() != 0)
                out.clearBuffer();
            if (pageContext != null) pageContext.handlePageException(t);
        } finally {
            if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
        }
    }
}
