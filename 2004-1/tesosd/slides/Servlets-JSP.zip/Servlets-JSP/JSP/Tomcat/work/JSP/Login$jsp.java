package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import org.apache.jasper.runtime.*;


public class Login$jsp extends HttpJspBase {


    static {
    }
    public Login$jsp( ) {
    }

    private static boolean _jspx_inited = false;

    public final void _jspx_init() throws org.apache.jasper.runtime.JspException {
    }

    public void _jspService(HttpServletRequest request, HttpServletResponse  response)
        throws java.io.IOException, ServletException {

        JspFactory _jspxFactory = null;
        PageContext pageContext = null;
        HttpSession session = null;
        ServletContext application = null;
        ServletConfig config = null;
        JspWriter out = null;
        Object page = this;
        String  _value = null;
        try {

            if (_jspx_inited == false) {
                synchronized (this) {
                    if (_jspx_inited == false) {
                        _jspx_init();
                        _jspx_inited = true;
                    }
                }
            }
            _jspxFactory = JspFactory.getDefaultFactory();
            response.setContentType("text/html;charset=ISO-8859-1");
            pageContext = _jspxFactory.getPageContext(this, request, response,
            			"", true, 8192, true);

            application = pageContext.getServletContext();
            config = pageContext.getServletConfig();
            session = pageContext.getSession();
            out = pageContext.getOut();

            // HTML // begin [file="/Login.jsp";from=(0,0);to=(3,28)]
                out.write("<HTML>\r\n<HEAD><TITLE>Login</TITLE></HEAD>\r\n<BODY>\r\n<form method=\"POST\" action=\"");

            // end
            // begin [file="/Login.jsp";from=(3,31);to=(3,56)]
                out.print( request.getRequestURL() );
            // end
            // HTML // begin [file="/Login.jsp";from=(3,58);to=(8,0)]
                out.write("\">\r\n  <p>Usuário: <input type=\"text\" name=\"usuario\" size=\"20\"></p>\r\n  <p><input type=\"submit\" value=\"Submeter\" name=\"B1\"><input type=\"reset\" value=\"Redefinir\" name=\"B2\"></p>\r\n</form>\r\n\r\n");

            // end
            // begin [file="/Login.jsp";from=(8,2);to=(13,0)]
                
                  String usuario = request.getParameter( "usuario" );
                  if ( usuario != null ) {
                     session.setAttribute( "usuario", usuario);
                  }
            // end
            // HTML // begin [file="/Login.jsp";from=(13,2);to=(18,7)]
                out.write("\r\n\r\n<A HREF=\"ExibirArquivo.jsp\">ExibirArquivos.jsp</A>\r\n\r\n</BODY>\r\n</HTML>");

            // end

        } catch (Throwable t) {
            if (out != null && out.getBufferSize() != 0)
                out.clearBuffer();
            if (pageContext != null) pageContext.handlePageException(t);
        } finally {
            if (_jspxFactory != null) _jspxFactory.releasePageContext(pageContext);
        }
    }
}
