package jsp;

public class Cliente {

  private String nome;
  private String data;

  public String getNome() { return nome; };
  public String getData() { return data; };
  public void setNome( String nome ) { this.nome = nome; };
  public void setData( String data ) { this.data = data; };

  public String toString() {
    return "Nome=" + getNome() + ", Data=" + getData();
  }
}