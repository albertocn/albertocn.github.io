package helloworld;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

public interface HelloWorld extends EJBObject {

    String hello() throws RemoteException;
}