DROP TABLE TB_LIVROS;
CREATE TABLE TB_Livros (
  id       varchar(20)   NOT NULL PRIMARY KEY,
  titulo   varchar(50)   NOT NULL,
  autor    varchar(50)   NOT NULL,
  preco    numeric(11,2) NOT NULL,
  desconto numeric(2,2)  NOT NULL
);