package livraria;

import javax.ejb.*;
import java.rmi.*;

public class LivroBeanCMP implements EntityBean {
  private EntityContext entityContext;
  public String id;
  public String titulo;
  public String autor;
  public double preco;
  public double desconto;

  private double precoComDesconto;
  private double valorDoDesconto;

  public LivroPK ejbCreate(String id, String titulo, String autor, double preco, double desconto) throws CreateException {
    this.id = id;
    this.titulo = titulo;
    this.autor = autor;
    this.preco = preco;
    this.desconto = desconto;
    atualizarValoresDependentes();
    return null;
  }
  public LivroPK ejbCreate(String id) throws CreateException {
    return ejbCreate(id, null, null, 0.0, 0.0);
  }
  public void ejbPostCreate(String id, String titulo, String autor, double preco, double desconto) throws CreateException {
  }
  public void ejbPostCreate(String id) throws CreateException {
    ejbPostCreate(id, null, null, 0.0, 0.0);
  }
  public void ejbLoad() {
    atualizarValoresDependentes();
  }
  public void ejbStore() {
  }
  public void ejbRemove() throws RemoveException {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
  public void unsetEntityContext() {
    entityContext = null;
  }
  public String getId() {
    return id;
  }
  public String getTitulo() {
    return titulo;
  }
  public void setTitulo(String titulo) {
    this.titulo = titulo;
  }
  public String getAutor() {
    return autor;
  }
  public void setAutor(String autor) {
    this.autor = autor;
  }
  public double getPreco() {
    return preco;
  }
  public void setPreco(double preco) {
    this.preco = preco;
  }
  public double getDesconto() {
    return desconto;
  }
  public void setDesconto(double desconto) {
    this.desconto = desconto;
  }
  public double getPrecoComDesconto() {
    return this.precoComDesconto;
  }

  public double getValorDoDesconto() {
    return this.valorDoDesconto;
  }

  protected void atualizarValoresDependentes() {
      precoComDesconto = getPreco() - (getPreco() * getDesconto());
      valorDoDesconto = getPreco() - precoComDesconto;
  }

}