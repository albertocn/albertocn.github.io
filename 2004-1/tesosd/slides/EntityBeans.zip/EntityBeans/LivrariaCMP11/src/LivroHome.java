import java.rmi.*;
import javax.ejb.*;
import livraria.*;
import java.util.Collection;

public interface LivroHome extends EJBHome {
  public Livro create(String id, String titulo, String autor, double preco, double desconto) throws RemoteException, CreateException;
  public Livro create(String id) throws RemoteException, CreateException;
  public Livro findByPrimaryKey(LivroPK primaryKey) throws RemoteException, FinderException;
  public Collection findAll() throws RemoteException, FinderException;
}
