package livraria;

import javax.ejb.*;

abstract public class LivroBeanCMP implements EntityBean {
  EntityContext entityContext;
  double precoComDesconto;
  double valorDoDesconto;
  public LivroPK ejbCreate(java.lang.String id, java.lang.String titulo, java.lang.String autor, double preco, double desconto) throws CreateException {
    setId(id);
    setTitulo(titulo);
    setAutor(autor);
    setPreco(preco);
    setDesconto(desconto);
    atualizarValoresDependentes();
    return null;
  }
  public void ejbPostCreate(java.lang.String id, java.lang.String titulo, java.lang.String autor, double preco, double desconto) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
  }
  public abstract void setId(java.lang.String id);
  public abstract void setTitulo(java.lang.String titulo);
  public abstract void setAutor(java.lang.String autor);
  public abstract void setPreco(double preco);
  public abstract void setDesconto(double desconto);
  public abstract java.lang.String getId();
  public abstract java.lang.String getTitulo();
  public abstract java.lang.String getAutor();
  public abstract double getPreco();
  public abstract double getDesconto();
  public double getPrecoComDesconto() {
    return precoComDesconto;
  }
  public double getValorDoDesconto() {
    return valorDoDesconto;
  }
  public void ejbLoad() {
    atualizarValoresDependentes();
  }
  public void ejbStore() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }

  protected void atualizarValoresDependentes() {
      precoComDesconto = getPreco() - (getPreco() * getDesconto());
      valorDoDesconto = getPreco() - precoComDesconto;
  }
}