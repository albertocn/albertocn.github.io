package livraria.jsp;

import java.rmi.RemoteException;
import javax.ejb.*;
import javax.naming.NamingException;

import livraria.LivroPK;

public class RemoverLivroBean extends AbstractLivroBean {

    private String id;

    public void remover()
            throws RemoteException, NamingException,
                   FinderException, RemoveException {

        getLivroHome().findByPrimaryKey(new LivroPK(getId())).remove();
        id = null;
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
}