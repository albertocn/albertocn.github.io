package livraria.jsp;

import java.rmi.RemoteException;
import java.math.BigDecimal;
import javax.ejb.CreateException;
import javax.naming.NamingException;

import livraria.Livro;

public class CadastrarLivroBean extends AbstractLivroBean {

    private String id;
    private String titulo;
    private String autor;
    private double preco;
    private double desconto;

    public CadastrarLivroBean() {
        setId("");
        setTitulo("");
        setAutor("");
        setPreco( 1 );
        setDesconto( 0 );
    }

    public Livro cadastrar()
            throws RemoteException, NamingException, CreateException {

        return getLivroHome().create(getId(), getTitulo(), getAutor(),
                                     getPreco(), getDesconto());
    }

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }

    public double getDesconto() { return desconto; }
    public void setDesconto(double desconto) { this.desconto = desconto; }
}