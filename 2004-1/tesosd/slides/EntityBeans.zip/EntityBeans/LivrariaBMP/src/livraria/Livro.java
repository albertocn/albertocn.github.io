package livraria;

import javax.ejb.*;
import java.util.*;
import java.math.*;

public interface Livro extends javax.ejb.EJBLocalObject {
  public String getId();
  public void setTitulo(String titulo);
  public String getTitulo();
  public void setAutor(String autor);
  public String getAutor();
  public void setPreco(double preco);
  public double getPreco();
  public void setDesconto(double desconto);
  public double getDesconto();
  public double getPrecoComDesconto();
  public double getValorDoDesconto();
}