package livraria.jsp;

import java.rmi.*;
import java.util.*;
import javax.ejb.*;
import javax.naming.*;

import livraria.*;
import java.io.*;

public class ConsultarLivrosBean extends AbstractLivroBean {

    private String tipo;
    private String chave;
    private Collection colecaoVazia = Collections.unmodifiableCollection(new Vector());

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getChave() { return chave; }
    public void setChave(String chave) { this.chave = chave; }

    public Collection executarConsulta()
            throws RemoteException, FinderException, NamingException {

        Collection retorno;

        if ("Id".equalsIgnoreCase(tipo)) {
            retorno = findId();
        } else if ("Titulo".equalsIgnoreCase(tipo)) {
            retorno = findTitulo();
        } else if ("Todos".equalsIgnoreCase(tipo)) {
            retorno = findAll();
        } else {
            retorno = colecaoVazia;
        }

        zerarPropriedades();

        return retorno;
    }

    private Collection findId()
            throws NamingException, RemoteException, FinderException {
        try {
            Collection livro = new Vector(1);
            livro.add(getLivroHome().findByPrimaryKey(new LivroPK(chave)));
            return livro;
        } catch (FinderException fe) {
            return colecaoVazia;
        }
    }

    private Collection findTitulo()
            throws NamingException, RemoteException, FinderException {

        return (chave == null) ? colecaoVazia : getLivroHome().findByTitulo(chave);
    }

    private Collection findAll()
            throws NamingException, RemoteException, FinderException {
        return getLivroHome().findAll();
    }

    private void zerarPropriedades() {
        tipo = null;
        chave = null;
    }
}