package livraria;

import javax.ejb.*;
import java.util.*;
import java.math.*;

public interface LivroHome extends javax.ejb.EJBLocalHome {
  public Collection findAll() throws FinderException;
  public Collection findByTitulo(String titulo) throws FinderException;
  public Livro findByPrimaryKey(LivroPK pk) throws FinderException;
  public Livro create(String id, String titulo, String autor, double preco, double desconto) throws CreateException;
}