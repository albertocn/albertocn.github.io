package livraria;

import java.sql.*;
import javax.ejb.*;
import javax.sql.DataSource;
import javax.naming.*;
import java.util.*;

public class LivroBeanBMP implements EntityBean {
  EntityContext entityContext;
  java.lang.String id;
  java.lang.String titulo;
  java.lang.String autor;
  double preco;
  double desconto;
  double precoComDesconto;
  double valorDoDesconto;


  protected DataSource dataSource;

  public void ejbRemove() throws RemoveException {
    Connection con = null;
    PreparedStatement stmt = null;
    try {
        con = dataSource.getConnection();
        stmt = con.prepareStatement("DELETE FROM " + getNomeTabela() +
                                   " WHERE Id = ?");
        stmt.setString(1, id);
        if (stmt.executeUpdate() < 1) {
            throw new RemoveException("Error ao apagar linha");
        }
        stmt.close();
        stmt = null;
        con.close();
        con = null;
    }
    catch(SQLException e) {
        throw new EJBException("Error ao executar DELETE em ejbRemove()", e);
    }
    finally {
        try {
            if (stmt != null) {
                stmt.close();
            }
        }
        catch(SQLException e) {
        }
        try {
            if (con != null) {
                con.close();
            }
        }
        catch(SQLException e) {
        }
    }

  }
  public void setId(java.lang.String id) {
    this.id = id;
  }
  public void setTitulo(java.lang.String titulo) {
    this.titulo = titulo;
  }
  public void setAutor(java.lang.String autor) {
    this.autor = autor;
  }
  public void setPreco(double preco) {
    this.preco = preco;
  }
  public void setDesconto(double desconto) {
    this.desconto = desconto;
  }
  public java.lang.String getId() {
    return id;
  }
  public java.lang.String getTitulo() {
    return titulo;
  }
  public java.lang.String getAutor() {
    return autor;
  }
  public double getPreco() {
    return preco;
  }
  public double getDesconto() {
    return desconto;
  }

  public void ejbLoad() {
    LivroPK key = (LivroPK) entityContext.getPrimaryKey();
    id = key.id;

    Connection con = null;
    PreparedStatement stmt = null;
    try {
        con = dataSource.getConnection();
        stmt = con.prepareStatement("SELECT Titulo, Autor, Preco, Desconto" +
                                   " FROM " + getNomeTabela() +
                                   " WHERE Id = ?");
        stmt.setString(1, id);
        ResultSet resultSet = stmt.executeQuery();
        if (!resultSet.next()) {
            throw new NoSuchEntityException("Linha n�o existe");
        }
        titulo = resultSet.getString(1);
        autor = resultSet.getString(2);
        preco = resultSet.getDouble(3);
        desconto = resultSet.getDouble(4);
        stmt.close();
        stmt = null;
        con.close();
        con = null;
    }
    catch(SQLException e) {
        throw new EJBException("Error ao executar SELECT em ejbLoad()", e);
    }
    finally {
        try {
            if (stmt != null) {
                stmt.close();
            }
        }
        catch(SQLException e) {
        }
        try {
            if (con != null) {
                con.close();
            }
        }
        catch(SQLException e) {
        }
    }

    atualizarValoresDependentes();
  }
  public void ejbStore() {
    Connection con = null;
    PreparedStatement stmt = null;
    try {
        con = dataSource.getConnection();
        stmt = con.prepareStatement("UPDATE " + getNomeTabela() +
                                   " SET Titulo = ?, Autor = ?," +
                                       " Preco = ?, Desconto = ? " +
                                   " WHERE Id = ?");
        stmt.setString(1, titulo);
        stmt.setString(2, autor);
        stmt.setDouble(3, preco);
        stmt.setDouble(4, desconto);
        stmt.setString(5, id);
        if (stmt.executeUpdate() < 1) {
            throw new NoSuchEntityException("Linha n�o existe");
        }
        stmt.close();
        stmt = null;
        con.close();
        con = null;
    }
    catch(SQLException e) {
        throw new EJBException("Erro ao executar UPDATE em ejbStore()", e);
    }
    finally {
        try {
            if (stmt != null) {
                stmt.close();
            }
        }
        catch(SQLException e) {
        }
        try {
            if (con != null) {
                con.close();
            }
        }
        catch(SQLException e) {
        }
    }
  }

  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }

  // ---------------------- Finders ----------------------

  public LivroPK ejbFindByPrimaryKey(LivroPK pk) throws FinderException {
    Connection con = null;
    PreparedStatement stmt = null;
    try {
      con = dataSource.getConnection();
      stmt = con.prepareStatement("SELECT Id FROM " + getNomeTabela() +
                                 " WHERE Id = ?");
      stmt.setString(1, pk.id);
      ResultSet resultSet = stmt.executeQuery();
      if (!resultSet.next()) {
          throw new ObjectNotFoundException("Chave prim�ria n�o existe");
      }
      stmt.close();
      stmt = null;
      con.close();
      con = null;
      return pk;
    }
    catch(SQLException e) {
      throw new EJBException("Erro ao executar SELECT em ejbFindByPrimaryKey()", e);
    } finally {
      try {
        if (stmt != null)
          stmt.close();
        } catch(SQLException e) {}
        try {
          if (con != null)
            con.close();
        } catch(SQLException e) {}
    }
  }

  public java.util.Collection ejbFindAll() throws FinderException {
    Connection con = null;
    PreparedStatement stmt = null;
    try {
      con = dataSource.getConnection();
      stmt = con.prepareStatement("SELECT Id FROM " + getNomeTabela());
      ResultSet resultSet = stmt.executeQuery();
      Vector keys = new Vector();
      while (resultSet.next()) {
          keys.addElement(new LivroPK(resultSet.getString(1)));
      }
      stmt.close();
      stmt = null;
      con.close();
      con = null;
      return keys;
    }
    catch(SQLException e) {
      throw new EJBException("Erro ao executar SELECT em ejbFindAll()", e);
    } finally {
      try {
        if (stmt != null)
          stmt.close();
      } catch(SQLException e) {}
      try {
        if (con != null)
          con.close();
      } catch(SQLException e) {}
    }
  }

  public java.util.Collection ejbFindByTitulo(String titulo) throws FinderException {

    Connection con = null;
    PreparedStatement stmt = null;
    try {
      con = dataSource.getConnection();
      stmt = con.prepareStatement("SELECT Id FROM " + getNomeTabela() +
                                 " WHERE Titulo = ?");
      stmt.setString(1, titulo);
      ResultSet resultSet = stmt.executeQuery();
      Vector keys = new Vector();
      while (resultSet.next()) {
          keys.addElement(new LivroPK(resultSet.getString(1)));
      }
      stmt.close();
      stmt = null;
      con.close();
      con = null;
      return keys;
    }
    catch(SQLException e) {
      throw new EJBException("Erro ao executar SELECT em ejbFindByTitulo()", e);
    } finally {
      try {
        if (stmt != null)
          stmt.close();
      } catch(SQLException e) {}
      try {
        if (con != null)
          con.close();
      } catch(SQLException e) {}
    }
  }

  protected String getNomeTabela() throws EJBException {
    try {
      Context context = new InitialContext();
      return (String) context.lookup("java:comp/env/NomeTabelaLivros");
    } catch(Exception e) {
      throw new EJBException("Propriedade NomeTabelaLivros n�o" +
                             " especificada:" + e.toString());
    }
  }


  public double getPrecoComDesconto() {
    return precoComDesconto;
  }

  public double getValorDoDesconto() {
    return valorDoDesconto;
  }

  protected void atualizarValoresDependentes() {
      precoComDesconto = preco - (preco * desconto);
      valorDoDesconto = preco - precoComDesconto;
  }

  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
    try {
      Context context = new InitialContext();
      dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Employee");
    } catch(Exception e) {
      throw new EJBException("Erro ao procurar DataSource:" + e.toString());
    }
  }
  public LivroPK ejbCreate(String id, String titulo, String autor, double preco, double desconto) throws CreateException {
    if (id == null || id.trim().equals("") ) {
      throw new CreateException( "id n�o especificado" );
    }
    this.id = id;
    this.titulo = titulo;
    this.autor = autor;
    this.preco = preco;
    this.desconto = desconto;
    atualizarValoresDependentes();
    try {
        // Checa se o objeto j� existe
        ejbFindByPrimaryKey(new LivroPK(id));

        // Se existe, � necessario lan�ar uma exce��o
        throw new DuplicateKeyException("Chave prim�ria j� existe");
    }
    catch(ObjectNotFoundException e) {
        // Pode-se criar o objeto
    }
    catch(FinderException fe) {
      new EJBException ( fe );
    }
    Connection con = null;
    PreparedStatement stmt = null;
    try {
        con = dataSource.getConnection();
        stmt = con.prepareStatement("INSERT INTO " + getNomeTabela() +
                                   " (Id, Titulo, Autor, Preco, Desconto)" +
                                   " VALUES (?, ?, ?, ?, ?)");
        stmt.setString(1, id);
        stmt.setString(2, titulo);
        stmt.setString(3, autor);
        stmt.setDouble(4, preco);
        stmt.setDouble(5, desconto);
        if (stmt.executeUpdate() != 1) {
            throw new CreateException("Erro ao adicionar linha");
        }
        stmt.close();
        stmt = null;
        con.close();
        con = null;
        return new LivroPK(id);
    }
    catch(SQLException e) {
        throw new EJBException("Erro ao executar INSERT em ejbCreate()", e);
    }
    finally {
        try {
            if (stmt != null) {
                stmt.close();
            }
        }
        catch(SQLException e) {
        }
        try {
            if (con != null) {
                con.close();
            }
        }
        catch(SQLException e) {
        }
    }
  }
  public void ejbPostCreate(String id, String titulo, String autor, double preco, double desconto) throws CreateException {
  }
}