package livraria;

import java.io.*;

public class LivroPK implements Serializable {



























  public String id;

  public LivroPK() {
  }

  public LivroPK(String id) {
    this.id = id;
  }
  public boolean equals(Object obj) {
    if (obj != null) {
      if (this.getClass().equals(obj.getClass())) {
        LivroPK that = (LivroPK) obj;
        return (((this.id == null) && (that.id == null)) || (this.id != null && this.id.equals(that.id)));
      }
    }
    return false;
  }
  public int hashCode() {
    return id.hashCode();
  }
}