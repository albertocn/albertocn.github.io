package livraria.jsp;

import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import livraria.LivroHome;

public abstract class AbstractLivroBean {

    protected LivroHome getLivroHome() throws NamingException {
        Context ic = new InitialContext();
        Object objref = ic.lookup("java:comp/env/ejb/Livro");
        return (LivroHome) PortableRemoteObject.narrow(objref,
                                                       LivroHome.class);
    }
}