package queue.jms;

import javax.jms.*;

public class ConsumidorQueue extends ClienteQueue {

  private QueueReceiver receiver;

  public ConsumidorQueue(String servidor, String fila) throws Exception {
    super (servidor, fila);
  }

  public void iniciar() throws Exception {
    receiver = session.createReceiver( queue );
    con.start();
    log("Conectado");
  }

  public void receber() throws Exception {
    ObjectMessage objMsg = (ObjectMessage) receiver.receive();
    log ("Objeto retirado da fila: " + objMsg.getObject());
    session.commit();
  }

  public void parar() throws Exception {
    con.close();
    log ("Desconectado");
  }

  public static void main(String[] args) throws Exception {
    ConsumidorQueue cf = new ConsumidorQueue("machadinho", "tesosd");
    cf.iniciar();
    cf.receber();
    cf.parar();
  }
}