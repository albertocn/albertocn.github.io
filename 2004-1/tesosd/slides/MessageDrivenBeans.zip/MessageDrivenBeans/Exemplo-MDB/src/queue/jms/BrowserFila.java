package queue.jms;

import java.util.*;
import javax.jms.*;

public class BrowserFila extends ClienteQueue {

  protected QueueBrowser browser;

  public BrowserFila( String servidor, String fila) throws Exception {
    super( servidor, fila );
    browser = session.createBrowser( queue );
  }

  public void iniciar() throws Exception {
    while (true) {
      log( "Checando a fila" );
      long cont = 0;
      Enumeration e = browser.getEnumeration();
      while (e.hasMoreElements()) {
        ObjectMessage objMsg = (ObjectMessage) e.nextElement();
        log( "Objeto na fila: " + objMsg.getObject() );
        cont++;
      }
      log ("Tamanho da fila: " + cont);
      log ("Dormindo");
      Thread.sleep(5000);
    }
  }

  public static void main(String[] args) throws Exception {
    BrowserFila bf = new BrowserFila ( "machadinho", "tesosd" );
    bf.iniciar();
  }
}
