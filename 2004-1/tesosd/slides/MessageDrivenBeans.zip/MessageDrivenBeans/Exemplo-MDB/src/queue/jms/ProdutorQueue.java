package queue.jms;

import java.io.Serializable;
import java.util.Date;
import javax.jms.*;

/**
 * Coloca mensagens em uma fila JMS
 */

public class ProdutorQueue extends ClienteQueue {

    protected QueueSender sender;

    public ProdutorQueue( String servidor, String fila) throws Exception {
      super( servidor, fila );
    }
    public void iniciar() throws Exception {
      sender = session.createSender( queue );
      con.start();
      log("Conectado");
    }

    public void enviar(Serializable obj) throws Exception {
      log ("Colocando objeto na fila: " + obj);
      ObjectMessage objMsg = session.createObjectMessage(obj);
      sender.send( objMsg );
      session.commit();
    }

    public void parar() throws Exception {
      con.close();
      log ("Desconectado");
    }

    public static void main(String[] args) throws Exception {
      ProdutorQueue r = new ProdutorQueue("machadinho", "tesosd");
      r.iniciar();
      r.enviar(new Date());
      r.enviar("Alberto");
      r.enviar(new Long(10));
      r.parar();
    }
}
