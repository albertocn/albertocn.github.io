package queue.jms;

import javax.naming.Context;
import javax.naming.InitialContext;

import java.util.Properties;

import javax.jms.*;

public class ClienteQueue {

  protected QueueConnection con;
  protected QueueSession session;
  protected Queue queue;

  public ClienteQueue( String servidor, String fila ) throws Exception {
    QueueConnectionFactory factory = (QueueConnectionFactory)
                          getContext( servidor ).lookup("ConnectionFactory");
    con = factory.createQueueConnection();
    session = con.createQueueSession(true, Session.AUTO_ACKNOWLEDGE);
    queue = session.createQueue( fila );
  }

  public Context getContext(String servidor) throws javax.naming.NamingException {
    Properties prop = new Properties();
    prop.setProperty(Context.INITIAL_CONTEXT_FACTORY,
                     "org.jnp.interfaces.NamingContextFactory");
    prop.setProperty( Context.URL_PKG_PREFIXES,
                     "org.jboss.naming:org.jnp.interfaces");
    prop.setProperty(Context.PROVIDER_URL,
                     servidor);
    return new InitialContext(prop);
  }

  public void log(String s) {
    System.out.println(s);
  }

}