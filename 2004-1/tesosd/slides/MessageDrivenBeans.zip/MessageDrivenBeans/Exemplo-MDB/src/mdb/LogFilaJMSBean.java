package mdb;

import javax.ejb.*;
import javax.jms.*;
import javax.naming.*;

public class LogFilaJMSBean
    implements MessageDrivenBean, MessageListener {
  MessageDrivenContext messageDrivenContext;
  public void ejbCreate() {}
  public void ejbRemove() {}
  public void onMessage(Message msg) {
    ObjectMessage objMsg = (ObjectMessage) msg;
    try {
      System.out.println("Objeto recebido: " + objMsg.getObject());
    } catch (JMSException e) {
      e.printStackTrace();
    }
  }
  public void setMessageDrivenContext(MessageDrivenContext messageDrivenContext) {
    this.messageDrivenContext = messageDrivenContext;
  }
}
