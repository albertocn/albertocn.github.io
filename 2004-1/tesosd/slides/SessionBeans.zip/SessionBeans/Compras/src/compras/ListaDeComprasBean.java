package compras;

import javax.ejb.*;
import java.util.*;

public class ListaDeComprasBean implements SessionBean {

  private SessionContext sessionContext;
  private Map itens = new HashMap();

  // ------------------- Remote ----------------

  public void adicionarItem(Item item) {

    if (itens.containsKey(item.getDescricao())) {

      // Obt�m o item existente
      Item existente = (Item) itens.remove(item.getDescricao());

      // Cria um novo item com a soma das quantidades
      Item novo = new Item(existente.getDescricao(),
                           existente.getQuantidade() +
                           item.getQuantidade());

      // Recoloca o item no mapa
      itens.put(novo.getDescricao(), novo);

    } else {
      // Coloca o item na lista
      itens.put(item.getDescricao(), item);
    }
  }

  public Collection getItens() {
    return new Vector(itens.values());
  }

  public void esvaziar() {
    itens.clear();
  }

  // -------------------- Home -----------------

  public void ejbCreate() {}

  // --------------- Ciclo de Vida -------------

  public void ejbRemove() {}
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void setSessionContext(SessionContext context) {
    sessionContext = context;
  }
}