package compras;

public class Item implements java.io.Serializable {

    private final String descricao;
    private final int quantidade;

    public Item(String descricao, int quantidade) {
        this.descricao = descricao;
        this.quantidade = quantidade;
    }

    public String getDescricao() {
        return descricao;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public boolean equals(Object o) {
        if (o instanceof Item) {
            Item outro = (Item) o;
            return descricao.equals(outro.getDescricao());
        } else {
            return false;
        }
    }
}