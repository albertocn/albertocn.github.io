package compras.web;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

import java.rmi.*;
import javax.ejb.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;

import compras.*;

public class ListaDeComprasServlet extends HttpServlet {

    public void doGet(HttpServletRequest request,
                      HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html; charset=\"iso-8859-1\"");
        PrintWriter out = response.getWriter();

        try {
            out.println(getResponse(request));
        } catch (Exception e) {
            e.printStackTrace(out);
        }
    }

    private String getResponse(HttpServletRequest req)
            throws Exception {

        return gerarPaginaListaDeCompras(req);
    }

    private String gerarPaginaListaDeCompras(HttpServletRequest req)
            throws Exception {
        StringBuffer resp = new StringBuffer();

        ListaDeCompras lista = obterListaDeCompras(req);

        if (req.getParameter("Tarefa") != null) {
            String tarefa = (String) req.getParameter("Tarefa");
            if (tarefa.equalsIgnoreCase("Adicionar")) {
                adicionarItem(lista, req);
            } else if (tarefa.equalsIgnoreCase("Esvaziar")) {
                lista.esvaziar();
            }
        }

        resp.append("<html>\n");
        resp.append("<head><title>Lista de Compras</title></head>\n");
        resp.append("<body>\n");

        resp.append(gerarTabelaItens(lista.getItens().iterator()));
        resp.append("<hr>\n");
        resp.append(gerarFormAdicionarItem(req));
        resp.append("<hr>\n");
        resp.append(getFormEsvaziar());

        resp.append("</body></html>");

        return resp.toString();
    }

    private void adicionarItem(ListaDeCompras lista, HttpServletRequest req)
            throws RemoteException {
        String descricao = (String) req.getParameter("Descricao");
        int quantidade = Integer.parseInt((String) req.getParameter("Quantidade"));

        lista.adicionarItem(new Item(descricao, quantidade));
    }

    private String gerarTabelaItens(Iterator it) {

        if (!it.hasNext()) {
            return "N�o h� itens na lista";
        }

        StringBuffer sb = new StringBuffer();

        sb.append("<table border=1>\n");
        sb.append("<tr>\n");
        sb.append("<th>Descri��o</th>\n");
        sb.append("<th>Quantidade</th>\n");
        sb.append("</tr>\n");

        while (it.hasNext()) {
            Item item = (Item) it.next();

            sb.append("<tr>\n");
            sb.append("<td>" + item.getDescricao() + "</td>\n");
            sb.append("<td>" + item.getQuantidade() + "</td>\n");
            sb.append("</tr>\n");
        }

        sb.append("</table>\n");

        return sb.toString();
    }

    private String gerarFormAdicionarItem(HttpServletRequest req) {
        StringBuffer sb = new StringBuffer();

        sb.append("<h3>Adicinar um item � lista:</h3>\n");
        sb.append("<form method=\"GET\" action=\"/Compras/ListaDeComprasServlet\">\n");
        sb.append("<input type=\"hidden\" name=\"Tarefa\" value=\"Adicionar\">\n");
        sb.append("<table border=\"0\">\n");
        sb.append("<tr>\n");
        sb.append("<td><b>Item:</b></td>\n");
        sb.append("<td><input type=\"text\" name=\"Descricao\" size=\"20\"></td>\n");
        sb.append("</tr>\n");
        sb.append("<tr>\n");
        sb.append("<td><b>Quantidade:</b></td>\n");
        sb.append("<td><input type=\"text\" name=\"Quantidade\" size=\"5\" value=\"1\"></td>\n");
        sb.append("</tr>\n");
        sb.append("</table>\n");
        sb.append("<p><input type=\"submit\" value=\"Adicionar\" name=\"Adicionar\">\n");
        sb.append("<input type=\"reset\" value=\"Limpar campos\" name=\"Limpar\"></p>\n");
        sb.append("</form>\n");

        return sb.toString();
    }

    private String getFormEsvaziar() {
        StringBuffer sb = new StringBuffer();

        sb.append("<form method=\"GET\" action=\"/Compras/ListaDeComprasServlet\">\n");
        sb.append("<input type=\"hidden\" name=\"Tarefa\" value=\"Esvaziar\">\n");
        sb.append("<p><input type=\"submit\" value=\"Esvaziar\" name=\"Esvaziar\">\n");
        sb.append("</form>\n");

        return sb.toString();
    }

    private ListaDeCompras obterListaDeCompras(HttpServletRequest req)
            throws NamingException, CreateException, RemoteException {

        final String NOME_ATTRIB = "ListaDeCompras";

        HttpSession session = req.getSession(true);

        ListaDeCompras lista;

        if (session.getAttribute(NOME_ATTRIB) == null) {
            lista = criarListaDeCompras();
            session.setAttribute(NOME_ATTRIB, lista);
        } else {
            // Checa se o Session Bean j� expirou. Caso tenha
            // acontedido, cria uma nova inst�ncia
            try {
                lista = (ListaDeCompras) session.getAttribute(NOME_ATTRIB);
                lista.getHandle();
            } catch(Exception e) {
                lista = criarListaDeCompras();
                session.setAttribute(NOME_ATTRIB, lista);
            }
        }
        return lista;
    }

    private ListaDeCompras criarListaDeCompras()
            throws NamingException, RemoteException, CreateException {

        Context initCtx = new InitialContext();

        Object objref = initCtx.lookup("java:comp/env/ejb/ListaDeCompras");
        ListaDeComprasHome home = (ListaDeComprasHome)
                PortableRemoteObject.narrow(objref,
                                            ListaDeComprasHome.class);
        return home.create();
    }
}
