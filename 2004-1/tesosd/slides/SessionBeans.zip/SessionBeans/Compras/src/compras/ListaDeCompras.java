package compras;

import java.rmi.*;
import javax.ejb.*;
import java.util.Collection;

public interface ListaDeCompras extends EJBObject {

    /**
     * Adiciona um Item � lista
     */
    void adicionarItem(Item item) throws RemoteException;

    /**
     * Retorna uma cole��o com os itens (inst�ncias da
     * classe Item) contidos na lista
     */
    Collection getItens() throws RemoteException;

    /**
     * Esvazia a lista de compras
     */
    void esvaziar() throws RemoteException;
}