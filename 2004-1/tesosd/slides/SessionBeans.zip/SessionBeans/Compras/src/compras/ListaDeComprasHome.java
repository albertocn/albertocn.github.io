package compras;

import javax.ejb.*;
import java.rmi.*;

public interface ListaDeComprasHome extends javax.ejb.EJBHome {
  /**
   * Cria uma lista de compras
   */
  ListaDeCompras create() throws RemoteException, CreateException;
}