package pagamento;

import java.rmi.*;
import java.sql.*;
import java.text.*;
import javax.ejb.*;
import javax.naming.*;
import javax.sql.*;

public class EfetuarPagamentoBean implements SessionBean {

  SessionContext sessionContext;

  // -------------------- Home -----------------

  public void ejbCreate() throws CreateException {}

  // --------------- Ciclo de Vida -------------

  public void ejbRemove() {}
  public void ejbActivate() {}
  public void ejbPassivate() {}
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
  }

  // -------------------- Remote -----------------

  public void comCheque(String nomeCliente, double valor) throws PagamentoException {

    validarCliente( nomeCliente );
    validarValorCheque( valor );

    Connection con = null;

    try {
      con = getConnection();

      PreparedStatement ps =  con.prepareStatement(
              "INSERT INTO TB_Pagamentos_Cheque " +
              "(Nome_Cliente, Valor, Data) " +
              "VALUES (?,?,?)");

      ps.setString(1, nomeCliente);
      ps.setDouble(2, valor);
      ps.setTimestamp(3, new Timestamp( System.currentTimeMillis() ) );

      ps.execute();
      ps.close();

    } catch (SQLException sqle) {
      throw new EJBException(sqle);
    } catch (NamingException ne) {
      ne.printStackTrace();
      throw new EJBException(ne);
    } finally {
      if (con != null) {
        try {
          con.close();
        } catch (SQLException e) {}
      }
    }
  }

  // ------------- Remote e Local ----------------

  public void comCartao(String nomeCliente, double valor, String numCartao) throws PagamentoException {

    validarCliente( nomeCliente );
    validarValorCartao( valor );
    validarNumeroCartao( numCartao );

    Connection con = null;

    try {
      con = getConnection();

      PreparedStatement ps =  con.prepareStatement(
              "INSERT INTO TB_Pagamentos_Cartao " +
              "(Nome_Cliente, Valor, Numero_Cartao, Data) " +
              "VALUES (?,?,?,?)");

      ps.setString(1, nomeCliente);
      ps.setDouble(2, valor);
      ps.setString(3, numCartao);
      ps.setTimestamp(4, new Timestamp( System.currentTimeMillis() ) );

      ps.execute();
      ps.close();

    } catch (SQLException sqle) {
      throw new EJBException(sqle);
    } catch (NamingException ne) {
      throw new EJBException(ne);
    } finally {
      if (con != null) {
        try {
          con.close();
        } catch (SQLException e) {}
      }
    }
  }

  // -------------------- Local ------------------

  public double total() {
    return 0;
  }

  // ---------- Privados ou Protegidos ---------

  protected void validarCliente(String nomeCliente) throws PagamentoException {
    if ( vazia (nomeCliente) ) {
      throw new PagamentoException( "Nome do cliente n�o preenchido" );
    }
  }

  protected void validarValorCheque(double valor) throws PagamentoException {
    if ( valor < getMinCheque() ) {
      throw new PagamentoException( "Valor muito baixo para usar cheque" );
    }
  }

  protected void validarValorCartao(double valor) throws PagamentoException {
    if ( valor > getMaxCartao() ) {
      throw new PagamentoException( "Valor muito alto para usar cart�o" );
    }
  }

  protected void validarNumeroCartao(String numCartao) throws PagamentoException {
    if ( vazia (numCartao) ) {
      throw new PagamentoException( "N�mero do cart�o n�o preenchido" );
    }
  }

  private boolean vazia (String s){
    return ( s == null || s.trim().equals("") );
  }

  protected Connection getConnection() throws SQLException, NamingException {
    Context ctx = new InitialContext();
    DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/Curso");
    return ds.getConnection();
  }

  protected double getMinCheque() {
    try {
      Context ctx = new InitialContext();
      Double valor = (Double) ctx.lookup("java:comp/env/minCheque");
      return valor.doubleValue();
    } catch (NamingException ne) {
      throw new EJBException( ne );
    }
  }

  protected double getMaxCartao() {
    try {
      Context ctx = new InitialContext();
      Double valor = (Double) ctx.lookup("java:comp/env/maxCartao");
      return valor.doubleValue();
    } catch (NamingException ne) {
      throw new EJBException( ne );
    }
  }

  private String formatarData(java.util.Date dt) {
    DateFormat df = new SimpleDateFormat("yyyyMMddHHmmssSSS");
    return df.format(dt);
  }
}