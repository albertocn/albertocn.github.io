package pagamento;

import javax.ejb.*;
import java.util.*;

public interface EfetuarPagamentoLocalHome extends javax.ejb.EJBLocalHome {
  public EfetuarPagamentoLocal create() throws CreateException;
}