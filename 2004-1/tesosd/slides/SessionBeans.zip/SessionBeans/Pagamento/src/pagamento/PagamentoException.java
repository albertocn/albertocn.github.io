package pagamento;

public class PagamentoException extends Exception {

  public PagamentoException(String msg) {
    super(msg);
  }
}