package pagamento;

import javax.ejb.*;
import java.util.*;

public interface EfetuarPagamentoLocal extends javax.ejb.EJBLocalObject {

  public void comCartao(String nomeCliente, double valor, String numCartao) throws PagamentoException;

  public double total();
}