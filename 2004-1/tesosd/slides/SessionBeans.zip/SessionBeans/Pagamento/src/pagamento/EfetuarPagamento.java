package pagamento;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import java.util.*;

public interface EfetuarPagamento extends javax.ejb.EJBObject {

  public void comCartao(String nomeCliente, double valor, String numCartao) throws PagamentoException, RemoteException;

  public void comCheque(String nomeCliente, double valor) throws PagamentoException, RemoteException;
}