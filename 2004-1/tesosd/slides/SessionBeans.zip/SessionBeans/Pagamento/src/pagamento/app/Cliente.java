package pagamento.app;

import java.util.Properties;
import java.rmi.RemoteException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.ejb.CreateException;
import javax.ejb.RemoveException;
import javax.rmi.PortableRemoteObject;

import pagamento.EfetuarPagamento;
import pagamento.EfetuarPagamentoHome;
import pagamento.PagamentoException;

public class Cliente {

    protected Context initialContext = null;
    protected EfetuarPagamentoHome home = null;
    protected EfetuarPagamento remote = null;

    public void pagarComCheque(String cliente, double valor)
            throws PagamentoException, RemoteException,
                   NamingException, CreateException {

        getEfetuarPagamento().comCheque(cliente, valor);
    }

    public void pagarComCartao(String cliente, double valor,
                               String numCartao)
            throws PagamentoException, RemoteException,
                   NamingException, CreateException {

        getEfetuarPagamento().comCartao(cliente, valor, numCartao);
    }

    public void removerBean()
            throws RemoteException, RemoveException {

        if (remote != null) {
            // Libera o Session Bean
            remote.remove();

            initialContext = null;
            home = null;
            remote = null;
        }
    }

    protected EfetuarPagamento getEfetuarPagamento()
            throws RemoteException, NamingException, CreateException {

        if (remote == null) {

            // Utiliza o Home para criar obter uma refer�ncia o
            // Session Bean
            remote = getEfetuarPagamentoHome().create();
        }
        return remote;
    }

    protected EfetuarPagamentoHome getEfetuarPagamentoHome()
            throws NamingException{

        if (home == null) {

            // Obt�m uma refer�ncia remota para o objeto que implementa
            // a interface Home e faz o cast
            Object objref = getContext().lookup("EfetuarPagamento");

            home = (EfetuarPagamentoHome)
                    PortableRemoteObject.narrow(objref,
                                                EfetuarPagamentoHome.class);
        }
        return home;
    }

    protected Context getContext() throws NamingException {

      if (initialContext == null) {
        Properties prop = new Properties();
        prop.setProperty(Context.INITIAL_CONTEXT_FACTORY,
                         "org.jnp.interfaces.NamingContextFactory");
        prop.setProperty( Context.URL_PKG_PREFIXES,
                         "org.jboss.naming:org.jnp.interfaces");
        prop.setProperty(Context.PROVIDER_URL,
                         "localhost" );

        initialContext = new InitialContext(prop);
      }

      return initialContext;
    }


    public static void main(String[] args) {
        try {
            Cliente c = new Cliente();

            String nomeCliente1 = "X";
            double valorEmCheque = 1000.0;

            String nomeCliente2 = "Y";
            double valorNoCartao = 2000.0;
            String numCartao = "489348903489033";

            // Pagamento com cheque
            c.pagarComCheque(nomeCliente1, valorEmCheque);
            System.out.println(nomeCliente1 + " - R$ " + valorEmCheque);

            // Pagamento com cart�o
            c.pagarComCartao(nomeCliente2, valorNoCartao, numCartao);
            System.out.println(nomeCliente2 + " - R$ " + valorNoCartao +
                               " -> Cartao: " + numCartao);

            c.removerBean();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}