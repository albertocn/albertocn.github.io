package pagamento;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface EfetuarPagamentoHome extends javax.ejb.EJBHome {
  public EfetuarPagamento create() throws CreateException, RemoteException;
}