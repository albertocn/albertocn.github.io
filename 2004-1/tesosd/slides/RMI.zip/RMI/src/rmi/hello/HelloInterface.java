package rmi.hello;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface HelloInterface extends Remote {

  public String getMsg() throws RemoteException;
}