package rmi.hello;

import java.net.InetAddress;
import java.net.UnknownHostException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Date;

import java.rmi.RemoteException;

import java.rmi.server.UnicastRemoteObject;

public class HelloServer
       extends UnicastRemoteObject
       implements HelloInterface {

  private static final DateFormat df = new SimpleDateFormat("dd/MM/yyyy kk:mm:ss.SSS");

  public HelloServer() throws RemoteException {
    super();
  }

  public String getMsg() throws RemoteException {
    try {
      return "[" + getDataHoraFormatados() + " em " + getNome() + "] Hello!";
    } catch (UnknownHostException e) {
      throw new RemoteException( "Erro ao obter nome do servidor", e );
    }
  }

  private String getDataHoraFormatados() {
    return df.format( new Date() );
  }

  private String getNome() throws UnknownHostException {
    return InetAddress.getLocalHost().getHostName();
  }
}