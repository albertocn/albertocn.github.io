package rmi.hello;

import java.net.MalformedURLException;

import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.RMISecurityManager;

public class HelloClient  {

  private HelloInterface helloIF;

  public HelloClient( String servidor, String nome )
      throws RemoteException, NotBoundException, MalformedURLException {
    executarLookup( servidor, nome );
  }

  private void executarLookup( String serv, String nome )
      throws RemoteException, NotBoundException, MalformedURLException {
    System.out.println("Fazendo lookup no servidor: " + serv );

    String url = "rmi://" + serv + ":1099/" + nome;
    System.out.println("URL: " + url);

    this.helloIF = (HelloInterface) Naming.lookup( url );
    System.out.println("Lookup de " + nome + " efetuado com sucesso" );
  }

  public void chamar() throws RemoteException {
    System.out.println( helloIF.getMsg() );
  }

  public static void main(String[] args) {
    String servidor = args[0];
    String nome = args[1];
    int chamadas = Integer.parseInt( args[2] );

    try {
      HelloClient hc = new HelloClient ( servidor, nome );
      long inicio = System.currentTimeMillis();
      for (int i = 0; i < chamadas; i++) {
        hc.chamar();
      }
      long fim = System.currentTimeMillis();
      System.out.println("Tempo total para " + chamadas + " chamadas: " +
                         (fim - inicio) + " ms");
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}