DROP TABLE TB_Transacoes;
CREATE TABLE dbo.TB_Transacoes (
  Id integer PRIMARY KEY
);