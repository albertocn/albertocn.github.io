package transacoes;

import java.rmi.*;
import java.sql.*;
import javax.ejb.*;
import javax.naming.*;
import javax.sql.*;

public class TransacaoBean implements SessionBean {

    protected SessionContext sessionContext;
    DuplicateKeyException e;


    // ------------------- Home -------------------

    public void ejbCreate() {}

    // --------------- Ciclo de Vida --------------

    public void ejbRemove() {}
    public void ejbActivate() {}
    public void ejbPassivate() {}
    public void setSessionContext(SessionContext context) {
        sessionContext = context;
    }


    // ------------ Protected e Private -------------

    protected Connection getConnection(int n) throws EJBException {
        try {
            Context context = new InitialContext();

            DataSource dataSource = (DataSource)
                    context.lookup("java:comp/env/jdbc/Transacoes" + n);

            return dataSource.getConnection();
        }
        catch(Exception e) {
            throw new EJBException("Erro ao procurar DataSource:" + e.toString());
        }
    }

    protected String getInsert(int id) throws EJBException {
        return "INSERT INTO " + getNomeTabela() + " (Id) VALUES (" + id + ")";
    }

    protected String getNomeTabela() throws EJBException {
        try {
            Context context = new InitialContext();
            return (String) context.lookup("java:comp/env/NomeTabelaTransacoes");
        }
        catch(Exception e) {
            throw new EJBException("Propriedade NomeTabelaTransacoes n�o" +
                                   " especificada:" + e.toString());
        }
    }
}