package transacoes;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface TransacaoU extends Transacao {
  public boolean inserirValores(int a, int b) throws RemoteException;
}