package transacoes;

import java.sql.*;
import javax.ejb.*;

public class TransacaoCBean extends TransacaoBean {

    // ------------------ Remote ------------------

    public boolean inserirValores(int a, int b) {

        Connection conA = null;
        Connection conB = null;

        try {
            conA = getConnection(1);
            conB = getConnection(2);

            Statement stmtA = conA.createStatement();
            Statement stmtB = conB.createStatement();

            stmtA.executeUpdate(getInsert(a));
            stmtB.executeUpdate(getInsert(b));

            return true;

        } catch (Exception e) {
            e.printStackTrace();
            sessionContext.setRollbackOnly();
            return false;
        }
    }
}