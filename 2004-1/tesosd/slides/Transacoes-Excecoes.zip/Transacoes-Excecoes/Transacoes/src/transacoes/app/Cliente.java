package transacoes.app;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import javax.rmi.PortableRemoteObject;

import transacoes.Transacao;
import transacoes.TransacaoCHome;
import transacoes.TransacaoUHome;

public class Cliente {

    public boolean testarTransacaoC(int a, int b) {
        try {
            Object objref = getContext().lookup("TransacaoC");

            TransacaoCHome home = (TransacaoCHome)
                    PortableRemoteObject.narrow(objref,
                                                TransacaoCHome.class);
            return testarTransacao(home.create(), a, b);

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean testarTransacaoU(int a, int b) {

        try {
            Object objref = getContext().lookup("TransacaoU");

            TransacaoUHome home = (TransacaoUHome)
                    PortableRemoteObject.narrow(objref,
                                                TransacaoUHome.class);
            return testarTransacao(home.create(), a, b);

        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    protected boolean testarTransacao(Transacao t, int a, int b) {
        try {
            return t.inserirValores(a, b);
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    protected Context getContext() throws NamingException {
      Properties prop = new Properties();

      prop.setProperty(Context.INITIAL_CONTEXT_FACTORY,
                       "org.jnp.interfaces.NamingContextFactory");

      prop.setProperty( Context.URL_PKG_PREFIXES,
                       "org.jboss.naming:org.jnp.interfaces");

      prop.setProperty(Context.PROVIDER_URL,
                       "machadinho" );

      return new InitialContext(prop);
    }


    public static void main(String[] args) {

        Cliente c = new Cliente();

        System.out.println("Testando o Bean com Transacao controlada pelo Container");

        System.out.println("Executando o teste com 1 e 2 ...");
        if (c.testarTransacaoC(1, 2)) {
            System.out.println("Ok: Executou um COMMIT");
        } else {
            System.out.println("Erro: Executou um ROLLBACK");
        }

        System.out.println("Executando o teste com 3 e 2 ...");
        if (!c.testarTransacaoC(3, 2)) {
            System.out.println("Ok: Executou um ROLLBACK");
        } else {
            System.out.println("Erro: Executou um COMMIT");
        }

        System.out.println("Testando o Bean com Transacao controlada pelo Usuario");

        System.out.println("Executando o teste com 4 e 5 ...");
        if (c.testarTransacaoU(4, 5)) {
            System.out.println("Ok: Executou um COMMIT");
        } else {
            System.out.println("Erro: Executou um ROLLBACK");
        }

        System.out.println("Executando o teste com 6 e 5 ...");
        if (!c.testarTransacaoU(6, 5)) {
            System.out.println("Ok: Executou um ROLLBACK");
        } else {
            System.out.println("Erro: Executou um COMMIT");
        }
  }
}