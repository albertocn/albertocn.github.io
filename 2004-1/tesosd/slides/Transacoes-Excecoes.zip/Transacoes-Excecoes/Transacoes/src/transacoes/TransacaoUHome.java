package transacoes;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

public interface TransacaoUHome extends EJBHome {
    public TransacaoU create() throws RemoteException, CreateException;
}