package transacoes;

import java.sql.*;
import javax.ejb.*;
import javax.naming.*;
import javax.transaction.*;

public class TransacaoUBean extends TransacaoBean {


    // ------------------ Remote ------------------

    public boolean inserirValores(int a, int b) {

        Connection conA = null;
        Connection conB = null;

        try {
            getUserTransaction().begin();

            conA = getConnection(1);
            conB = getConnection(2);

            Statement stmtA = conA.createStatement();
            Statement stmtB = conB.createStatement();

            stmtA.executeUpdate(getInsert(a));
            stmtB.executeUpdate(getInsert(b));

            getUserTransaction().commit();

            return true;

        } catch (Exception e) {
            try {
                getUserTransaction().rollback();
            } catch (SystemException se) {}

            return false;
        }
    }


    // ------------ Protected e Private -------------

    protected UserTransaction getUserTransaction() throws EJBException {
        try {
            Context ctx = new InitialContext();
            return (UserTransaction) ctx.lookup("java:comp/UserTransaction");
        }
        catch(Exception e) {
            throw new EJBException("Erro ao procurar UserTransaction:" +
                                   e.toString());
        }
    }
}