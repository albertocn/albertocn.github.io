package transacoes;

import java.rmi.*;
import javax.ejb.*;
import java.util.*;

public interface TransacaoCHome extends EJBHome {
    public TransacaoC create() throws RemoteException, CreateException;
}