package transacoes;

import java.rmi.*;
import javax.ejb.*;

public interface Transacao extends EJBObject {
    boolean inserirValores(int a, int b) throws RemoteException;
}