package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import java.util.Iterator;
import java.util.Map;

/**
 * Classe base para as classes que executam Statements,
 * PreparedStatements e CallableStatements
 */

public class ExecutarBase {

  protected final String nome;

  public ExecutarBase(String nome) {
    this.nome = nome;
  }

  protected void exibirResultSet( ResultSet rs ) throws SQLException {
    new ExibirResultSet (rs);
  }

  protected Connection criarConexao() {
    try {
      return FabricaConexoes.instance( nome );
    } catch (SQLException e) {
      do { e.printStackTrace();
      } while ( (e = e.getNextException()) != null );
    } catch (Exception e) {
      e.printStackTrace();
    }
    return null;
  }

  protected void preencherParams (PreparedStatement pstmt, Map params)
      throws SQLException {
    Iterator it = params.entrySet().iterator();
    while (it.hasNext()) {
      Map.Entry entry = (Map.Entry) it.next();
      int index = new Integer( entry.getKey().toString() ).intValue();
      Parametro param = (Parametro) entry.getValue();
      pstmt.setObject( index, param.getObject(), param.getTipoSQL() );
    }
  }
}