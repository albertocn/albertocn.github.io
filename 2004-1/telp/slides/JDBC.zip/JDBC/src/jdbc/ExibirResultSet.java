package jdbc;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

/**
 * Demonstra a utiliza��o de ResultSet, imprimindo todo seu conte�do.
 */

public class ExibirResultSet {

  public ExibirResultSet( ResultSet rs ) {
    try {
      ResultSetMetaData rsmd = rs.getMetaData();

      int numCols = rsmd.getColumnCount();

      imprimirNomesColunas( rsmd, numCols );
      imprimirLinhas( rs, numCols );

    } catch (SQLException e) {
      e.printStackTrace();
    }
  }

  protected void imprimirNomesColunas( ResultSetMetaData rsmd, int numCols )
      throws SQLException {
    for (int i = 1; i <= numCols; i++) {
       System.out.print(rsmd.getColumnName(i));
       if (i < numCols)
         System.out.print("; ");
    }
    System.out.println();
  }

  protected void imprimirLinhas( ResultSet rs, int numCols)
      throws SQLException {
    while (rs.next()) {
      for (int i = 1; i <= numCols; i++) {
        String s = rs.getString(i);
        System.out.print(s);
        if (i < numCols)
          System.out.print("; ");
      }
      System.out.println();
    }
  }
}