package poo;

import java.util.ArrayList;
import java.util.Collection;

public class Finalizador extends Object {

  private Collection col;

  public Finalizador() {
    System.out.println("Executando construtor");
    col = new ArrayList();
  }

  protected void finalize() throws Throwable {
    col = null;
    System.out.println("Executando finalizador");
    super.finalize();
  }

  public static void main(String[] args) {
    new Finalizador();
//    System.gc();
  }
}