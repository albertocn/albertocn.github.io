package poo;

public class Circulo extends Forma {

  protected double r;

  public Circulo( double x, double y, double r ) {
    super( x, y );
    this.r = r;
  }

  public double area() {
    return Math.PI * r * r;
  }

  public String toString() {
    return "[Circulo]: " + super.toString() + ", r = " + r;
  }
}