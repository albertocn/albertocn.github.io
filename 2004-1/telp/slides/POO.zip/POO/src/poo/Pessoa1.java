package poo;

class Pessoa1 {

  // Atributos
  String nome;
  int idade;

  // Construtor
  Pessoa1( String n, int i ) { nome = n; idade = i; }

  // M�todos
  String getNome() { return nome; }
  int getIdade() { return idade; }
  void setNome(String novoNome) { nome = novoNome; }
}
