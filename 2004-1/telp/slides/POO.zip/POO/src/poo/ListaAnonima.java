package poo;
import java.util.*;

public class ListaAnonima implements Lista {
    List lista = new LinkedList();

    // Adiciona um elemento � lista
    public void add(Object o) {
        lista.add(o);
    }
    // Retorna um objeto que pode enumerar os elementos da lista
    public Enumeration elementos() {

        // Retorna uma classe an�nima
        return new Enumeration() {

            private List copia = new LinkedList();

            // Faz uma c�pia da lista em um inicializador de
            // inst�ncia pois n�o � poss�vel definir 
            // construtores em classes an�nimas
            {
                for (int i = 0; i < lista.size(); i++) {
                    copia.add(i, lista.get(i));
                }
            }

            // Retorna true se ainda h� algum elemento
            public boolean hasMoreElements() {
                return copia.size() > 0;
            }
            // Retorna o pr�ximo elemento
            public Object nextElement() {
                return copia.remove(0);
            }
        };
    }
}