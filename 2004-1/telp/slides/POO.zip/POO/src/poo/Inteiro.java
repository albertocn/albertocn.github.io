package poo;

public class Inteiro {

  private int valor;

  public Inteiro ( int valor ) {
    this.valor = valor;
  }

  public int getValor() { return valor; }

  public Inteiro somar ( int valor ) {
    this.valor += valor;
    return this;
  }

  public static void main(String[] args) {
    Inteiro i = new Inteiro( 0 );
    i.somar( 1 )
     .somar( 2 )
     .somar( 10 );
    System.out.println( "Inteiro: " + i.getValor() );
  }
}