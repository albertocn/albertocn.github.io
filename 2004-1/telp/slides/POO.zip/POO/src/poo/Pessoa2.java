package poo;

public class Pessoa2 {

  // Atributos
  protected String nome;
  private int idade;

  // Construtor
  public Pessoa2( String n, int i ) { nome = n; idade = i; }

  // M�todos
  public String getNome() { return nome; }
  public int getIdade() { return idade; }
  public void setNome(String novoNome) { nome = novoNome; }
}
