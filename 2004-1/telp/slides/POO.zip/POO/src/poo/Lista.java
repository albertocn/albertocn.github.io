package poo;
import java.util.*;

public interface Lista {
    // Adiciona um elemento � lista
    void add(Object o);

    // Retorna um objeto que pode enumerar os elementos da lista
    Enumeration elementos();
}