package poo;

public abstract class Forma {

  protected double x, y;

  public Forma ( double x, double y ) {
    this.x = x;
    this.y = y;
  }

  public abstract double area();

  public String toString() {
    return "x = " + x + ", y = " + y;
  }
}