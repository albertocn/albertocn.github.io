package poo;

public class Quadrado extends Forma {

  protected double lado;

  public Quadrado( double x, double y, double lado ) {
    super( x, y );
    this.lado = lado;
  }

  public double area() {
    return lado * lado;
  }

  public String toString() {
    return "[Quadrado]: " + super.toString() + ", lado = " + lado;
  }
}