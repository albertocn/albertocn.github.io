package poo;
import java.util.*;

public class ListaMembro implements Lista {
    List lista = new LinkedList();

    // Adiciona um elemento � lista
    public void add(Object o) {
        lista.add(o);
    }
    // Retorna um objeto que pode enumerar os elementos da lista
    public Enumeration elementos() {
        return new EnumerationMembro();
    }

    // Classe membro
    class EnumerationMembro implements Enumeration {
        private List copia = new LinkedList();

        // Faz uma c�pia da lista
        public EnumerationMembro() {
            for (int i = 0; i < lista.size(); i++) {
                copia.add(i, lista.get(i));
            }
        }
        // Retorna true se ainda h� algum elemento
        public boolean hasMoreElements() {
            return copia.size() > 0;
        }
        // Retorna o pr�ximo elemento
        public Object nextElement() {
            return copia.remove(0);
        }
    }
}