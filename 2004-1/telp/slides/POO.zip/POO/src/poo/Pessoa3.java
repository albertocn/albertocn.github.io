package poo;

public class Pessoa3 {

  // Atributos
  protected String nome;
  private int idade;

  // Construtor padr�o
  public Pessoa3() {
    nome = "Alberto";
    idade = 26;
  }

  // Construtor com todos os atributos
  public Pessoa3( String n, int i ) {
    nome = n;
    idade = i;
  }

  // M�todos
  public String getNome() { return nome; }
  public int getIdade() { return idade; }
  public void setNome(String novoNome) { nome = novoNome; }

  public String toString() {
    return "Nome: " + nome + ", Idade: " + idade;
  }

  public static void main(String[] args) {
    Pessoa3 p1 = new Pessoa3();
    Pessoa3 p2 = new Pessoa3( "Jos�", 20 );

    System.out.println( p1.getNome() + " tem " + p1.getIdade() + " anos");
    System.out.println( p2.getNome() + " tem " + p2.getIdade() + " anos");
  }
}
