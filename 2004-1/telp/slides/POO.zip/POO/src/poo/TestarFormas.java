package poo;

public class TestarFormas {

  public TestarFormas( Forma[] formas ) {
    imprimir( formas );
    imprimirArea( formas );
  }

  private void imprimirArea ( Forma[] formas ) {
    for (int i = 0; i < formas.length; i++) {
      System.out.println( "Area de formas[" + i +"] = " + formas[i].area() );
    }
  }

  private void imprimir ( Forma[] formas ) {
    for (int i = 0; i < formas.length; i++) {
      System.out.println( formas[i] );
    }
  }

  public static void main(String[] args) {
    Forma[] formas = new Forma[2];
    formas[0] = new Circulo( 1, 2, 3 );
    formas[1] = new Quadrado( 4, 5, 8 );
    new TestarFormas( formas );
  }
}