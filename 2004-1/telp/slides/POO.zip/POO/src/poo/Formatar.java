package poo;

import java.text.DateFormat;
import java.text.SimpleDateFormat;

import java.util.Date;

public class Formatar {

  private static DateFormat df = new SimpleDateFormat( "dd/MM/yyyy" );

  public static String getData( Date data ) {
    return df.format( data );
  }

  public static String espacos ( int n ) {
    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < n; i++)
      sb.append( ' ' );
    return sb.toString();
  }

  public static void main(String[] args) {
    System.out.println("Data:" + Formatar.espacos(2) + Formatar.getData( new Date() ) );
  }
}