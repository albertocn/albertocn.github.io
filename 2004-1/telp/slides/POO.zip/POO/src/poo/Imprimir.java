package poo;

public class Imprimir {
    public static void main(String[] args) {
        Imprimivel[] imprimiveis = new Imprimivel[10];

        imprimiveis[0] = new Linha();

        for (int i = 1; i < imprimiveis.length; i++) {
            if (i < imprimiveis.length / 2) {
                imprimiveis[i] = new Retangulo(i, 2*i);
            } else {
                imprimiveis[i] = new Quadrado2(i);
            }
        }

        for (int i = 0; i < imprimiveis.length; i++) {
            imprimiveis[i].print();
        }
    }
}

abstract class FiguraGeometrica {
    public abstract int area();
    public abstract int perimetro();
}

interface Imprimivel {
    void print();
}

class Retangulo extends FiguraGeometrica implements Imprimivel {
    private int a, b;
    public Retangulo(int a, int b) {
        this.a = a; this.b = b;
    }
    public int area() { return a*b; };
    public int perimetro() { return (2*a) + (2*b); };
    public void print() {
        System.out.println("Retangulo (" + a + "," + b + ")");
    }
}

class Quadrado2 extends FiguraGeometrica implements Imprimivel {
    private int l;
    public Quadrado2(int l) { this.l = l; }
    public int area() { return l*l; };
    public int perimetro() { return 4*l; };
    public void print() {
        System.out.println("Quadrado (" + l + ")");
    }
}

class Linha implements Imprimivel {
    public void print() {
        for (int i = 0; i < 60; i++) {
            System.out.print("=");
        }
        System.out.print("\n");
    }
}