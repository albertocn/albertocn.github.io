package poo;

import java.util.Calendar;
import java.util.Date;

public class Cliente extends Pessoa3 {

  private String cpf;

  public Cliente( String cpf, String nome, int idade ) {
    super( nome, idade );
    this.cpf = cpf;
  }

  public String getCpf() { return cpf; }

  public int getAnoNascimento() {
    Calendar cal = Calendar.getInstance();
    cal.setTime( new Date() );
    cal.roll( Calendar.YEAR, - getIdade() );
    return cal.get( Calendar.YEAR );
  }

  public String toString() {
    return "CPF: " + cpf + ", " + super.toString();
  }

  public String toString2() {
    return "[CPF:" + cpf + ", " + super.toString() + "]";
  }

  public static void main(String[] args) {
    Cliente c = new Cliente ( "123.456.789-00", "Jos�", 30 );
    System.out.println( "CPF: " + c.getCpf() );
    System.out.println( "Nome: " + c.getNome() );
    System.out.println( "Idade: " + c.getIdade() );
    System.out.println( "Ano de nascimento: " + c.getAnoNascimento() );
    System.out.println(c);
    System.out.println(c.toString2());
  }
}