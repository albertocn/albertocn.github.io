package b;

public class ClasseB {
  public void metodoPublicoB() {}
  private void metodoPrivadoB() {}
  protected void metodoProtegidoB() {}
  void metodoPacoteB() {}
}