package a;

public class ClasseA {
  public void metodoPublicoA() {}
  private void metodoPrivadoA() {}
  protected void metodoProtegidoA() {}
  void metodoPacoteA() {}
}