package a;

import b.ClasseB;

public class TesteVisibilidade1 {

  public TesteVisibilidade1() {
    chamarA();
    chamarB();
  }

  private void chamarB() {
    ClasseB objB = new ClasseB();
    objB.metodoPublicoB();
  }

  private void chamarA() {
    ClasseA objA = new ClasseA();
    objA.metodoPublicoA();
    objA.metodoPacoteA();
    objA.metodoProtegidoA();
  }
}