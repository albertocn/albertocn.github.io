package a;

import b.ClasseB;

public class TesteVisibilidade2 extends ClasseB {

  public TesteVisibilidade2() {
    chamarA();
    chamarB();

    this.metodoPublicoB();
    this.metodoProtegidoB();
  }

  private void chamarB() {
    ClasseB objB = new ClasseB();
    objB.metodoPublicoB();
  }

  private void chamarA() {
    ClasseA objA = new ClasseA();
    objA.metodoPublicoA();
    objA.metodoPacoteA();
    objA.metodoProtegidoA();
  }
}
