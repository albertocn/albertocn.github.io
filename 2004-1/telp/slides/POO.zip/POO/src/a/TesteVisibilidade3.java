package a;

import b.ClasseB;

public class TesteVisibilidade3 extends ClasseA {

  public TesteVisibilidade3() {
    chamarA();
    chamarB();

    this.metodoPublicoA();
    this.metodoProtegidoA();
    this.metodoPacoteA();
  }

  private void chamarB() {
    ClasseB objB = new ClasseB();
    objB.metodoPublicoB();
  }

  private void chamarA() {
    ClasseA objA = new ClasseA();
    objA.metodoPublicoA();
    objA.metodoPacoteA();
    objA.metodoProtegidoA();
  }
}

