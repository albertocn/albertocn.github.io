package estruturascontrole;

/**
 * Demonstra a utiliza��o de do while
 */
public class ImprimirMeses2 {

  public void imprimir(int ano) {
    System.out.println( "Ano: " + ano );
    int mes = 1;
    do {
      int dias = DiasNoMes.obter(ano, mes);
      System.out.println("M�s " + mes + " => " + dias + " dias");
    } while (++mes <= 12);
  }

  public static void main(String[] args) {
    ImprimirMeses2 imp = new ImprimirMeses2();
    imp.imprimir( 2000 );
  }
}
