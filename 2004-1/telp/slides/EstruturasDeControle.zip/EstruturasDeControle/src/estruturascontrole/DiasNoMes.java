package estruturascontrole;

import java.util.Calendar;

/**
 * Demonstra a utiliza��o do switch
 */
public class DiasNoMes {

  public static int obter(int ano, int mes) {
      int numDias = -1;

      switch (mes) {
          case 1:   // Janeiro
          case 3:   // Mar�o
          case 5:   // Maio
          case 7:   // Julho
          case 8:   // Agosto
          case 10:  // Outubro
          case 12:  // Dezembro
              numDias = 31;
              break;
          case 4:   // Abril
          case 6:   // Junho
          case 9:   // Setembro
          case 11:  // Novembro
              numDias = 30;
              break;
          case 2:   // Fevereiro
              if ( ((ano % 4 == 0) && !(ano % 100 == 0))
                   || (ano % 400 == 0) )
                   numDias = 29;
              else
                  numDias = 28;
              break;
          default:
              numDias = 0;
              break;
      }
      return numDias;
  }

  public static int obterDiasNoMesAtual() {
    Calendar c = Calendar.getInstance();
    int ano = c.get( c.YEAR );
    int mes = c.get( c.MONTH ) + 1;
    return DiasNoMes.obter(ano, mes);
  }

  public static void main(String[] args) {
    System.out.println("Dias no m�s atual: " + DiasNoMes.obterDiasNoMesAtual());
  }
}

