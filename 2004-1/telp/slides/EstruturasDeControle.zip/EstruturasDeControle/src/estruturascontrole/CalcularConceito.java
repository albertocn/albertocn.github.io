package estruturascontrole;

import javax.swing.JOptionPane;

/**
 * Demonstra a utiliza��o do comando if
 */
public class CalcularConceito {

  public float solicitarNota() {
    String notaStr = JOptionPane.showInputDialog( null,
                                                 "Digite uma nota de 0 a 10",
                                                 "Entrada de nota",
                                                 JOptionPane.QUESTION_MESSAGE);
    return Float.parseFloat( notaStr );
  }

  public char obterConceito( float nota ) {

    if (nota < 0.0 || nota > 10) {
      System.err.println ( "Nota (" + nota + ") n�o est� entre 0 e 10");
      System.exit(1);
    }

    char conceito;

    if (nota >= 9.0) {
       conceito = 'A';
    } else if (nota >= 8.0) {
       conceito = 'B';
    } else if (nota >= 7.0) {
       conceito = 'C';
    } else if (nota >= 6.0) {
       conceito = 'D';
    } else {
       conceito = 'E';
    }
    return conceito;
  }

  public void exibirConceito( char conceito ) {
    JOptionPane.showMessageDialog( null,
                                   "Conceito: " + conceito,
                                   "Resultado",
                                   JOptionPane.INFORMATION_MESSAGE);
  }

  public static void main(String[] args) {
    CalcularConceito calc = new CalcularConceito();
    float notaLida = calc.solicitarNota();
    calc.exibirConceito( calc.obterConceito( notaLida ) );
    System.exit(0);
    }
}
