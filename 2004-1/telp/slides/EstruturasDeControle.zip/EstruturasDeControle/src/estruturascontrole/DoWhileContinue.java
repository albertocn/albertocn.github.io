package estruturascontrole;

/**
 * Demonstra a utiliza��o do comando continue.
 *
 * Imprime os dez primeiros n�meros positivos que s�o divis�veis por 3
 */
public class DoWhileContinue {
  public static void main(String[] args) {
    int totalDeAchados = 0, atual = -1;
    long[] divisores = new long[10];

    do {
      atual++;

      // Testa se o n�mero atuaal � divis�vel por 3 e se for
      // o coloca no array de divisores. Caso contr�rio,
      //  reinicia o la�o
      if (atual % 3 == 0) {
        divisores[totalDeAchados] = atual;
        totalDeAchados++;
      } else
        continue;

      // Imprime os que j� foram encontrados
      System.out.print("Encontrados: ");
      for (int j = 0; j < totalDeAchados - 1; j++) {
        System.out.print(divisores[j] + ",");
      }
      System.out.println(divisores[totalDeAchados - 1]);

    } while (totalDeAchados != 10);
  }
}