package estruturascontrole;

/**
 * Demonstra a utiliza��o do break em um la�o for com label
 */
public class ForBreakLabel {
    public static void main(String[] args) {
        int cont = 0, i = 0, j = 0;
        long rand = Math.round( Math.random() * 100);
        System.out.println("rand=" + rand);

        laco_i:
        for (i = 0 ; i < 10; i++) {
            for (j = 0; j < 10; j++) {
                if (cont == rand) {
                    break laco_i;
                }
                cont++;
            }
        }
        System.out.println("Parou quando i = " + i + " e j = " + j);
    }
}