package estruturascontrole;

/**
 * Demonstra a utiliza��o do comando break em um la�o while
 */

public class WhileBreak {
    public static void main(String[] args) {
        int cont = 0;
        while (true) {
            cont++;
            if (cont == 1000) {
                break;
            }
        }
        System.out.println("Executou " + cont + " vezes");
    }
}

