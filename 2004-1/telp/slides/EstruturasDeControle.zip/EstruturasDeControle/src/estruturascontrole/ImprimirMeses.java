package estruturascontrole;

/**
 * Demonstra a utiliza��o do while
 */
public class ImprimirMeses {

  public void imprimir(int ano) {
    System.out.println( "Ano: " + ano );
    int mes = 0;
    while (mes++ < 12) {
      int dias = DiasNoMes.obter(ano, mes);
      System.out.println("M�s " + mes + " => " + dias + " dias");
    }
  }

  public static void main(String[] args) {
    ImprimirMeses imp = new ImprimirMeses();
    imp.imprimir( 2000 );
  }
}

