package estruturascontrole;

/**
 * Demonstra a utiliza��o do for
 */
public class ImprimirMeses3 {

  public void imprimir(int ano) {
    System.out.println( "Ano: " + ano );
    for (int mes = 1; mes <= 12; mes++) {
      int dias = DiasNoMes.obter(ano, mes);
      System.out.println("M�s " + mes + " => " + dias + " dias");
    }
  }

  public static void main(String[] args) {
    ImprimirMeses3 imp = new ImprimirMeses3();
    imp.imprimir( 2000 );
  }
}
