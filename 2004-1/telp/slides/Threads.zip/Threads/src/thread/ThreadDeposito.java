package thread;

/**
 * Thread que efetua um dep�sito de um valor em uma conta.
 */
public class ThreadDeposito extends Thread {

   private Conta conta;
   private long valor;

   /**
    * Construtor
    * @param conta Conta na qual ser� efetuado o dep�sito
    * @param valor Valor a ser depositado na conta
    */
   public ThreadDeposito( Conta conta, long valor ) {
      this.conta = conta;
      this.valor = valor;
   }

   /** Executa o dep�sito na conta */
   public void run() {
      conta.depositar( valor );
   }
}