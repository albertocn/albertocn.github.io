package thread;

/**
 * Exibe as Threads executando atualmente no sistema.
 */
public class ThreadsNoProcesso {

  /** Exibe todas as threads ativas atualmente */
  public void exibirThreads() {
    ThreadGroup tg = Thread.currentThread().getThreadGroup().getParent();

    int numThreads = tg.activeCount();
    Thread[] threads = new Thread[numThreads];

    tg.enumerate( threads );
    for (int i = 0; i < numThreads; i++) {
      System.out.println("Thread #" + i + " = " + threads[i].getName() +
                         " | Grupo: " + getHierarquia( threads[i].getThreadGroup() ) );
    }
  }

  /** Retorna uma string que mostra a hierarquia dos grupos de Thread */
  private String getHierarquia (ThreadGroup tg) {
    if (tg == null)
      return "";
    else {
      if (tg.getParent() == null)
        return tg.getName();
      else
        return tg.getName() + " << " + getHierarquia( tg.getParent() );
    };
  }

  public static void main ( String[] args ) {
    ThreadGroup tgA = new ThreadGroup( "grupoA" );
    Thread tA = new ThreadSleep(tgA, "A");
    tA.start();

    ThreadGroup tgB = new ThreadGroup( tgA, "grupoB");
    Thread tB = new ThreadSleep(tgB, "B");
    tB.start();

    Thread tX = new ThreadSleep("X");
    tX.start();

    ThreadsNoProcesso ts = new ThreadsNoProcesso();
    ts.exibirThreads();
  }
}

class ThreadSleep extends Thread {

  public static final long TEMPO = 2000;

  public ThreadSleep(String n) {
    super(n);
  }

  public ThreadSleep(ThreadGroup tg, String n) {
    super(tg, n);
  }

  public void run() {
    try {
      sleep( TEMPO );
    } catch (InterruptedException ie) {}
  }
}
