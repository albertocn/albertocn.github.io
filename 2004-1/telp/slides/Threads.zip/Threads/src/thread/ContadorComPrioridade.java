package thread;

/**
 * Demonstra a especifica��o de Prioridades em Threads.
 */
public class ContadorComPrioridade implements Runnable {

  /** N�mero de itera��es que ser�o executadas */
  private static final int NUM_ITERACOES = 100;

  // Valor do contador
  private long valor = 0;

  // Tempo a Thread ficar� dormindo
  private long intervalo;

  /**
   * Construtor
   *
   * @param intervalo Intervalo de tempo que a Thread permanecer� dormindo
   *                  entre as opera��es de incremento.
   */
  public ContadorComPrioridade( long intervalo ) {
    this.intervalo = intervalo;
  }

  /**
   * Executa um la�o o n�mero de vez indicadas por NUM_ITERACOES, incrementa
   * o valor e coloca a Thread corrente para dormir.
   */
  public void run() {
    for (int i = 0; i < NUM_ITERACOES; i++)
    {
      synchronized (this) {
        valor++;
        try {
          Thread.currentThread().sleep( intervalo );
        } catch (InterruptedException ie) {}
      }
    }
  }

  /**
   * Retorna o valor do contador
   * @return Valor do contador
   */
  public synchronized long getValor() {
    return valor;
  }

  public static void main(String[] args) {
    ContadorComPrioridade contMin = new ContadorComPrioridade(10);
    ContadorComPrioridade contMax = new ContadorComPrioridade(10);

    Thread tMinPrio = new Thread ( contMin );
    Thread tMaxPrio = new Thread ( contMax );

    tMinPrio.setPriority( Thread.MIN_PRIORITY );
    tMaxPrio.setPriority( Thread.MAX_PRIORITY );

    tMinPrio.start();
    tMaxPrio.start();

    while ( tMinPrio.isAlive() || tMaxPrio.isAlive() ) {
      long min = contMin.getValor();
      long max = contMax.getValor();
      System.out.println("Min = " + min + " | Max = " + max);
      try {
        Thread.currentThread().sleep( 50 );
      } catch (InterruptedException ie) {}
    }
  }
}