package thread;

import javax.swing.JOptionPane;

/**
 * Simula v�rios dep�sitos sobre uma mesma conta.
 */
public class SimulacaoDepositos {

  /** Valor de cada dep�sito */
  private static final long VALOR_DEPOSITO = 1;

  /** Inicia os dep�sitos e exibe ao final o saldo da conta */
  public void iniciar() {
     Conta conta = criarConta();
     esperarDepositos ( criarThreadsDeposito( conta ) );
     System.out.println( "Saldo saldo atual = " + conta.getSaldo() );
  }

   /** Factory Method que retorna a conta sobre a qual ser�o feitos dep�sitos */
   private Conta criarConta() {
      return deveSincronizar() ? new ContaSincronizada() : new Conta();
   }

   /** Exibe uma janela solicitando uma confirma��o para sincronizar */
   private static boolean deveSincronizar() {
      Object[] opcoes = { "Sim", "N�o" };
      int resp = JOptionPane.showOptionDialog ( null
                                              , "Sincronizar?"
                                              , "Confirmar sincroniza��o"
                                              , JOptionPane.DEFAULT_OPTION
                                              , JOptionPane.QUESTION_MESSAGE
                                              , null
                                              , opcoes
                                              , opcoes[1] );

      return resp == JOptionPane.YES_OPTION;
   }

   /** Cria e inicia as threads que ir�o executar os dep�sitos */
   private ThreadDeposito[] criarThreadsDeposito( Conta conta ) {
      ThreadDeposito[] threadsDeposito = new ThreadDeposito[10];

      for (int i = 0; i < threadsDeposito.length; i++) {
         threadsDeposito[i] = new ThreadDeposito( conta, VALOR_DEPOSITO );
         threadsDeposito[i].start();
      }

      return threadsDeposito;
   }

   /** Espera a conclus�o dos dep�sitos */
   private void esperarDepositos ( ThreadDeposito[] threadsDeposito )
   {
      while (true) {
         boolean depositosEncerraram = true;
         for (int i = 0; i < threadsDeposito.length; i++) {
             if (threadsDeposito[i].isAlive()) {
                depositosEncerraram = false;
                break;
             }
         }
         if (depositosEncerraram) {
             break;
         }
      }
   }

   public static void main(String[] argv) {
      SimulacaoDepositos simulacao = new SimulacaoDepositos();
      simulacao.iniciar();
      System.exit(0);
   }
}